# Guide d'Intégration Lygospay - Martama

## Vue d'ensemble

Martama utilise Lygospay comme passerelle de paiement pour permettre aux clients africains de payer facilement via Mobile Money et d'autres méthodes locales.

## Architecture de l'Intégration

### 1. Frontend (React)

#### Pages principales :
- **ProductDetail.tsx** : Initie le paiement en appelant `/api/create-lygos-payment`
- **LygosSuccess.tsx** : Page de redirection après paiement réussi
- **LygosFailure.tsx** : Page de redirection après paiement échoué/annulé

### 2. Backend (Cloudflare Worker)

#### Routes API (`src/worker/routes/lygos.ts`) :

1. **POST `/api/create-lygos-payment`**
   - Crée une commande en base de données avec statut "pending"
   - Appelle l'API Lygospay pour créer une passerelle de paiement
   - Retourne l'URL de redirection Lygospay au frontend

2. **GET `/api/verify-lygos-payment/:orderId`**
   - Vérifie le statut du paiement directement auprès de Lygospay
   - Met à jour la commande si le paiement est confirmé
   - Gère les commissions d'affiliation
   - Crée le compte utilisateur si nécessaire

3. **POST `/api/webhook/lygospay`**
   - Reçoit les notifications serveur-à-serveur de Lygospay
   - Vérifie TOUJOURS le statut avec l'API Lygospay (sécurité)
   - Met à jour la commande et octroie l'accès au produit

## Flux de Paiement

```
1. Client clique sur "Commander" → ProductDetail.tsx
2. Frontend appelle /api/create-lygos-payment → Backend crée commande + passerelle Lygospay
3. Frontend redirige vers URL Lygospay → Client effectue le paiement
4. Lygospay redirige vers /lygos-success ou /lygos-failure
5. LygosSuccess.tsx appelle /api/verify-lygos-payment/:orderId
6. Backend vérifie avec API Lygospay et met à jour la commande
7. (En parallèle) Webhook Lygospay notifie /api/webhook/lygospay
```

## Configuration Requise

### 1. Variables d'Environnement

Dans votre tableau de bord Mocha (Settings > Environment Variables) :

```
LYGOS_PAY_API_KEY=votre_clé_api_lygospay
```

### 2. Configuration du Webhook Lygospay

Dans votre tableau de bord Lygospay, configurez l'URL du webhook :

```
https://martama.site/api/webhook/lygospay
```

**Important** : Cette URL DOIT être accessible publiquement pour que Lygospay puisse envoyer les notifications.

### 3. URLs de Redirection

Les URLs de succès et d'échec sont configurées automatiquement par le backend :

- **Success URL** : `https://martama.mocha.app/lygos-success?order_id={ORDER_ID}`
- **Failure URL** : `https://martama.mocha.app/lygos-failure?order_id={ORDER_ID}`

## Sécurité

### Principe de Vérification à Deux Niveaux

1. **Vérification Frontend** : Après redirection, la page de succès vérifie le paiement
2. **Webhook Backend** : Lygospay notifie directement le serveur

**CRITIQUE** : Le backend ne fait JAMAIS confiance uniquement au webhook. Il vérifie toujours le statut en appelant directement l'API Lygospay GET `/v1/gateway/payin/{order_id}`.

### Protection contre les Webhooks Dupliqués

- Chaque webhook a un `event_id` unique stocké en base de données
- Les webhooks dupliqués sont ignorés automatiquement

## Gestion des Affiliés

Lorsqu'un paiement est confirmé avec un code promo d'affilié :

1. Une commission est créée dans la table `commissions`
2. Le solde de l'affilié est mis à jour
3. L'historique d'achat du client est enregistré
4. Les achats ultérieurs ont des taux de commission dégressifs :
   - 1er achat : taux plein (défini sur le produit)
   - 2ème achat : taux divisé par 2
   - 3ème achat et plus : 5% fixe

## Activation de Lygospay

Pour activer Lygospay sur Martama :

1. Allez dans le tableau de bord Admin
2. Cliquez sur "Passerelles de Paiement"
3. Activez "Lygos"

Une fois activé, les clients seront automatiquement redirigés vers Lygospay lors du paiement.

## Statuts de Commande

- **pending** : Commande créée, paiement en attente
- **paid** : Paiement confirmé par Lygospay
- **delivered** : Accès livré au client par l'admin
- **cancelled** : Paiement échoué ou annulé

## Débogage

### Logs à consulter :

1. **Console du Worker** : Erreurs API, webhooks reçus
2. **Table `lygos_webhooks`** : Historique de tous les webhooks reçus
3. **Table `orders`** : Statut et détails de chaque commande

### Problèmes courants :

**Le paiement ne se confirme pas** :
- Vérifiez que la clé API Lygospay est correcte
- Vérifiez que le webhook est bien configuré dans Lygospay
- Consultez les logs des webhooks dans la base de données

**Erreur "Clé API non configurée"** :
- Assurez-vous que `LYGOS_PAY_API_KEY` est défini dans les variables d'environnement

**Le client est redirigé mais ne voit pas la confirmation** :
- Vérifiez que `/api/verify-lygos-payment/:orderId` est accessible
- Vérifiez les logs du Worker pour voir si l'API Lygospay répond

## API Lygospay Utilisée

### Endpoints :

1. **POST `https://api.lygosapp.com/v1/gateway`**
   - Crée une nouvelle passerelle de paiement
   - Retourne une URL de paiement et un ID de passerelle

2. **GET `https://api.lygosapp.com/v1/gateway/payin/{order_id}`**
   - Vérifie le statut d'un paiement
   - Utilisé pour la vérification de sécurité

### Headers requis :

```json
{
  "Content-Type": "application/json",
  "api-key": "VOTRE_CLE_API"
}
```

## Support

Pour toute question sur l'intégration Lygospay :
- WhatsApp : +229 51 66 13 57
- Email du support technique Martama

---

**Dernière mise à jour** : Décembre 2024
**Version** : 1.0
