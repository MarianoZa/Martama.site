/**
 * Format dates in UTC+1 (Benin timezone)
 */

export function formatDateTimeBenin(dateString: string | null | undefined): string {
  if (!dateString) return 'N/A';
  
  try {
    // Ensure the date string is treated as UTC by appending 'Z' if not present
    let isoString = dateString;
    if (!dateString.endsWith('Z') && !dateString.includes('+') && !dateString.includes('T')) {
      // SQLite datetime format: "2024-01-01 12:00:00" -> convert to ISO
      isoString = dateString.replace(' ', 'T') + 'Z';
    } else if (!dateString.endsWith('Z') && dateString.includes('T') && !dateString.includes('+')) {
      // ISO format without timezone
      isoString = dateString + 'Z';
    }
    
    const date = new Date(isoString);
    
    // Format with options for UTC+1 (Benin timezone)
    const options: Intl.DateTimeFormatOptions = {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      hour12: false,
      timeZone: 'Africa/Porto-Novo' // Benin timezone (UTC+1)
    };
    
    return new Intl.DateTimeFormat('fr-FR', options).format(date);
  } catch (error) {
    console.error('Error formatting date:', error);
    return 'N/A';
  }
}

export function formatDateBenin(dateString: string | null | undefined): string {
  if (!dateString) return 'N/A';
  
  try {
    // Ensure the date string is treated as UTC
    let isoString = dateString;
    if (!dateString.endsWith('Z') && !dateString.includes('+') && !dateString.includes('T')) {
      isoString = dateString.replace(' ', 'T') + 'Z';
    } else if (!dateString.endsWith('Z') && dateString.includes('T') && !dateString.includes('+')) {
      isoString = dateString + 'Z';
    }
    
    const date = new Date(isoString);
    
    const options: Intl.DateTimeFormatOptions = {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      timeZone: 'Africa/Porto-Novo' // Benin timezone (UTC+1)
    };
    
    return new Intl.DateTimeFormat('fr-FR', options).format(date);
  } catch (error) {
    console.error('Error formatting date:', error);
    return 'N/A';
  }
}

export function formatTimeBenin(dateString: string | null | undefined): string {
  if (!dateString) return 'N/A';
  
  try {
    // Ensure the date string is treated as UTC
    let isoString = dateString;
    if (!dateString.endsWith('Z') && !dateString.includes('+') && !dateString.includes('T')) {
      isoString = dateString.replace(' ', 'T') + 'Z';
    } else if (!dateString.endsWith('Z') && dateString.includes('T') && !dateString.includes('+')) {
      isoString = dateString + 'Z';
    }
    
    const date = new Date(isoString);
    
    const options: Intl.DateTimeFormatOptions = {
      hour: '2-digit',
      minute: '2-digit',
      hour12: false,
      timeZone: 'Africa/Porto-Novo' // Benin timezone (UTC+1)
    };
    
    return new Intl.DateTimeFormat('fr-FR', options).format(date);
  } catch (error) {
    console.error('Error formatting time:', error);
    return 'N/A';
  }
}

export function formatRelativeTimeBenin(dateString: string | null | undefined): string {
  if (!dateString) return 'N/A';
  
  try {
    // Ensure the date string is treated as UTC
    let isoString = dateString;
    if (!dateString.endsWith('Z') && !dateString.includes('+') && !dateString.includes('T')) {
      isoString = dateString.replace(' ', 'T') + 'Z';
    } else if (!dateString.endsWith('Z') && dateString.includes('T') && !dateString.includes('+')) {
      isoString = dateString + 'Z';
    }
    
    const date = new Date(isoString);
    const now = new Date();
    
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);
    
    if (diffMins < 1) return 'À l\'instant';
    if (diffMins < 60) return `Il y a ${diffMins} min`;
    if (diffHours < 24) return `Il y a ${diffHours}h`;
    if (diffDays < 7) return `Il y a ${diffDays}j`;
    
    // For older dates, show full date in Benin timezone
    return formatDateBenin(dateString);
  } catch (error) {
    console.error('Error formatting relative time:', error);
    return 'N/A';
  }
}

export function getCurrentTimeBenin(): string {
  const now = new Date();
  return formatDateTimeBenin(now.toISOString());
}
