/**
 * Image optimization utilities for better performance
 */

/**
 * Preload critical images to improve perceived performance
 * @param imageUrls - Array of image URLs to preload
 */
export function preloadImages(imageUrls: string[]): void {
  if (typeof window === 'undefined') return;
  
  imageUrls.forEach(url => {
    const link = document.createElement('link');
    link.rel = 'preload';
    link.as = 'image';
    link.href = url;
    document.head.appendChild(link);
  });
}

/**
 * Lazy load images when they come into viewport
 * @param imageElement - The image element to observe
 * @param callback - Callback when image enters viewport
 */
export function observeImageLoad(
  imageElement: HTMLImageElement,
  callback?: () => void
): IntersectionObserver | null {
  if (typeof window === 'undefined' || !('IntersectionObserver' in window)) {
    return null;
  }

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const img = entry.target as HTMLImageElement;
          const dataSrc = img.getAttribute('data-src');
          
          if (dataSrc) {
            img.src = dataSrc;
            img.removeAttribute('data-src');
          }
          
          observer.unobserve(img);
          callback?.();
        }
      });
    },
    {
      rootMargin: '50px', // Start loading 50px before entering viewport
    }
  );

  observer.observe(imageElement);
  return observer;
}

/**
 * Get optimized image URL with width parameter (if supported by CDN)
 * @param url - Original image URL
 * @param width - Desired width
 */
export function getOptimizedImageUrl(url: string, width?: number): string {
  if (!url || !width) return url;
  
  // If using Mocha CDN, add width parameter
  if (url.includes('mochausercontent.com')) {
    const separator = url.includes('?') ? '&' : '?';
    return `${url}${separator}w=${width}`;
  }
  
  return url;
}

/**
 * Generate responsive image srcset
 * @param url - Original image URL
 * @param sizes - Array of widths for different breakpoints
 */
export function generateSrcSet(url: string, sizes: number[] = [320, 640, 768, 1024, 1280]): string {
  return sizes
    .map(width => `${getOptimizedImageUrl(url, width)} ${width}w`)
    .join(', ');
}
