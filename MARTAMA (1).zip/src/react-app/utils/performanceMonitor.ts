/**
 * Performance monitoring utilities for tracking app performance
 */

/**
 * Measure and log component render time
 */
export function measureRenderTime(componentName: string, callback: () => void): void {
  if (typeof window === 'undefined' || !window.performance) return;
  
  const startTime = performance.now();
  callback();
  const endTime = performance.now();
  
  const renderTime = endTime - startTime;
  
  // Only log if render takes more than 16ms (60fps threshold)
  if (renderTime > 16) {
    console.warn(`${componentName} render took ${renderTime.toFixed(2)}ms`);
  }
}

/**
 * Report Core Web Vitals to console (for development)
 */
export function reportWebVitals(): void {
  if (typeof window === 'undefined') return;
  
  // Largest Contentful Paint (LCP)
  if ('PerformanceObserver' in window) {
    const lcpObserver = new PerformanceObserver((list) => {
      const entries = list.getEntries();
      const lastEntry = entries[entries.length - 1] as any;
      console.log('LCP:', lastEntry.renderTime || lastEntry.loadTime);
    });
    
    try {
      lcpObserver.observe({ entryTypes: ['largest-contentful-paint'] });
    } catch (e) {
      // LCP not supported
    }
    
    // First Input Delay (FID)
    const fidObserver = new PerformanceObserver((list) => {
      const entries = list.getEntries();
      entries.forEach((entry: any) => {
        console.log('FID:', entry.processingStart - entry.startTime);
      });
    });
    
    try {
      fidObserver.observe({ entryTypes: ['first-input'] });
    } catch (e) {
      // FID not supported
    }
    
    // Cumulative Layout Shift (CLS)
    let clsScore = 0;
    const clsObserver = new PerformanceObserver((list) => {
      const entries = list.getEntries();
      entries.forEach((entry: any) => {
        if (!entry.hadRecentInput) {
          clsScore += entry.value;
          console.log('CLS:', clsScore);
        }
      });
    });
    
    try {
      clsObserver.observe({ entryTypes: ['layout-shift'] });
    } catch (e) {
      // CLS not supported
    }
  }
}

/**
 * Batch multiple state updates to reduce re-renders
 */
export function batchUpdates(updates: Array<() => void>): void {
  // React 18+ automatically batches updates, but this can be useful for older versions
  updates.forEach(update => update());
}
