/**
 * Utilities for handling Google Drive video links
 */

/**
 * Check if a URL is a valid Google Drive link
 */
export function isGoogleDriveUrl(url: string): boolean {
  if (!url) return false;
  
  const drivePatterns = [
    /drive\.google\.com\/file\/d\//,
    /drive\.google\.com\/open\?id=/,
  ];
  
  return drivePatterns.some(pattern => pattern.test(url));
}

/**
 * Extract file ID from various Google Drive URL formats
 */
export function extractGoogleDriveFileId(url: string): string | null {
  if (!url) return null;
  
  // Format: https://drive.google.com/file/d/{fileId}/view
  const fileIdMatch = url.match(/\/file\/d\/([a-zA-Z0-9_-]+)/);
  if (fileIdMatch) {
    return fileIdMatch[1];
  }
  
  // Format: https://drive.google.com/open?id={fileId}
  const openIdMatch = url.match(/[?&]id=([a-zA-Z0-9_-]+)/);
  if (openIdMatch) {
    return openIdMatch[1];
  }
  
  return null;
}

/**
 * Convert Google Drive share URL to embeddable preview URL
 * @param url - Google Drive share URL
 * @returns Preview URL for iframe embedding or original URL if not Google Drive
 */
export function convertGoogleDriveUrl(url: string): string {
  if (!isGoogleDriveUrl(url)) {
    return url;
  }
  
  const fileId = extractGoogleDriveFileId(url);
  if (!fileId) {
    return url;
  }
  
  return `https://drive.google.com/file/d/${fileId}/preview`;
}

/**
 * Get a user-friendly message about Google Drive video integration
 */
export function getGoogleDriveMessage(url: string): string | null {
  if (!isGoogleDriveUrl(url)) {
    return null;
  }
  
  return "✓ Vidéo Google Drive (sera intégrée automatiquement)";
}
