import { useState, useEffect } from "react";
import { useAuth } from "@getmocha/users-service/react";

export type AdminRole = 
  | 'super_admin'
  | 'data_analyst'
  | 'delivery_agent'
  | 'affiliate_manager'
  | 'content_moderator';

export interface AdminPermissions {
  viewDashboard: boolean;
  viewStats: boolean;
  exportData: boolean;
  manageProducts: boolean;
  manageFormations: boolean;
  manageAcademy: boolean;
  manageBlog: boolean;
  manageTestimonials: boolean;
  viewOrders: boolean;
  deliverOrders: boolean;
  manageInventory: boolean;
  viewAffiliates: boolean;
  manageAffiliates: boolean;
  manageExceptionalCodes: boolean;
  processWithdrawals: boolean;
  viewPayments: boolean;
  managePayments: boolean;
  managePaymentGateways: boolean;
  viewUsers: boolean;
  manageUsers: boolean;
  manageAdmins: boolean;
  manageAdminRoles: boolean;
  manageAnnouncements: boolean;
}

const ROLE_PERMISSIONS: Record<AdminRole, AdminPermissions> = {
  super_admin: {
    viewDashboard: true,
    viewStats: true,
    exportData: true,
    manageProducts: true,
    manageFormations: true,
    manageAcademy: true,
    manageBlog: true,
    manageTestimonials: true,
    viewOrders: true,
    deliverOrders: true,
    manageInventory: true,
    viewAffiliates: true,
    manageAffiliates: true,
    manageExceptionalCodes: true,
    processWithdrawals: true,
    viewPayments: true,
    managePayments: true,
    managePaymentGateways: true,
    viewUsers: true,
    manageUsers: true,
    manageAdmins: true,
    manageAdminRoles: true,
    manageAnnouncements: true,
  },
  data_analyst: {
    viewDashboard: true,
    viewStats: true,
    exportData: true,
    manageProducts: false,
    manageFormations: false,
    manageAcademy: false,
    manageBlog: false,
    manageTestimonials: false,
    viewOrders: true,
    deliverOrders: false,
    manageInventory: false,
    viewAffiliates: true,
    manageAffiliates: false,
    manageExceptionalCodes: false,
    processWithdrawals: false,
    viewPayments: true,
    managePayments: false,
    managePaymentGateways: false,
    viewUsers: true,
    manageUsers: false,
    manageAdmins: false,
    manageAdminRoles: false,
    manageAnnouncements: false,
  },
  delivery_agent: {
    viewDashboard: false,
    viewStats: false,
    exportData: false,
    manageProducts: false,
    manageFormations: false,
    manageAcademy: false,
    manageBlog: false,
    manageTestimonials: false,
    viewOrders: true,
    deliverOrders: true,
    manageInventory: true,
    viewAffiliates: false,
    manageAffiliates: false,
    manageExceptionalCodes: false,
    processWithdrawals: false,
    viewPayments: false,
    managePayments: false,
    managePaymentGateways: false,
    viewUsers: false,
    manageUsers: false,
    manageAdmins: false,
    manageAdminRoles: false,
    manageAnnouncements: false,
  },
  affiliate_manager: {
    viewDashboard: false,
    viewStats: true,
    exportData: true,
    manageProducts: false,
    manageFormations: false,
    manageAcademy: false,
    manageBlog: false,
    manageTestimonials: false,
    viewOrders: false,
    deliverOrders: false,
    manageInventory: false,
    viewAffiliates: true,
    manageAffiliates: true,
    manageExceptionalCodes: true,
    processWithdrawals: true,
    viewPayments: false,
    managePayments: false,
    managePaymentGateways: false,
    viewUsers: false,
    manageUsers: false,
    manageAdmins: false,
    manageAdminRoles: false,
    manageAnnouncements: false,
  },
  content_moderator: {
    viewDashboard: false,
    viewStats: false,
    exportData: false,
    manageProducts: true,
    manageFormations: true,
    manageAcademy: true,
    manageBlog: true,
    manageTestimonials: true,
    viewOrders: false,
    deliverOrders: false,
    manageInventory: false,
    viewAffiliates: false,
    manageAffiliates: false,
    manageExceptionalCodes: false,
    processWithdrawals: false,
    viewPayments: false,
    managePayments: false,
    managePaymentGateways: false,
    viewUsers: false,
    manageUsers: false,
    manageAdmins: false,
    manageAdminRoles: false,
    manageAnnouncements: false,
  },
};

export function useAdminPermissions() {
  const { user } = useAuth();
  const [localUser, setLocalUser] = useState<any>(null);
  const [permissions, setPermissions] = useState<AdminPermissions | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchUser();
  }, [user]);

  const fetchUser = async () => {
    try {
      setLoading(true);
      const response = await fetch("/api/users/me");
      if (response.ok) {
        const data = await response.json();
        setLocalUser(data);
        
        if (data?.admin_role) {
          const perms = ROLE_PERMISSIONS[data.admin_role as AdminRole];
          setPermissions(perms);
        }
      }
    } catch (error) {
      console.error("Failed to fetch user:", error);
    } finally {
      setLoading(false);
    }
  };

  const hasPermission = (permission: keyof AdminPermissions): boolean => {
    if (!permissions) return false;
    return permissions[permission] || false;
  };

  const getDefaultPage = (): string => {
    if (!localUser?.admin_role) return '/admin';
    
    const roleDefaultPages: Record<string, string> = {
      'super_admin': '/admin',
      'data_analyst': '/admin',
      'content_moderator': '/admin/products',
      'affiliate_manager': '/admin/affiliates',
      'delivery_agent': '/admin/orders',
    };
    
    return roleDefaultPages[localUser.admin_role] || '/admin';
  };

  return {
    user: localUser,
    permissions,
    loading,
    hasPermission,
    getDefaultPage,
    isAdmin: localUser?.role === 'admin',
    isSuperAdmin: localUser?.admin_role === 'super_admin',
  };
}
