import { BrowserRouter as Router, Routes, Route } from "react-router";
import { AuthProvider } from "@getmocha/users-service/react";
import HomePage from "@/react-app/pages/Home";
import AuthCallbackPage from "@/react-app/pages/AuthCallback";
import CatalogPage from "@/react-app/pages/Catalog";
import ProductDetailPage from "@/react-app/pages/ProductDetail";
import UserDashboard from "@/react-app/pages/UserDashboard";
import UserProfile from "@/react-app/pages/UserProfile";
import AdminDashboard from "@/react-app/pages/AdminDashboard";
import AdminOrders from "@/react-app/pages/AdminOrders";
import AdminProducts from "@/react-app/pages/AdminProducts";
import AdminAffiliates from "@/react-app/pages/AdminAffiliates";
import BecomeAffiliate from "@/react-app/pages/BecomeAffiliate";

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/auth/callback" element={<AuthCallbackPage />} />
          <Route path="/catalog" element={<CatalogPage />} />
          <Route path="/products/:id" element={<ProductDetailPage />} />
          <Route path="/dashboard" element={<UserDashboard />} />
          <Route path="/profile" element={<UserProfile />} />
          <Route path="/admin" element={<AdminDashboard />} />
          <Route path="/admin/orders" element={<AdminOrders />} />
          <Route path="/admin/products" element={<AdminProducts />} />
          <Route path="/admin/affiliates" element={<AdminAffiliates />} />
          <Route path="/become-affiliate" element={<BecomeAffiliate />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
}
