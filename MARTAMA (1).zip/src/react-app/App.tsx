import { BrowserRouter as Router, Routes, Route } from "react-router";
import { AuthProvider } from "@getmocha/users-service/react";
import { ThemeProvider } from "@/react-app/context/ThemeContext";
import { useToast } from "@/react-app/hooks/useToast";
import ToastContainer from "@/react-app/components/ToastContainer";
import WhatsAppButton from "@/react-app/components/WhatsAppButton";
import HomePage from "@/react-app/pages/Home";
import AuthCallbackPage from "@/react-app/pages/AuthCallback";
import CatalogPage from "@/react-app/pages/Catalog";
import ProductDetailPage from "@/react-app/pages/ProductDetail";
import UserDashboard from "@/react-app/pages/UserDashboard";
import UserProfile from "@/react-app/pages/UserProfile";
import AdminDashboard from "@/react-app/pages/AdminDashboard";
import AdminOrders from "@/react-app/pages/AdminOrders";
import AdminProducts from "@/react-app/pages/AdminProducts";
import AdminAffiliates from "@/react-app/pages/AdminAffiliates";
import AdminUsers from "@/react-app/pages/AdminUsers";
import AdminPayments from "@/react-app/pages/AdminPayments";
import AdminAddAffiliate from "@/react-app/pages/AdminAddAffiliate";
import AdminAnnouncement from "@/react-app/pages/AdminAnnouncement";
import AdminExceptionalCodes from "@/react-app/pages/AdminExceptionalCodes";
import AdminPaymentGateways from "@/react-app/pages/AdminPaymentGateways";
import AdminTestimonials from "@/react-app/pages/AdminTestimonials";
import BecomeAffiliate from "@/react-app/pages/BecomeAffiliate";
import AffiliateDashboard from "@/react-app/pages/AffiliateDashboard";
import AffiliateProfile from "@/react-app/pages/AffiliateProfile";
import AffiliateSales from "@/react-app/pages/AffiliateSales";
import AffiliateWithdrawal from "@/react-app/pages/AffiliateWithdrawal";
import PostPurchaseAuth from "@/react-app/pages/PostPurchaseAuth";
import HelpCenter from "@/react-app/pages/HelpCenter";
import LygosSuccess from "@/react-app/pages/LygosSuccess";
import LygosFailure from "@/react-app/pages/LygosFailure";
import Blog from "@/react-app/pages/Blog";
import BlogPost from "@/react-app/pages/BlogPost";
import AdminBlog from "@/react-app/pages/AdminBlog";
import AdminBlogEditor from "@/react-app/pages/AdminBlogEditor";
import AdminFormationEditor from "@/react-app/pages/AdminFormationEditor";
import FormationViewer from "@/react-app/pages/FormationViewer";
import Academy from "@/react-app/pages/Academy";
import AdminAcademy from "@/react-app/pages/AdminAcademy";
import AdminAcademyEditor from "@/react-app/pages/AdminAcademyEditor";
import AcademyClassViewer from "@/react-app/pages/AcademyClassViewer";
import AdminAcademyClassEditor from "@/react-app/pages/AdminAcademyClassEditor";
import AdminOrderDetail from "@/react-app/pages/AdminOrderDetail";
import AdminRoles from "@/react-app/pages/AdminRoles";

function AppContent() {
  const { toasts, removeToast } = useToast();

  return (
    <>
      <Router>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/auth/callback" element={<AuthCallbackPage />} />
          <Route path="/auth/post-purchase" element={<PostPurchaseAuth />} />
          <Route path="/catalog" element={<CatalogPage />} />
          <Route path="/products/:id" element={<ProductDetailPage />} />
          <Route path="/dashboard" element={<UserDashboard />} />
          <Route path="/profile" element={<UserProfile />} />
          <Route path="/admin" element={<AdminDashboard />} />
          <Route path="/admin/orders" element={<AdminOrders />} />
          <Route path="/admin/orders/:id" element={<AdminOrderDetail />} />
          <Route path="/admin/products" element={<AdminProducts />} />
          <Route path="/admin/affiliates" element={<AdminAffiliates />} />
          <Route path="/admin/affiliates/add" element={<AdminAddAffiliate />} />
          <Route path="/admin/users" element={<AdminUsers />} />
          <Route path="/admin/payments" element={<AdminPayments />} />
          <Route path="/admin/announcement" element={<AdminAnnouncement />} />
          <Route path="/admin/exceptional-codes" element={<AdminExceptionalCodes />} />
          <Route path="/admin/payment-gateways" element={<AdminPaymentGateways />} />
          <Route path="/admin/testimonials" element={<AdminTestimonials />} />
          <Route path="/admin/roles" element={<AdminRoles />} />
          <Route path="/become-affiliate" element={<BecomeAffiliate />} />
          <Route path="/affiliate/dashboard" element={<AffiliateDashboard />} />
          <Route path="/affiliate/profile" element={<AffiliateProfile />} />
          <Route path="/affiliate/sales" element={<AffiliateSales />} />
          <Route path="/affiliate/withdrawal" element={<AffiliateWithdrawal />} />
          <Route path="/help" element={<HelpCenter />} />
          <Route path="/lygos-success" element={<LygosSuccess />} />
          <Route path="/lygos-failure" element={<LygosFailure />} />
          <Route path="/blog" element={<Blog />} />
          <Route path="/blog/:slug" element={<BlogPost />} />
          <Route path="/admin/blog" element={<AdminBlog />} />
          <Route path="/admin/blog/new" element={<AdminBlogEditor />} />
          <Route path="/admin/blog/edit/:id" element={<AdminBlogEditor />} />
          <Route path="/admin/formation/:productId" element={<AdminFormationEditor />} />
          <Route path="/formations/:id" element={<FormationViewer />} />
          <Route path="/academy" element={<Academy />} />
          <Route path="/academy/class/:id" element={<AcademyClassViewer />} />
          <Route path="/admin/academy" element={<AdminAcademy />} />
          <Route path="/admin/academy/new" element={<AdminAcademyEditor />} />
          <Route path="/admin/academy/edit/:id" element={<AdminAcademyEditor />} />
          <Route path="/admin/academy/class/:classId/content" element={<AdminAcademyClassEditor />} />
        </Routes>
      </Router>
      <ToastContainer toasts={toasts} onRemove={removeToast} />
      <WhatsAppButton />
    </>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </ThemeProvider>
  );
}
