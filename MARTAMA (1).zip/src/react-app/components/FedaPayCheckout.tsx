import React, { useState, useEffect } from 'react';

interface TransactionDetails {
  amount: number;
  description: string;
  orderId: number;
  customerEmail: string;
  firstName: string;
  lastName: string;
  phoneNumber: string;
  countryCode: string;
}

interface FedaPayCheckoutProps {
  transactionDetails: TransactionDetails;
  onSuccess: () => void;
  onCancel: () => void;
}

// Declare FedaPay on window
declare global {
  interface Window {
    FedaPay: any;
  }
}

const FedaPayCheckout: React.FC<FedaPayCheckoutProps> = ({ 
  transactionDetails, 
  onSuccess, 
  onCancel 
}) => {
  const [isInitializing, setIsInitializing] = useState(false);
  const [publicKey, setPublicKey] = useState<string>('');

  useEffect(() => {
    // Load FedaPay public key
    const loadPublicKey = async () => {
      try {
        const response = await fetch('/api/fedapay/public-key');
        const data = await response.json();
        setPublicKey(data.public_key);
      } catch (error) {
        console.error('Failed to load FedaPay public key:', error);
      }
    };
    loadPublicKey();
  }, []);

  const getCountryCode = (phoneCode: string): string => {
    const countryMap: { [key: string]: string } = {
      '+221': 'SN',
      '+225': 'CI',
      '+223': 'ML',
      '+226': 'BF',
      '+227': 'NE',
      '+228': 'TG',
      '+229': 'BJ',
      '+237': 'CM',
      '+212': 'MA',
      '+213': 'DZ',
      '+216': 'TN',
    };
    return countryMap[phoneCode] || 'SN';
  };

  const handlePayment = async () => {
    if (!publicKey) {
      alert('Erreur: Clé publique FedaPay non disponible');
      return;
    }

    if (!window.FedaPay) {
      alert('Erreur: Le widget FedaPay n\'est pas chargé');
      return;
    }

    setIsInitializing(true);

    try {
      // Initialize FedaPay widget with transaction details
      const widget = window.FedaPay.init({
        public_key: publicKey,
        transaction: {
          amount: transactionDetails.amount,
          description: transactionDetails.description,
        },
        customer: {
          email: transactionDetails.customerEmail,
          firstname: transactionDetails.firstName,
          lastname: transactionDetails.lastName,
          phone_number: {
            number: transactionDetails.phoneNumber,
            country: getCountryCode(transactionDetails.countryCode),
          },
        },
        currency: {
          iso: 'XOF',
        },
        onComplete: async (transaction: any) => {
          if (transaction.reason === window.FedaPay.DIALOG_DISMISSED) {
            console.log('Payment cancelled by user');
            // Update order status to abandoned
            await fetch(`/api/orders/${transactionDetails.orderId}/payment`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                transaction_id: null,
                status: 'abandoned',
              }),
            });
            onCancel();
            setIsInitializing(false);
            return;
          }

          // Update order with transaction details
          await fetch(`/api/orders/${transactionDetails.orderId}/payment`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              transaction_id: transaction.id,
              status: transaction.status,
              customer_email: transactionDetails.customerEmail,
            }),
          });

          onSuccess();
          setIsInitializing(false);
        },
      });

      // Open the payment widget
      widget.open();
    } catch (error) {
      console.error('Error initializing FedaPay widget:', error);
      alert('Erreur lors de l\'initialisation du paiement');
      setIsInitializing(false);
    }
  };

  return (
    <button
      onClick={handlePayment}
      disabled={isInitializing || !publicKey}
      className="w-full py-4 rounded-2xl font-bold text-lg text-white transition-all disabled:opacity-50"
      style={{ backgroundColor: 'var(--success)' }}
    >
      {isInitializing ? "Initialisation du paiement..." : `Payer ${transactionDetails.amount.toLocaleString()} FCFA`}
    </button>
  );
};

export default FedaPayCheckout;
