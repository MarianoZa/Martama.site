import { useNavigate, useLocation } from "react-router";
import { Home, Package, TrendingUp, Menu, DollarSign, Link2, Copy, ShoppingBag, HelpCircle } from "lucide-react";
import { useState } from "react";

interface BottomNavProps {
  userRole?: string;
  isAffiliate?: boolean;
  affiliateCode?: string;
  isAuthenticated?: boolean;
}

export default function BottomNav({ userRole, isAffiliate, affiliateCode, isAuthenticated = false }: BottomNavProps) {
  const navigate = useNavigate();
  const location = useLocation();
  const [copied, setCopied] = useState(false);

  const isActive = (paths: string[]) => paths.some(path => location.pathname === path || location.pathname.startsWith(path));

  const copyAffiliateLink = () => {
    if (affiliateCode) {
      const link = `${window.location.origin}/?ref=${affiliateCode}`;
      navigator.clipboard.writeText(link);
      setCopied(true);
      
      // Vibration feedback if supported
      if ('vibrate' in navigator) {
        navigator.vibrate(50);
      }
      
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleAccountClick = () => {
    if (!isAuthenticated) {
      // Redirect to Google login
      window.location.href = "/api/auth/login";
    } else {
      navigate("/dashboard");
    }
  };

  // Admin navigation - DO NOT RENDER (admins use sidebar only)
  if (userRole === 'admin') {
    return null;
  }

  // Affiliate navigation
  if (isAffiliate && affiliateCode) {
    return (
      <nav 
        className="fixed bottom-0 left-0 right-0 border-t z-50 px-1 pb-safe"
        style={{ 
          backgroundColor: 'var(--bg-primary)',
          borderColor: 'var(--border-color)',
          boxShadow: '0 -4px 20px rgba(0, 0, 0, 0.08)',
          paddingBottom: 'max(env(safe-area-inset-bottom), 0.5rem)'
        }}
      >
        <div className="max-w-lg mx-auto flex items-center justify-around py-1">
          <button
            onClick={() => navigate("/affiliate/dashboard")}
            className="flex flex-col items-center gap-0.5 px-2 py-2 rounded-xl transition-all duration-200 min-w-[60px]"
            style={{
              backgroundColor: isActive(["/affiliate/dashboard"]) ? 'rgba(139, 92, 246, 0.15)' : 'transparent',
              color: isActive(["/affiliate/dashboard"]) ? 'var(--primary)' : 'var(--text-muted)',
              transform: isActive(["/affiliate/dashboard"]) ? 'scale(1.05)' : 'scale(1)'
            }}
          >
            <TrendingUp className="w-6 h-6" />
            <span className="text-[10px] font-semibold">Stats</span>
          </button>

          <button
            onClick={copyAffiliateLink}
            className="flex flex-col items-center gap-0.5 px-2 py-2 rounded-xl transition-all duration-200 min-w-[60px]"
            style={{
              backgroundColor: copied ? 'rgba(16, 185, 129, 0.15)' : 'transparent',
              color: copied ? 'var(--success)' : 'var(--text-muted)'
            }}
          >
            {copied ? <Copy className="w-6 h-6" /> : <Link2 className="w-6 h-6" />}
            <span className="text-[10px] font-semibold">{copied ? "Copié!" : "Lien"}</span>
          </button>

          <button
            onClick={() => navigate("/affiliate/sales")}
            className="flex flex-col items-center gap-0.5 px-2 py-2 rounded-xl transition-all duration-200 min-w-[60px]"
            style={{
              backgroundColor: isActive(["/affiliate/sales"]) ? 'rgba(251, 191, 36, 0.15)' : 'transparent',
              color: isActive(["/affiliate/sales"]) ? '#f59e0b' : 'var(--text-muted)',
              transform: isActive(["/affiliate/sales"]) ? 'scale(1.05)' : 'scale(1)'
            }}
          >
            <DollarSign className="w-6 h-6" />
            <span className="text-[10px] font-semibold">Gains</span>
          </button>

          <button
            onClick={() => navigate("/affiliate/withdrawal")}
            className="flex flex-col items-center gap-0.5 px-2 py-2 rounded-xl transition-all duration-200 min-w-[60px]"
            style={{
              backgroundColor: isActive(["/affiliate/withdrawal"]) ? 'rgba(139, 92, 246, 0.15)' : 'transparent',
              color: isActive(["/affiliate/withdrawal"]) ? 'var(--primary)' : 'var(--text-muted)',
              transform: isActive(["/affiliate/withdrawal"]) ? 'scale(1.05)' : 'scale(1)'
            }}
          >
            <ShoppingBag className="w-6 h-6" />
            <span className="text-[10px] font-semibold">Retrait</span>
          </button>

          <button
            onClick={() => navigate("/affiliate/profile")}
            className="flex flex-col items-center gap-0.5 px-2 py-2 rounded-xl transition-all duration-200 min-w-[60px]"
            style={{
              backgroundColor: isActive(["/affiliate/profile", "/profile"]) ? 'rgba(139, 92, 246, 0.15)' : 'transparent',
              color: isActive(["/affiliate/profile", "/profile"]) ? 'var(--primary)' : 'var(--text-muted)',
              transform: isActive(["/affiliate/profile", "/profile"]) ? 'scale(1.05)' : 'scale(1)'
            }}
          >
            <Menu className="w-6 h-6" />
            <span className="text-[10px] font-semibold">Plus</span>
          </button>
        </div>
      </nav>
    );
  }

  // Default user navigation (authenticated or not)
  return (
    <nav 
      className="fixed bottom-0 left-0 right-0 border-t z-50 px-1 pb-safe"
      style={{ 
        backgroundColor: 'var(--bg-primary)',
        borderColor: 'var(--border-color)',
        boxShadow: '0 -4px 20px rgba(0, 0, 0, 0.08)',
        paddingBottom: 'max(env(safe-area-inset-bottom), 0.5rem)'
      }}
    >
      <div className="max-w-lg mx-auto flex items-center justify-around py-1">
        <button
          onClick={() => navigate("/")}
          className="flex flex-col items-center gap-0.5 px-2 py-2 rounded-xl transition-all duration-200 min-w-[60px]"
          style={{
            backgroundColor: isActive(["/"]) && location.pathname === "/" ? 'rgba(139, 92, 246, 0.15)' : 'transparent',
            color: isActive(["/"]) && location.pathname === "/" ? 'var(--primary)' : 'var(--text-muted)',
            transform: isActive(["/"]) && location.pathname === "/" ? 'scale(1.05)' : 'scale(1)'
          }}
        >
          <Home className="w-6 h-6" />
          <span className="text-[10px] font-semibold">Accueil</span>
        </button>

        <button
          onClick={() => navigate("/catalog")}
          className="flex flex-col items-center gap-0.5 px-2 py-2 rounded-xl transition-all duration-200 min-w-[60px]"
          style={{
            backgroundColor: isActive(["/catalog", "/products"]) ? 'rgba(139, 92, 246, 0.15)' : 'transparent',
            color: isActive(["/catalog", "/products"]) ? 'var(--primary)' : 'var(--text-muted)',
            transform: isActive(["/catalog", "/products"]) ? 'scale(1.05)' : 'scale(1)'
          }}
        >
          <Package className="w-6 h-6" />
          <span className="text-[10px] font-semibold">Boutique</span>
        </button>

        <button
          onClick={handleAccountClick}
          className="flex flex-col items-center gap-0.5 px-2 py-2 rounded-xl transition-all duration-200 min-w-[60px]"
          style={{
            backgroundColor: isActive(["/dashboard", "/profile"]) ? 'rgba(251, 191, 36, 0.15)' : 'transparent',
            color: isActive(["/dashboard", "/profile"]) ? '#f59e0b' : 'var(--text-muted)',
            transform: isActive(["/dashboard", "/profile"]) ? 'scale(1.05)' : 'scale(1)'
          }}
        >
          <ShoppingBag className="w-6 h-6" />
          <span className="text-[10px] font-semibold">{isAuthenticated ? "Mes Achats" : "Compte"}</span>
        </button>

        <button
          onClick={() => navigate("/help")}
          className="flex flex-col items-center gap-0.5 px-2 py-2 rounded-xl transition-all duration-200 min-w-[60px]"
          style={{
            backgroundColor: isActive(["/help"]) ? 'rgba(139, 92, 246, 0.15)' : 'transparent',
            color: isActive(["/help"]) ? 'var(--primary)' : 'var(--text-muted)',
            transform: isActive(["/help"]) ? 'scale(1.05)' : 'scale(1)'
          }}
        >
          <HelpCircle className="w-6 h-6" />
          <span className="text-[10px] font-semibold">Aide</span>
        </button>
      </div>
    </nav>
  );
}
