import { Facebook, Instagram, Mail, Phone, MapPin } from 'lucide-react';
import { useNavigate } from 'react-router';

export default function Footer() {
  const navigate = useNavigate();

  return (
    <footer className="px-6 py-16 mt-20 border-t" style={{ borderColor: 'var(--border-color)', backgroundColor: 'var(--bg-secondary)' }}>
      <div className="max-w-7xl mx-auto">
        <div className="grid md:grid-cols-4 gap-8 mb-12">
          {/* About & Mission */}
          <div className="md:col-span-2">
            <h3 className="text-lg font-bold mb-4" style={{ color: 'var(--text-primary)' }}>
              À propos de Martama
            </h3>
            <p className="text-sm leading-relaxed mb-6" style={{ color: 'var(--text-secondary)' }}>
              Plateforme d'apprentissage et d'abonnements premium pour l'Afrique. Accédez à des formations de qualité et rejoignez notre programme d'affiliation.
            </p>
            
            <h4 className="text-base font-bold mb-3" style={{ color: 'var(--text-primary)' }}>
              Notre Mission
            </h4>
            <p className="text-sm leading-relaxed mb-4" style={{ color: 'var(--text-secondary)' }}>
              Fournir aux Africains des abonnements aux outils premium à des prix qui défient toute concurrence, avec une fiabilité totale.
            </p>
            
            <div className="flex items-center gap-3">
              <a
                href="https://www.facebook.com/share/1GXSppGMSE/"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-xl flex items-center justify-center transition-all duration-300 hover:scale-110"
                style={{ backgroundColor: 'var(--gray-100)' }}
                title="Facebook"
              >
                <Facebook className="w-5 h-5" style={{ color: 'var(--text-primary)' }} />
              </a>
              <a
                href="https://instagram.com/martama.site"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-xl flex items-center justify-center transition-all duration-300 hover:scale-110"
                style={{ backgroundColor: 'var(--gray-100)' }}
                title="Instagram"
              >
                <Instagram className="w-5 h-5" style={{ color: 'var(--text-primary)' }} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-bold mb-4" style={{ color: 'var(--text-primary)' }}>
              Liens rapides
            </h3>
            <ul className="space-y-2 text-sm">
              <li>
                <button
                  onClick={() => navigate('/catalog')}
                  className="hover:opacity-70 transition-opacity"
                  style={{ color: 'var(--text-secondary)' }}
                >
                  Catalogue
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('/help')}
                  className="hover:opacity-70 transition-opacity"
                  style={{ color: 'var(--text-secondary)' }}
                >
                  Centre d'Aide
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('/become-affiliate')}
                  className="hover:opacity-70 transition-opacity"
                  style={{ color: 'var(--text-secondary)' }}
                >
                  Devenir Affilié
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('/dashboard')}
                  className="hover:opacity-70 transition-opacity"
                  style={{ color: 'var(--text-secondary)' }}
                >
                  Mon Espace
                </button>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-lg font-bold mb-4" style={{ color: 'var(--text-primary)' }}>
              Contact
            </h3>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start gap-2">
                <Phone className="w-4 h-4 flex-shrink-0 mt-0.5" style={{ color: 'var(--primary)' }} />
                <a
                  href="tel:+22951661357"
                  className="hover:opacity-70 transition-opacity"
                  style={{ color: 'var(--text-secondary)' }}
                >
                  +229 51 66 13 57
                </a>
              </li>
              <li className="flex items-start gap-2">
                <Mail className="w-4 h-4 flex-shrink-0 mt-0.5" style={{ color: 'var(--primary)' }} />
                <a
                  href="mailto:contact@martama.site"
                  className="hover:opacity-70 transition-opacity"
                  style={{ color: 'var(--text-secondary)' }}
                >
                  contact@martama.site
                </a>
              </li>
              <li className="flex items-start gap-2">
                <MapPin className="w-4 h-4 flex-shrink-0 mt-0.5" style={{ color: 'var(--primary)' }} />
                <span style={{ color: 'var(--text-secondary)' }}>
                  Cotonou, Bénin
                </span>
              </li>
            </ul>
          </div>
        </div>

        {/* Legal Links */}
        <div className="flex flex-wrap justify-center gap-6 mb-8 pb-8 border-b" style={{ borderColor: 'var(--border-color)' }}>
          <a
            href="/terms"
            className="text-sm hover:opacity-70 transition-opacity"
            style={{ color: 'var(--text-secondary)' }}
          >
            Conditions d'utilisation
          </a>
          <a
            href="/privacy"
            className="text-sm hover:opacity-70 transition-opacity"
            style={{ color: 'var(--text-secondary)' }}
          >
            Politique de confidentialité
          </a>
          <a
            href="/refund"
            className="text-sm hover:opacity-70 transition-opacity"
            style={{ color: 'var(--text-secondary)' }}
          >
            Politique de remboursement
          </a>
        </div>

        {/* Bottom */}
        <div className="text-center text-sm">
          <p style={{ color: 'var(--text-muted)' }}>
            © 2025 Martama. Tous droits réservés.
          </p>
        </div>
      </div>
    </footer>
  );
}
