import { memo } from "react";
import { useNavigate } from "react-router";
import { BookOpen, Package, Layers, Sparkles } from "lucide-react";
import type { Product } from "@/shared/types";

interface ProductCardProps {
  product: Product;
}

function ProductCard({ product }: ProductCardProps) {
  const navigate = useNavigate();

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "formation": return <BookOpen className="w-5 h-5" />;
      case "abonnement": return <Layers className="w-5 h-5" />;
      case "pack": return <Package className="w-5 h-5" />;
      default: return <Sparkles className="w-5 h-5" />;
    }
  };

  return (
    <div
      onClick={() => navigate(`/products/${product.id}`)}
      className="group rounded-3xl border overflow-hidden hover:shadow-xl transition-all duration-300 hover:scale-105 cursor-pointer"
      style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}
    >
      {product.image_url && (
        <div className="aspect-video w-full overflow-hidden" style={{ background: 'linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%)' }}>
          <img
            src={product.image_url}
            alt={product.name}
            loading="lazy"
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
          />
        </div>
      )}
      <div className="p-6">
        <div className="flex items-center gap-2 mb-3">
          <div className="w-8 h-8 rounded-lg flex items-center justify-center text-white" style={{ background: 'linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%)' }}>
            {getCategoryIcon(product.category)}
          </div>
          <span className="text-sm font-medium capitalize" style={{ color: 'var(--text-secondary)' }}>
            {product.category}
          </span>
        </div>
        <h3 className="text-xl font-bold mb-2 line-clamp-2" style={{ color: 'var(--text-primary)' }}>
          {product.name}
        </h3>
        <p className="text-sm mb-4 line-clamp-2 whitespace-pre-line" style={{ color: 'var(--text-secondary)' }}>
          {product.description}
        </p>
        <div className="flex items-center justify-between">
          <div>
            {product.price_1_months === 0 ? (
              <div className="text-2xl font-bold" style={{ color: 'var(--success)' }}>
                Gratuit
              </div>
            ) : product.price_1_months ? (
              <div className="text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>
                {product.price_1_months.toLocaleString()} FCFA
                <span className="text-sm font-normal ml-1" style={{ color: 'var(--text-muted)' }}>/mois</span>
              </div>
            ) : null}
          </div>
          <div className="text-sm font-medium transition-colors" style={{ color: 'var(--primary)' }}>
            Voir détails →
          </div>
        </div>
      </div>
    </div>
  );
}

// Memoize component to prevent unnecessary re-renders
export default memo(ProductCard, (prevProps, nextProps) => {
  return prevProps.product.id === nextProps.product.id &&
         prevProps.product.is_active === nextProps.product.is_active &&
         prevProps.product.price_1_months === nextProps.product.price_1_months;
});
