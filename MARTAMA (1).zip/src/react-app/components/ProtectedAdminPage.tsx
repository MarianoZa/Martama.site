import { useEffect, ReactNode } from "react";
import { useNavigate } from "react-router";
import { useAdminPermissions } from "@/react-app/hooks/useAdminPermissions";
import { Shield } from "lucide-react";

interface ProtectedAdminPageProps {
  children: ReactNode;
  requiredPermission?: keyof import("@/react-app/hooks/useAdminPermissions").AdminPermissions;
}

/**
 * Wrapper component to protect admin pages with permission checks
 * Usage: Wrap your admin page component with this and specify the required permission
 */
export default function ProtectedAdminPage({ children, requiredPermission }: ProtectedAdminPageProps) {
  const navigate = useNavigate();
  const { user, permissions, loading, hasPermission, getDefaultPage } = useAdminPermissions();

  useEffect(() => {
    if (loading) return;

    // Not logged in or not admin - redirect to home
    if (!user || user.role !== 'admin') {
      navigate('/', { replace: true });
      return;
    }

    // Check specific permission if required
    if (requiredPermission && !hasPermission(requiredPermission)) {
      // Redirect to their default page based on role
      const defaultPage = getDefaultPage();
      navigate(defaultPage, { replace: true });
      return;
    }
  }, [user, permissions, loading, requiredPermission, navigate, hasPermission, getDefaultPage]);

  // Show loading while checking permissions
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: 'var(--bg-primary)' }}>
        <div className="w-12 h-12 border-4 rounded-full animate-spin" style={{ borderColor: 'var(--gray-200)', borderTopColor: 'var(--primary)' }}></div>
      </div>
    );
  }

  // Show access denied if no permission
  if (requiredPermission && !hasPermission(requiredPermission)) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: 'var(--bg-primary)' }}>
        <div className="text-center max-w-md mx-auto p-8">
          <Shield className="w-16 h-16 mx-auto mb-4 opacity-30" style={{ color: 'var(--text-muted)' }} />
          <h2 className="text-2xl font-bold mb-2" style={{ color: 'var(--text-primary)' }}>Accès Restreint</h2>
          <p className="mb-6" style={{ color: 'var(--text-secondary)' }}>
            Vous n'avez pas l'autorisation d'accéder à cette page. Redirection...
          </p>
        </div>
      </div>
    );
  }

  return <>{children}</>;
}
