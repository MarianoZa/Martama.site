import { useState } from "react";
import { X, ArrowRight, ArrowLeft, Check } from "lucide-react";

interface Step {
  title: string;
  description: string;
  target?: string;
  icon: string;
}

interface OnboardingTourProps {
  userRole: string;
  onComplete: () => void;
}

export default function OnboardingTour({ userRole, onComplete }: OnboardingTourProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [isVisible, setIsVisible] = useState(true);

  // Define different onboarding paths based on user role
  const getSteps = (): Step[] => {
    if (userRole === 'admin') {
      return [
        {
          title: "👋 Bienvenue dans l'Administration",
          description: "Gérez votre plateforme Martama de manière efficace. Découvrons ensemble les principales fonctionnalités.",
          icon: "🎯"
        },
        {
          title: "📦 Gérer les Produits",
          description: "Créez et modifiez vos abonnements, formations et packs. Configurez les prix, les commissions et les options de paiement.",
          icon: "📦"
        },
        {
          title: "🛒 Traiter les Commandes",
          description: "Validez les paiements et livrez les abonnements manuellement. Les formations et packs sont livrés automatiquement.",
          icon: "🛒"
        },
        {
          title: "👥 Gérer les Affiliés",
          description: "Approuvez les demandes d'affiliation, gérez les codes promo et traitez les demandes de retrait.",
          icon: "👥"
        },
        {
          title: "📊 Suivre les Performances",
          description: "Consultez les statistiques de ventes, les revenus et les performances des affiliés depuis votre tableau de bord.",
          icon: "📊"
        }
      ];
    } else if (userRole === 'affiliate') {
      return [
        {
          title: "🎉 Félicitations, vous êtes Affilié !",
          description: "Commencez à gagner des commissions en partageant vos liens d'affiliation personnalisés.",
          icon: "💰"
        },
        {
          title: "🔗 Votre Code Promo",
          description: "Partagez votre code promo unique avec votre audience. Chaque vente réalisée avec ce code vous rapporte une commission.",
          icon: "🔗"
        },
        {
          title: "📈 Suivre vos Performances",
          description: "Accédez à votre tableau de bord affilié pour voir vos clics, ventes, commissions et solde disponible.",
          icon: "📈"
        },
        {
          title: "💸 Retirer vos Gains",
          description: "Demandez un retrait dès que votre solde atteint 2000 FCFA. Les paiements sont traités sous 24-48h.",
          icon: "💸"
        }
      ];
    } else {
      return [
        {
          title: "🎉 Bienvenue sur Martama !",
          description: "Découvrez des abonnements premium, des formations professionnelles et des ressources exclusives adaptés au marché africain.",
          icon: "🌍"
        },
        {
          title: "📚 Explorer le Catalogue",
          description: "Parcourez nos offres : Netflix, ChatGPT, CapCut Pro et bien plus encore. Des tarifs adaptés et des paiements sécurisés.",
          icon: "🛍️"
        },
        {
          title: "🎓 Accéder aux Formations",
          description: "Profitez de formations vidéo complètes avec des ressources téléchargeables. Accès immédiat après achat.",
          icon: "🎓"
        },
        {
          title: "💰 Devenir Affilié",
          description: "Gagnez des commissions en recommandant Martama à vos amis. Jusqu'à 30% de commission sur chaque vente !",
          icon: "💰"
        },
        {
          title: "🏫 Rejoindre l'Academy",
          description: "Accédez à des classes privées exclusives avec mentorat et communauté d'entraide.",
          icon: "🏫"
        }
      ];
    }
  };

  const steps = getSteps();
  const progress = ((currentStep + 1) / steps.length) * 100;

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      handleComplete();
    }
  };

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleComplete = async () => {
    setIsVisible(false);
    // Mark onboarding as completed
    try {
      await fetch("/api/users/complete-onboarding", {
        method: "POST"
      });
    } catch (error) {
      console.error("Failed to mark onboarding as completed:", error);
    }
    onComplete();
  };

  const handleSkip = () => {
    handleComplete();
  };

  if (!isVisible) return null;

  const currentStepData = steps[currentStep];

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-sm animate-fade-in">
      <div 
        className="relative w-full max-w-2xl mx-6 rounded-3xl border shadow-2xl overflow-hidden animate-scale-in"
        style={{ 
          backgroundColor: 'var(--bg-primary)', 
          borderColor: 'var(--border-color)',
          animation: 'scaleIn 0.3s ease-out'
        }}
      >
        {/* Progress Bar */}
        <div className="h-2" style={{ backgroundColor: 'var(--bg-secondary)' }}>
          <div 
            className="h-full transition-all duration-300"
            style={{ 
              width: `${progress}%`, 
              backgroundColor: 'var(--primary)',
              background: 'linear-gradient(90deg, var(--primary) 0%, var(--accent) 100%)'
            }}
          />
        </div>

        {/* Close Button */}
        <button
          onClick={handleSkip}
          className="absolute top-6 right-6 p-2 rounded-xl hover:opacity-80 transition-opacity z-10"
          style={{ backgroundColor: 'var(--bg-secondary)' }}
        >
          <X className="w-5 h-5" style={{ color: 'var(--text-muted)' }} />
        </button>

        {/* Content */}
        <div className="p-12">
          {/* Icon */}
          <div className="text-7xl mb-6 animate-bounce-slow">
            {currentStepData.icon}
          </div>

          {/* Title */}
          <h2 className="text-3xl font-bold mb-4" style={{ color: 'var(--text-primary)' }}>
            {currentStepData.title}
          </h2>

          {/* Description */}
          <p className="text-lg mb-8 leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
            {currentStepData.description}
          </p>

          {/* Step Indicators */}
          <div className="flex items-center justify-center gap-2 mb-8">
            {steps.map((_, index) => (
              <div
                key={index}
                className="h-2 rounded-full transition-all duration-300"
                style={{
                  width: index === currentStep ? '32px' : '8px',
                  backgroundColor: index <= currentStep ? 'var(--primary)' : 'var(--border-color)'
                }}
              />
            ))}
          </div>

          {/* Navigation Buttons */}
          <div className="flex items-center justify-between gap-4">
            <button
              onClick={handleSkip}
              className="px-6 py-3 rounded-xl font-semibold transition-all"
              style={{ 
                backgroundColor: 'var(--bg-secondary)', 
                color: 'var(--text-muted)' 
              }}
            >
              Passer
            </button>

            <div className="flex gap-3">
              {currentStep > 0 && (
                <button
                  onClick={handlePrevious}
                  className="px-6 py-3 rounded-xl font-semibold transition-all border"
                  style={{ 
                    backgroundColor: 'var(--bg-secondary)', 
                    color: 'var(--text-primary)',
                    borderColor: 'var(--border-color)'
                  }}
                >
                  <ArrowLeft className="w-5 h-5" />
                </button>
              )}

              <button
                onClick={handleNext}
                className="flex items-center gap-2 px-8 py-3 rounded-xl font-semibold transition-all text-white shadow-lg hover:shadow-xl"
                style={{ backgroundColor: 'var(--primary)' }}
              >
                {currentStep === steps.length - 1 ? (
                  <>
                    <Check className="w-5 h-5" />
                    Terminer
                  </>
                ) : (
                  <>
                    Suivant
                    <ArrowRight className="w-5 h-5" />
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Step Counter */}
          <div className="text-center mt-6 text-sm" style={{ color: 'var(--text-muted)' }}>
            Étape {currentStep + 1} sur {steps.length}
          </div>
        </div>
      </div>

      <style>{`
        @keyframes scaleIn {
          from {
            opacity: 0;
            transform: scale(0.9);
          }
          to {
            opacity: 1;
            transform: scale(1);
          }
        }

        @keyframes bounce-slow {
          0%, 100% {
            transform: translateY(0);
          }
          50% {
            transform: translateY(-10px);
          }
        }

        .animate-bounce-slow {
          animation: bounce-slow 2s ease-in-out infinite;
        }

        .animate-scale-in {
          animation: scaleIn 0.3s ease-out;
        }
      `}</style>
    </div>
  );
}
