import { useEffect } from "react";
import { useNavigate } from "react-router";
import { useAdminPermissions } from "@/react-app/hooks/useAdminPermissions";

interface ProtectedAdminRouteProps {
  children: React.ReactNode;
  requiredPermission?: keyof import("@/react-app/hooks/useAdminPermissions").AdminPermissions;
}

export default function ProtectedAdminRoute({ children, requiredPermission }: ProtectedAdminRouteProps) {
  const navigate = useNavigate();
  const { user, permissions, loading, hasPermission, getDefaultPage } = useAdminPermissions();

  useEffect(() => {
    if (loading) return;

    // Not logged in or not admin
    if (!user || user.role !== 'admin') {
      navigate('/', { replace: true });
      return;
    }

    // Check specific permission if required
    if (requiredPermission && !hasPermission(requiredPermission)) {
      // Redirect to their default page
      navigate(getDefaultPage(), { replace: true });
      return;
    }
  }, [user, permissions, loading, requiredPermission, navigate, hasPermission, getDefaultPage]);

  // Show loading while checking
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: 'var(--bg-primary)' }}>
        <div className="w-12 h-12 border-4 rounded-full animate-spin" style={{ borderColor: 'var(--gray-200)', borderTopColor: 'var(--primary)' }}></div>
      </div>
    );
  }

  // Don't render if no permission
  if (requiredPermission && !hasPermission(requiredPermission)) {
    return null;
  }

  return <>{children}</>;
}
