import { useNavigate } from "react-router";
import { useAuth } from "@getmocha/users-service/react";
import { Sparkles, LogOut, User, LayoutDashboard } from "lucide-react";

interface HeaderProps {
  showBackButton?: boolean;
  onBack?: () => void;
}

export default function Header({ showBackButton, onBack }: HeaderProps) {
  const navigate = useNavigate();
  const { user, redirectToLogin } = useAuth();

  const handleLogout = async () => {
    try {
      await fetch("/api/logout");
      window.location.href = "/";
    } catch (error) {
      console.error("Logout failed:", error);
    }
  };

  return (
    <header className="px-6 py-6 flex justify-between items-center max-w-7xl mx-auto">
      <div className="flex items-center gap-4">
        {showBackButton && onBack && (
          <button
            onClick={onBack}
            className="p-2 hover:bg-white/10 rounded-xl transition-colors"
          >
            <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
        )}
        <div 
          className="flex items-center gap-2 cursor-pointer" 
          onClick={() => navigate("/")}
        >
          <div className="w-10 h-10 bg-gradient-to-br from-purple-400 to-pink-500 rounded-xl flex items-center justify-center shadow-lg">
            <Sparkles className="w-6 h-6 text-white" />
          </div>
          <span className="text-2xl font-bold text-white">Martama</span>
        </div>
      </div>

      <div className="flex items-center gap-3">
        {user ? (
          <>
            <button
              onClick={() => navigate("/dashboard")}
              className="flex items-center gap-2 px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-xl backdrop-blur-sm transition-all duration-300 font-medium border border-white/20"
            >
              <LayoutDashboard className="w-4 h-4" />
              <span className="hidden md:inline">Mon Espace</span>
            </button>
            <button
              onClick={() => navigate("/profile")}
              className="flex items-center gap-2 px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-xl backdrop-blur-sm transition-all duration-300 font-medium border border-white/20"
            >
              <User className="w-4 h-4" />
              <span className="hidden md:inline">Profil</span>
            </button>
            <button
              onClick={handleLogout}
              className="flex items-center gap-2 px-4 py-2 bg-red-500/20 hover:bg-red-500/30 text-red-200 rounded-xl backdrop-blur-sm transition-all duration-300 font-medium border border-red-500/30"
            >
              <LogOut className="w-4 h-4" />
              <span className="hidden md:inline">Déconnexion</span>
            </button>
          </>
        ) : (
          <button
            onClick={redirectToLogin}
            className="px-6 py-2.5 bg-white/10 hover:bg-white/20 text-white rounded-xl backdrop-blur-sm transition-all duration-300 font-medium border border-white/20"
          >
            Connexion
          </button>
        )}
      </div>
    </header>
  );
}
