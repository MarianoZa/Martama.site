import { CheckCircle, Clock, XCircle, AlertCircle } from "lucide-react";

interface StatusBadgeProps {
  status: string;
  size?: 'sm' | 'md' | 'lg';
}

export default function StatusBadge({ status, size = 'md' }: StatusBadgeProps) {
  const getStatusConfig = (status: string) => {
    const normalized = status.toLowerCase();
    
    switch (normalized) {
      case 'paid':
      case 'delivered':
      case 'réglé':
      case 'active':
      case 'approved':
        return {
          label: 'Réglé',
          icon: CheckCircle,
          bg: 'rgba(16, 185, 129, 0.15)',
          color: '#10b981',
          border: 'rgba(16, 185, 129, 0.3)'
        };
      
      case 'pending':
      case 'en attente':
        return {
          label: 'En attente',
          icon: Clock,
          bg: 'rgba(251, 191, 36, 0.15)',
          color: '#f59e0b',
          border: 'rgba(251, 191, 36, 0.3)'
        };
      
      case 'cancelled':
      case 'abandonné':
      case 'abandoned':
        return {
          label: 'Abandonné',
          icon: XCircle,
          bg: 'rgba(107, 114, 128, 0.15)',
          color: '#6b7280',
          border: 'rgba(107, 114, 128, 0.3)'
        };
      
      case 'failed':
      case 'échoué':
      case 'refunded':
      case 'rejected':
        return {
          label: 'Échoué',
          icon: AlertCircle,
          bg: 'rgba(139, 92, 246, 0.15)',
          color: '#8b5cf6',
          border: 'rgba(139, 92, 246, 0.3)'
        };
      
      default:
        return {
          label: status,
          icon: AlertCircle,
          bg: 'rgba(107, 114, 128, 0.15)',
          color: '#6b7280',
          border: 'rgba(107, 114, 128, 0.3)'
        };
    }
  };

  const config = getStatusConfig(status);
  const Icon = config.icon;
  
  const sizeClasses = {
    sm: 'px-2 py-1 text-xs gap-1',
    md: 'px-3 py-1.5 text-sm gap-1.5',
    lg: 'px-4 py-2 text-base gap-2'
  };
  
  const iconSizes = {
    sm: 'w-3 h-3',
    md: 'w-4 h-4',
    lg: 'w-5 h-5'
  };

  return (
    <span 
      className={`inline-flex items-center ${sizeClasses[size]} rounded-full font-semibold border`}
      style={{
        backgroundColor: config.bg,
        color: config.color,
        borderColor: config.border
      }}
    >
      <Icon className={iconSizes[size]} />
      <span>{config.label}</span>
    </span>
  );
}
