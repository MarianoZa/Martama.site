import { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router";
import { 
  Home, 
  Package, 
  ShoppingBag, 
  Users, 
  DollarSign,
  FileText,
  GraduationCap,
  MessageSquare,
  Settings,
  User,
  CreditCard,
  Megaphone,
  ChevronDown,
  ChevronRight,
  LogOut,
  Menu,
  X,
  Shield
} from "lucide-react";

interface MenuItem {
  label: string;
  icon: any;
  path?: string;
  permission?: string;
}

interface MenuSection {
  id: string;
  label: string;
  icon: any;
  items: MenuItem[];
  permission?: string;
}

type AdminPermissions = {
  viewDashboard: boolean;
  viewStats: boolean;
  exportData: boolean;
  manageProducts: boolean;
  manageFormations: boolean;
  manageAcademy: boolean;
  manageBlog: boolean;
  manageTestimonials: boolean;
  viewOrders: boolean;
  deliverOrders: boolean;
  manageInventory: boolean;
  viewAffiliates: boolean;
  manageAffiliates: boolean;
  manageExceptionalCodes: boolean;
  processWithdrawals: boolean;
  viewPayments: boolean;
  managePaymentGateways: boolean;
  viewUsers: boolean;
  manageUsers: boolean;
  manageAdmins: boolean;
  manageAnnouncements: boolean;
};

export default function AdminSidebar() {
  const navigate = useNavigate();
  const location = useLocation();
  const [user, setUser] = useState<any>(null);
  const [permissions, setPermissions] = useState<AdminPermissions | null>(null);
  const [expandedSections, setExpandedSections] = useState<string[]>(["dashboard", "administration"]);
  const [isMobileOpen, setIsMobileOpen] = useState(false);

  useEffect(() => {
    fetchUser();
  }, []);

  const fetchUser = async () => {
    try {
      const response = await fetch("/api/users/me");
      if (response.ok) {
        const data = await response.json();
        setUser(data);
        
        // Get permissions based on admin role
        if (data?.admin_role) {
          const perms = getPermissionsForRole(data.admin_role);
          setPermissions(perms);
        }
      }
    } catch (error) {
      console.error("Failed to fetch user:", error);
    }
  };

  const getPermissionsForRole = (role: string): AdminPermissions => {
    const allPermissions: Record<string, AdminPermissions> = {
      super_admin: {
        viewDashboard: true,
        viewStats: true,
        exportData: true,
        manageProducts: true,
        manageFormations: true,
        manageAcademy: true,
        manageBlog: true,
        manageTestimonials: true,
        viewOrders: true,
        deliverOrders: true,
        manageInventory: true,
        viewAffiliates: true,
        manageAffiliates: true,
        manageExceptionalCodes: true,
        processWithdrawals: true,
        viewPayments: true,
        managePaymentGateways: true,
        viewUsers: true,
        manageUsers: true,
        manageAdmins: true,
        manageAnnouncements: true,
      },
      data_analyst: {
        viewDashboard: true,
        viewStats: true,
        exportData: true,
        manageProducts: false,
        manageFormations: false,
        manageAcademy: false,
        manageBlog: false,
        manageTestimonials: false,
        viewOrders: true,
        deliverOrders: false,
        manageInventory: false,
        viewAffiliates: true,
        manageAffiliates: false,
        manageExceptionalCodes: false,
        processWithdrawals: false,
        viewPayments: true,
        managePaymentGateways: false,
        viewUsers: true,
        manageUsers: false,
        manageAdmins: false,
        manageAnnouncements: false,
      },
      delivery_agent: {
        viewDashboard: false,
        viewStats: false,
        exportData: false,
        manageProducts: false,
        manageFormations: false,
        manageAcademy: false,
        manageBlog: false,
        manageTestimonials: false,
        viewOrders: true,
        deliverOrders: true,
        manageInventory: true,
        viewAffiliates: false,
        manageAffiliates: false,
        manageExceptionalCodes: false,
        processWithdrawals: false,
        viewPayments: false,
        managePaymentGateways: false,
        viewUsers: false,
        manageUsers: false,
        manageAdmins: false,
        manageAnnouncements: false,
      },
      affiliate_manager: {
        viewDashboard: false,
        viewStats: true,
        exportData: true,
        manageProducts: false,
        manageFormations: false,
        manageAcademy: false,
        manageBlog: false,
        manageTestimonials: false,
        viewOrders: false,
        deliverOrders: false,
        manageInventory: false,
        viewAffiliates: true,
        manageAffiliates: true,
        manageExceptionalCodes: true,
        processWithdrawals: true,
        viewPayments: false,
        managePaymentGateways: false,
        viewUsers: false,
        manageUsers: false,
        manageAdmins: false,
        manageAnnouncements: false,
      },
      content_moderator: {
        viewDashboard: false,
        viewStats: false,
        exportData: false,
        manageProducts: true,
        manageFormations: true,
        manageAcademy: true,
        manageBlog: true,
        manageTestimonials: true,
        viewOrders: false,
        deliverOrders: false,
        manageInventory: false,
        viewAffiliates: false,
        manageAffiliates: false,
        manageExceptionalCodes: false,
        processWithdrawals: false,
        viewPayments: false,
        managePaymentGateways: false,
        viewUsers: false,
        manageUsers: false,
        manageAdmins: false,
        manageAnnouncements: false,
      },
    };

    return allPermissions[role] || allPermissions.content_moderator;
  };

  const hasPermission = (permission: string): boolean => {
    if (!permissions) return false;
    return permissions[permission as keyof AdminPermissions] || false;
  };

  const toggleSection = (section: string) => {
    setExpandedSections(prev => 
      prev.includes(section) 
        ? prev.filter(s => s !== section)
        : [...prev, section]
    );
  };

  const menuSections: MenuSection[] = [
    {
      id: "administration",
      label: "Administration",
      icon: Settings,
      items: [
        { label: "Produits", icon: Package, path: "/admin/products", permission: "manageProducts" },
        { label: "Commandes", icon: ShoppingBag, path: "/admin/orders", permission: "viewOrders" },
        { label: "Affiliés", icon: Users, path: "/admin/affiliates", permission: "viewAffiliates" },
        { label: "Paiements", icon: DollarSign, path: "/admin/payments", permission: "viewPayments" },
      ]
    },
    {
      id: "contenu",
      label: "Contenu",
      icon: FileText,
      items: [
        { label: "Blog", icon: FileText, path: "/admin/blog", permission: "manageBlog" },
        { label: "Academy", icon: GraduationCap, path: "/admin/academy", permission: "manageAcademy" },
        { label: "Témoignages", icon: MessageSquare, path: "/admin/testimonials", permission: "manageTestimonials" },
      ]
    },
    {
      id: "parametres",
      label: "Paramètres",
      icon: Settings,
      items: [
        { label: "Utilisateurs", icon: User, path: "/admin/users", permission: "viewUsers" },
        { label: "Administrateurs", icon: Shield, path: "/admin/roles", permission: "manageAdmins" },
        { label: "Passerelles", icon: CreditCard, path: "/admin/payment-gateways", permission: "managePaymentGateways" },
        { label: "Annonces", icon: Megaphone, path: "/admin/announcement", permission: "manageAnnouncements" },
      ]
    }
  ];

  const isActive = (path: string) => location.pathname === path || location.pathname.startsWith(path);

  const handleLogout = async () => {
    try {
      await fetch("/api/logout");
      window.location.href = "/";
    } catch (error) {
      console.error("Logout failed:", error);
    }
  };

  const getRoleLabel = (role: string | null) => {
    const labels: Record<string, string> = {
      super_admin: 'Super Admin',
      data_analyst: 'Analyste',
      delivery_agent: 'Agent',
      affiliate_manager: 'Gestionnaire',
      content_moderator: 'Modérateur',
    };
    return labels[role || ''] || 'Admin';
  };

  const getRoleBadgeColor = (role: string | null) => {
    const colors: Record<string, string> = {
      super_admin: 'bg-red-500/20 text-red-600 border-red-500/30',
      data_analyst: 'bg-blue-500/20 text-blue-600 border-blue-500/30',
      delivery_agent: 'bg-green-500/20 text-green-600 border-green-500/30',
      affiliate_manager: 'bg-purple-500/20 text-purple-600 border-purple-500/30',
      content_moderator: 'bg-yellow-500/20 text-yellow-600 border-yellow-500/30',
    };
    return colors[role || ''] || 'bg-gray-500/20 text-gray-600 border-gray-500/30';
  };

  const getDefaultAdminPage = () => {
    if (!user?.admin_role) return '/admin';
    
    const roleDefaultPages: Record<string, string> = {
      'super_admin': '/admin',
      'data_analyst': '/admin',
      'content_moderator': '/admin/products',
      'affiliate_manager': '/admin/affiliates',
      'delivery_agent': '/admin/orders',
    };
    
    return roleDefaultPages[user.admin_role] || '/admin';
  };

  // Filter menu sections and items based on permissions
  const getFilteredMenuSections = () => {
    if (!permissions) return [];

    return menuSections
      .map(section => ({
        ...section,
        items: section.items.filter(item => 
          !item.permission || hasPermission(item.permission)
        )
      }))
      .filter(section => section.items.length > 0);
  };

  const SidebarContent = () => (
    <>
      {/* User Profile */}
      <div className="p-6 border-b" style={{ borderColor: 'var(--border-color)' }}>
        <div className="flex items-center gap-3 mb-3">
          <div 
            className="w-12 h-12 rounded-full flex items-center justify-center text-white text-lg font-bold"
            style={{ background: 'linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%)' }}
          >
            {user?.full_name?.charAt(0) || user?.email?.charAt(0) || "A"}
          </div>
          <div className="flex-1 min-w-0">
            <div className="font-bold text-sm truncate" style={{ color: 'var(--text-primary)' }}>
              {user?.full_name || "Admin"}
            </div>
            <div className="text-xs truncate" style={{ color: 'var(--text-muted)' }}>
              {user?.email || "admin@martama.site"}
            </div>
            {user?.admin_role && (
              <span className={`inline-block mt-1 px-2 py-0.5 rounded text-xs font-medium border ${getRoleBadgeColor(user.admin_role)}`}>
                {getRoleLabel(user.admin_role)}
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Navigation Menu */}
      <div className="flex-1 overflow-y-auto py-4">
        {/* Tableau de bord - Only if has permission */}
        {hasPermission('viewDashboard') && (
          <button
            onClick={() => {
              navigate("/admin");
              setIsMobileOpen(false);
            }}
            className="w-full px-6 py-3 flex items-center gap-3 mb-2 transition-all"
            style={{
              backgroundColor: isActive("/admin") && location.pathname === "/admin" ? 'rgba(139, 92, 246, 0.15)' : 'transparent',
              color: isActive("/admin") && location.pathname === "/admin" ? 'var(--primary)' : 'var(--text-primary)',
              borderLeft: isActive("/admin") && location.pathname === "/admin" ? '3px solid var(--primary)' : '3px solid transparent',
              fontWeight: isActive("/admin") && location.pathname === "/admin" ? '600' : '500'
            }}
          >
            <Home className="w-5 h-5" style={{ color: isActive("/admin") && location.pathname === "/admin" ? 'var(--primary)' : 'var(--text-primary)' }} />
            <span className="text-sm">Tableau de bord</span>
          </button>
        )}

        {getFilteredMenuSections().map((section) => (
          <div key={section.id} className="mb-2">
            {/* Section Header */}
            <button
              onClick={() => toggleSection(section.id)}
              className="w-full px-6 py-3 flex items-center justify-between hover:bg-opacity-80 transition-colors"
              style={{ 
                backgroundColor: expandedSections.includes(section.id) ? 'var(--bg-secondary)' : 'transparent',
                color: 'var(--text-primary)'
              }}
            >
              <div className="flex items-center gap-3">
                <section.icon className="w-5 h-5" style={{ color: 'var(--primary)' }} />
                <span className="font-semibold text-sm">{section.label}</span>
              </div>
              {expandedSections.includes(section.id) ? (
                <ChevronDown className="w-4 h-4" style={{ color: 'var(--text-muted)' }} />
              ) : (
                <ChevronRight className="w-4 h-4" style={{ color: 'var(--text-muted)' }} />
              )}
            </button>

            {/* Section Items */}
            {expandedSections.includes(section.id) && (
              <div className="mt-1">
                {section.items.map((item) => (
                  <button
                    key={item.path}
                    onClick={() => {
                      navigate(item.path!);
                      setIsMobileOpen(false);
                    }}
                    className="w-full px-6 py-2.5 pl-14 flex items-center gap-3 text-sm transition-all"
                    style={{
                      backgroundColor: isActive(item.path!) ? 'rgba(139, 92, 246, 0.15)' : 'transparent',
                      color: isActive(item.path!) ? 'var(--primary)' : 'var(--text-secondary)',
                      borderLeft: isActive(item.path!) ? '3px solid var(--primary)' : '3px solid transparent',
                      fontWeight: isActive(item.path!) ? '600' : '400'
                    }}
                  >
                    <item.icon className="w-4 h-4" />
                    <span>{item.label}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        ))}

        {/* Limited access indicator */}
        {!hasPermission('viewDashboard') && getFilteredMenuSections().length > 0 && (
          <div className="px-6 py-4">
            <div className="p-3 rounded-xl border text-center" style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)', borderColor: 'rgba(139, 92, 246, 0.3)' }}>
              <Shield className="w-6 h-6 mx-auto mb-2" style={{ color: 'var(--primary)' }} />
              <p className="text-xs font-medium" style={{ color: 'var(--primary)' }}>
                Accès spécialisé
              </p>
            </div>
          </div>
        )}

        {/* Logout Button */}
        <div className="px-6 pt-4 pb-2">
          <button
            onClick={handleLogout}
            className="w-full px-5 py-4 rounded-xl font-bold flex items-center justify-center gap-3 transition-all hover:shadow-lg text-base"
            style={{ backgroundColor: 'rgba(239, 68, 68, 0.15)', color: 'var(--error)', border: '2px solid rgba(239, 68, 68, 0.3)' }}
          >
            <LogOut className="w-5 h-5" />
            Déconnexion
          </button>
        </div>
      </div>
    </>
  );

  return (
    <>
      {/* Mobile Menu Button */}
      <button
        onClick={() => setIsMobileOpen(!isMobileOpen)}
        className="lg:hidden fixed top-4 left-4 z-[60] p-3 rounded-xl shadow-lg"
        style={{ backgroundColor: 'var(--primary)' }}
      >
        {isMobileOpen ? (
          <X className="w-6 h-6 text-white" />
        ) : (
          <Menu className="w-6 h-6 text-white" />
        )}
      </button>

      {/* Mobile Overlay */}
      {isMobileOpen && (
        <div 
          className="lg:hidden fixed inset-0 bg-black/50 backdrop-blur-sm z-[60]"
          onClick={() => setIsMobileOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed top-0 left-0 h-full border-r flex flex-col z-[70] transition-transform duration-300 ${
          isMobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
        style={{ 
          width: '280px',
          backgroundColor: 'var(--bg-primary)',
          borderColor: 'var(--border-color)',
          boxShadow: '2px 0 10px rgba(0, 0, 0, 0.05)'
        }}
      >
        {/* Logo */}
        <div 
          className="p-6 border-b flex items-center gap-3 cursor-pointer"
          style={{ borderColor: 'var(--border-color)' }}
          onClick={() => {
            // Navigate to default admin page based on role
            const defaultPage = getDefaultAdminPage();
            navigate(defaultPage);
            setIsMobileOpen(false);
          }}
        >
          <div 
            className="w-10 h-10 rounded-xl flex items-center justify-center text-white font-bold text-xl"
            style={{ background: 'linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%)' }}
          >
            M
          </div>
          <div>
            <div className="font-bold text-lg" style={{ color: 'var(--text-primary)' }}>Martama</div>
            <div className="text-xs" style={{ color: 'var(--text-muted)' }}>Administration</div>
          </div>
        </div>

        <SidebarContent />
      </aside>

      {/* Main Content Spacer */}
      <div className="hidden lg:block" style={{ width: '280px', flexShrink: 0 }} />
    </>
  );
}
