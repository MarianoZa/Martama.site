import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router";
import { ArrowLeft, Save, Eye } from "lucide-react";
import AdminSidebar from "@/react-app/components/AdminSidebar";

interface BlogPost {
  id: number;
  title: string;
  slug: string;
  excerpt: string | null;
  content: string;
  image_url: string | null;
  author_name: string | null;
  category: string | null;
  is_published: number;
  published_at: string | null;
  created_at: string;
}

export default function AdminBlogEditor() {
  const navigate = useNavigate();
  const { id } = useParams();
  const isEditing = !!id;

  const [loading, setLoading] = useState(isEditing);
  const [saving, setSaving] = useState(false);
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string>("");

  const [formData, setFormData] = useState({
    title: "",
    slug: "",
    excerpt: "",
    content: "",
    image_url: "",
    author_name: "",
    category: "",
    is_published: 0,
  });

  useEffect(() => {
    const loadFont = () => {
      const link = document.createElement("link");
      link.href = "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap";
      link.rel = "stylesheet";
      document.head.appendChild(link);
    };
    loadFont();
  }, []);

  useEffect(() => {
    if (isEditing) {
      fetchPost();
    }
  }, [id]);

  const fetchPost = async () => {
    try {
      setLoading(true);
      const response = await fetch(`/api/blog/admin/posts/${id}`);
      if (response.ok) {
        const post: BlogPost = await response.json();
        setFormData({
          title: post.title,
          slug: post.slug,
          excerpt: post.excerpt || "",
          content: post.content,
          image_url: post.image_url || "",
          author_name: post.author_name || "",
          category: post.category || "",
          is_published: post.is_published,
        });
        setImagePreview(post.image_url || "");
      } else if (response.status === 404) {
        alert("Article non trouvé");
        navigate("/admin/blog");
      }
    } catch (error) {
      console.error('Failed to fetch blog post:', error);
    } finally {
      setLoading(false);
    }
  };

  const generateSlug = (title: string) => {
    return title
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)/g, '');
  };

  const handleTitleChange = (title: string) => {
    setFormData({
      ...formData,
      title,
      slug: isEditing ? formData.slug : generateSlug(title)
    });
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedImage(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);

    try {
      let imageUrl = formData.image_url;
      if (selectedImage) {
        const imageFormData = new FormData();
        imageFormData.append("image", selectedImage);

        const uploadResponse = await fetch("/api/admin/upload-image", {
          method: "POST",
          body: imageFormData,
        });

        if (uploadResponse.ok) {
          const uploadData = await uploadResponse.json();
          imageUrl = uploadData.url;
        } else {
          alert("Échec du téléchargement de l'image");
          setSaving(false);
          return;
        }
      }

      const payload = {
        ...formData,
        image_url: imageUrl || null,
      };

      const url = isEditing
        ? `/api/blog/admin/posts/${id}`
        : "/api/blog/admin/posts";

      const response = await fetch(url, {
        method: isEditing ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (response.ok) {
        navigate("/admin/blog");
      } else {
        const error = await response.json();
        alert(error.error || "Erreur lors de l'enregistrement");
      }
    } catch (error) {
      console.error("Failed to save blog post:", error);
      alert("Erreur lors de l'enregistrement");
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ fontFamily: "'Outfit', sans-serif", backgroundColor: 'var(--bg-primary)' }}>
        <div className="inline-block w-12 h-12 border-4 rounded-full animate-spin" style={{ borderColor: 'var(--gray-200)', borderTopColor: 'var(--primary)' }}></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex" style={{ fontFamily: "'Outfit', sans-serif", backgroundColor: 'var(--bg-primary)' }}>
      <AdminSidebar />
      
      <div className="flex-1">
      {/* Fixed Header */}
      <header className="sticky top-0 z-40 px-6 py-4 border-b" style={{ backgroundColor: 'var(--bg-primary)', borderColor: 'var(--border-color)' }}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate("/admin/blog")}
              className="p-2 hover:opacity-80 rounded-xl transition-opacity"
              style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)' }}
            >
              <ArrowLeft className="w-6 h-6" style={{ color: 'var(--primary)' }} />
            </button>
            <div>
              <h1 className="text-xl font-bold" style={{ color: 'var(--text-primary)' }}>
                {isEditing ? "Modifier l'article" : "Nouvel article"}
              </h1>
              <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
                {formData.slug && `/blog/${formData.slug}`}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => {
                if (formData.slug) {
                  window.open(`/blog/${formData.slug}`, '_blank');
                } else {
                  alert("Veuillez d'abord sauvegarder l'article");
                }
              }}
              className="flex items-center gap-2 px-4 py-2 rounded-xl font-medium border transition-colors"
              style={{ 
                backgroundColor: 'var(--bg-secondary)', 
                borderColor: 'var(--border-color)',
                color: 'var(--text-primary)'
              }}
            >
              <Eye className="w-4 h-4" />
              <span className="hidden sm:inline">Prévisualiser</span>
            </button>
            <button
              onClick={handleSubmit}
              disabled={saving}
              className="flex items-center gap-2 px-6 py-2 rounded-xl font-semibold transition-all text-white disabled:opacity-50"
              style={{ backgroundColor: 'var(--primary)' }}
            >
              <Save className="w-4 h-4" />
              {saving ? "Enregistrement..." : "Enregistrer"}
            </button>
          </div>
        </div>
      </header>

      {/* Main Form */}
      <main className="px-6 py-8 pb-24">
        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Title */}
          <div>
            <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
              Titre de l'article *
            </label>
            <input
              type="text"
              value={formData.title}
              onChange={(e) => handleTitleChange(e.target.value)}
              required
              placeholder="Ex: Comment optimiser votre abonnement Netflix"
              className="w-full px-5 py-4 border rounded-xl focus:outline-none focus:ring-2 text-2xl font-bold"
              style={{
                backgroundColor: 'var(--bg-secondary)',
                borderColor: 'var(--border-color)',
                color: 'var(--text-primary)',
                '--tw-ring-color': 'var(--primary)'
              } as any}
            />
          </div>

          {/* Slug */}
          <div>
            <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
              URL de l'article (slug) *
            </label>
            <div className="flex items-center gap-2 px-4 py-3 border rounded-xl" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
              <span className="text-sm" style={{ color: 'var(--text-muted)' }}>/blog/</span>
              <input
                type="text"
                value={formData.slug}
                onChange={(e) => setFormData({ ...formData, slug: e.target.value })}
                required
                placeholder="comment-optimiser-votre-abonnement-netflix"
                className="flex-1 bg-transparent border-0 focus:outline-none font-mono text-sm"
                style={{ color: 'var(--text-primary)' }}
              />
            </div>
          </div>

          {/* Category and Author */}
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                Catégorie
              </label>
              <input
                type="text"
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                placeholder="Ex: Guides, Astuces, Actualités"
                className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                style={{
                  backgroundColor: 'var(--bg-secondary)',
                  borderColor: 'var(--border-color)',
                  color: 'var(--text-primary)',
                  '--tw-ring-color': 'var(--primary)'
                } as any}
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                Auteur
              </label>
              <input
                type="text"
                value={formData.author_name}
                onChange={(e) => setFormData({ ...formData, author_name: e.target.value })}
                placeholder="Ex: L'équipe Martama"
                className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                style={{
                  backgroundColor: 'var(--bg-secondary)',
                  borderColor: 'var(--border-color)',
                  color: 'var(--text-primary)',
                  '--tw-ring-color': 'var(--primary)'
                } as any}
              />
            </div>
          </div>

          {/* Excerpt */}
          <div>
            <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
              Extrait (résumé court)
            </label>
            <textarea
              value={formData.excerpt}
              onChange={(e) => setFormData({ ...formData, excerpt: e.target.value })}
              rows={3}
              placeholder="Un court résumé de l'article (affiché dans la liste des articles et pour le SEO)"
              className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2 resize-none"
              style={{
                backgroundColor: 'var(--bg-secondary)',
                borderColor: 'var(--border-color)',
                color: 'var(--text-primary)',
                '--tw-ring-color': 'var(--primary)'
              } as any}
            />
            <p className="text-xs mt-1.5" style={{ color: 'var(--text-muted)' }}>
              Recommandé: 150-200 caractères
            </p>
          </div>

          {/* Cover Image */}
          <div>
            <label className="block text-sm font-medium mb-3" style={{ color: 'var(--text-muted)' }}>
              Image de couverture
            </label>
            <div className="space-y-4">
              <input
                type="file"
                accept="image/*"
                onChange={handleImageSelect}
                className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                style={{
                  backgroundColor: 'var(--bg-secondary)',
                  borderColor: 'var(--border-color)',
                  color: 'var(--text-primary)',
                  '--tw-ring-color': 'var(--primary)'
                } as any}
              />
              {imagePreview && (
                <div className="relative w-full aspect-video rounded-2xl overflow-hidden border" style={{ borderColor: 'var(--border-color)' }}>
                  <img
                    src={imagePreview}
                    alt="Aperçu de l'image de couverture"
                    className="w-full h-full object-cover"
                  />
                </div>
              )}
            </div>
          </div>

          {/* Content Editor */}
          <div>
            <label className="block text-sm font-medium mb-3" style={{ color: 'var(--text-muted)' }}>
              Contenu de l'article * (HTML supporté)
            </label>
            <textarea
              value={formData.content}
              onChange={(e) => setFormData({ ...formData, content: e.target.value })}
              required
              rows={20}
              placeholder={`<h2>Introduction</h2>
<p>Votre contenu ici...</p>

<h3>Sous-titre</h3>
<p>Plus de contenu...</p>

<ul>
  <li>Point 1</li>
  <li>Point 2</li>
</ul>

<a href="https://martama.site/products/1">Lien vers un produit</a>`}
              className="w-full px-5 py-4 border rounded-xl focus:outline-none focus:ring-2 font-mono text-sm resize-none"
              style={{
                backgroundColor: 'var(--bg-secondary)',
                borderColor: 'var(--border-color)',
                color: 'var(--text-primary)',
                '--tw-ring-color': 'var(--primary)'
              } as any}
            />
            <div className="mt-3 p-4 rounded-xl" style={{ backgroundColor: 'rgba(59, 130, 246, 0.1)', border: '1px solid rgba(59, 130, 246, 0.3)' }}>
              <p className="text-sm font-medium mb-2" style={{ color: 'var(--info)' }}>
                💡 Conseils pour un meilleur contenu:
              </p>
              <ul className="text-xs space-y-1" style={{ color: 'var(--text-secondary)' }}>
                <li>• Utilisez &lt;h2&gt; et &lt;h3&gt; pour structurer votre article</li>
                <li>• Utilisez &lt;p&gt; pour les paragraphes</li>
                <li>• Utilisez &lt;ul&gt; et &lt;li&gt; pour les listes à puces</li>
                <li>• Utilisez &lt;strong&gt; pour le texte en gras et &lt;em&gt; pour l'italique</li>
                <li>• Utilisez &lt;a href="URL"&gt; pour les liens hypertexte</li>
              </ul>
            </div>
          </div>

          {/* Publish Toggle */}
          <div className="flex items-center gap-4 p-6 rounded-2xl border" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
            <input
              type="checkbox"
              id="is_published"
              checked={formData.is_published === 1}
              onChange={(e) => setFormData({ ...formData, is_published: e.target.checked ? 1 : 0 })}
              className="w-6 h-6 rounded"
            />
            <label htmlFor="is_published" className="flex-1">
              <div className="font-semibold text-base mb-1" style={{ color: 'var(--text-primary)' }}>
                Publier cet article
              </div>
              <div className="text-sm" style={{ color: 'var(--text-muted)' }}>
                L'article sera visible publiquement sur le blog
              </div>
            </label>
          </div>
        </form>
      </main>
      </div>
    </div>
  );
}
