import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { ArrowLeft, Plus, Edit, Trash2, Users, CheckCircle, XCircle, Clock, Video } from "lucide-react";
import BottomNav from "@/react-app/components/BottomNav";
import AdminSidebar from "@/react-app/components/AdminSidebar";

interface AcademyClass {
  id: number;
  name: string;
  description: string | null;
  image_url: string | null;
  instructor_name: string | null;
  category: string | null;
  max_members: number | null;
  current_members: number;
  is_active: number;
  start_date: string | null;
  end_date: string | null;
  meeting_schedule: string | null;
  requirements: string | null;
}

interface ClassRequest {
  id: number;
  class_id: number;
  class_name: string;
  user_email: string;
  user_name: string | null;
  user_phone: string | null;
  motivation: string | null;
  status: string;
  created_at: string;
}

export default function AdminAcademy() {
  const navigate = useNavigate();
  const [classes, setClasses] = useState<AcademyClass[]>([]);
  const [requests, setRequests] = useState<ClassRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'classes' | 'requests'>('classes');
  const [requestFilter, setRequestFilter] = useState('pending');

  useEffect(() => {
    const loadFont = () => {
      const link = document.createElement("link");
      link.href = "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap";
      link.rel = "stylesheet";
      document.head.appendChild(link);
    };
    loadFont();
  }, []);

  useEffect(() => {
    if (activeTab === 'classes') {
      fetchClasses();
    } else {
      fetchRequests();
    }
  }, [activeTab, requestFilter]);

  const fetchClasses = async () => {
    try {
      setLoading(true);
      const response = await fetch("/api/academy/admin/classes");
      if (response.status === 403) {
        navigate("/");
        return;
      }
      const data = await response.json();
      setClasses(data);
    } catch (error) {
      console.error("Failed to fetch classes:", error);
    } finally {
      setLoading(false);
    }
  };

  const fetchRequests = async () => {
    try {
      setLoading(true);
      const response = await fetch(`/api/academy/admin/requests?status=${requestFilter}`);
      if (response.ok) {
        const data = await response.json();
        setRequests(data);
      }
    } catch (error) {
      console.error("Failed to fetch requests:", error);
    } finally {
      setLoading(false);
    }
  };

  

  const handleDeleteClass = async (id: number) => {
    if (!confirm("Êtes-vous sûr de vouloir supprimer cette classe ?")) return;

    try {
      const response = await fetch(`/api/academy/admin/classes/${id}`, {
        method: "DELETE",
      });

      if (response.ok) {
        await fetchClasses();
      }
    } catch (error) {
      console.error("Failed to delete class:", error);
    }
  };

  const handleApproveRequest = async (id: number) => {
    try {
      const response = await fetch(`/api/academy/admin/requests/${id}/approve`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });

      if (response.ok) {
        await fetchRequests();
      } else {
        const error = await response.json();
        alert(error.error || "Erreur lors de l'approbation");
      }
    } catch (error) {
      console.error("Failed to approve request:", error);
    }
  };

  const handleRejectRequest = async (id: number) => {
    const notes = prompt("Raison du rejet (optionnel):");
    
    try {
      const response = await fetch(`/api/academy/admin/requests/${id}/reject`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ admin_notes: notes }),
      });

      if (response.ok) {
        await fetchRequests();
      }
    } catch (error) {
      console.error("Failed to reject request:", error);
    }
  };

  return (
    <div className="min-h-screen flex" style={{ fontFamily: "'Outfit', sans-serif", backgroundColor: 'var(--bg-primary)' }}>
      <AdminSidebar />
      
      <div className="flex-1 pb-20 lg:pb-0">
      <header className="px-6 py-6">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate("/admin")}
              className="p-2 hover:opacity-80 rounded-xl transition-opacity"
              style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)' }}
            >
              <ArrowLeft className="w-6 h-6" style={{ color: 'var(--primary)' }} />
            </button>
            <div>
              <h1 className="text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>Gestion Academy</h1>
              <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>Gérez les classes et les demandes d'adhésion</p>
            </div>
          </div>
          {activeTab === 'classes' && (
            <button
              onClick={() => navigate("/admin/academy/new")}
              className="flex items-center gap-2 px-6 py-3 rounded-xl font-semibold transition-all text-white"
              style={{ backgroundColor: 'var(--primary)' }}
            >
              <Plus className="w-5 h-5" />
              Nouvelle Classe
            </button>
          )}
        </div>

        {/* Tabs */}
        <div className="flex gap-3 mb-8">
          <button
            onClick={() => setActiveTab('classes')}
            className={`px-6 py-3 rounded-xl font-semibold transition-all ${
              activeTab === 'classes' ? "text-white shadow-lg" : ""
            }`}
            style={{
              backgroundColor: activeTab === 'classes' ? 'var(--primary)' : 'var(--bg-secondary)',
              color: activeTab === 'classes' ? '#ffffff' : 'var(--text-primary)',
            }}
          >
            Classes
          </button>
          <button
            onClick={() => setActiveTab('requests')}
            className={`px-6 py-3 rounded-xl font-semibold transition-all ${
              activeTab === 'requests' ? "text-white shadow-lg" : ""
            }`}
            style={{
              backgroundColor: activeTab === 'requests' ? 'var(--primary)' : 'var(--bg-secondary)',
              color: activeTab === 'requests' ? '#ffffff' : 'var(--text-primary)',
            }}
          >
            Demandes
          </button>
        </div>

        {activeTab === 'requests' && (
          <div className="flex gap-3 mb-8">
            {['pending', 'approved', 'rejected', 'all'].map((filter) => (
              <button
                key={filter}
                onClick={() => setRequestFilter(filter)}
                className={`px-4 py-2 rounded-xl font-medium transition-all ${
                  requestFilter === filter ? "text-white" : ""
                }`}
                style={{
                  backgroundColor: requestFilter === filter ? 'var(--primary)' : 'var(--bg-secondary)',
                  color: requestFilter === filter ? '#ffffff' : 'var(--text-primary)',
                }}
              >
                {filter === 'all' && 'Toutes'}
                {filter === 'pending' && 'En attente'}
                {filter === 'approved' && 'Approuvées'}
                {filter === 'rejected' && 'Rejetées'}
              </button>
            ))}
          </div>
        )}
      </header>

      <main className="px-6 pb-12">
        {loading ? (
          <div className="text-center py-20">
            <div className="inline-block w-12 h-12 border-4 rounded-full animate-spin" style={{ borderColor: 'var(--gray-200)', borderTopColor: 'var(--primary)' }}></div>
          </div>
        ) : activeTab === 'classes' ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {classes.map((classData) => (
              <div
                key={classData.id}
                className="rounded-2xl border overflow-hidden"
                style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}
              >
                {classData.image_url && (
                  <div className="aspect-video w-full overflow-hidden">
                    <img src={classData.image_url} alt={classData.name} className="w-full h-full object-cover" />
                  </div>
                )}
                
                <div className="p-6">
                  <div className="flex items-start justify-between mb-3">
                    <h3 className="text-xl font-bold flex-1" style={{ color: 'var(--text-primary)' }}>{classData.name}</h3>
                    {classData.is_active === 1 ? (
                      <span className="px-2 py-0.5 bg-green-500/20 text-green-600 text-xs font-medium rounded-full">Actif</span>
                    ) : (
                      <span className="px-2 py-0.5 bg-red-500/20 text-red-600 text-xs font-medium rounded-full">Inactif</span>
                    )}
                  </div>
                  
                  <div className="space-y-2 mb-4 text-sm" style={{ color: 'var(--text-muted)' }}>
                    {classData.instructor_name && (
                      <div className="flex items-center gap-2">
                        <Users className="w-4 h-4" />
                        <span>{classData.instructor_name}</span>
                      </div>
                    )}
                    {classData.max_members && (
                      <div className="flex items-center gap-2">
                        <Users className="w-4 h-4" />
                        <span>{classData.current_members} / {classData.max_members} membres</span>
                      </div>
                    )}
                  </div>
                  
                  <div className="flex gap-2">
                    <button
                      onClick={() => navigate(`/admin/academy/class/${classData.id}/content`)}
                      className="flex-1 flex items-center justify-center gap-2 px-4 py-2 rounded-xl font-medium transition-colors text-white"
                      style={{ backgroundColor: 'var(--success)' }}
                    >
                      <Video className="w-4 h-4" />
                      Contenu
                    </button>
                    <button
                      onClick={() => navigate(`/admin/academy/edit/${classData.id}`)}
                      className="flex-1 flex items-center justify-center gap-2 px-4 py-2 rounded-xl font-medium transition-colors text-white"
                      style={{ backgroundColor: 'var(--info)' }}
                    >
                      <Edit className="w-4 h-4" />
                      Modifier
                    </button>
                    <button
                      onClick={() => handleDeleteClass(classData.id)}
                      className="px-4 py-2 border rounded-xl transition-colors"
                      style={{ backgroundColor: 'rgba(239, 68, 68, 0.1)', color: 'var(--error)', borderColor: 'rgba(239, 68, 68, 0.3)' }}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="space-y-4">
            {requests.map((request) => (
              <div
                key={request.id}
                className="rounded-2xl border p-6"
                style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <h3 className="text-lg font-bold mb-1" style={{ color: 'var(--text-primary)' }}>
                      {request.class_name}
                    </h3>
                    <p className="text-sm mb-2" style={{ color: 'var(--text-secondary)' }}>
                      {request.user_name} ({request.user_email})
                    </p>
                    {request.user_phone && (
                      <p className="text-sm" style={{ color: 'var(--text-muted)' }}>
                        📱 {request.user_phone}
                      </p>
                    )}
                  </div>
                  <div>
                    {request.status === 'pending' && (
                      <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-sm font-medium bg-yellow-500/20 text-yellow-600">
                        <Clock className="w-4 h-4" />
                        En attente
                      </span>
                    )}
                    {request.status === 'approved' && (
                      <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-sm font-medium bg-green-500/20 text-green-600">
                        <CheckCircle className="w-4 h-4" />
                        Approuvé
                      </span>
                    )}
                    {request.status === 'rejected' && (
                      <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-sm font-medium bg-red-500/20 text-red-600">
                        <XCircle className="w-4 h-4" />
                        Rejeté
                      </span>
                    )}
                  </div>
                </div>
                
                {request.motivation && (
                  <div className="mb-4 p-4 rounded-xl" style={{ backgroundColor: 'var(--bg-primary)' }}>
                    <p className="text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>Motivation:</p>
                    <p className="text-sm" style={{ color: 'var(--text-primary)' }}>{request.motivation}</p>
                  </div>
                )}
                
                {request.status === 'pending' && (
                  <div className="flex gap-3">
                    <button
                      onClick={() => handleApproveRequest(request.id)}
                      className="flex-1 flex items-center justify-center gap-2 px-4 py-2 rounded-xl font-medium transition-colors text-white"
                      style={{ backgroundColor: 'var(--success)' }}
                    >
                      <CheckCircle className="w-4 h-4" />
                      Approuver
                    </button>
                    <button
                      onClick={() => handleRejectRequest(request.id)}
                      className="flex-1 flex items-center justify-center gap-2 px-4 py-2 rounded-xl font-medium transition-colors"
                      style={{ backgroundColor: 'rgba(239, 68, 68, 0.1)', color: 'var(--error)' }}
                    >
                      <XCircle className="w-4 h-4" />
                      Rejeter
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </main>
      
      <BottomNav userRole="admin" />
      </div>
    </div>
  );
}
