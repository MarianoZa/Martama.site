import { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router";
import { useAdminPermissions } from "@/react-app/hooks/useAdminPermissions";
import { ArrowLeft, Package, Clock, CheckCircle, XCircle, RefreshCw, Download, Eye } from "lucide-react";
import BottomNav from "@/react-app/components/BottomNav";
import AdminSidebar from "@/react-app/components/AdminSidebar";
import type { Order } from "@/shared/types";
import { formatDateTimeBenin } from "@/react-app/utils/dateFormatter";

export default function AdminOrders() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { hasPermission, loading: permissionsLoading, getDefaultPage } = useAdminPermissions();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeFilter, setActiveFilter] = useState(searchParams.get("status") || "all");
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [credentials, setCredentials] = useState("");
  const [updating, setUpdating] = useState(false);

  // Check permission and redirect if needed
  useEffect(() => {
    if (permissionsLoading) return;
    
    if (!hasPermission('viewOrders')) {
      navigate(getDefaultPage(), { replace: true });
    }
  }, [permissionsLoading, hasPermission, navigate, getDefaultPage]);

  useEffect(() => {
    const loadFont = () => {
      const link = document.createElement("link");
      link.href = "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap";
      link.rel = "stylesheet";
      document.head.appendChild(link);
    };
    loadFont();
  }, []);

  useEffect(() => {
    fetchOrders();
  }, [activeFilter]);

  const fetchOrders = async () => {
    try {
      setLoading(true);
      const url = activeFilter === "all" 
        ? "/api/admin/orders" 
        : `/api/admin/orders?status=${activeFilter}`;
      const response = await fetch(url);
      
      if (response.status === 403) {
        navigate("/");
        return;
      }
      
      const data = await response.json();
      setOrders(data);
    } catch (error) {
      console.error("Failed to fetch orders:", error);
    } finally {
      setLoading(false);
    }
  };

  const updateOrderStatus = async (orderId: number, newStatus: string) => {
    try {
      setUpdating(true);
      const response = await fetch(`/api/admin/orders/${orderId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          status: newStatus,
          access_credentials: newStatus === "delivered" ? credentials : undefined,
        }),
      });
      
      if (response.ok) {
        await fetchOrders();
        setSelectedOrder(null);
        setCredentials("");
      }
    } catch (error) {
      console.error("Failed to update order:", error);
    } finally {
      setUpdating(false);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pending": return <Clock className="w-5 h-5" />;
      case "paid": return <CheckCircle className="w-5 h-5" />;
      case "delivered": return <Package className="w-5 h-5" />;
      case "cancelled": return <XCircle className="w-5 h-5" />;
      default: return <RefreshCw className="w-5 h-5" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending": return "bg-orange-500/20 text-orange-600 border-orange-500/30";
      case "paid": return "bg-blue-500/20 text-blue-600 border-blue-500/30";
      case "delivered": return "bg-green-500/20 text-green-600 border-green-500/30";
      case "cancelled": return "bg-red-500/20 text-red-600 border-red-500/30";
      default: return "bg-purple-500/20 text-purple-600 border-purple-500/30";
    }
  };

  return (
    <div className="min-h-screen flex" style={{ fontFamily: "'Outfit', sans-serif", backgroundColor: 'var(--bg-primary)' }}>
      <AdminSidebar />
      
      <div className="flex-1 pb-20 lg:pb-0">
      <header className="px-4 sm:px-6 py-4 sm:py-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6 sm:mb-8">
          <div className="flex items-center gap-3 sm:gap-4">
            <button
              onClick={() => navigate("/admin")}
              className="p-2 hover:opacity-80 rounded-xl transition-opacity"
              style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)' }}
            >
              <ArrowLeft className="w-5 h-5 sm:w-6 sm:h-6" style={{ color: 'var(--primary)' }} />
            </button>
            <div>
              <h1 className="text-lg sm:text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>Commandes</h1>
              <p className="text-xs sm:text-sm" style={{ color: 'var(--text-secondary)' }}>{orders.length} commandes</p>
            </div>
          </div>
          
          <div className="flex gap-2 w-full sm:w-auto">
            <a
              href="/api/admin/export/orders"
              className="flex-1 sm:flex-initial flex items-center justify-center gap-2 px-4 sm:px-5 py-2.5 sm:py-3 rounded-xl font-semibold text-sm sm:text-base transition-all text-white"
              style={{ backgroundColor: 'var(--success)' }}
            >
              <Download className="w-4 h-4 sm:w-5 sm:h-5" />
              <span className="hidden sm:inline">CSV</span>
            </a>
            <a
              href="/api/admin/export/orders-json"
              className="flex-1 sm:flex-initial flex items-center justify-center gap-2 px-4 sm:px-5 py-2.5 sm:py-3 rounded-xl font-semibold text-sm sm:text-base transition-all border"
              style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--success)', color: 'var(--success)' }}
            >
              <Download className="w-4 h-4 sm:w-5 sm:h-5" />
              <span className="hidden sm:inline">JSON</span>
            </a>
          </div>
        </div>

        {/* Filters */}
        <div className="flex gap-2 sm:gap-3 overflow-x-auto pb-2 scrollbar-hide -mx-4 px-4 sm:mx-0 sm:px-0">
          {[
            { key: "all", label: "Toutes" },
            { key: "pending", label: "En Attente" },
            { key: "paid", label: "Payées" },
            { key: "delivered", label: "Livrées" },
            { key: "cancelled", label: "Annulées" }
          ].map((filter) => (
            <button
              key={filter.key}
              onClick={() => setActiveFilter(filter.key)}
              className={`px-4 sm:px-6 py-2 sm:py-3 rounded-xl font-semibold whitespace-nowrap transition-all text-sm sm:text-base ${
                activeFilter === filter.key ? "text-white shadow-lg" : ""
              }`}
              style={{
                backgroundColor: activeFilter === filter.key ? 'var(--primary)' : 'var(--bg-secondary)',
                color: activeFilter === filter.key ? '#ffffff' : 'var(--text-primary)',
                borderColor: 'var(--border-color)',
                border: activeFilter === filter.key ? 'none' : '1px solid'
              }}
            >
              {filter.label}
            </button>
          ))}
        </div>
      </header>

      <main className="px-4 sm:px-6 pb-12">
        {loading ? (
          <div className="text-center py-20">
            <div className="inline-block w-12 h-12 border-4 rounded-full animate-spin" style={{ borderColor: 'var(--gray-200)', borderTopColor: 'var(--primary)' }}></div>
          </div>
        ) : orders.length === 0 ? (
          <div className="text-center py-20">
            <Package className="w-16 h-16 mx-auto mb-4" style={{ color: 'var(--text-muted)', opacity: 0.3 }} />
            <p className="text-xl" style={{ color: 'var(--text-muted)' }}>Aucune commande</p>
          </div>
        ) : (
          <div className="space-y-3 sm:space-y-4">
            {orders.map((order: any) => (
              <div
                key={order.id}
                className="rounded-2xl border p-4 sm:p-6 hover:opacity-90 transition-opacity"
                style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}
              >
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 mb-4">
                  <div className="flex-1 min-w-0">
                    <h3 className="text-base sm:text-lg font-bold mb-1 truncate" style={{ color: 'var(--text-primary)' }}>
                      #{order.id} - {order.product_name}
                    </h3>
                    <p className="text-xs sm:text-sm truncate" style={{ color: 'var(--text-secondary)' }}>{order.customer_email}</p>
                  </div>
                  <div className={`px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-full border flex items-center gap-1.5 sm:gap-2 flex-shrink-0 ${getStatusColor(order.status)}`}>
                    <span className="hidden sm:inline">{getStatusIcon(order.status)}</span>
                    <span className="text-xs sm:text-sm font-medium capitalize">{order.status}</span>
                  </div>
                </div>

                {/* Mobile: Scroll horizontally for stats */}
                <div className="overflow-x-auto -mx-4 px-4 sm:mx-0 sm:px-0 mb-4">
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4 min-w-[400px] sm:min-w-0">
                  <div>
                      <p className="text-[10px] sm:text-xs mb-1" style={{ color: 'var(--text-muted)' }}>Montant Total</p>
                      <p className="font-semibold text-sm sm:text-base" style={{ color: 'var(--text-primary)' }}>{order.amount.toLocaleString()} FCFA</p>
                      {order.discount_amount > 0 && (
                        <p className="text-[10px] sm:text-xs" style={{ color: 'var(--success)' }}>
                          -{order.discount_amount.toLocaleString()} F
                        </p>
                      )}
                    </div>
                    <div>
                      <p className="text-[10px] sm:text-xs mb-1" style={{ color: 'var(--text-muted)' }}>Durée</p>
                      <p className="font-semibold text-sm sm:text-base" style={{ color: 'var(--text-primary)' }}>{order.duration_months || 'N/A'} mois</p>
                    </div>
                    <div>
                      <p className="text-[10px] sm:text-xs mb-1" style={{ color: 'var(--text-muted)' }}>Passerelle</p>
                      <p className="font-semibold text-sm sm:text-base capitalize truncate" style={{ color: 'var(--text-primary)' }}>
                        {order.payment_gateway || order.payment_method || 'N/A'}
                      </p>
                    </div>
                    <div>
                      <p className="text-[10px] sm:text-xs mb-1" style={{ color: 'var(--text-muted)' }}>Créée le</p>
                      <p className="font-semibold text-xs sm:text-sm" style={{ color: 'var(--text-primary)' }}>
                        {formatDateTimeBenin(order.created_at)}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Transaction Details */}
                {order.payment_reference && (
                  <div className="mb-4 p-3 rounded-xl border" style={{ backgroundColor: 'rgba(59, 130, 246, 0.05)', borderColor: 'rgba(59, 130, 246, 0.2)' }}>
                    <p className="text-xs mb-1" style={{ color: 'var(--text-muted)' }}>Référence de Transaction</p>
                    <p className="text-sm font-mono" style={{ color: 'var(--info)' }}>{order.payment_reference}</p>
                  </div>
                )}

                {/* Delivery Details */}
                {order.delivered_at && (
                  <div className="mb-4 p-3 rounded-xl border" style={{ backgroundColor: 'rgba(16, 185, 129, 0.05)', borderColor: 'rgba(16, 185, 129, 0.2)' }}>
                    <p className="text-xs mb-1" style={{ color: 'var(--text-muted)' }}>Livré le</p>
                    <p className="text-sm" style={{ color: 'var(--success)' }}>
                      {formatDateTimeBenin(order.delivered_at)}
                      {order.delivered_by && ` par ${order.delivered_by}`}
                    </p>
                  </div>
                )}

                {order.affiliate_code && (
                  <div className="mb-4 p-3 rounded-xl border" style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)', borderColor: 'rgba(139, 92, 246, 0.2)' }}>
                    <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
                      Code affilié: <span className="font-semibold" style={{ color: 'var(--text-primary)' }}>{order.affiliate_code}</span> 
                      {' '}- Commission: <span className="font-semibold" style={{ color: 'var(--text-primary)' }}>{order.affiliate_commission.toLocaleString()} FCFA</span>
                    </p>
                  </div>
                )}

                {order.access_credentials && (
                  <div className="mb-4 p-3 rounded-xl border" style={{ backgroundColor: 'rgba(16, 185, 129, 0.1)', borderColor: 'rgba(16, 185, 129, 0.2)' }}>
                    <p className="text-sm font-mono" style={{ color: 'var(--success)' }}>
                      Accès: {order.access_credentials}
                    </p>
                  </div>
                )}

                <div className="flex flex-col sm:flex-row gap-2">
                  <button
                    onClick={() => navigate(`/admin/orders/${order.id}`)}
                    className="flex items-center justify-center gap-2 px-4 py-2.5 sm:py-2 rounded-xl font-medium text-sm sm:text-base transition-all"
                    style={{ backgroundColor: 'var(--bg-secondary)', color: 'var(--text-primary)', border: '1px solid var(--border-color)' }}
                  >
                    <Eye className="w-4 h-4" />
                    Détails
                  </button>
                  
                  {order.status === "paid" && (
                    <button
                      onClick={() => setSelectedOrder(order)}
                      className="px-4 py-2.5 sm:py-2 rounded-xl font-medium text-sm sm:text-base transition-colors text-white"
                      style={{ backgroundColor: 'var(--success)' }}
                    >
                      Livrer l'Accès
                    </button>
                  )}
                  
                  {order.status === "pending" && !order.payment_reference && (
                    <div className="flex flex-col sm:flex-row gap-2">
                      <button
                        onClick={() => updateOrderStatus(order.id, "paid")}
                        disabled={updating}
                        className="px-4 py-2.5 sm:py-2 rounded-xl font-medium text-sm sm:text-base transition-colors text-white disabled:opacity-50"
                        style={{ backgroundColor: 'var(--info)' }}
                      >
                        Marquer comme Payée
                      </button>
                      <button
                        onClick={() => updateOrderStatus(order.id, "cancelled")}
                        disabled={updating}
                        className="px-4 py-2.5 sm:py-2 border rounded-xl font-medium text-sm sm:text-base transition-colors disabled:opacity-50"
                        style={{ backgroundColor: 'rgba(239, 68, 68, 0.1)', color: 'var(--error)', borderColor: 'rgba(239, 68, 68, 0.3)' }}
                      >
                        Annuler
                      </button>
                    </div>
                  )}
                  
                  {order.status === "pending" && order.payment_reference && (
                    <div className="p-3 rounded-xl border" style={{ backgroundColor: 'rgba(59, 130, 246, 0.1)', borderColor: 'rgba(59, 130, 246, 0.2)' }}>
                      <p className="text-sm" style={{ color: 'var(--info)' }}>
                        ⏳ En attente de confirmation {
                          order.payment_gateway === 'lygospay' || order.payment_gateway === 'lygospay_checkout' 
                            ? 'Lygospay' 
                            : order.payment_gateway === 'fedapay'
                            ? 'FedaPay'
                            : order.payment_method === 'FedaPay'
                            ? 'FedaPay'
                            : 'paiement'
                        }...
                      </p>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      {/* Delivery Modal */}
      {selectedOrder && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-6 z-50">
          <div className="rounded-3xl border p-8 max-w-md w-full" style={{ backgroundColor: 'var(--bg-primary)', borderColor: 'var(--border-color)' }}>
            <h3 className="text-2xl font-bold mb-4" style={{ color: 'var(--text-primary)' }}>Livrer l'Accès</h3>
            <p className="mb-6" style={{ color: 'var(--text-secondary)' }}>
              Commande #{selectedOrder.id} - {(selectedOrder as any).product_name}
            </p>
            
            <div className="mb-6">
              <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                Identifiants d'accès
              </label>
              <textarea
                value={credentials}
                onChange={(e) => setCredentials(e.target.value)}
                placeholder="Email: user@example.com&#10;Mot de passe: ********"
                rows={4}
                className="w-full px-4 py-3 border rounded-xl font-mono text-sm focus:outline-none focus:ring-2"
                style={{ 
                  backgroundColor: 'var(--bg-secondary)', 
                  borderColor: 'var(--border-color)', 
                  color: 'var(--text-primary)',
                  '--tw-ring-color': 'var(--primary)'
                } as any}
              />
              <p className="text-xs mt-2" style={{ color: 'var(--text-muted)' }}>
                Les identifiants seront automatiquement attribués depuis l'inventaire si disponibles
              </p>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => updateOrderStatus(selectedOrder.id, "delivered")}
                disabled={updating}
                className="flex-1 px-6 py-3 rounded-xl font-semibold transition-colors text-white disabled:opacity-50"
                style={{ backgroundColor: 'var(--success)' }}
              >
                {updating ? "En cours..." : "Livrer"}
              </button>
              <button
                onClick={() => {
                  setSelectedOrder(null);
                  setCredentials("");
                }}
                className="px-6 py-3 rounded-xl font-semibold transition-colors"
                style={{ backgroundColor: 'var(--bg-secondary)', color: 'var(--text-primary)' }}
              >
                Annuler
              </button>
            </div>
          </div>
        </div>
      )}
      
      <BottomNav userRole="admin" />
      </div>
    </div>
  );
}
