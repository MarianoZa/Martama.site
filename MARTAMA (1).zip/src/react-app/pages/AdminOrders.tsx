import { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router";
import { ArrowLeft, Package, Clock, CheckCircle, XCircle, RefreshCw } from "lucide-react";
import type { Order } from "@/shared/types";

export default function AdminOrders() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeFilter, setActiveFilter] = useState(searchParams.get("status") || "all");
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [credentials, setCredentials] = useState("");
  const [updating, setUpdating] = useState(false);

  useEffect(() => {
    const loadFont = () => {
      const link = document.createElement("link");
      link.href = "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap";
      link.rel = "stylesheet";
      document.head.appendChild(link);
    };
    loadFont();
  }, []);

  useEffect(() => {
    fetchOrders();
  }, [activeFilter]);

  const fetchOrders = async () => {
    try {
      setLoading(true);
      const url = activeFilter === "all" 
        ? "/api/admin/orders" 
        : `/api/admin/orders?status=${activeFilter}`;
      const response = await fetch(url);
      
      if (response.status === 403) {
        navigate("/");
        return;
      }
      
      const data = await response.json();
      setOrders(data);
    } catch (error) {
      console.error("Failed to fetch orders:", error);
    } finally {
      setLoading(false);
    }
  };

  const updateOrderStatus = async (orderId: number, newStatus: string) => {
    try {
      setUpdating(true);
      const response = await fetch(`/api/admin/orders/${orderId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          status: newStatus,
          access_credentials: newStatus === "delivered" ? credentials : undefined,
        }),
      });
      
      if (response.ok) {
        await fetchOrders();
        setSelectedOrder(null);
        setCredentials("");
      }
    } catch (error) {
      console.error("Failed to update order:", error);
    } finally {
      setUpdating(false);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pending": return <Clock className="w-5 h-5" />;
      case "paid": return <CheckCircle className="w-5 h-5" />;
      case "delivered": return <Package className="w-5 h-5" />;
      case "cancelled": return <XCircle className="w-5 h-5" />;
      default: return <RefreshCw className="w-5 h-5" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending": return "bg-orange-500/20 text-orange-300 border-orange-500/30";
      case "paid": return "bg-blue-500/20 text-blue-300 border-blue-500/30";
      case "delivered": return "bg-green-500/20 text-green-300 border-green-500/30";
      case "cancelled": return "bg-red-500/20 text-red-300 border-red-500/30";
      default: return "bg-purple-500/20 text-purple-300 border-purple-500/30";
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-indigo-900" style={{ fontFamily: "'Outfit', sans-serif" }}>
      {/* Header */}
      <header className="px-6 py-6 max-w-7xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <button
            onClick={() => navigate("/admin")}
            className="p-2 hover:bg-white/10 rounded-xl transition-colors"
          >
            <ArrowLeft className="w-6 h-6 text-white" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-white">Gestion des Commandes</h1>
            <p className="text-purple-200 text-sm">Traiter et livrer les commandes</p>
          </div>
        </div>

        {/* Filters */}
        <div className="flex gap-3 overflow-x-auto pb-2">
          <button
            onClick={() => setActiveFilter("all")}
            className={`px-6 py-3 rounded-xl font-semibold whitespace-nowrap transition-all ${
              activeFilter === "all"
                ? "bg-white text-purple-900 shadow-lg"
                : "bg-white/10 text-white hover:bg-white/20 backdrop-blur-sm"
            }`}
          >
            Toutes
          </button>
          <button
            onClick={() => setActiveFilter("pending")}
            className={`px-6 py-3 rounded-xl font-semibold whitespace-nowrap transition-all ${
              activeFilter === "pending"
                ? "bg-white text-purple-900 shadow-lg"
                : "bg-white/10 text-white hover:bg-white/20 backdrop-blur-sm"
            }`}
          >
            En Attente
          </button>
          <button
            onClick={() => setActiveFilter("paid")}
            className={`px-6 py-3 rounded-xl font-semibold whitespace-nowrap transition-all ${
              activeFilter === "paid"
                ? "bg-white text-purple-900 shadow-lg"
                : "bg-white/10 text-white hover:bg-white/20 backdrop-blur-sm"
            }`}
          >
            Payées
          </button>
          <button
            onClick={() => setActiveFilter("delivered")}
            className={`px-6 py-3 rounded-xl font-semibold whitespace-nowrap transition-all ${
              activeFilter === "delivered"
                ? "bg-white text-purple-900 shadow-lg"
                : "bg-white/10 text-white hover:bg-white/20 backdrop-blur-sm"
            }`}
          >
            Livrées
          </button>
        </div>
      </header>

      {/* Orders List */}
      <main className="px-6 pb-12 max-w-7xl mx-auto">
        {loading ? (
          <div className="text-center py-20">
            <div className="inline-block w-12 h-12 border-4 border-white/20 border-t-white rounded-full animate-spin"></div>
          </div>
        ) : orders.length === 0 ? (
          <div className="text-center py-20">
            <Package className="w-16 h-16 text-white/30 mx-auto mb-4" />
            <p className="text-xl text-white/70">Aucune commande</p>
          </div>
        ) : (
          <div className="space-y-4">
            {orders.map((order: any) => (
              <div
                key={order.id}
                className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6 hover:bg-white/10 transition-all"
              >
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-lg font-bold text-white mb-1">#{order.id} - {order.product_name}</h3>
                    <p className="text-purple-200 text-sm">{order.customer_email}</p>
                  </div>
                  <div className={`px-3 py-1.5 rounded-full border flex items-center gap-2 ${getStatusColor(order.status)}`}>
                    {getStatusIcon(order.status)}
                    <span className="text-sm font-medium capitalize">{order.status}</span>
                  </div>
                </div>

                <div className="grid md:grid-cols-4 gap-4 mb-4">
                  <div>
                    <p className="text-purple-300 text-xs mb-1">Montant</p>
                    <p className="text-white font-semibold">{order.amount.toLocaleString()} FCFA</p>
                  </div>
                  <div>
                    <p className="text-purple-300 text-xs mb-1">Durée</p>
                    <p className="text-white font-semibold">{order.duration_months || 'N/A'} mois</p>
                  </div>
                  <div>
                    <p className="text-purple-300 text-xs mb-1">Méthode</p>
                    <p className="text-white font-semibold">{order.payment_method || 'N/A'}</p>
                  </div>
                  <div>
                    <p className="text-purple-300 text-xs mb-1">Date</p>
                    <p className="text-white font-semibold">
                      {new Date(order.created_at).toLocaleDateString('fr-FR')}
                    </p>
                  </div>
                </div>

                {order.affiliate_code && (
                  <div className="mb-4 p-3 bg-purple-500/10 rounded-xl border border-purple-500/20">
                    <p className="text-purple-300 text-sm">
                      Code affilié: <span className="font-semibold text-white">{order.affiliate_code}</span> 
                      {' '}- Commission: <span className="font-semibold text-white">{order.affiliate_commission.toLocaleString()} FCFA</span>
                    </p>
                  </div>
                )}

                {order.access_credentials && (
                  <div className="mb-4 p-3 bg-green-500/10 rounded-xl border border-green-500/20">
                    <p className="text-green-300 text-sm font-mono">
                      Accès: {order.access_credentials}
                    </p>
                  </div>
                )}

                <div className="flex gap-2">
                  {order.status === "pending" && (
                    <button
                      onClick={() => updateOrderStatus(order.id, "paid")}
                      disabled={updating}
                      className="px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-xl font-medium transition-colors disabled:opacity-50"
                    >
                      Marquer comme Payée
                    </button>
                  )}
                  
                  {order.status === "paid" && (
                    <button
                      onClick={() => setSelectedOrder(order)}
                      className="px-4 py-2 bg-green-500 hover:bg-green-600 text-white rounded-xl font-medium transition-colors"
                    >
                      Livrer l'Accès
                    </button>
                  )}
                  
                  {(order.status === "pending" || order.status === "paid") && (
                    <button
                      onClick={() => updateOrderStatus(order.id, "cancelled")}
                      disabled={updating}
                      className="px-4 py-2 bg-red-500/20 hover:bg-red-500/30 text-red-300 border border-red-500/30 rounded-xl font-medium transition-colors disabled:opacity-50"
                    >
                      Annuler
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      {/* Delivery Modal */}
      {selectedOrder && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-6 z-50">
          <div className="bg-gradient-to-br from-purple-900 to-indigo-900 rounded-3xl border border-white/20 p-8 max-w-md w-full">
            <h3 className="text-2xl font-bold text-white mb-4">Livrer l'Accès</h3>
            <p className="text-purple-200 mb-6">
              Commande #{selectedOrder.id} - {(selectedOrder as any).product_name}
            </p>
            
            <div className="mb-6">
              <label className="block text-purple-300 text-sm font-medium mb-2">
                Identifiants d'accès
              </label>
              <textarea
                value={credentials}
                onChange={(e) => setCredentials(e.target.value)}
                placeholder="Email: user@example.com&#10;Mot de passe: ********"
                rows={4}
                className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-purple-300/50 focus:outline-none focus:ring-2 focus:ring-purple-500 font-mono text-sm"
              />
              <p className="text-purple-300 text-xs mt-2">
                Les identifiants seront automatiquement attribués depuis l'inventaire si disponibles
              </p>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => updateOrderStatus(selectedOrder.id, "delivered")}
                disabled={updating}
                className="flex-1 px-6 py-3 bg-green-500 hover:bg-green-600 text-white rounded-xl font-semibold transition-colors disabled:opacity-50"
              >
                {updating ? "En cours..." : "Livrer"}
              </button>
              <button
                onClick={() => {
                  setSelectedOrder(null);
                  setCredentials("");
                }}
                className="px-6 py-3 bg-white/10 hover:bg-white/20 text-white rounded-xl font-semibold transition-colors"
              >
                Annuler
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
