import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "@getmocha/users-service/react";
import { useToast } from "@/react-app/hooks/useToast";
import ToastContainer from "@/react-app/components/ToastContainer";
import BottomNav from "@/react-app/components/BottomNav";
import { ArrowLeft, Edit2, Check, X, Tag, CreditCard } from "lucide-react";

export default function AffiliateProfile() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toasts, removeToast, success, error } = useToast();
  const [loading, setLoading] = useState(true);
  const [affiliate, setAffiliate] = useState<any>(null);
  const [editingPromoCode, setEditingPromoCode] = useState(false);
  const [editingPayment, setEditingPayment] = useState(false);
  const [newPromoCode, setNewPromoCode] = useState("");
  const [paymentInfo, setPaymentInfo] = useState({
    payment_method: "",
    payment_phone_number: "",
  });
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    const loadFont = () => {
      const link = document.createElement("link");
      link.href = "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap";
      link.rel = "stylesheet";
      document.head.appendChild(link);
    };
    loadFont();
  }, []);

  useEffect(() => {
    if (!user) {
      navigate("/");
      return;
    }
    fetchAffiliateProfile();
  }, [user]);

  const fetchAffiliateProfile = async () => {
    try {
      setLoading(true);
      const response = await fetch("/api/affiliate/profile");
      
      if (response.status === 404) {
        error("Vous n'êtes pas affilié");
        navigate("/");
        return;
      }
      
      if (response.ok) {
        const data = await response.json();
        setAffiliate(data);
        setNewPromoCode(data.promo_code || "");
        setPaymentInfo({
          payment_method: data.payment_method || "Mobile Money",
          payment_phone_number: data.payment_phone_number || "",
        });
      }
    } catch (err) {
      console.error("Failed to fetch affiliate profile:", err);
      error("Erreur lors du chargement du profil");
    } finally {
      setLoading(false);
    }
  };

  const handleUpdatePromoCode = async () => {
    if (!newPromoCode.trim()) {
      error("Veuillez entrer un code promo");
      return;
    }

    setSubmitting(true);

    try {
      const response = await fetch("/api/affiliate/update-promo-code", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ promo_code: newPromoCode }),
      });

      const data = await response.json();

      if (!response.ok) {
        error(data.error || "Erreur lors de la mise à jour");
        setSubmitting(false);
        return;
      }

      success("Code promo mis à jour avec succès !");
      setAffiliate(data.affiliate);
      setEditingPromoCode(false);
    } catch (err) {
      console.error("Failed to update promo code:", err);
      error("Erreur lors de la mise à jour");
    } finally {
      setSubmitting(false);
    }
  };

  const handleUpdatePaymentInfo = async () => {
    if (!paymentInfo.payment_phone_number.trim()) {
      error("Veuillez entrer votre numéro de téléphone");
      return;
    }

    setSubmitting(true);

    try {
      const response = await fetch("/api/affiliate/update-payment-info", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(paymentInfo),
      });

      const data = await response.json();

      if (!response.ok) {
        error(data.error || "Erreur lors de la mise à jour");
        setSubmitting(false);
        return;
      }

      success("Informations de paiement mises à jour !");
      setAffiliate(data.affiliate);
      setEditingPayment(false);
    } catch (err) {
      console.error("Failed to update payment info:", err);
      error("Erreur lors de la mise à jour");
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: 'var(--bg-primary)' }}>
        <div className="w-12 h-12 border-4 rounded-full animate-spin" style={{ borderColor: 'var(--gray-200)', borderTopColor: 'var(--primary)' }}></div>
      </div>
    );
  }

  if (!affiliate) {
    return null;
  }

  return (
    <div className="min-h-screen pb-20 lg:pb-8" style={{ fontFamily: "'Outfit', sans-serif", backgroundColor: 'var(--bg-primary)' }}>
      <ToastContainer toasts={toasts} onRemove={removeToast} />
      
      <header className="px-6 py-6 max-w-4xl mx-auto">
        <div className="flex items-center gap-4 mb-6">
          <button
            onClick={() => navigate("/affiliate")}
            className="p-2 rounded-xl transition-colors hover:shadow-md"
            style={{ backgroundColor: 'var(--bg-secondary)' }}
          >
            <ArrowLeft className="w-6 h-6" style={{ color: 'var(--text-primary)' }} />
          </button>
          <div>
            <h1 className="text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>
              Mon Profil Affilié
            </h1>
            <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
              Gérez vos informations de compte
            </p>
          </div>
        </div>
      </header>

      <main className="px-6 max-w-4xl mx-auto space-y-6">
        {/* Promo Code Section */}
        <div className="rounded-2xl border p-6" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)' }}>
                <Tag className="w-6 h-6" style={{ color: 'var(--primary)' }} />
              </div>
              <div>
                <h2 className="text-lg font-bold" style={{ color: 'var(--text-primary)' }}>
                  Code Promo
                </h2>
                <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
                  Votre code d'affiliation unique
                </p>
              </div>
            </div>
            {!editingPromoCode && (
              <button
                onClick={() => setEditingPromoCode(true)}
                className="flex items-center gap-2 px-4 py-2 rounded-xl font-medium transition-colors"
                style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)', color: 'var(--primary)' }}
              >
                <Edit2 className="w-4 h-4" />
                Modifier
              </button>
            )}
          </div>

          {editingPromoCode ? (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                  Nouveau code promo
                </label>
                <input
                  type="text"
                  value={newPromoCode}
                  onChange={(e) => setNewPromoCode(e.target.value.toUpperCase())}
                  placeholder="Ex: MONCODE2024"
                  maxLength={20}
                  className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2 font-mono text-lg"
                  style={{ 
                    backgroundColor: 'var(--bg-primary)', 
                    borderColor: 'var(--border-color)', 
                    color: 'var(--text-primary)',
                    '--tw-ring-color': 'var(--primary)'
                  } as any}
                />
                <p className="text-xs mt-1" style={{ color: 'var(--text-muted)' }}>
                  3-20 caractères alphanumériques uniquement
                </p>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={handleUpdatePromoCode}
                  disabled={submitting || !newPromoCode.trim()}
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-xl font-semibold text-white transition-all disabled:opacity-50"
                  style={{ backgroundColor: 'var(--success)' }}
                >
                  <Check className="w-5 h-5" />
                  {submitting ? "Enregistrement..." : "Enregistrer"}
                </button>
                <button
                  onClick={() => {
                    setEditingPromoCode(false);
                    setNewPromoCode(affiliate.promo_code);
                  }}
                  disabled={submitting}
                  className="px-4 py-3 rounded-xl font-semibold transition-colors"
                  style={{ backgroundColor: 'var(--bg-primary)', color: 'var(--text-primary)' }}
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
          ) : (
            <div className="rounded-xl p-4 border-2 border-dashed" style={{ borderColor: 'var(--primary)' }}>
              <div className="text-center">
                <div className="text-3xl font-bold mb-1" style={{ color: 'var(--primary)' }}>
                  {affiliate.promo_code}
                </div>
                <p className="text-sm" style={{ color: 'var(--text-muted)' }}>
                  Code actif depuis {new Date(affiliate.created_at).toLocaleDateString('fr-FR')}
                </p>
              </div>
            </div>
          )}

          <div className="mt-4 p-4 rounded-xl" style={{ backgroundColor: 'rgba(59, 130, 246, 0.1)' }}>
            <p className="text-sm" style={{ color: 'var(--info)' }}>
              ℹ️ Votre code promo sera automatiquement mis à jour partout (dashboard admin, liens d'affiliation, etc.)
            </p>
          </div>
        </div>

        {/* Payment Information Section */}
        <div className="rounded-2xl border p-6" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ backgroundColor: 'rgba(16, 185, 129, 0.1)' }}>
                <CreditCard className="w-6 h-6" style={{ color: 'var(--success)' }} />
              </div>
              <div>
                <h2 className="text-lg font-bold" style={{ color: 'var(--text-primary)' }}>
                  Informations de Paiement
                </h2>
                <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
                  Pour vos retraits de commissions
                </p>
              </div>
            </div>
            {!editingPayment && (
              <button
                onClick={() => setEditingPayment(true)}
                className="flex items-center gap-2 px-4 py-2 rounded-xl font-medium transition-colors"
                style={{ backgroundColor: 'rgba(16, 185, 129, 0.1)', color: 'var(--success)' }}
              >
                <Edit2 className="w-4 h-4" />
                Modifier
              </button>
            )}
          </div>

          {editingPayment ? (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                  Méthode de paiement
                </label>
                <select
                  value={paymentInfo.payment_method}
                  onChange={(e) => setPaymentInfo({ ...paymentInfo, payment_method: e.target.value })}
                  className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                  style={{ 
                    backgroundColor: 'var(--bg-primary)', 
                    borderColor: 'var(--border-color)', 
                    color: 'var(--text-primary)',
                    '--tw-ring-color': 'var(--primary)'
                  } as any}
                >
                  <option value="Mobile Money">Mobile Money</option>
                  <option value="Wave">Wave</option>
                  <option value="Orange Money">Orange Money</option>
                  <option value="MTN Money">MTN Money</option>
                  <option value="Moov Money">Moov Money</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                  Numéro de téléphone
                </label>
                <input
                  type="tel"
                  value={paymentInfo.payment_phone_number}
                  onChange={(e) => setPaymentInfo({ ...paymentInfo, payment_phone_number: e.target.value })}
                  placeholder="Ex: +229 XX XX XX XX"
                  className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                  style={{ 
                    backgroundColor: 'var(--bg-primary)', 
                    borderColor: 'var(--border-color)', 
                    color: 'var(--text-primary)',
                    '--tw-ring-color': 'var(--primary)'
                  } as any}
                />
              </div>

              <div className="flex gap-3">
                <button
                  onClick={handleUpdatePaymentInfo}
                  disabled={submitting || !paymentInfo.payment_phone_number.trim()}
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-xl font-semibold text-white transition-all disabled:opacity-50"
                  style={{ backgroundColor: 'var(--success)' }}
                >
                  <Check className="w-5 h-5" />
                  {submitting ? "Enregistrement..." : "Enregistrer"}
                </button>
                <button
                  onClick={() => {
                    setEditingPayment(false);
                    setPaymentInfo({
                      payment_method: affiliate.payment_method || "Mobile Money",
                      payment_phone_number: affiliate.payment_phone_number || "",
                    });
                  }}
                  disabled={submitting}
                  className="px-4 py-3 rounded-xl font-semibold transition-colors"
                  style={{ backgroundColor: 'var(--bg-primary)', color: 'var(--text-primary)' }}
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 rounded-xl" style={{ backgroundColor: 'var(--bg-primary)' }}>
                <span className="text-sm" style={{ color: 'var(--text-muted)' }}>Méthode</span>
                <span className="font-semibold" style={{ color: 'var(--text-primary)' }}>
                  {affiliate.payment_method || paymentInfo.payment_method}
                </span>
              </div>
              <div className="flex items-center justify-between p-3 rounded-xl" style={{ backgroundColor: 'var(--bg-primary)' }}>
                <span className="text-sm" style={{ color: 'var(--text-muted)' }}>Numéro</span>
                <span className="font-semibold" style={{ color: 'var(--text-primary)' }}>
                  {affiliate.payment_phone_number || paymentInfo.payment_phone_number || "Non défini"}
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Info Box */}
        <div className="rounded-2xl p-6 border" style={{ backgroundColor: 'rgba(245, 158, 11, 0.1)', borderColor: 'rgba(245, 158, 11, 0.3)' }}>
          <h3 className="font-semibold mb-2" style={{ color: 'var(--warning)' }}>
            ⚠️ Important
          </h3>
          <ul className="space-y-1 text-sm" style={{ color: 'var(--text-secondary)' }}>
            <li>• La modification du code promo met à jour automatiquement tous vos liens d'affiliation</li>
            <li>• Les informations de paiement sont utilisées pour vos demandes de retrait</li>
            <li>• Assurez-vous que les informations sont correctes avant de demander un retrait</li>
          </ul>
        </div>
      </main>

      <BottomNav userRole="affiliate" />
    </div>
  );
}
