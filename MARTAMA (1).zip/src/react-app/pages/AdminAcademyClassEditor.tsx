import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router";
import { ArrowLeft, Plus, Edit, Trash2, Video, ChevronDown, ChevronRight, GripVertical, Link as LinkIcon } from "lucide-react";
import { convertGoogleDriveUrl, getGoogleDriveMessage, isGoogleDriveUrl } from "@/react-app/utils/googleDrive";
import AdminSidebar from "@/react-app/components/AdminSidebar";

interface Module {
  id: number;
  class_id: number;
  title: string;
  description: string | null;
  display_order: number;
}

interface Resource {
  title: string;
  url: string;
  type?: string;
}

interface VideoItem {
  id: number;
  module_id: number;
  class_id: number;
  title: string;
  video_type: string;
  video_url: string;
  aspect_ratio: string;
  duration_minutes: number | null;
  display_order: number;
  resources?: string | null;
}

export default function AdminAcademyClassEditor() {
  const { classId } = useParams();
  const navigate = useNavigate();
  const [modules, setModules] = useState<Module[]>([]);
  const [videos, setVideos] = useState<{ [moduleId: number]: VideoItem[] }>({});
  const [expandedModules, setExpandedModules] = useState<Set<number>>(new Set());
  const [showModuleModal, setShowModuleModal] = useState(false);
  const [showVideoModal, setShowVideoModal] = useState(false);
  const [editingModule, setEditingModule] = useState<Module | null>(null);
  const [editingVideo, setEditingVideo] = useState<VideoItem | null>(null);
  const [selectedModuleId, setSelectedModuleId] = useState<number | null>(null);

  const [moduleForm, setModuleForm] = useState({
    title: "",
    description: "",
    display_order: 0,
  });

  const [videoForm, setVideoForm] = useState({
    title: "",
    video_type: "youtube",
    video_url: "",
    aspect_ratio: "16:9",
    duration_minutes: "",
    display_order: 0,
  });

  const [videoResources, setVideoResources] = useState<Resource[]>([]);

  useEffect(() => {
    const loadFont = () => {
      const link = document.createElement("link");
      link.href = "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap";
      link.rel = "stylesheet";
      document.head.appendChild(link);
    };
    loadFont();
  }, []);

  useEffect(() => {
    fetchModules();
  }, [classId]);

  const fetchModules = async () => {
    try {
      const response = await fetch(`/api/academy/admin/classes/${classId}/modules`);
      if (response.ok) {
        const data = await response.json();
        setModules(data);
        
        // Fetch videos for each module
        for (const module of data) {
          fetchModuleVideos(module.id);
        }
      }
    } catch (error) {
      console.error("Failed to fetch modules:", error);
    }
  };

  const fetchModuleVideos = async (moduleId: number) => {
    try {
      const response = await fetch(`/api/academy/admin/modules/${moduleId}/videos`);
      if (response.ok) {
        const data = await response.json();
        setVideos(prev => ({
          ...prev,
          [moduleId]: data
        }));
      }
    } catch (error) {
      console.error("Failed to fetch videos:", error);
    }
  };

  const handleOpenModuleModal = (module?: Module) => {
    if (module) {
      setEditingModule(module);
      setModuleForm({
        title: module.title,
        description: module.description || "",
        display_order: module.display_order,
      });
    } else {
      setEditingModule(null);
      setModuleForm({
        title: "",
        description: "",
        display_order: modules.length,
      });
    }
    setShowModuleModal(true);
  };

  const handleOpenVideoModal = (moduleId: number, video?: VideoItem) => {
    setSelectedModuleId(moduleId);
    if (video) {
      setEditingVideo(video);
      setVideoForm({
        title: video.title,
        video_type: video.video_type,
        video_url: video.video_url,
        aspect_ratio: video.aspect_ratio,
        duration_minutes: video.duration_minutes?.toString() || "",
        display_order: video.display_order,
      });
      
      // Parse resources if they exist
      if (video.resources) {
        try {
          const parsed = JSON.parse(video.resources);
          setVideoResources(Array.isArray(parsed) ? parsed : []);
        } catch (e) {
          setVideoResources([]);
        }
      } else {
        setVideoResources([]);
      }
    } else {
      setEditingVideo(null);
      const moduleVideos = videos[moduleId] || [];
      setVideoForm({
        title: "",
        video_type: "youtube",
        video_url: "",
        aspect_ratio: "16:9",
        duration_minutes: "",
        display_order: moduleVideos.length,
      });
      setVideoResources([]);
    }
    setShowVideoModal(true);
  };

  const handleSubmitModule = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const url = editingModule 
        ? `/api/academy/admin/modules/${editingModule.id}`
        : "/api/academy/admin/modules";
      
      const response = await fetch(url, {
        method: editingModule ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...moduleForm,
          class_id: classId,
        }),
      });

      if (response.ok) {
        await fetchModules();
        setShowModuleModal(false);
      }
    } catch (error) {
      console.error("Failed to save module:", error);
    }
  };

  const handleSubmitVideo = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const url = editingVideo 
        ? `/api/academy/admin/videos/${editingVideo.id}`
        : "/api/academy/admin/videos";
      
      // Convert Google Drive URL if detected
      const finalVideoUrl = isGoogleDriveUrl(videoForm.video_url)
        ? convertGoogleDriveUrl(videoForm.video_url)
        : videoForm.video_url;
      
      const response = await fetch(url, {
        method: editingVideo ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...videoForm,
          video_url: finalVideoUrl,
          module_id: selectedModuleId,
          class_id: classId,
          duration_minutes: videoForm.duration_minutes ? parseInt(videoForm.duration_minutes) : null,
          resources: videoResources.length > 0 ? videoResources : null,
        }),
      });

      if (response.ok) {
        if (selectedModuleId) {
          await fetchModuleVideos(selectedModuleId);
        }
        setShowVideoModal(false);
      }
    } catch (error) {
      console.error("Failed to save video:", error);
    }
  };

  const handleDeleteModule = async (id: number) => {
    if (!confirm("Êtes-vous sûr de vouloir supprimer ce module et toutes ses vidéos ?")) return;

    try {
      const response = await fetch(`/api/academy/admin/modules/${id}`, {
        method: "DELETE",
      });

      if (response.ok) {
        await fetchModules();
      }
    } catch (error) {
      console.error("Failed to delete module:", error);
    }
  };

  const handleDeleteVideo = async (id: number, moduleId: number) => {
    if (!confirm("Êtes-vous sûr de vouloir supprimer cette vidéo ?")) return;

    try {
      const response = await fetch(`/api/academy/admin/videos/${id}`, {
        method: "DELETE",
      });

      if (response.ok) {
        await fetchModuleVideos(moduleId);
      }
    } catch (error) {
      console.error("Failed to delete video:", error);
    }
  };

  const toggleModule = (moduleId: number) => {
    const newExpanded = new Set(expandedModules);
    if (newExpanded.has(moduleId)) {
      newExpanded.delete(moduleId);
    } else {
      newExpanded.add(moduleId);
    }
    setExpandedModules(newExpanded);
  };

  return (
    <div className="min-h-screen flex" style={{ fontFamily: "'Outfit', sans-serif", backgroundColor: 'var(--bg-primary)' }}>
      <AdminSidebar />
      
      <div className="flex-1">
      {/* Header */}
      <header className="sticky top-0 z-10 px-6 py-4 border-b" style={{ backgroundColor: 'var(--bg-primary)', borderColor: 'var(--border-color)' }}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate("/admin/academy")}
              className="p-2 hover:opacity-80 rounded-xl transition-opacity"
              style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)' }}
            >
              <ArrowLeft className="w-6 h-6" style={{ color: 'var(--primary)' }} />
            </button>
            <div>
              <h1 className="text-xl font-bold" style={{ color: 'var(--text-primary)' }}>
                Gestion du contenu
              </h1>
            </div>
          </div>
          <button
            onClick={() => handleOpenModuleModal()}
            className="flex items-center gap-2 px-6 py-3 rounded-xl font-semibold transition-all text-white"
            style={{ backgroundColor: 'var(--primary)' }}
          >
            <Plus className="w-5 h-5" />
            Nouveau Module
          </button>
        </div>
      </header>

      {/* Content */}
      <main className="px-6 py-8">
        {modules.length === 0 ? (
          <div className="text-center py-20">
            <Video className="w-16 h-16 mx-auto mb-4 opacity-30" style={{ color: 'var(--text-muted)' }} />
            <p className="text-xl mb-4" style={{ color: 'var(--text-muted)' }}>
              Aucun module créé
            </p>
            <button
              onClick={() => handleOpenModuleModal()}
              className="px-6 py-3 rounded-xl font-semibold text-white"
              style={{ backgroundColor: 'var(--primary)' }}
            >
              Créer le premier module
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            {modules.map((module) => {
              const moduleVideos = videos[module.id] || [];
              const isExpanded = expandedModules.has(module.id);
              
              return (
                <div
                  key={module.id}
                  className="rounded-2xl border overflow-hidden"
                  style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}
                >
                  {/* Module Header */}
                  <div className="p-4 flex items-center gap-3">
                    <button
                      onClick={() => toggleModule(module.id)}
                      className="p-2 hover:opacity-80 rounded-lg transition-opacity"
                      style={{ backgroundColor: 'var(--bg-primary)' }}
                    >
                      {isExpanded ? (
                        <ChevronDown className="w-5 h-5" style={{ color: 'var(--text-primary)' }} />
                      ) : (
                        <ChevronRight className="w-5 h-5" style={{ color: 'var(--text-primary)' }} />
                      )}
                    </button>
                    
                    <GripVertical className="w-5 h-5" style={{ color: 'var(--text-muted)' }} />
                    
                    <div className="flex-1">
                      <h3 className="font-semibold" style={{ color: 'var(--text-primary)' }}>
                        {module.title}
                      </h3>
                      <p className="text-sm" style={{ color: 'var(--text-muted)' }}>
                        {moduleVideos.length} vidéo{moduleVideos.length !== 1 ? 's' : ''}
                      </p>
                    </div>
                    
                    <div className="flex gap-2">
                      <button
                        onClick={() => handleOpenVideoModal(module.id)}
                        className="px-4 py-2 rounded-xl font-medium transition-colors text-white"
                        style={{ backgroundColor: 'var(--success)' }}
                      >
                        <Plus className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleOpenModuleModal(module)}
                        className="px-4 py-2 rounded-xl font-medium transition-colors text-white"
                        style={{ backgroundColor: 'var(--info)' }}
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteModule(module.id)}
                        className="px-4 py-2 rounded-xl transition-colors"
                        style={{ backgroundColor: 'rgba(239, 68, 68, 0.1)', color: 'var(--error)' }}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                  
                  {/* Videos List */}
                  {isExpanded && (
                    <div className="border-t p-4 space-y-2" style={{ borderColor: 'var(--border-color)', backgroundColor: 'var(--bg-primary)' }}>
                      {moduleVideos.length === 0 ? (
                        <p className="text-center py-4 text-sm" style={{ color: 'var(--text-muted)' }}>
                          Aucune vidéo dans ce module
                        </p>
                      ) : (
                        moduleVideos.map((video) => (
                          <div
                            key={video.id}
                            className="flex items-center gap-3 p-3 rounded-xl border"
                            style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}
                          >
                            <GripVertical className="w-4 h-4" style={{ color: 'var(--text-muted)' }} />
                            <Video className="w-5 h-5" style={{ color: 'var(--primary)' }} />
                            <div className="flex-1">
                              <p className="font-medium" style={{ color: 'var(--text-primary)' }}>
                                {video.title}
                              </p>
                              <p className="text-xs" style={{ color: 'var(--text-muted)' }}>
                                {video.video_type === 'youtube' && '📺 YouTube'}
                                {video.video_type === 'vimeo' && '🎬 Vimeo'}
                                {video.video_type === 'googledrive' && '☁️ Google Drive'}
                                {video.duration_minutes && ` • ${video.duration_minutes}min`}
                              </p>
                            </div>
                            <div className="flex gap-2">
                              <button
                                onClick={() => handleOpenVideoModal(module.id, video)}
                                className="px-3 py-2 rounded-lg font-medium text-white"
                                style={{ backgroundColor: 'var(--info)' }}
                              >
                                <Edit className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => handleDeleteVideo(video.id, module.id)}
                                className="px-3 py-2 rounded-lg"
                                style={{ backgroundColor: 'rgba(239, 68, 68, 0.1)', color: 'var(--error)' }}
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </main>

      </div>
      
      {/* Module Modal */}
      {showModuleModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-6 z-50">
          <div className="rounded-3xl border p-8 max-w-2xl w-full" style={{ backgroundColor: 'var(--bg-primary)', borderColor: 'var(--border-color)' }}>
            <h3 className="text-2xl font-bold mb-6" style={{ color: 'var(--text-primary)' }}>
              {editingModule ? "Modifier le module" : "Nouveau module"}
            </h3>

            <form onSubmit={handleSubmitModule} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                  Titre du module *
                </label>
                <input
                  type="text"
                  value={moduleForm.title}
                  onChange={(e) => setModuleForm({ ...moduleForm, title: e.target.value })}
                  required
                  placeholder="Ex: Introduction"
                  className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                  style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)', color: 'var(--text-primary)' }}
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                  Description
                </label>
                <textarea
                  value={moduleForm.description}
                  onChange={(e) => setModuleForm({ ...moduleForm, description: e.target.value })}
                  rows={3}
                  className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                  style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)', color: 'var(--text-primary)' }}
                />
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="submit"
                  className="flex-1 px-6 py-3 rounded-xl font-semibold text-white"
                  style={{ backgroundColor: 'var(--primary)' }}
                >
                  {editingModule ? "Mettre à jour" : "Créer"}
                </button>
                <button
                  type="button"
                  onClick={() => setShowModuleModal(false)}
                  className="px-6 py-3 rounded-xl font-semibold"
                  style={{ backgroundColor: 'var(--bg-secondary)', color: 'var(--text-primary)' }}
                >
                  Annuler
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Video Modal */}
      {showVideoModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-6 z-50 overflow-y-auto">
          <div className="rounded-3xl border p-8 max-w-2xl w-full my-8" style={{ backgroundColor: 'var(--bg-primary)', borderColor: 'var(--border-color)' }}>
            <h3 className="text-2xl font-bold mb-6" style={{ color: 'var(--text-primary)' }}>
              {editingVideo ? "Modifier la vidéo" : "Nouvelle vidéo"}
            </h3>

            <form onSubmit={handleSubmitVideo} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                  Titre de la vidéo *
                </label>
                <input
                  type="text"
                  value={videoForm.title}
                  onChange={(e) => setVideoForm({ ...videoForm, title: e.target.value })}
                  required
                  placeholder="Ex: Leçon 1 - Les bases"
                  className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                  style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)', color: 'var(--text-primary)' }}
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                  Type de vidéo *
                </label>
                <select
                  value={videoForm.video_type}
                  onChange={(e) => setVideoForm({ ...videoForm, video_type: e.target.value })}
                  className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                  style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)', color: 'var(--text-primary)' }}
                >
                  <option value="youtube">YouTube</option>
                  <option value="vimeo">Vimeo</option>
                  <option value="googledrive">Google Drive</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                  URL de la vidéo *
                </label>
                <input
                  type="url"
                  value={videoForm.video_url}
                  onChange={(e) => setVideoForm({ ...videoForm, video_url: e.target.value })}
                  required
                  placeholder={
                    videoForm.video_type === 'youtube' ? 'https://youtube.com/watch?v=...' :
                    videoForm.video_type === 'vimeo' ? 'https://vimeo.com/...' :
                    'https://drive.google.com/file/d/.../view'
                  }
                  className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2 font-mono text-sm"
                  style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)', color: 'var(--text-primary)' }}
                />
                {videoForm.video_url && isGoogleDriveUrl(videoForm.video_url) && (
                  <p className="text-xs mt-2 font-medium" style={{ color: 'var(--success)' }}>
                    {getGoogleDriveMessage(videoForm.video_url)}
                  </p>
                )}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                    Ratio d'aspect
                  </label>
                  <select
                    value={videoForm.aspect_ratio}
                    onChange={(e) => setVideoForm({ ...videoForm, aspect_ratio: e.target.value })}
                    className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                    style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)', color: 'var(--text-primary)' }}
                  >
                    <option value="16:9">16:9 (Standard)</option>
                    <option value="4:3">4:3 (Classique)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                    Durée (minutes)
                  </label>
                  <input
                    type="number"
                    value={videoForm.duration_minutes}
                    onChange={(e) => setVideoForm({ ...videoForm, duration_minutes: e.target.value })}
                    min="0"
                    placeholder="Ex: 15"
                    className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                    style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)', color: 'var(--text-primary)' }}
                  />
                </div>
              </div>

              {/* Resources Section */}
              <div className="border rounded-xl p-4" style={{ borderColor: 'var(--border-color)', backgroundColor: 'var(--bg-secondary)' }}>
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h4 className="text-base font-semibold" style={{ color: 'var(--text-primary)' }}>🔗 Liens et Ressources</h4>
                    <p className="text-xs mt-0.5" style={{ color: 'var(--text-muted)' }}>Ajoutez des liens utiles sous la vidéo</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setVideoResources([...videoResources, { title: '', url: '' }])}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium text-sm text-white"
                    style={{ backgroundColor: 'var(--success)' }}
                  >
                    <Plus className="w-4 h-4" />
                    Ajouter
                  </button>
                </div>

                {videoResources.length === 0 ? (
                  <div className="text-center py-6 border-2 border-dashed rounded-lg" style={{ borderColor: 'var(--border-color)' }}>
                    <LinkIcon className="w-8 h-8 mx-auto mb-2 opacity-30" style={{ color: 'var(--text-muted)' }} />
                    <p className="text-sm" style={{ color: 'var(--text-muted)' }}>Aucun lien ajouté</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {videoResources.map((resource, index) => (
                      <div key={index} className="border rounded-lg p-3" style={{ borderColor: 'var(--border-color)', backgroundColor: 'var(--bg-primary)' }}>
                        <div className="grid gap-3 mb-2">
                          <input
                            type="text"
                            value={resource.title}
                            onChange={(e) => {
                              const newResources = [...videoResources];
                              newResources[index].title = e.target.value;
                              setVideoResources(newResources);
                            }}
                            placeholder="Titre du lien (ex: Documentation officielle)"
                            className="w-full px-3 py-2 border rounded-lg focus:outline-none text-sm"
                            style={{ 
                              backgroundColor: 'var(--bg-secondary)', 
                              borderColor: 'var(--border-color)', 
                              color: 'var(--text-primary)'
                            }}
                          />
                          <input
                            type="url"
                            value={resource.url}
                            onChange={(e) => {
                              const newResources = [...videoResources];
                              newResources[index].url = e.target.value;
                              setVideoResources(newResources);
                            }}
                            placeholder="https://example.com"
                            className="w-full px-3 py-2 border rounded-lg focus:outline-none text-sm font-mono"
                            style={{ 
                              backgroundColor: 'var(--bg-secondary)', 
                              borderColor: 'var(--border-color)', 
                              color: 'var(--text-primary)'
                            }}
                          />
                        </div>
                        <button
                          type="button"
                          onClick={() => setVideoResources(videoResources.filter((_, i) => i !== index))}
                          className="w-full py-1.5 border rounded-lg text-xs font-medium transition-colors"
                          style={{ backgroundColor: 'rgba(239, 68, 68, 0.1)', color: 'var(--error)', borderColor: 'rgba(239, 68, 68, 0.3)' }}
                        >
                          Supprimer
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="submit"
                  className="flex-1 px-6 py-3 rounded-xl font-semibold text-white"
                  style={{ backgroundColor: 'var(--primary)' }}
                >
                  {editingVideo ? "Mettre à jour" : "Ajouter"}
                </button>
                <button
                  type="button"
                  onClick={() => setShowVideoModal(false)}
                  className="px-6 py-3 rounded-xl font-semibold"
                  style={{ backgroundColor: 'var(--bg-secondary)', color: 'var(--text-primary)' }}
                >
                  Annuler
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
