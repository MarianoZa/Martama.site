import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "@getmocha/users-service/react";
import Header from "@/react-app/components/Header";
import BottomNav from "@/react-app/components/BottomNav";
import StatusBadge from "@/react-app/components/StatusBadge";
import { useToast } from "@/react-app/hooks/useToast";
import { 
  DollarSign,
  CreditCard,
  Clock,
  CheckCircle,
  X,
  AlertCircle,
  Wallet,
  Shield
} from "lucide-react";
import { formatDateTimeBenin } from "@/react-app/utils/dateFormatter";

interface WithdrawalRequest {
  id: number;
  amount: number;
  payment_method: string;
  payment_details: string | null;
  status: string;
  processed_at: string | null;
  created_at: string;
}

interface AffiliateStats {
  id: number;
  promo_code: string;
  balance: number;
  total_commissions: number;
  payment_phone_number?: string;
}

export default function AffiliateWithdrawal() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const toast = useToast();
  const [stats, setStats] = useState<AffiliateStats | null>(null);
  const [requests, setRequests] = useState<WithdrawalRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const [formData, setFormData] = useState({
    amount: "",
    payment_method: "",
    payment_details: ""
  });

  useEffect(() => {
    const loadFont = () => {
      const link = document.createElement("link");
      link.href = "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap";
      link.rel = "stylesheet";
      document.head.appendChild(link);
    };
    loadFont();
  }, []);

  useEffect(() => {
    if (user) {
      fetchAffiliateData();
    }
  }, [user]);

  const fetchAffiliateData = async () => {
    try {
      setLoading(true);
      
      // Get affiliate stats
      const statsResponse = await fetch("/api/affiliate/stats");
      if (statsResponse.status === 404) {
        navigate("/become-affiliate");
        return;
      }
      const statsData = await statsResponse.json();
      setStats(statsData);
      
      // Get withdrawal requests
      const requestsResponse = await fetch("/api/affiliate/withdrawal-requests");
      if (requestsResponse.ok) {
        const requestsData = await requestsResponse.json();
        setRequests(requestsData);
      }
    } catch (error) {
      console.error("Failed to fetch affiliate data:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!stats) return;
    
    const amount = parseFloat(formData.amount);
    
    // Validate amount
    if (isNaN(amount) || amount < 2000) {
      toast.error("Le montant minimum de retrait est de 2000 FCFA");
      return;
    }
    
    if (amount > stats.balance) {
      toast.error("Solde insuffisant");
      return;
    }
    
    if (!formData.payment_method || !formData.payment_details) {
      toast.error("Veuillez remplir tous les champs");
      return;
    }
    
    try {
      setSubmitting(true);
      
      const response = await fetch("/api/affiliate/withdrawal-requests", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          amount,
          payment_method: formData.payment_method,
          payment_details: formData.payment_details
        })
      });
      
      if (response.ok) {
        toast.success("Demande de retrait soumise avec succès !");
        setShowModal(false);
        setFormData({ amount: "", payment_method: "", payment_details: "" });
        await fetchAffiliateData();
      } else {
        const error = await response.json();
        toast.error(error.error || "Échec de la soumission");
      }
    } catch (error) {
      console.error("Failed to submit withdrawal request:", error);
      toast.error("Une erreur s'est produite");
    } finally {
      setSubmitting(false);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case "approved":
        return <CheckCircle className="w-4 h-4 text-blue-500" />;
      case "pending":
        return <Clock className="w-4 h-4 text-amber-500" />;
      case "rejected":
        return <X className="w-4 h-4 text-red-500" />;
      default:
        return null;
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: 'var(--bg-primary)' }}>
        <div className="text-center">
          <p className="text-xl mb-4" style={{ color: 'var(--text-primary)' }}>Veuillez vous connecter</p>
          <button
            onClick={() => navigate("/")}
            className="px-6 py-3 rounded-xl font-semibold"
            style={{ backgroundColor: 'var(--primary)', color: '#ffffff' }}
          >
            Retour à l'accueil
          </button>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: 'var(--bg-primary)' }}>
        <div className="w-12 h-12 border-4 rounded-full animate-spin" style={{ borderColor: 'var(--gray-200)', borderTopColor: 'var(--primary)' }}></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-20" style={{ fontFamily: "'Outfit', sans-serif", backgroundColor: 'var(--bg-primary)' }}>
      <Header showBackButton onBack={() => navigate("/affiliate/dashboard")} />

      <main className="px-4 sm:px-6 py-6 sm:py-8 max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-2xl sm:text-3xl font-bold mb-2" style={{ color: 'var(--text-primary)' }}>
            Demande de Retrait
          </h1>
          <p className="text-sm sm:text-base" style={{ color: 'var(--text-secondary)' }}>
            Retirez vos commissions vers votre compte
          </p>
        </div>

        {/* Balance Card */}
        <div className="rounded-2xl p-6 mb-6 border relative overflow-hidden" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
          {/* Subtle Green Accent Background */}
          <div className="absolute inset-0 opacity-5" style={{ background: 'linear-gradient(135deg, rgba(34, 197, 94, 0.3) 0%, rgba(59, 130, 246, 0.3) 100%)' }}></div>
          
          {/* Security Badge - Subtle */}
          <div className="absolute top-4 right-4 flex items-center gap-1.5 px-2.5 py-1 rounded-lg border" style={{ backgroundColor: 'rgba(34, 197, 94, 0.08)', borderColor: 'rgba(34, 197, 94, 0.2)' }}>
            <Shield className="w-3.5 h-3.5 text-green-600" />
            <span className="text-xs font-medium text-green-700">Sécurisé</span>
          </div>

          <div className="mb-4 relative">
            <div className="flex items-center gap-2 mb-1">
              <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ backgroundColor: 'rgba(34, 197, 94, 0.1)' }}>
                <Wallet className="w-4 h-4 text-green-600" />
              </div>
              <div>
                <span className="text-sm font-semibold" style={{ color: 'var(--text-primary)' }}>Solde Disponible</span>
                <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>Protégé et disponible 24/7</p>
              </div>
            </div>
          </div>

          <div className="mb-6 relative">
            <div className="text-4xl sm:text-5xl font-bold mb-2" style={{ color: 'var(--text-primary)' }}>
              {stats?.balance.toLocaleString() || 0} <span className="text-2xl sm:text-3xl" style={{ color: 'var(--text-secondary)' }}>F</span>
            </div>
            <div className="flex items-center gap-2 text-sm" style={{ color: 'var(--text-secondary)' }}>
              <div className="w-5 h-5 rounded-full flex items-center justify-center" style={{ backgroundColor: 'rgba(34, 197, 94, 0.1)' }}>
                <CheckCircle className="w-3 h-3 text-green-600" />
              </div>
              <span>Total commissions: <span className="font-semibold" style={{ color: 'var(--text-primary)' }}>{stats?.total_commissions.toLocaleString() || 0} F</span></span>
            </div>
          </div>

          <button
            onClick={() => {
              if (stats && stats.balance < 2000) {
                toast.error("Solde insuffisant. Minimum requis: 2000 FCFA");
                return;
              }
              setShowModal(true);
            }}
            disabled={!stats || stats.balance < 2000}
            className="w-full px-6 py-3 sm:py-4 rounded-xl font-bold text-base sm:text-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 hover:scale-[1.02] active:scale-[0.98] text-white relative overflow-hidden"
            style={{ background: 'linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%)', boxShadow: '0 4px 12px rgba(139, 92, 246, 0.2)' }}
          >
            <DollarSign className="w-5 h-5" />
            Demander un retrait
            {/* Subtle green shine effect */}
            <div className="absolute inset-0 opacity-0 hover:opacity-10 transition-opacity" style={{ background: 'linear-gradient(135deg, transparent 0%, rgba(34, 197, 94, 0.5) 50%, transparent 100%)' }}></div>
          </button>
          {stats && stats.balance < 2000 && (
            <div className="mt-3 flex items-center justify-center gap-2 text-xs" style={{ color: 'var(--text-muted)' }}>
              <AlertCircle className="w-4 h-4" />
              <span>Minimum 2,000 F requis pour un retrait</span>
            </div>
          )}
        </div>

        {/* Info Alert */}
        <div className="rounded-2xl p-4 mb-6 border flex items-start gap-3" style={{ backgroundColor: 'rgba(59, 130, 246, 0.1)', borderColor: 'rgba(59, 130, 246, 0.3)' }}>
          <AlertCircle className="w-5 h-5 flex-shrink-0 text-blue-500 mt-0.5" />
          <div>
            <h4 className="text-sm font-semibold mb-1" style={{ color: 'var(--text-primary)' }}>
              Informations importantes
            </h4>
            <p className="text-xs leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
              • Le montant minimum de retrait est de 2,000 FCFA<br />
              • Les demandes sont traitées sous 24-48h<br />
              • Vérifiez bien vos coordonnées de paiement<br />
              • Les frais éventuels sont à votre charge
            </p>
          </div>
        </div>

        {/* Withdrawal Requests List */}
        <div className="mb-6">
          <h2 className="text-lg sm:text-xl font-bold mb-4" style={{ color: 'var(--text-primary)' }}>
            Historique des demandes
          </h2>

          {requests.length === 0 ? (
            <div className="rounded-2xl p-8 border text-center" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
              <div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4" style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)' }}>
                <CreditCard className="w-8 h-8" style={{ color: 'var(--primary)' }} />
              </div>
              <h3 className="text-lg font-bold mb-2" style={{ color: 'var(--text-primary)' }}>
                Aucune demande de retrait
              </h3>
              <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
                Vos demandes de retrait apparaîtront ici
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {requests.map((request) => (
                <div
                  key={request.id}
                  className="rounded-2xl p-4 sm:p-5 border"
                  style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}
                >
                  {/* Header */}
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-2">
                      {getStatusIcon(request.status)}
                      <div>
                        <h3 className="text-sm sm:text-base font-bold" style={{ color: 'var(--text-primary)' }}>
                          {request.amount.toLocaleString()} F
                        </h3>
                        <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>
                          {request.payment_method}
                        </p>
                      </div>
                    </div>
                    <StatusBadge status={request.status} />
                  </div>

                  {/* Details */}
                  <div className="space-y-2 text-xs sm:text-sm">
                    <div className="flex justify-between">
                      <span style={{ color: 'var(--text-muted)' }}>Demandé le:</span>
                      <span className="font-medium" style={{ color: 'var(--text-primary)' }}>
                        {formatDateTimeBenin(request.created_at)}
                      </span>
                    </div>
                    {request.processed_at && (
                      <div className="flex justify-between">
                        <span style={{ color: 'var(--text-muted)' }}>Traité le:</span>
                        <span className="font-medium" style={{ color: 'var(--text-primary)' }}>
                          {formatDateTimeBenin(request.processed_at)}
                        </span>
                      </div>
                    )}
                    {request.payment_details && (
                      <div className="flex justify-between">
                        <span style={{ color: 'var(--text-muted)' }}>Détails:</span>
                        <span className="font-medium font-mono" style={{ color: 'var(--text-primary)' }}>
                          {request.payment_details}
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>

      {/* Withdrawal Request Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="rounded-3xl border p-6 sm:p-8 max-w-md w-full" style={{ backgroundColor: 'var(--bg-primary)', borderColor: 'var(--border-color)' }}>
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl sm:text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>
                Nouvelle demande
              </h3>
              <button
                onClick={() => setShowModal(false)}
                className="p-2 hover:opacity-80 rounded-xl transition-opacity"
                style={{ backgroundColor: 'var(--bg-secondary)' }}
              >
                <X className="w-6 h-6" style={{ color: 'var(--text-primary)' }} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                  Montant à retirer (FCFA) *
                </label>
                <input
                  type="number"
                  min="2000"
                  max={stats?.balance}
                  value={formData.amount}
                  onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                  required
                  placeholder="2000"
                  className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                  style={{ 
                    backgroundColor: 'var(--bg-secondary)', 
                    borderColor: 'var(--border-color)', 
                    color: 'var(--text-primary)',
                    '--tw-ring-color': 'var(--primary)'
                  } as any}
                />
                <p className="text-xs mt-1" style={{ color: 'var(--text-muted)' }}>
                  Disponible: {stats?.balance.toLocaleString()} F
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                  Méthode de paiement *
                </label>
                <select
                  value={formData.payment_method}
                  onChange={(e) => {
                    setFormData({ 
                      ...formData, 
                      payment_method: e.target.value,
                      payment_details: e.target.value && stats?.payment_phone_number ? stats.payment_phone_number : ""
                    });
                  }}
                  required
                  className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                  style={{ 
                    backgroundColor: 'var(--bg-secondary)', 
                    borderColor: 'var(--border-color)', 
                    color: 'var(--text-primary)',
                    '--tw-ring-color': 'var(--primary)'
                  } as any}
                >
                  <option value="">Sélectionnez...</option>
                  <option value="Moov Money">Moov Money</option>
                  <option value="MTN Mobile Money">MTN Mobile Money</option>
                  <option value="Wave">Wave</option>
                  <option value="Celtiis">Celtiis</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                  Numéro de téléphone *
                </label>
                <input
                  type="tel"
                  value={formData.payment_details}
                  onChange={(e) => setFormData({ ...formData, payment_details: e.target.value })}
                  required
                  placeholder="+229 XX XX XX XX"
                  className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                  style={{ 
                    backgroundColor: 'var(--bg-secondary)', 
                    borderColor: 'var(--border-color)', 
                    color: 'var(--text-primary)',
                    '--tw-ring-color': 'var(--primary)'
                  } as any}
                />
              </div>

              <div className="flex gap-3 pt-4 border-t" style={{ borderColor: 'var(--border-color)' }}>
                <button
                  type="submit"
                  disabled={submitting}
                  className="flex-1 px-6 py-3 rounded-xl font-semibold transition-all disabled:opacity-50 text-white"
                  style={{ backgroundColor: 'var(--primary)' }}
                >
                  {submitting ? "En cours..." : "Soumettre"}
                </button>
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-6 py-3 rounded-xl font-semibold transition-all"
                  style={{ backgroundColor: 'var(--bg-secondary)', color: 'var(--text-primary)' }}
                >
                  Annuler
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <BottomNav 
        isAffiliate={true}
        affiliateCode={stats?.promo_code}
      />
    </div>
  );
}
