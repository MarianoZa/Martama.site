import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "@getmocha/users-service/react";
import Header from "@/react-app/components/Header";
import { User, Mail, Phone, Save, Shield } from "lucide-react";

interface UserProfile {
  id: string;
  email: string;
  full_name: string | null;
  phone_number: string | null;
  role: string;
  preferred_categories: string | null;
}

export default function UserProfile() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [fullName, setFullName] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");

  useEffect(() => {
    const loadFont = () => {
      const link = document.createElement("link");
      link.href = "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap";
      link.rel = "stylesheet";
      document.head.appendChild(link);
    };
    loadFont();
  }, []);

  useEffect(() => {
    if (user) {
      fetchProfile();
    }
  }, [user]);

  const fetchProfile = async () => {
    try {
      setLoading(true);
      const response = await fetch("/api/users/me");
      const data = await response.json();
      setProfile(data);
      setFullName(data.full_name || "");
      setPhoneNumber(data.phone_number || "");
    } catch (error) {
      console.error("Failed to fetch profile:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    try {
      setSaving(true);
      setMessage("");
      
      const response = await fetch("/api/users/profile", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          full_name: fullName || null,
          phone_number: phoneNumber || null,
        }),
      });

      if (response.ok) {
        setMessage("Profil mis à jour avec succès");
        await fetchProfile();
        setTimeout(() => setMessage(""), 3000);
      } else {
        setMessage("Erreur lors de la mise à jour");
      }
    } catch (error) {
      console.error("Failed to update profile:", error);
      setMessage("Erreur lors de la mise à jour");
    } finally {
      setSaving(false);
    }
  };

  if (!user || loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-indigo-900 flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-white/20 border-t-white rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-indigo-900" style={{ fontFamily: "'Outfit', sans-serif" }}>
      <Header showBackButton onBack={() => navigate("/dashboard")} />

      <main className="px-6 py-12 max-w-3xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">Mon Profil</h1>
          <p className="text-purple-200 text-lg">Gérez vos informations personnelles</p>
        </div>

        <div className="bg-white/5 backdrop-blur-md rounded-3xl border border-white/10 p-8">
          {/* Role Badge */}
          <div className="mb-8 flex items-center gap-3">
            <div className="w-16 h-16 bg-gradient-to-br from-purple-400 to-pink-500 rounded-2xl flex items-center justify-center">
              <User className="w-8 h-8 text-white" />
            </div>
            <div>
              <p className="text-purple-200 text-sm">Statut du compte</p>
              <div className="flex items-center gap-2">
                <span className="text-white text-xl font-bold capitalize">{profile?.role}</span>
                {profile?.role === 'admin' && (
                  <Shield className="w-5 h-5 text-orange-400" />
                )}
              </div>
            </div>
          </div>

          {/* Form Fields */}
          <div className="space-y-6">
            {/* Email (read-only) */}
            <div>
              <label className="block text-purple-300 text-sm font-medium mb-2">
                Email
              </label>
              <div className="relative">
                <div className="absolute left-4 top-1/2 -translate-y-1/2">
                  <Mail className="w-5 h-5 text-purple-400" />
                </div>
                <input
                  type="email"
                  value={profile?.email || ""}
                  disabled
                  className="w-full pl-12 pr-4 py-3 bg-white/5 border border-white/20 rounded-xl text-white/50 cursor-not-allowed"
                />
              </div>
              <p className="text-purple-300 text-xs mt-1">L'email ne peut pas être modifié</p>
            </div>

            {/* Full Name */}
            <div>
              <label className="block text-purple-300 text-sm font-medium mb-2">
                Nom Complet
              </label>
              <div className="relative">
                <div className="absolute left-4 top-1/2 -translate-y-1/2">
                  <User className="w-5 h-5 text-purple-400" />
                </div>
                <input
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="Votre nom complet"
                  className="w-full pl-12 pr-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-purple-300/50 focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
              </div>
            </div>

            {/* Phone Number */}
            <div>
              <label className="block text-purple-300 text-sm font-medium mb-2">
                Numéro de Téléphone
              </label>
              <div className="relative">
                <div className="absolute left-4 top-1/2 -translate-y-1/2">
                  <Phone className="w-5 h-5 text-purple-400" />
                </div>
                <input
                  type="tel"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  placeholder="+221 XX XXX XX XX"
                  className="w-full pl-12 pr-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-purple-300/50 focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
              </div>
            </div>

            {/* Success Message */}
            {message && (
              <div className={`p-4 rounded-xl ${
                message.includes('succès') 
                  ? 'bg-green-500/20 border border-green-500/30 text-green-300' 
                  : 'bg-red-500/20 border border-red-500/30 text-red-300'
              }`}>
                {message}
              </div>
            )}

            {/* Save Button */}
            <button
              onClick={handleSave}
              disabled={saving}
              className="w-full flex items-center justify-center gap-2 px-6 py-4 bg-white text-purple-900 rounded-2xl font-bold text-lg hover:bg-purple-50 transition-all duration-300 shadow-2xl hover:shadow-purple-500/50 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Save className="w-5 h-5" />
              {saving ? "Enregistrement..." : "Enregistrer les modifications"}
            </button>
          </div>
        </div>

        {/* Account Info */}
        <div className="mt-8 bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Informations du compte</h3>
          <div className="space-y-3 text-sm">
            <div className="flex justify-between">
              <span className="text-purple-300">ID Utilisateur</span>
              <span className="text-white font-mono">{profile?.id.substring(0, 8)}...</span>
            </div>
            <div className="flex justify-between">
              <span className="text-purple-300">Type de compte</span>
              <span className="text-white capitalize">{profile?.role}</span>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
