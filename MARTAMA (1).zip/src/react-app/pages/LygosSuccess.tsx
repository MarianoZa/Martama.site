import { useEffect, useState } from "react";
import { useNavigate, useSearchParams } from "react-router";
import { CheckCircle, Loader } from "lucide-react";
import Header from "@/react-app/components/Header";
import Footer from "@/react-app/components/Footer";

export default function LygosSuccess() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [verifying, setVerifying] = useState(true);
  const [verified, setVerified] = useState(false);
  const [error, setError] = useState("");
  const [orderDetails, setOrderDetails] = useState<any>(null);

  useEffect(() => {
    const loadFont = () => {
      const link = document.createElement("link");
      link.href = "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap";
      link.rel = "stylesheet";
      document.head.appendChild(link);
    };
    loadFont();
  }, []);

  useEffect(() => {
    verifyPayment();
  }, []);

  const verifyPayment = async () => {
    const orderId = searchParams.get("order_id");

    if (!orderId) {
      setError("Identifiant de commande manquant");
      setVerifying(false);
      return;
    }

    try {
      setVerifying(true);

      // Call backend to verify payment with Lygospay
      const response = await fetch(`/api/verify-lygos-payment/${orderId}`);

      if (!response.ok) {
        const errorData = await response.json();
        setError(errorData.error || "Erreur lors de la vérification du paiement");
        setVerifying(false);
        return;
      }

      const data = await response.json();

      if (data.status === "success") {
        setVerified(true);
        setOrderDetails(data.order);

        // Store order info for post-auth redirect if needed
        if (data.order.customer_email) {
          localStorage.setItem('recent_order', JSON.stringify({
            email: data.order.customer_email,
            order_id: data.order.id,
            status: 'paid'
          }));
        }
      } else {
        setError("Le paiement n'a pas encore été confirmé. Veuillez patienter ou contactez le support.");
      }

      setVerifying(false);
    } catch (err) {
      console.error("Verification error:", err);
      setError("Erreur lors de la vérification du paiement");
      setVerifying(false);
    }
  };

  const handleContinue = () => {
    if (orderDetails?.customer_email) {
      // Check if user needs to authenticate
      window.location.href = `/auth/post-purchase?email=${encodeURIComponent(orderDetails.customer_email)}`;
    } else {
      navigate("/");
    }
  };

  return (
    <div className="min-h-screen flex flex-col" style={{ fontFamily: "'Outfit', sans-serif", backgroundColor: 'var(--bg-primary)' }}>
      <Header />

      <main className="flex-1 px-6 py-16 flex items-center justify-center">
        <div className="max-w-md w-full text-center">
          {verifying ? (
            <>
              <div className="w-20 h-20 mx-auto mb-6 flex items-center justify-center">
                <Loader className="w-20 h-20 animate-spin" style={{ color: 'var(--primary)' }} />
              </div>
              <h1 className="text-3xl font-bold mb-4" style={{ color: 'var(--text-primary)' }}>
                Vérification du paiement...
              </h1>
              <p className="text-lg" style={{ color: 'var(--text-secondary)' }}>
                Veuillez patienter pendant que nous confirmons votre paiement avec Lygospay.
              </p>
            </>
          ) : verified ? (
            <>
              <div 
                className="w-20 h-20 mx-auto mb-6 rounded-full flex items-center justify-center"
                style={{ backgroundColor: 'rgba(16, 185, 129, 0.1)' }}
              >
                <CheckCircle className="w-16 h-16" style={{ color: 'var(--success)' }} />
              </div>
              <h1 className="text-3xl font-bold mb-4" style={{ color: 'var(--text-primary)' }}>
                Paiement réussi !
              </h1>
              <p className="text-lg mb-8" style={{ color: 'var(--text-secondary)' }}>
                Votre paiement a été confirmé avec succès. Vous allez recevoir vos accès par email sous peu.
              </p>

              {orderDetails && (
                <div 
                  className="rounded-2xl p-6 mb-8 text-left"
                  style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}
                >
                  <h3 className="font-bold mb-4" style={{ color: 'var(--text-primary)' }}>
                    Détails de la commande
                  </h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span style={{ color: 'var(--text-secondary)' }}>Commande #</span>
                      <span className="font-semibold" style={{ color: 'var(--text-primary)' }}>
                        {orderDetails.id}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span style={{ color: 'var(--text-secondary)' }}>Email</span>
                      <span className="font-semibold" style={{ color: 'var(--text-primary)' }}>
                        {orderDetails.customer_email}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span style={{ color: 'var(--text-secondary)' }}>Montant</span>
                      <span className="font-semibold text-xl" style={{ color: 'var(--success)' }}>
                        {Number(orderDetails.amount).toLocaleString()} FCFA
                      </span>
                    </div>
                  </div>
                </div>
              )}

              <button
                onClick={handleContinue}
                className="w-full px-8 py-4 rounded-2xl font-bold text-lg text-white transition-all"
                style={{ backgroundColor: 'var(--primary)' }}
              >
                Accéder à mes achats
              </button>

              <p className="text-sm mt-6" style={{ color: 'var(--text-muted)' }}>
                Un email de confirmation a été envoyé à {orderDetails?.customer_email}
              </p>
            </>
          ) : (
            <>
              <div 
                className="w-20 h-20 mx-auto mb-6 rounded-full flex items-center justify-center"
                style={{ backgroundColor: 'rgba(245, 158, 11, 0.1)' }}
              >
                <svg className="w-16 h-16" style={{ color: 'var(--warning)' }} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                </svg>
              </div>
              <h1 className="text-3xl font-bold mb-4" style={{ color: 'var(--text-primary)' }}>
                Vérification en cours
              </h1>
              <p className="text-lg mb-8" style={{ color: 'var(--text-secondary)' }}>
                {error || "Le paiement est en cours de traitement. Veuillez patienter quelques instants."}
              </p>

              <div className="flex flex-col gap-3">
                <button
                  onClick={verifyPayment}
                  className="w-full px-8 py-4 rounded-2xl font-bold text-lg text-white transition-all"
                  style={{ backgroundColor: 'var(--primary)' }}
                >
                  Vérifier à nouveau
                </button>

                <button
                  onClick={() => navigate("/")}
                  className="w-full px-8 py-4 rounded-2xl font-bold text-lg transition-all"
                  style={{ backgroundColor: 'var(--bg-secondary)', color: 'var(--text-primary)' }}
                >
                  Retour à l'accueil
                </button>
              </div>

              <p className="text-sm mt-6" style={{ color: 'var(--text-muted)' }}>
                Si le problème persiste, contactez-nous sur WhatsApp : +229 51 66 13 57
              </p>
            </>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
}
