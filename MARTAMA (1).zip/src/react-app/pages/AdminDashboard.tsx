import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "@getmocha/users-service/react";
import { 
  ArrowLeft, 
  Package, 
  DollarSign, 
  Users, 
  TrendingUp,
  ShoppingCart,
  AlertCircle
} from "lucide-react";

interface DashboardStats {
  orders: {
    total: number;
    pending: number;
    paid: number;
  };
  revenue: {
    total: number;
  };
  affiliates: {
    total: number;
    pending_requests: number;
  };
}

export default function AdminDashboard() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadFont = () => {
      const link = document.createElement("link");
      link.href = "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap";
      link.rel = "stylesheet";
      document.head.appendChild(link);
    };
    loadFont();
  }, []);

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      setLoading(true);
      const response = await fetch("/api/admin/stats");
      
      if (response.status === 403) {
        navigate("/");
        return;
      }
      
      const data = await response.json();
      setStats(data);
    } catch (error) {
      console.error("Failed to fetch stats:", error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-indigo-900 flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-white/20 border-t-white rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-indigo-900" style={{ fontFamily: "'Outfit', sans-serif" }}>
      {/* Header */}
      <header className="px-6 py-6 max-w-7xl mx-auto">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate("/")}
              className="p-2 hover:bg-white/10 rounded-xl transition-colors"
            >
              <ArrowLeft className="w-6 h-6 text-white" />
            </button>
            <div>
              <h1 className="text-2xl font-bold text-white">Tableau de Bord Admin</h1>
              <p className="text-purple-200 text-sm">Gérez votre plateforme Martama</p>
            </div>
          </div>
          {user && (
            <div className="text-white text-sm text-right">
              <span className="opacity-75">Admin</span>
              <div className="font-semibold">{user.email}</div>
            </div>
          )}
        </div>
      </header>

      {/* Stats Grid */}
      <main className="px-6 py-8 max-w-7xl mx-auto">
        {/* Overview Section */}
        <div className="mb-8">
          <h2 className="text-lg font-semibold text-white mb-1">Vue d'overview de votre plateforme</h2>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {/* CA Total */}
          <div className="bg-white/5 backdrop-blur-md rounded-3xl border border-white/10 p-6 hover:bg-white/10 transition-all">
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-purple-300 text-sm mb-1">CA Total</p>
                <div className="text-3xl font-bold text-white">
                  {stats?.revenue.total.toLocaleString() || 0} FCFA
                </div>
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-green-400/20 to-green-600/20 rounded-2xl flex items-center justify-center">
                <DollarSign className="w-6 h-6 text-green-400" />
              </div>
            </div>
            <div className="text-green-400 text-sm flex items-center gap-1">
              <TrendingUp className="w-4 h-4" />
              <span>+10.2% depuis le mois dernier</span>
            </div>
          </div>

          {/* Ventes du jour */}
          <div className="bg-white/5 backdrop-blur-md rounded-3xl border border-white/10 p-6 hover:bg-white/10 transition-all">
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-purple-300 text-sm mb-1">Ventes du jour</p>
                <div className="text-3xl font-bold text-white">
                  {stats?.orders.total || 0}
                </div>
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-purple-400/20 to-purple-600/20 rounded-2xl flex items-center justify-center">
                <ShoppingCart className="w-6 h-6 text-purple-400" />
              </div>
            </div>
            <div className="text-green-400 text-sm flex items-center gap-1">
              <TrendingUp className="w-4 h-4" />
              <span>+15.3% depuis hier</span>
            </div>
          </div>

          {/* Nouveaux clients */}
          <div className="bg-white/5 backdrop-blur-md rounded-3xl border border-white/10 p-6 hover:bg-white/10 transition-all">
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-purple-300 text-sm mb-1">Nouveaux clients</p>
                <div className="text-3xl font-bold text-white">
                  0
                </div>
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-blue-400/20 to-blue-600/20 rounded-2xl flex items-center justify-center">
                <Users className="w-6 h-6 text-blue-400" />
              </div>
            </div>
            <div className="text-green-400 text-sm flex items-center gap-1">
              <TrendingUp className="w-4 h-4" />
              <span>+5 aujourd'hui</span>
            </div>
          </div>

          {/* Affiliés Actifs */}
          <div className="bg-white/5 backdrop-blur-md rounded-3xl border border-white/10 p-6 hover:bg-white/10 transition-all">
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-purple-300 text-sm mb-1">Affiliés Actifs</p>
                <div className="text-3xl font-bold text-white">
                  {stats?.affiliates.total || 0}
                </div>
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-orange-400/20 to-orange-600/20 rounded-2xl flex items-center justify-center">
                <Users className="w-6 h-6 text-orange-400" />
              </div>
            </div>
            <div className="text-green-400 text-sm flex items-center gap-1">
              <TrendingUp className="w-4 h-4" />
              <span>+2 depuis le mois dernier</span>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-white mb-6">Accès rapides</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            <button
              onClick={() => navigate("/admin/payments")}
              className="p-6 bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 hover:bg-white/10 transition-all text-left group"
            >
              <div className="w-12 h-12 bg-purple-500/20 rounded-2xl flex items-center justify-center mb-3">
                <DollarSign className="w-6 h-6 text-purple-300 group-hover:text-white transition-colors" />
              </div>
              <h3 className="text-lg font-semibold text-white mb-1">Gestion des Paiements</h3>
              <p className="text-purple-200 text-sm">Approuver, rejeter et suivre les demandes de retrait.</p>
            </button>

            <button
              onClick={() => navigate("/admin/affiliates")}
              className="p-6 bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 hover:bg-white/10 transition-all text-left group"
            >
              <div className="w-12 h-12 bg-purple-500/20 rounded-2xl flex items-center justify-center mb-3">
                <Users className="w-6 h-6 text-purple-300 group-hover:text-white transition-colors" />
              </div>
              <h3 className="text-lg font-semibold text-white mb-1">Gestion des Affiliés</h3>
              <p className="text-purple-200 text-sm">Ajouter et gérer vos affiliés.</p>
            </button>

            <button
              onClick={() => navigate("/admin/products")}
              className="p-6 bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 hover:bg-white/10 transition-all text-left group"
            >
              <div className="w-12 h-12 bg-purple-500/20 rounded-2xl flex items-center justify-center mb-3">
                <Package className="w-6 h-6 text-purple-300 group-hover:text-white transition-colors" />
              </div>
              <h3 className="text-lg font-semibold text-white mb-1">Gestion des Produits</h3>
              <p className="text-purple-200 text-sm">Ajouter et modifier vos produits.</p>
            </button>

            <button
              onClick={() => navigate("/admin/orders")}
              className="p-6 bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 hover:bg-white/10 transition-all text-left group"
            >
              <div className="w-12 h-12 bg-purple-500/20 rounded-2xl flex items-center justify-center mb-3">
                <ShoppingCart className="w-6 h-6 text-purple-300 group-hover:text-white transition-colors" />
              </div>
              <h3 className="text-lg font-semibold text-white mb-1">Voir les Commandes</h3>
              <p className="text-purple-200 text-sm">Consulter toutes les commandes.</p>
            </button>
          </div>
        </div>

        {/* Recent Orders */}
        <div>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-white">Commandes Récentes</h2>
            <button
              onClick={() => navigate("/admin/orders")}
              className="text-purple-300 text-sm font-medium hover:text-purple-200 transition-colors"
            >
              Voir tout
            </button>
          </div>
          
          <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6">
            <p className="text-purple-200 text-center py-8">Chargement des commandes récentes...</p>
          </div>
        </div>

        {/* Alerts */}
        {stats && (stats.orders.pending > 0 || stats.affiliates.pending_requests > 0) && (
          <div className="space-y-4 mt-8">
            <h2 className="text-2xl font-bold text-white mb-6">Alertes</h2>
            
            {stats.orders.pending > 0 && (
              <div className="p-4 bg-orange-500/10 border border-orange-500/30 rounded-2xl backdrop-blur-sm flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-orange-400 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-white font-semibold mb-1">Commandes en attente</h4>
                  <p className="text-orange-200 text-sm">
                    Vous avez {stats.orders.pending} commande{stats.orders.pending > 1 ? 's' : ''} en attente de traitement.
                  </p>
                  <button
                    onClick={() => navigate("/admin/orders?status=pending")}
                    className="mt-2 text-orange-300 text-sm font-medium hover:text-orange-200 transition-colors"
                  >
                    Voir les commandes →
                  </button>
                </div>
              </div>
            )}

            {stats.affiliates.pending_requests > 0 && (
              <div className="p-4 bg-purple-500/10 border border-purple-500/30 rounded-2xl backdrop-blur-sm flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-purple-400 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-white font-semibold mb-1">Demandes d'affiliation</h4>
                  <p className="text-purple-200 text-sm">
                    {stats.affiliates.pending_requests} demande{stats.affiliates.pending_requests > 1 ? 's' : ''} d'affiliation en attente.
                  </p>
                  <button
                    onClick={() => navigate("/admin/affiliates?tab=requests")}
                    className="mt-2 text-purple-300 text-sm font-medium hover:text-purple-200 transition-colors"
                  >
                    Voir les demandes →
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
