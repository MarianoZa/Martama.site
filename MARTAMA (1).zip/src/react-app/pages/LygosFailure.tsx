import { useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router";
import { XCircle } from "lucide-react";
import Header from "@/react-app/components/Header";
import Footer from "@/react-app/components/Footer";

export default function LygosFailure() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const orderId = searchParams.get("order_id");

  useEffect(() => {
    const loadFont = () => {
      const link = document.createElement("link");
      link.href = "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap";
      link.rel = "stylesheet";
      document.head.appendChild(link);
    };
    loadFont();
  }, []);

  const handleRetry = () => {
    // Navigate back to catalog to try again
    navigate("/catalog");
  };

  return (
    <div className="min-h-screen flex flex-col" style={{ fontFamily: "'Outfit', sans-serif", backgroundColor: 'var(--bg-primary)' }}>
      <Header />

      <main className="flex-1 px-6 py-16 flex items-center justify-center">
        <div className="max-w-md w-full text-center">
          <div 
            className="w-20 h-20 mx-auto mb-6 rounded-full flex items-center justify-center"
            style={{ backgroundColor: 'rgba(239, 68, 68, 0.1)' }}
          >
            <XCircle className="w-16 h-16" style={{ color: 'var(--error)' }} />
          </div>

          <h1 className="text-3xl font-bold mb-4" style={{ color: 'var(--text-primary)' }}>
            Paiement annulé
          </h1>

          <p className="text-lg mb-8" style={{ color: 'var(--text-secondary)' }}>
            Votre paiement a été annulé ou a échoué. Aucun montant n'a été débité de votre compte.
          </p>

          {orderId && (
            <div 
              className="rounded-2xl p-6 mb-8 text-left"
              style={{ backgroundColor: 'var(--bg-secondary)' }}
            >
              <h3 className="font-bold mb-2" style={{ color: 'var(--text-primary)' }}>
                Référence de commande
              </h3>
              <p className="text-sm font-mono" style={{ color: 'var(--text-secondary)' }}>
                #{orderId}
              </p>
            </div>
          )}

          <div className="space-y-3">
            <button
              onClick={handleRetry}
              className="w-full px-8 py-4 rounded-2xl font-bold text-lg text-white transition-all"
              style={{ backgroundColor: 'var(--primary)' }}
            >
              Réessayer le paiement
            </button>

            <button
              onClick={() => navigate("/")}
              className="w-full px-8 py-4 rounded-2xl font-bold text-lg transition-all"
              style={{ backgroundColor: 'var(--bg-secondary)', color: 'var(--text-primary)' }}
            >
              Retour à l'accueil
            </button>
          </div>

          <div 
            className="mt-8 p-4 rounded-xl border"
            style={{ backgroundColor: 'rgba(37, 211, 102, 0.05)', borderColor: 'rgba(37, 211, 102, 0.2)' }}
          >
            <p className="text-sm mb-2 font-semibold" style={{ color: 'var(--text-primary)' }}>
              Besoin d'aide ?
            </p>
            <a
              href="https://wa.me/22951661357?text=Bonjour%2C%20j%27ai%20un%20problème%20avec%20mon%20paiement"
              target="_blank"
              rel="noopener noreferrer"
              className="text-sm font-medium hover:underline"
              style={{ color: '#25D366' }}
            >
              Contactez-nous sur WhatsApp : +229 51 66 13 57
            </a>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
