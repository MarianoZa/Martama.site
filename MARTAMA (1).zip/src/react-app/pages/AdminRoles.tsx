import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { useAdminPermissions } from "@/react-app/hooks/useAdminPermissions";
import { ArrowLeft, Shield, Search, Users, Edit, Trash2, X, UserPlus } from "lucide-react";
import AdminSidebar from "@/react-app/components/AdminSidebar";

interface AdminUser {
  id: string;
  email: string;
  full_name: string | null;
  role: string;
  admin_role: string | null;
  is_active: number;
  created_at: string;
}

interface RegularUser {
  id: string;
  email: string;
  full_name: string | null;
  phone_number: string | null;
  created_at: string;
}

interface AdminRole {
  value: string;
  label: string;
  description: string;
}

export default function AdminRoles() {
  const navigate = useNavigate();
  const { hasPermission, loading: permissionsLoading, getDefaultPage } = useAdminPermissions();
  const [admins, setAdmins] = useState<AdminUser[]>([]);
  const [regularUsers, setRegularUsers] = useState<RegularUser[]>([]);
  const [roles, setRoles] = useState<AdminRole[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [selectedUser, setSelectedUser] = useState<RegularUser | null>(null);
  const [editingAdmin, setEditingAdmin] = useState<AdminUser | null>(null);
  const [deletingAdmin, setDeletingAdmin] = useState<AdminUser | null>(null);
  const [selectedRole, setSelectedRole] = useState("content_moderator");
  const [saving, setSaving] = useState(false);

  // Check permission and redirect if needed
  useEffect(() => {
    if (permissionsLoading) return;
    
    if (!hasPermission('manageAdminRoles')) {
      navigate(getDefaultPage(), { replace: true });
    }
  }, [permissionsLoading, hasPermission, navigate, getDefaultPage]);

  useEffect(() => {
    const loadFont = () => {
      const link = document.createElement("link");
      link.href = "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap";
      link.rel = "stylesheet";
      document.head.appendChild(link);
    };
    loadFont();
  }, []);

  useEffect(() => {
    fetchAdmins();
    fetchRegularUsers();
    fetchRoles();
  }, []);

  const fetchAdmins = async () => {
    try {
      setLoading(true);
      const response = await fetch("/api/admin/roles");
      
      if (response.status === 403) {
        navigate("/admin");
        return;
      }
      
      const data = await response.json();
      setAdmins(data);
    } catch (error) {
      console.error("Failed to fetch admins:", error);
    } finally {
      setLoading(false);
    }
  };

  const fetchRegularUsers = async () => {
    try {
      const response = await fetch("/api/admin/roles/users");
      if (response.ok) {
        const data = await response.json();
        setRegularUsers(data);
      }
    } catch (error) {
      console.error("Failed to fetch regular users:", error);
    }
  };

  const fetchRoles = async () => {
    try {
      const response = await fetch("/api/admin/roles/roles");
      const data = await response.json();
      setRoles(data);
    } catch (error) {
      console.error("Failed to fetch roles:", error);
    }
  };

  const handleSelectUser = (user: RegularUser) => {
    setSelectedUser(user);
    setSelectedRole("content_moderator");
    setShowAddModal(true);
  };

  const handleEditAdmin = (admin: AdminUser) => {
    setEditingAdmin(admin);
    setSelectedRole(admin.admin_role || "content_moderator");
    setShowEditModal(true);
  };

  const handleDeleteAdmin = (admin: AdminUser) => {
    setDeletingAdmin(admin);
    setShowDeleteModal(true);
  };

  const handleAddAdmin = async () => {
    if (!selectedUser) return;

    setSaving(true);
    try {
      const response = await fetch("/api/admin/roles", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          user_id: selectedUser.id,
          admin_role: selectedRole,
        }),
      });

      if (response.ok) {
        await fetchAdmins();
        await fetchRegularUsers();
        setShowAddModal(false);
        setSelectedUser(null);
      } else {
        const error = await response.json();
        alert(error.error || "Échec de l'opération");
      }
    } catch (error) {
      console.error("Failed to add admin:", error);
      alert("Erreur lors de l'ajout");
    } finally {
      setSaving(false);
    }
  };

  const handleUpdateAdmin = async () => {
    if (!editingAdmin) return;

    setSaving(true);
    try {
      const response = await fetch(`/api/admin/roles/${editingAdmin.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          admin_role: selectedRole,
          is_active: 1,
        }),
      });

      if (response.ok) {
        await fetchAdmins();
        setShowEditModal(false);
        setEditingAdmin(null);
      } else {
        const error = await response.json();
        alert(error.error || "Échec de la mise à jour");
      }
    } catch (error) {
      console.error("Failed to update admin:", error);
      alert("Erreur lors de la mise à jour");
    } finally {
      setSaving(false);
    }
  };

  const handleRemoveAdmin = async () => {
    if (!deletingAdmin) return;

    setSaving(true);
    try {
      const response = await fetch(`/api/admin/roles/${deletingAdmin.id}`, {
        method: "DELETE",
      });

      if (response.ok) {
        await fetchAdmins();
        await fetchRegularUsers();
        setShowDeleteModal(false);
        setDeletingAdmin(null);
      } else {
        const error = await response.json();
        alert(error.error || "Échec de la suppression");
      }
    } catch (error) {
      console.error("Failed to remove admin:", error);
      alert("Erreur lors de la suppression");
    } finally {
      setSaving(false);
    }
  };

  const getRoleBadgeColor = (role: string | null) => {
    switch (role) {
      case "super_admin": return "bg-red-500/20 text-red-600 border-red-500/30";
      case "data_analyst": return "bg-blue-500/20 text-blue-600 border-blue-500/30";
      case "delivery_agent": return "bg-green-500/20 text-green-600 border-green-500/30";
      case "affiliate_manager": return "bg-purple-500/20 text-purple-600 border-purple-500/30";
      case "content_moderator": return "bg-yellow-500/20 text-yellow-600 border-yellow-500/30";
      default: return "bg-gray-500/20 text-gray-600 border-gray-500/30";
    }
  };

  const getRoleLabel = (role: string | null) => {
    const found = roles.find(r => r.value === role);
    return found?.label || role || "N/A";
  };

  const filteredUsers = regularUsers.filter(user =>
    user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
    user.full_name?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen flex" style={{ fontFamily: "'Outfit', sans-serif", backgroundColor: 'var(--bg-primary)' }}>
      <AdminSidebar />
      
      <div className="flex-1">
        <header className="px-6 py-6">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-4">
              <button
                onClick={() => navigate("/admin")}
                className="p-2 hover:opacity-80 rounded-xl transition-opacity"
                style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)' }}
              >
                <ArrowLeft className="w-6 h-6" style={{ color: 'var(--primary)' }} />
              </button>
              <div>
                <h1 className="text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>Gestion des Administrateurs</h1>
                <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>Attribuez des rôles admin aux utilisateurs existants</p>
              </div>
            </div>
          </div>

          {/* Stats */}
          <div className="grid md:grid-cols-5 gap-6 mb-8">
            <div className="rounded-2xl border p-6" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm" style={{ color: 'var(--text-muted)' }}>Total Admins</span>
                <Shield className="w-8 h-8" style={{ color: 'var(--primary)' }} />
              </div>
              <div className="text-3xl font-bold" style={{ color: 'var(--text-primary)' }}>{admins.length}</div>
            </div>

            <div className="rounded-2xl border p-6" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm" style={{ color: 'var(--text-muted)' }}>Super Admins</span>
                <Shield className="w-8 h-8 text-red-500" />
              </div>
              <div className="text-3xl font-bold" style={{ color: 'var(--text-primary)' }}>
                {admins.filter(a => a.admin_role === 'super_admin').length}
              </div>
            </div>

            <div className="rounded-2xl border p-6" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm" style={{ color: 'var(--text-muted)' }}>Analystes</span>
                <Users className="w-8 h-8 text-blue-500" />
              </div>
              <div className="text-3xl font-bold" style={{ color: 'var(--text-primary)' }}>
                {admins.filter(a => a.admin_role === 'data_analyst').length}
              </div>
            </div>

            <div className="rounded-2xl border p-6" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm" style={{ color: 'var(--text-muted)' }}>Agents</span>
                <Users className="w-8 h-8 text-green-500" />
              </div>
              <div className="text-3xl font-bold" style={{ color: 'var(--text-primary)' }}>
                {admins.filter(a => a.admin_role === 'delivery_agent').length}
              </div>
            </div>

            <div className="rounded-2xl border p-6" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm" style={{ color: 'var(--text-muted)' }}>Modérateurs</span>
                <Users className="w-8 h-8 text-yellow-500" />
              </div>
              <div className="text-3xl font-bold" style={{ color: 'var(--text-primary)' }}>
                {admins.filter(a => a.admin_role === 'content_moderator').length}
              </div>
            </div>
          </div>
        </header>

        <main className="px-6 pb-12 space-y-8">
          {/* Current Admins */}
          <div>
            <h2 className="text-xl font-bold mb-4 flex items-center gap-2" style={{ color: 'var(--text-primary)' }}>
              <Shield className="w-6 h-6" style={{ color: 'var(--primary)' }} />
              Administrateurs Actuels
            </h2>

            {loading ? (
              <div className="text-center py-20">
                <div className="inline-block w-12 h-12 border-4 rounded-full animate-spin" style={{ borderColor: 'var(--gray-200)', borderTopColor: 'var(--primary)' }}></div>
              </div>
            ) : (
              <div className="rounded-3xl border overflow-hidden" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b" style={{ borderColor: 'var(--border-color)' }}>
                        <th className="px-6 py-4 text-left text-sm font-semibold" style={{ color: 'var(--text-muted)' }}>Email</th>
                        <th className="px-6 py-4 text-left text-sm font-semibold" style={{ color: 'var(--text-muted)' }}>Nom</th>
                        <th className="px-6 py-4 text-left text-sm font-semibold" style={{ color: 'var(--text-muted)' }}>Rôle Admin</th>
                        <th className="px-6 py-4 text-left text-sm font-semibold" style={{ color: 'var(--text-muted)' }}>Date Ajout</th>
                        <th className="px-6 py-4 text-left text-sm font-semibold" style={{ color: 'var(--text-muted)' }}>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {admins.map((admin) => (
                        <tr key={admin.id} className="border-b hover:opacity-90 transition-opacity" style={{ borderColor: 'var(--border-color)' }}>
                          <td className="px-6 py-4 text-sm" style={{ color: 'var(--text-primary)' }}>{admin.email}</td>
                          <td className="px-6 py-4 text-sm" style={{ color: 'var(--text-primary)' }}>{admin.full_name || '-'}</td>
                          <td className="px-6 py-4">
                            <span className={`px-3 py-1 rounded-full text-xs font-medium border ${getRoleBadgeColor(admin.admin_role)}`}>
                              {getRoleLabel(admin.admin_role)}
                            </span>
                          </td>
                          <td className="px-6 py-4 text-sm" style={{ color: 'var(--text-secondary)' }}>
                            {new Date(admin.created_at).toLocaleDateString('fr-FR')}
                          </td>
                          <td className="px-6 py-4">
                            <div className="flex items-center gap-2">
                              <button
                                onClick={() => handleEditAdmin(admin)}
                                className="p-2 hover:opacity-80 rounded-lg transition-opacity"
                                style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)' }}
                                title="Modifier le rôle"
                              >
                                <Edit className="w-4 h-4" style={{ color: 'var(--primary)' }} />
                              </button>
                              {admin.admin_role !== 'super_admin' && (
                                <button
                                  onClick={() => handleDeleteAdmin(admin)}
                                  className="p-2 hover:opacity-80 rounded-lg transition-opacity"
                                  style={{ backgroundColor: 'rgba(239, 68, 68, 0.1)' }}
                                  title="Retirer les droits admin"
                                >
                                  <Trash2 className="w-4 h-4" style={{ color: 'var(--error)' }} />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>

          {/* Regular Users - Add Admin */}
          <div>
            <h2 className="text-xl font-bold mb-4 flex items-center gap-2" style={{ color: 'var(--text-primary)' }}>
              <Users className="w-6 h-6" style={{ color: 'var(--success)' }} />
              Ajouter un Administrateur
            </h2>

            {/* Search Bar */}
            <div className="mb-6 relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5" style={{ color: 'var(--text-muted)' }} />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Rechercher un utilisateur par email ou nom..."
                className="w-full pl-12 pr-4 py-4 border rounded-2xl focus:outline-none focus:ring-2 text-base"
                style={{ 
                  backgroundColor: 'var(--bg-secondary)', 
                  borderColor: 'var(--border-color)', 
                  color: 'var(--text-primary)',
                  '--tw-ring-color': 'var(--primary)'
                } as any}
              />
            </div>

            <div className="rounded-3xl border overflow-hidden" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
              {filteredUsers.length === 0 ? (
                <div className="text-center py-12">
                  <Users className="w-16 h-16 mx-auto mb-4" style={{ color: 'var(--text-muted)', opacity: 0.3 }} />
                  <p style={{ color: 'var(--text-muted)' }}>
                    {searchQuery ? "Aucun utilisateur trouvé" : "Tous les utilisateurs sont déjà administrateurs"}
                  </p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b" style={{ borderColor: 'var(--border-color)' }}>
                        <th className="px-6 py-4 text-left text-sm font-semibold" style={{ color: 'var(--text-muted)' }}>Email</th>
                        <th className="px-6 py-4 text-left text-sm font-semibold" style={{ color: 'var(--text-muted)' }}>Nom</th>
                        <th className="px-6 py-4 text-left text-sm font-semibold" style={{ color: 'var(--text-muted)' }}>Téléphone</th>
                        <th className="px-6 py-4 text-left text-sm font-semibold" style={{ color: 'var(--text-muted)' }}>Date Inscription</th>
                        <th className="px-6 py-4 text-left text-sm font-semibold" style={{ color: 'var(--text-muted)' }}>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredUsers.slice(0, 50).map((user) => (
                        <tr key={user.id} className="border-b hover:opacity-90 transition-opacity" style={{ borderColor: 'var(--border-color)' }}>
                          <td className="px-6 py-4 text-sm" style={{ color: 'var(--text-primary)' }}>{user.email}</td>
                          <td className="px-6 py-4 text-sm" style={{ color: 'var(--text-primary)' }}>{user.full_name || '-'}</td>
                          <td className="px-6 py-4 text-sm" style={{ color: 'var(--text-secondary)' }}>{user.phone_number || '-'}</td>
                          <td className="px-6 py-4 text-sm" style={{ color: 'var(--text-secondary)' }}>
                            {new Date(user.created_at).toLocaleDateString('fr-FR')}
                          </td>
                          <td className="px-6 py-4">
                            <button
                              onClick={() => handleSelectUser(user)}
                              className="flex items-center gap-2 px-4 py-2 rounded-xl font-medium transition-colors text-white"
                              style={{ backgroundColor: 'var(--success)' }}
                            >
                              <UserPlus className="w-4 h-4" />
                              Rendre Admin
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        </main>

        {/* Add Admin Modal */}
        {showAddModal && selectedUser && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-6 z-50">
            <div className="rounded-3xl border p-8 max-w-2xl w-full" style={{ backgroundColor: 'var(--bg-primary)', borderColor: 'var(--border-color)' }}>
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>Attribuer un rôle admin</h3>
                <button
                  onClick={() => setShowAddModal(false)}
                  className="p-2 hover:opacity-80 rounded-xl transition-opacity"
                  style={{ backgroundColor: 'var(--bg-secondary)' }}
                >
                  <X className="w-6 h-6" style={{ color: 'var(--text-primary)' }} />
                </button>
              </div>

              <div className="mb-6 p-4 rounded-xl border" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
                <p className="text-sm mb-1" style={{ color: 'var(--text-muted)' }}>Utilisateur sélectionné</p>
                <p className="font-semibold" style={{ color: 'var(--text-primary)' }}>{selectedUser.email}</p>
                {selectedUser.full_name && (
                  <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>{selectedUser.full_name}</p>
                )}
              </div>

              <div className="mb-6">
                <label className="block text-sm font-medium mb-3" style={{ color: 'var(--text-muted)' }}>
                  Choisir un rôle administrateur
                </label>
                <div className="space-y-3">
                  {roles.map((role) => (
                    <button
                      key={role.value}
                      onClick={() => setSelectedRole(role.value)}
                      className={`w-full p-4 rounded-xl border-2 text-left transition-all ${
                        selectedRole === role.value ? 'border-current shadow-lg' : ''
                      }`}
                      style={{
                        backgroundColor: selectedRole === role.value ? 'rgba(139, 92, 246, 0.1)' : 'var(--bg-secondary)',
                        borderColor: selectedRole === role.value ? 'var(--primary)' : 'var(--border-color)',
                      }}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-semibold" style={{ color: 'var(--text-primary)' }}>{role.label}</span>
                        <span className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                          selectedRole === role.value ? 'border-current' : ''
                        }`} style={{ borderColor: selectedRole === role.value ? 'var(--primary)' : 'var(--border-color)' }}>
                          {selectedRole === role.value && (
                            <span className="w-3 h-3 rounded-full" style={{ backgroundColor: 'var(--primary)' }} />
                          )}
                        </span>
                      </div>
                      <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>{role.description}</p>
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={handleAddAdmin}
                  disabled={saving}
                  className="flex-1 px-6 py-3 rounded-xl font-semibold transition-colors text-white disabled:opacity-50"
                  style={{ backgroundColor: 'var(--success)' }}
                >
                  {saving ? "Attribution..." : "Confirmer et ajouter"}
                </button>
                <button
                  onClick={() => setShowAddModal(false)}
                  disabled={saving}
                  className="px-6 py-3 rounded-xl font-semibold transition-colors disabled:opacity-50"
                  style={{ backgroundColor: 'var(--bg-secondary)', color: 'var(--text-primary)' }}
                >
                  Annuler
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Edit Admin Modal */}
        {showEditModal && editingAdmin && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-6 z-50">
            <div className="rounded-3xl border p-8 max-w-2xl w-full" style={{ backgroundColor: 'var(--bg-primary)', borderColor: 'var(--border-color)' }}>
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>Modifier le rôle admin</h3>
                <button
                  onClick={() => setShowEditModal(false)}
                  className="p-2 hover:opacity-80 rounded-xl transition-opacity"
                  style={{ backgroundColor: 'var(--bg-secondary)' }}
                >
                  <X className="w-6 h-6" style={{ color: 'var(--text-primary)' }} />
                </button>
              </div>

              <div className="mb-6 p-4 rounded-xl border" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
                <p className="text-sm mb-1" style={{ color: 'var(--text-muted)' }}>Administrateur</p>
                <p className="font-semibold" style={{ color: 'var(--text-primary)' }}>{editingAdmin.email}</p>
                {editingAdmin.full_name && (
                  <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>{editingAdmin.full_name}</p>
                )}
              </div>

              <div className="mb-6">
                <label className="block text-sm font-medium mb-3" style={{ color: 'var(--text-muted)' }}>
                  Nouveau rôle
                </label>
                <div className="space-y-3">
                  {roles.map((role) => (
                    <button
                      key={role.value}
                      onClick={() => setSelectedRole(role.value)}
                      className={`w-full p-4 rounded-xl border-2 text-left transition-all ${
                        selectedRole === role.value ? 'border-current shadow-lg' : ''
                      }`}
                      style={{
                        backgroundColor: selectedRole === role.value ? 'rgba(139, 92, 246, 0.1)' : 'var(--bg-secondary)',
                        borderColor: selectedRole === role.value ? 'var(--primary)' : 'var(--border-color)',
                      }}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-semibold" style={{ color: 'var(--text-primary)' }}>{role.label}</span>
                        <span className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                          selectedRole === role.value ? 'border-current' : ''
                        }`} style={{ borderColor: selectedRole === role.value ? 'var(--primary)' : 'var(--border-color)' }}>
                          {selectedRole === role.value && (
                            <span className="w-3 h-3 rounded-full" style={{ backgroundColor: 'var(--primary)' }} />
                          )}
                        </span>
                      </div>
                      <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>{role.description}</p>
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={handleUpdateAdmin}
                  disabled={saving}
                  className="flex-1 px-6 py-3 rounded-xl font-semibold transition-colors text-white disabled:opacity-50"
                  style={{ backgroundColor: 'var(--primary)' }}
                >
                  {saving ? "Mise à jour..." : "Mettre à jour"}
                </button>
                <button
                  onClick={() => setShowEditModal(false)}
                  disabled={saving}
                  className="px-6 py-3 rounded-xl font-semibold transition-colors disabled:opacity-50"
                  style={{ backgroundColor: 'var(--bg-secondary)', color: 'var(--text-primary)' }}
                >
                  Annuler
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Delete Admin Modal */}
        {showDeleteModal && deletingAdmin && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-6 z-50">
            <div className="rounded-3xl border p-8 max-w-md w-full" style={{ backgroundColor: 'var(--bg-primary)', borderColor: 'var(--border-color)' }}>
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>Retirer les droits admin</h3>
                <button
                  onClick={() => setShowDeleteModal(false)}
                  className="p-2 hover:opacity-80 rounded-xl transition-opacity"
                  style={{ backgroundColor: 'var(--bg-secondary)' }}
                >
                  <X className="w-6 h-6" style={{ color: 'var(--text-primary)' }} />
                </button>
              </div>

              <div className="mb-6">
                <p className="mb-4" style={{ color: 'var(--text-primary)' }}>
                  Êtes-vous sûr de vouloir retirer les droits administrateur de cet utilisateur ?
                </p>
                <div className="p-4 rounded-xl border" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
                  <p className="text-sm mb-1" style={{ color: 'var(--text-muted)' }}>Email</p>
                  <p className="font-medium" style={{ color: 'var(--text-primary)' }}>{deletingAdmin.email}</p>
                  <p className="text-sm mb-1 mt-3" style={{ color: 'var(--text-muted)' }}>Rôle actuel</p>
                  <p className="font-medium" style={{ color: 'var(--text-primary)' }}>{getRoleLabel(deletingAdmin.admin_role)}</p>
                </div>
                <div className="mt-4 p-4 rounded-xl" style={{ backgroundColor: 'rgba(251, 191, 36, 0.1)', borderLeft: '4px solid var(--warning)' }}>
                  <p className="text-sm font-medium" style={{ color: 'var(--warning)' }}>
                    ⚠️ L'utilisateur redeviendra un utilisateur standard et perdra tous ses accès admin.
                  </p>
                </div>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={handleRemoveAdmin}
                  disabled={saving}
                  className="flex-1 px-6 py-3 rounded-xl font-semibold transition-colors text-white disabled:opacity-50"
                  style={{ backgroundColor: 'var(--error)' }}
                >
                  {saving ? "Suppression..." : "Retirer les droits"}
                </button>
                <button
                  onClick={() => setShowDeleteModal(false)}
                  disabled={saving}
                  className="px-6 py-3 rounded-xl font-semibold transition-colors disabled:opacity-50"
                  style={{ backgroundColor: 'var(--bg-secondary)', color: 'var(--text-primary)' }}
                >
                  Annuler
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
