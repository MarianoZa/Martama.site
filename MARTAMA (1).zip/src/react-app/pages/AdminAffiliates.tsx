import { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router";
import { ArrowLeft, Users, CheckCircle, XCircle, Eye, Plus } from "lucide-react";

interface AffiliateRequest {
  id: number;
  user_id: string;
  email: string;
  full_name: string | null;
  promo_code: string;
  specialty: string | null;
  audience_size: string | null;
  social_links: string | null;
  motivation: string | null;
  payment_method: string | null;
  status: string;
  created_at: string;
}

interface Affiliate {
  id: number;
  user_id: string;
  email: string;
  full_name: string | null;
  promo_code: string;
  balance: number;
  total_clicks: number;
  total_sales: number;
  total_commissions: number;
  status: string;
  created_at: string;
}

export default function AdminAffiliates() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [activeTab, setActiveTab] = useState(searchParams.get("tab") || "affiliates");
  const [affiliates, setAffiliates] = useState<Affiliate[]>([]);
  const [requests, setRequests] = useState<AffiliateRequest[]>([]);
  const [selectedRequest, setSelectedRequest] = useState<AffiliateRequest | null>(null);
  const [loading, setLoading] = useState(true);
  const [adminNotes, setAdminNotes] = useState("");

  useEffect(() => {
    const loadFont = () => {
      const link = document.createElement("link");
      link.href = "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap";
      link.rel = "stylesheet";
      document.head.appendChild(link);
    };
    loadFont();
  }, []);

  useEffect(() => {
    if (activeTab === "affiliates") {
      fetchAffiliates();
    } else {
      fetchRequests();
    }
  }, [activeTab]);

  const fetchAffiliates = async () => {
    try {
      setLoading(true);
      const response = await fetch("/api/admin/affiliates");
      
      if (response.status === 403) {
        navigate("/");
        return;
      }
      
      const data = await response.json();
      setAffiliates(data);
    } catch (error) {
      console.error("Failed to fetch affiliates:", error);
    } finally {
      setLoading(false);
    }
  };

  const fetchRequests = async () => {
    try {
      setLoading(true);
      const response = await fetch("/api/admin/affiliate-requests");
      
      if (response.status === 403) {
        navigate("/");
        return;
      }
      
      const data = await response.json();
      setRequests(data);
    } catch (error) {
      console.error("Failed to fetch requests:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async (requestId: number) => {
    try {
      const response = await fetch(`/api/admin/affiliate-requests/${requestId}/approve`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ admin_notes: adminNotes }),
      });

      if (response.ok) {
        await fetchRequests();
        await fetchAffiliates();
        setSelectedRequest(null);
        setAdminNotes("");
      }
    } catch (error) {
      console.error("Failed to approve request:", error);
    }
  };

  const handleReject = async (requestId: number) => {
    try {
      const response = await fetch(`/api/admin/affiliate-requests/${requestId}/reject`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ admin_notes: adminNotes }),
      });

      if (response.ok) {
        await fetchRequests();
        setSelectedRequest(null);
        setAdminNotes("");
      }
    } catch (error) {
      console.error("Failed to reject request:", error);
    }
  };

  const stats = {
    total_affiliates: affiliates.length,
    active_affiliates: affiliates.filter(a => a.status === "active").length,
    pending_requests: requests.filter(r => r.status === "pending").length,
    total_commissions: affiliates.reduce((sum, a) => sum + a.total_commissions, 0),
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-indigo-900" style={{ fontFamily: "'Outfit', sans-serif" }}>
      <header className="px-6 py-6 max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate("/admin")}
              className="p-2 hover:bg-white/10 rounded-xl transition-colors"
            >
              <ArrowLeft className="w-6 h-6 text-white" />
            </button>
            <div>
              <h1 className="text-2xl font-bold text-white">Gestion des Affiliés</h1>
              <p className="text-purple-200 text-sm">Gérez vos partenaires affiliés et leurs performances</p>
            </div>
          </div>
          <button
            onClick={() => navigate("/admin/affiliates/add")}
            className="flex items-center gap-2 px-6 py-3 bg-white text-purple-900 rounded-xl font-semibold hover:bg-purple-50 transition-all"
          >
            <Plus className="w-5 h-5" />
            Ajouter un Affilié
          </button>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-purple-300 text-sm">Total Affiliés</span>
              <Users className="w-8 h-8 text-purple-400" />
            </div>
            <div className="text-3xl font-bold text-white">{stats.total_affiliates}</div>
          </div>

          <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-purple-300 text-sm">Affiliés Actifs</span>
              <CheckCircle className="w-8 h-8 text-green-400" />
            </div>
            <div className="text-3xl font-bold text-white">{stats.active_affiliates}</div>
          </div>

          <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-purple-300 text-sm">Demandes en Attente</span>
              <div className="w-8 h-8 bg-orange-500/20 rounded-full flex items-center justify-center">
                <span className="text-orange-400 font-bold">{stats.pending_requests}</span>
              </div>
            </div>
            <div className="text-3xl font-bold text-white">{stats.pending_requests}</div>
          </div>

          <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-purple-300 text-sm">Commissions Totales</span>
              <span className="text-2xl">💰</span>
            </div>
            <div className="text-3xl font-bold text-white">{stats.total_commissions.toLocaleString()} F</div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-3 overflow-x-auto pb-2">
          <button
            onClick={() => setActiveTab("affiliates")}
            className={`px-6 py-3 rounded-xl font-semibold whitespace-nowrap transition-all ${
              activeTab === "affiliates"
                ? "bg-white text-purple-900 shadow-lg"
                : "bg-white/10 text-white hover:bg-white/20 backdrop-blur-sm"
            }`}
          >
            Affiliés Actifs
          </button>
          <button
            onClick={() => setActiveTab("requests")}
            className={`px-6 py-3 rounded-xl font-semibold whitespace-nowrap transition-all ${
              activeTab === "requests"
                ? "bg-white text-purple-900 shadow-lg"
                : "bg-white/10 text-white hover:bg-white/20 backdrop-blur-sm"
            }`}
          >
            Demandes ({stats.pending_requests})
          </button>
        </div>
      </header>

      <main className="px-6 pb-12 max-w-7xl mx-auto">
        {loading ? (
          <div className="text-center py-20">
            <div className="inline-block w-12 h-12 border-4 border-white/20 border-t-white rounded-full animate-spin"></div>
          </div>
        ) : activeTab === "affiliates" ? (
          <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-white/10">
                    <th className="px-6 py-4 text-left text-sm font-semibold text-purple-300">Nom</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-purple-300">Email</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-purple-300">Code Promo</th>
                    <th className="px-6 py-4 text-center text-sm font-semibold text-purple-300">Clics</th>
                    <th className="px-6 py-4 text-center text-sm font-semibold text-purple-300">Ventes</th>
                    <th className="px-6 py-4 text-right text-sm font-semibold text-purple-300">Commissions</th>
                    <th className="px-6 py-4 text-right text-sm font-semibold text-purple-300">Solde</th>
                    <th className="px-6 py-4 text-center text-sm font-semibold text-purple-300">Statut</th>
                  </tr>
                </thead>
                <tbody>
                  {affiliates.map((affiliate) => (
                    <tr key={affiliate.id} className="border-b border-white/5 hover:bg-white/5 transition-colors">
                      <td className="px-6 py-4">
                        <div className="text-white font-medium">{affiliate.full_name || "N/A"}</div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-purple-200 text-sm">{affiliate.email}</div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="inline-block px-3 py-1 bg-purple-500/20 text-purple-300 rounded-full text-sm font-mono font-semibold">
                          {affiliate.promo_code}
                        </div>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <div className="text-white font-semibold">{affiliate.total_clicks}</div>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <div className="text-white font-semibold">{affiliate.total_sales}</div>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <div className="text-white font-semibold">{affiliate.total_commissions.toLocaleString()} F</div>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <div className="text-green-400 font-semibold">{affiliate.balance.toLocaleString()} F</div>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                          affiliate.status === "active" 
                            ? "bg-green-500/20 text-green-300"
                            : "bg-red-500/20 text-red-300"
                        }`}>
                          {affiliate.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {affiliates.length === 0 && (
                <div className="text-center py-12">
                  <Users className="w-12 h-12 text-white/30 mx-auto mb-3" />
                  <p className="text-white/70">Aucun affilié pour le moment</p>
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            {requests.filter(r => r.status === "pending").map((request) => (
              <div
                key={request.id}
                className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <h3 className="text-xl font-bold text-white mb-1">
                      {request.full_name || "Nouvel affilié"}
                    </h3>
                    <p className="text-purple-200 text-sm">{request.email}</p>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => setSelectedRequest(request)}
                      className="px-4 py-2 bg-blue-500/20 hover:bg-blue-500/30 text-blue-300 border border-blue-500/30 rounded-xl transition-colors flex items-center gap-2"
                    >
                      <Eye className="w-4 h-4" />
                      Voir Détails
                    </button>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4 mb-4">
                  <div>
                    <span className="text-purple-300 text-sm">Code Promo Souhaité</span>
                    <div className="text-white font-mono font-semibold">{request.promo_code}</div>
                  </div>
                  <div>
                    <span className="text-purple-300 text-sm">Taille d'Audience</span>
                    <div className="text-white font-semibold">{request.audience_size || "N/A"}</div>
                  </div>
                  <div>
                    <span className="text-purple-300 text-sm">Spécialité</span>
                    <div className="text-white font-semibold">{request.specialty || "N/A"}</div>
                  </div>
                  <div>
                    <span className="text-purple-300 text-sm">Méthode de Paiement</span>
                    <div className="text-white font-semibold capitalize">{request.payment_method || "N/A"}</div>
                  </div>
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={() => handleApprove(request.id)}
                    className="flex-1 px-6 py-3 bg-green-500 hover:bg-green-600 text-white rounded-xl font-semibold transition-colors flex items-center justify-center gap-2"
                  >
                    <CheckCircle className="w-5 h-5" />
                    Approuver
                  </button>
                  <button
                    onClick={() => handleReject(request.id)}
                    className="flex-1 px-6 py-3 bg-red-500/20 hover:bg-red-500/30 text-red-300 border border-red-500/30 rounded-xl font-semibold transition-colors flex items-center justify-center gap-2"
                  >
                    <XCircle className="w-5 h-5" />
                    Rejeter
                  </button>
                </div>
              </div>
            ))}
            {requests.filter(r => r.status === "pending").length === 0 && (
              <div className="text-center py-20">
                <CheckCircle className="w-16 h-16 text-white/30 mx-auto mb-4" />
                <p className="text-xl text-white/70">Aucune demande en attente</p>
              </div>
            )}
          </div>
        )}
      </main>

      {/* Request Details Modal */}
      {selectedRequest && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-6 z-50 overflow-y-auto">
          <div className="bg-gradient-to-br from-purple-900 to-indigo-900 rounded-3xl border border-white/20 p-8 max-w-2xl w-full my-8">
            <h3 className="text-2xl font-bold text-white mb-6">Détails de la Demande</h3>
            
            <div className="space-y-4 mb-6">
              <div>
                <span className="text-purple-300 text-sm font-medium">Nom</span>
                <div className="text-white text-lg">{selectedRequest.full_name || "N/A"}</div>
              </div>
              
              <div>
                <span className="text-purple-300 text-sm font-medium">Email</span>
                <div className="text-white text-lg">{selectedRequest.email}</div>
              </div>
              
              <div>
                <span className="text-purple-300 text-sm font-medium">Code Promo</span>
                <div className="text-white text-lg font-mono">{selectedRequest.promo_code}</div>
              </div>
              
              {selectedRequest.specialty && (
                <div>
                  <span className="text-purple-300 text-sm font-medium">Spécialité</span>
                  <div className="text-white">{selectedRequest.specialty}</div>
                </div>
              )}
              
              {selectedRequest.social_links && (
                <div>
                  <span className="text-purple-300 text-sm font-medium">Réseaux Sociaux</span>
                  <div className="text-white whitespace-pre-wrap">{selectedRequest.social_links}</div>
                </div>
              )}
              
              {selectedRequest.motivation && (
                <div>
                  <span className="text-purple-300 text-sm font-medium">Motivation</span>
                  <div className="text-white whitespace-pre-wrap">{selectedRequest.motivation}</div>
                </div>
              )}
              
              <div>
                <label className="block text-purple-300 text-sm font-medium mb-2">
                  Notes Administrateur
                </label>
                <textarea
                  value={adminNotes}
                  onChange={(e) => setAdminNotes(e.target.value)}
                  rows={3}
                  placeholder="Ajoutez des notes (optionnel)"
                  className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-purple-300/50 focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => handleApprove(selectedRequest.id)}
                className="flex-1 px-6 py-3 bg-green-500 hover:bg-green-600 text-white rounded-xl font-semibold transition-colors"
              >
                Approuver
              </button>
              <button
                onClick={() => handleReject(selectedRequest.id)}
                className="flex-1 px-6 py-3 bg-red-500 hover:bg-red-600 text-white rounded-xl font-semibold transition-colors"
              >
                Rejeter
              </button>
              <button
                onClick={() => {
                  setSelectedRequest(null);
                  setAdminNotes("");
                }}
                className="px-6 py-3 bg-white/10 hover:bg-white/20 text-white rounded-xl font-semibold transition-colors"
              >
                Fermer
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
