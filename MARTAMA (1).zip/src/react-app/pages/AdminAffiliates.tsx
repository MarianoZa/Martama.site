import { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router";
import { useAdminPermissions } from "@/react-app/hooks/useAdminPermissions";
import { ArrowLeft, Users, CheckCircle, XCircle, Eye, Download, Trash2, ToggleLeft, ToggleRight, X } from "lucide-react";
import BottomNav from "@/react-app/components/BottomNav";
import AdminSidebar from "@/react-app/components/AdminSidebar";

interface AffiliateRequest {
  id: number;
  user_id: string;
  email: string;
  full_name: string | null;
  promo_code: string;
  specialty: string | null;
  audience_size: string | null;
  social_links: string | null;
  motivation: string | null;
  payment_method: string | null;
  status: string;
  created_at: string;
}

interface Affiliate {
  id: number;
  user_id: string;
  email: string;
  full_name: string | null;
  promo_code: string;
  balance: number;
  total_clicks: number;
  total_sales: number;
  total_commissions: number;
  status: string;
  created_at: string;
}

export default function AdminAffiliates() {
  const navigate = useNavigate();
  const { hasPermission, loading: permissionsLoading, getDefaultPage } = useAdminPermissions();
  const [searchParams] = useSearchParams();
  const [activeTab, setActiveTab] = useState(searchParams.get("tab") || "affiliates");
  const [affiliates, setAffiliates] = useState<Affiliate[]>([]);
  const [requests, setRequests] = useState<AffiliateRequest[]>([]);
  const [selectedRequest, setSelectedRequest] = useState<AffiliateRequest | null>(null);
  const [selectedAffiliate, setSelectedAffiliate] = useState<Affiliate | null>(null);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [loading, setLoading] = useState(true);
  const [adminNotes, setAdminNotes] = useState("");

  // Check permission and redirect if needed
  useEffect(() => {
    if (permissionsLoading) return;
    
    if (!hasPermission('viewAffiliates')) {
      navigate(getDefaultPage(), { replace: true });
    }
  }, [permissionsLoading, hasPermission, navigate, getDefaultPage]);

  useEffect(() => {
    const loadFont = () => {
      const link = document.createElement("link");
      link.href = "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap";
      link.rel = "stylesheet";
      document.head.appendChild(link);
    };
    loadFont();
  }, []);

  useEffect(() => {
    if (activeTab === "affiliates") {
      fetchAffiliates();
    } else {
      fetchRequests();
    }
  }, [activeTab]);

  const fetchAffiliates = async () => {
    try {
      setLoading(true);
      const response = await fetch("/api/admin/affiliates");
      
      if (response.status === 403) {
        navigate("/");
        return;
      }
      
      const data = await response.json();
      setAffiliates(data);
    } catch (error) {
      console.error("Failed to fetch affiliates:", error);
    } finally {
      setLoading(false);
    }
  };

  const fetchRequests = async () => {
    try {
      setLoading(true);
      const response = await fetch("/api/admin/affiliate-requests");
      
      if (response.status === 403) {
        navigate("/");
        return;
      }
      
      const data = await response.json();
      setRequests(data);
    } catch (error) {
      console.error("Failed to fetch requests:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async (requestId: number) => {
    try {
      const response = await fetch(`/api/admin/affiliate-requests/${requestId}/approve`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ admin_notes: adminNotes }),
      });

      if (response.ok) {
        await fetchRequests();
        await fetchAffiliates();
        setSelectedRequest(null);
        setAdminNotes("");
      }
    } catch (error) {
      console.error("Failed to approve request:", error);
    }
  };

  const handleReject = async (requestId: number) => {
    try {
      const response = await fetch(`/api/admin/affiliate-requests/${requestId}/reject`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ admin_notes: adminNotes }),
      });

      if (response.ok) {
        await fetchRequests();
        setSelectedRequest(null);
        setAdminNotes("");
      }
    } catch (error) {
      console.error("Failed to reject request:", error);
    }
  };

  const handleToggleStatus = async (affiliateId: number, currentStatus: string) => {
    const newStatus = currentStatus === "active" ? "inactive" : "active";
    
    try {
      const response = await fetch(`/api/admin/affiliates/${affiliateId}/toggle-status`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: newStatus }),
      });

      if (response.ok) {
        await fetchAffiliates();
      } else {
        alert("Échec de la mise à jour du statut");
      }
    } catch (error) {
      console.error("Failed to toggle status:", error);
      alert("Erreur lors de la mise à jour du statut");
    }
  };

  const handleDeleteAffiliate = async () => {
    if (!selectedAffiliate) return;

    try {
      const response = await fetch(`/api/admin/affiliates/${selectedAffiliate.id}`, {
        method: "DELETE",
      });

      if (response.ok) {
        await fetchAffiliates();
        setShowDeleteModal(false);
        setSelectedAffiliate(null);
      } else {
        const error = await response.json();
        alert(error.error || "Échec de la suppression");
      }
    } catch (error) {
      console.error("Failed to delete affiliate:", error);
      alert("Erreur lors de la suppression");
    }
  };

  const stats = {
    total_affiliates: affiliates.length,
    active_affiliates: affiliates.filter(a => a.status === "active").length,
    pending_requests: requests.filter(r => r.status === "pending").length,
    total_commissions: affiliates.reduce((sum, a) => sum + a.total_commissions, 0),
  };

  return (
    <div className="min-h-screen flex" style={{ fontFamily: "'Outfit', sans-serif", backgroundColor: 'var(--bg-primary)' }}>
      <AdminSidebar />
      
      <div className="flex-1 pb-20 lg:pb-0">
      <header className="px-6 py-6">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate("/admin")}
              className="p-2 hover:opacity-80 rounded-xl transition-opacity"
              style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)' }}
            >
              <ArrowLeft className="w-6 h-6" style={{ color: 'var(--primary)' }} />
            </button>
            <div>
              <h1 className="text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>Gestion des Affiliés</h1>
              <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>Gérez vos partenaires affiliés et leurs performances</p>
            </div>
          </div>
          <div className="flex gap-3">
            <div className="flex gap-2">
              <a
                href="/api/admin/export/affiliates"
                className="flex items-center gap-2 px-5 py-3 rounded-xl font-semibold transition-all text-white"
                style={{ backgroundColor: 'var(--success)' }}
              >
                <Download className="w-5 h-5" />
                CSV
              </a>
              <a
                href="/api/admin/export/affiliates-json"
                className="flex items-center gap-2 px-5 py-3 rounded-xl font-semibold transition-all border"
                style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--success)', color: 'var(--success)' }}
              >
                <Download className="w-5 h-5" />
                JSON
              </a>
            </div>
            
            <button
              onClick={() => navigate("/admin/exceptional-codes")}
              className="flex items-center gap-2 px-6 py-3 rounded-xl font-semibold transition-all border"
              style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--primary)', color: 'var(--primary)' }}
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z" />
              </svg>
              Codes Exceptionnels
            </button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <div className="rounded-2xl p-6 border" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm" style={{ color: 'var(--text-muted)' }}>Total Affiliés</span>
              <Users className="w-8 h-8" style={{ color: 'var(--primary)' }} />
            </div>
            <div className="text-3xl font-bold" style={{ color: 'var(--text-primary)' }}>{stats.total_affiliates}</div>
          </div>

          <div className="rounded-2xl p-6 border" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm" style={{ color: 'var(--text-muted)' }}>Affiliés Actifs</span>
              <CheckCircle className="w-8 h-8" style={{ color: 'var(--success)' }} />
            </div>
            <div className="text-3xl font-bold" style={{ color: 'var(--text-primary)' }}>{stats.active_affiliates}</div>
          </div>

          <div className="rounded-2xl p-6 border" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm" style={{ color: 'var(--text-muted)' }}>Demandes en Attente</span>
              <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ backgroundColor: 'rgba(251, 191, 36, 0.2)' }}>
                <span className="font-bold" style={{ color: 'var(--warning)' }}>{stats.pending_requests}</span>
              </div>
            </div>
            <div className="text-3xl font-bold" style={{ color: 'var(--text-primary)' }}>{stats.pending_requests}</div>
          </div>

          <div className="rounded-2xl p-6 border" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm" style={{ color: 'var(--text-muted)' }}>Commissions Totales</span>
              <span className="text-2xl">💰</span>
            </div>
            <div className="text-3xl font-bold" style={{ color: 'var(--text-primary)' }}>{stats.total_commissions.toLocaleString()} F</div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide">
          <button
            onClick={() => setActiveTab("affiliates")}
            className={`px-6 py-3 rounded-xl font-semibold whitespace-nowrap transition-all ${
              activeTab === "affiliates" ? "text-white shadow-lg" : ""
            }`}
            style={{
              backgroundColor: activeTab === "affiliates" ? 'var(--primary)' : 'var(--bg-secondary)',
              color: activeTab === "affiliates" ? '#ffffff' : 'var(--text-primary)',
              borderColor: 'var(--border-color)',
              border: activeTab === "affiliates" ? 'none' : '1px solid'
            }}
          >
            Affiliés Actifs
          </button>
          <button
            onClick={() => setActiveTab("requests")}
            className={`px-6 py-3 rounded-xl font-semibold whitespace-nowrap transition-all ${
              activeTab === "requests" ? "text-white shadow-lg" : ""
            }`}
            style={{
              backgroundColor: activeTab === "requests" ? 'var(--primary)' : 'var(--bg-secondary)',
              color: activeTab === "requests" ? '#ffffff' : 'var(--text-primary)',
              borderColor: 'var(--border-color)',
              border: activeTab === "requests" ? 'none' : '1px solid'
            }}
          >
            Demandes ({stats.pending_requests})
          </button>
        </div>
      </header>

      <main className="px-6 pb-12">
        {loading ? (
          <div className="text-center py-20">
            <div className="inline-block w-12 h-12 border-4 rounded-full animate-spin" style={{ borderColor: 'var(--gray-200)', borderTopColor: 'var(--primary)' }}></div>
          </div>
        ) : activeTab === "affiliates" ? (
          <div className="rounded-2xl border overflow-hidden" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b" style={{ borderColor: 'var(--border-color)' }}>
                    <th className="px-6 py-4 text-left text-sm font-semibold" style={{ color: 'var(--text-muted)' }}>Nom</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold" style={{ color: 'var(--text-muted)' }}>Email</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold" style={{ color: 'var(--text-muted)' }}>Code Promo</th>
                    <th className="px-6 py-4 text-center text-sm font-semibold" style={{ color: 'var(--text-muted)' }}>Clics</th>
                    <th className="px-6 py-4 text-center text-sm font-semibold" style={{ color: 'var(--text-muted)' }}>Ventes</th>
                    <th className="px-6 py-4 text-right text-sm font-semibold" style={{ color: 'var(--text-muted)' }}>Commissions</th>
                    <th className="px-6 py-4 text-right text-sm font-semibold" style={{ color: 'var(--text-muted)' }}>Solde</th>
                    <th className="px-6 py-4 text-center text-sm font-semibold" style={{ color: 'var(--text-muted)' }}>Statut</th>
                    <th className="px-6 py-4 text-center text-sm font-semibold" style={{ color: 'var(--text-muted)' }}>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {affiliates.map((affiliate) => (
                    <tr key={affiliate.id} className="border-b hover:opacity-80 transition-opacity" style={{ borderColor: 'var(--border-color)' }}>
                      <td className="px-6 py-4">
                        <div className="font-medium" style={{ color: 'var(--text-primary)' }}>{affiliate.full_name || "N/A"}</div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm" style={{ color: 'var(--text-secondary)' }}>{affiliate.email}</div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="inline-block px-3 py-1 rounded-full text-sm font-mono font-semibold" style={{ backgroundColor: 'rgba(139, 92, 246, 0.2)', color: 'var(--primary)' }}>
                          {affiliate.promo_code}
                        </div>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <div className="font-semibold" style={{ color: 'var(--text-primary)' }}>{affiliate.total_clicks}</div>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <div className="font-semibold" style={{ color: 'var(--text-primary)' }}>{affiliate.total_sales}</div>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <div className="font-semibold" style={{ color: 'var(--text-primary)' }}>{affiliate.total_commissions.toLocaleString()} F</div>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <div className="font-semibold" style={{ color: 'var(--success)' }}>{affiliate.balance.toLocaleString()} F</div>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                          affiliate.status === "active" 
                            ? "bg-green-500/20 text-green-600"
                            : "bg-red-500/20 text-red-600"
                        }`}>
                          {affiliate.status}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center justify-center gap-2">
                          {hasPermission('manageAffiliates') && (
                            <>
                              <button
                                onClick={() => handleToggleStatus(affiliate.id, affiliate.status)}
                                className="p-2 hover:opacity-80 rounded-lg transition-opacity"
                                style={{ 
                                  backgroundColor: affiliate.status === "active" 
                                    ? 'rgba(239, 68, 68, 0.1)' 
                                    : 'rgba(16, 185, 129, 0.1)' 
                                }}
                                title={affiliate.status === "active" ? "Désactiver" : "Activer"}
                              >
                                {affiliate.status === "active" ? (
                                  <ToggleRight className="w-5 h-5" style={{ color: 'var(--error)' }} />
                                ) : (
                                  <ToggleLeft className="w-5 h-5" style={{ color: 'var(--success)' }} />
                                )}
                              </button>
                              <button
                                onClick={() => {
                                  setSelectedAffiliate(affiliate);
                                  setShowDeleteModal(true);
                                }}
                                className="p-2 hover:opacity-80 rounded-lg transition-opacity"
                                style={{ backgroundColor: 'rgba(239, 68, 68, 0.1)' }}
                                title="Supprimer l'affilié"
                              >
                                <Trash2 className="w-5 h-5" style={{ color: 'var(--error)' }} />
                              </button>
                            </>
                          )}
                          {!hasPermission('manageAffiliates') && (
                            <span className="text-sm" style={{ color: 'var(--text-muted)' }}>-</span>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {affiliates.length === 0 && (
                <div className="text-center py-12">
                  <Users className="w-12 h-12 mx-auto mb-3" style={{ color: 'var(--text-muted)', opacity: 0.3 }} />
                  <p style={{ color: 'var(--text-muted)' }}>Aucun affilié pour le moment</p>
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            {requests.filter(r => r.status === "pending").map((request) => (
              <div
                key={request.id}
                className="rounded-2xl border p-6"
                style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <h3 className="text-xl font-bold mb-1" style={{ color: 'var(--text-primary)' }}>
                      {request.full_name || "Nouvel affilié"}
                    </h3>
                    <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>{request.email}</p>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => setSelectedRequest(request)}
                      className="px-4 py-2 border rounded-xl transition-colors flex items-center gap-2"
                      style={{ backgroundColor: 'rgba(59, 130, 246, 0.1)', color: 'var(--info)', borderColor: 'rgba(59, 130, 246, 0.3)' }}
                    >
                      <Eye className="w-4 h-4" />
                      Voir Détails
                    </button>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4 mb-4">
                  <div>
                    <span className="text-sm" style={{ color: 'var(--text-muted)' }}>Code Promo Souhaité</span>
                    <div className="font-mono font-semibold" style={{ color: 'var(--text-primary)' }}>{request.promo_code}</div>
                  </div>
                  <div>
                    <span className="text-sm" style={{ color: 'var(--text-muted)' }}>Taille d'Audience</span>
                    <div className="font-semibold" style={{ color: 'var(--text-primary)' }}>{request.audience_size || "N/A"}</div>
                  </div>
                  <div>
                    <span className="text-sm" style={{ color: 'var(--text-muted)' }}>Spécialité</span>
                    <div className="font-semibold" style={{ color: 'var(--text-primary)' }}>{request.specialty || "N/A"}</div>
                  </div>
                  <div>
                    <span className="text-sm" style={{ color: 'var(--text-muted)' }}>Méthode de Paiement</span>
                    <div className="font-semibold capitalize" style={{ color: 'var(--text-primary)' }}>{request.payment_method || "N/A"}</div>
                  </div>
                </div>

                {hasPermission('manageAffiliates') && (
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleApprove(request.id)}
                      className="flex-1 px-6 py-3 rounded-xl font-semibold transition-colors flex items-center justify-center gap-2 text-white"
                      style={{ backgroundColor: 'var(--success)' }}
                    >
                      <CheckCircle className="w-5 h-5" />
                      Approuver
                    </button>
                    <button
                      onClick={() => handleReject(request.id)}
                      className="flex-1 px-6 py-3 border rounded-xl font-semibold transition-colors flex items-center justify-center gap-2"
                      style={{ backgroundColor: 'rgba(239, 68, 68, 0.1)', color: 'var(--error)', borderColor: 'rgba(239, 68, 68, 0.3)' }}
                    >
                      <XCircle className="w-5 h-5" />
                      Rejeter
                    </button>
                  </div>
                )}
              </div>
            ))}
            {requests.filter(r => r.status === "pending").length === 0 && (
              <div className="text-center py-20">
                <CheckCircle className="w-16 h-16 mx-auto mb-4" style={{ color: 'var(--text-muted)', opacity: 0.3 }} />
                <p className="text-xl" style={{ color: 'var(--text-muted)' }}>Aucune demande en attente</p>
              </div>
            )}
          </div>
        )}
      </main>

      {/* Request Details Modal */}
      {selectedRequest && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-6 z-50 overflow-y-auto">
          <div className="rounded-3xl border p-8 max-w-2xl w-full my-8" style={{ backgroundColor: 'var(--bg-primary)', borderColor: 'var(--border-color)' }}>
            <h3 className="text-2xl font-bold mb-6" style={{ color: 'var(--text-primary)' }}>Détails de la Demande</h3>
            
            <div className="space-y-4 mb-6">
              <div>
                <span className="text-sm font-medium" style={{ color: 'var(--text-muted)' }}>Nom</span>
                <div className="text-lg" style={{ color: 'var(--text-primary)' }}>{selectedRequest.full_name || "N/A"}</div>
              </div>
              
              <div>
                <span className="text-sm font-medium" style={{ color: 'var(--text-muted)' }}>Email</span>
                <div className="text-lg" style={{ color: 'var(--text-primary)' }}>{selectedRequest.email}</div>
              </div>
              
              <div>
                <span className="text-sm font-medium" style={{ color: 'var(--text-muted)' }}>Code Promo</span>
                <div className="text-lg font-mono" style={{ color: 'var(--text-primary)' }}>{selectedRequest.promo_code}</div>
              </div>
              
              {selectedRequest.specialty && (
                <div>
                  <span className="text-sm font-medium" style={{ color: 'var(--text-muted)' }}>Spécialité</span>
                  <div style={{ color: 'var(--text-primary)' }}>{selectedRequest.specialty}</div>
                </div>
              )}
              
              {selectedRequest.social_links && (
                <div>
                  <span className="text-sm font-medium" style={{ color: 'var(--text-muted)' }}>Réseaux Sociaux</span>
                  <div className="whitespace-pre-wrap" style={{ color: 'var(--text-primary)' }}>{selectedRequest.social_links}</div>
                </div>
              )}
              
              {selectedRequest.motivation && (
                <div>
                  <span className="text-sm font-medium" style={{ color: 'var(--text-muted)' }}>Motivation</span>
                  <div className="whitespace-pre-wrap" style={{ color: 'var(--text-primary)' }}>{selectedRequest.motivation}</div>
                </div>
              )}
              
              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                  Notes Administrateur
                </label>
                <textarea
                  value={adminNotes}
                  onChange={(e) => setAdminNotes(e.target.value)}
                  rows={3}
                  placeholder="Ajoutez des notes (optionnel)"
                  className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                  style={{ 
                    backgroundColor: 'var(--bg-secondary)', 
                    borderColor: 'var(--border-color)', 
                    color: 'var(--text-primary)',
                    '--tw-ring-color': 'var(--primary)'
                  } as any}
                />
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => handleApprove(selectedRequest.id)}
                className="flex-1 px-6 py-3 rounded-xl font-semibold transition-colors text-white"
                style={{ backgroundColor: 'var(--success)' }}
              >
                Approuver
              </button>
              <button
                onClick={() => handleReject(selectedRequest.id)}
                className="flex-1 px-6 py-3 rounded-xl font-semibold transition-colors text-white"
                style={{ backgroundColor: 'var(--error)' }}
              >
                Rejeter
              </button>
              <button
                onClick={() => {
                  setSelectedRequest(null);
                  setAdminNotes("");
                }}
                className="px-6 py-3 rounded-xl font-semibold transition-colors"
                style={{ backgroundColor: 'var(--bg-secondary)', color: 'var(--text-primary)' }}
              >
                Fermer
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Affiliate Modal */}
      {showDeleteModal && selectedAffiliate && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-6 z-50">
          <div className="rounded-3xl border p-8 max-w-md w-full" style={{ backgroundColor: 'var(--bg-primary)', borderColor: 'var(--border-color)' }}>
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>Supprimer l'affilié</h3>
              <button
                onClick={() => setShowDeleteModal(false)}
                className="p-2 hover:opacity-80 rounded-xl transition-opacity"
                style={{ backgroundColor: 'var(--bg-secondary)' }}
              >
                <X className="w-6 h-6" style={{ color: 'var(--text-primary)' }} />
              </button>
            </div>

            <div className="mb-6">
              <p className="mb-4" style={{ color: 'var(--text-primary)' }}>
                Êtes-vous sûr de vouloir supprimer complètement cet affilié ?
              </p>
              <div className="p-4 rounded-xl border" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
                <p className="text-sm mb-1" style={{ color: 'var(--text-muted)' }}>Email</p>
                <p className="font-medium" style={{ color: 'var(--text-primary)' }}>{selectedAffiliate.email}</p>
                <p className="text-sm mb-1 mt-3" style={{ color: 'var(--text-muted)' }}>Code Promo</p>
                <p className="font-medium font-mono" style={{ color: 'var(--text-primary)' }}>{selectedAffiliate.promo_code}</p>
                <p className="text-sm mb-1 mt-3" style={{ color: 'var(--text-muted)' }}>Solde</p>
                <p className="font-medium" style={{ color: 'var(--success)' }}>{selectedAffiliate.balance.toLocaleString()} F</p>
              </div>
              <div className="mt-4 p-4 rounded-xl" style={{ backgroundColor: 'rgba(239, 68, 68, 0.1)', borderLeft: '4px solid var(--error)' }}>
                <p className="text-sm font-medium" style={{ color: 'var(--error)' }}>
                  ⚠️ Cette action est irréversible. L'affilié pourra ensuite refaire une nouvelle demande d'affiliation.
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={handleDeleteAffiliate}
                className="flex-1 flex items-center justify-center gap-2 px-6 py-3 rounded-xl font-semibold transition-colors text-white"
                style={{ backgroundColor: 'var(--error)' }}
              >
                <Trash2 className="w-5 h-5" />
                Supprimer
              </button>
              <button
                onClick={() => setShowDeleteModal(false)}
                className="px-6 py-3 rounded-xl font-semibold transition-colors"
                style={{ backgroundColor: 'var(--bg-secondary)', color: 'var(--text-primary)' }}
              >
                Annuler
              </button>
            </div>
          </div>
        </div>
      )}
      
      <BottomNav userRole="admin" />
      </div>
    </div>
  );
}
