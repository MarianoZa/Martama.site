import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "@getmocha/users-service/react";
import Header from "@/react-app/components/Header";
import { TrendingUp, Users, DollarSign, CheckCircle, AlertCircle } from "lucide-react";

export default function BecomeAffiliate() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);
  
  const [formData, setFormData] = useState({
    promo_code: "",
    specialty: "",
    audience_size: "",
    social_links: "",
    motivation: "",
    payment_method: "mobile_money",
  });

  useEffect(() => {
    const loadFont = () => {
      const link = document.createElement("link");
      link.href = "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap";
      link.rel = "stylesheet";
      document.head.appendChild(link);
    };
    loadFont();
  }, []);

  useEffect(() => {
    if (!user) {
      navigate("/");
    }
  }, [user, navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setMessage(null);

    try {
      const response = await fetch("/api/affiliate-requests", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (response.ok) {
        setMessage({
          type: 'success',
          text: "Votre demande d'affiliation a été soumise avec succès ! Nous examinerons votre candidature et vous contacterons bientôt."
        });
        setTimeout(() => navigate("/dashboard"), 3000);
      } else {
        setMessage({
          type: 'error',
          text: data.error || "Erreur lors de la soumission de votre demande"
        });
      }
    } catch (error) {
      console.error("Failed to submit affiliate request:", error);
      setMessage({
        type: 'error',
        text: "Erreur lors de la soumission de votre demande"
      });
    } finally {
      setLoading(false);
    }
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-indigo-900" style={{ fontFamily: "'Outfit', sans-serif" }}>
      <Header showBackButton onBack={() => navigate("/dashboard")} />

      <main className="px-6 py-12 max-w-5xl mx-auto">
        <div className="text-center mb-12">
          <div className="w-20 h-20 bg-gradient-to-br from-purple-400 to-pink-500 rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-2xl">
            <TrendingUp className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-5xl font-bold text-white mb-4">Rejoignez Notre Programme d'Affiliation</h1>
          <p className="text-xl text-purple-200 max-w-2xl mx-auto">
            Gagnez jusqu'à 30% de commission sur chaque vente générée grâce à votre code promo personnalisé
          </p>
        </div>

        {/* Benefits */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6 text-center">
            <div className="w-14 h-14 bg-green-500/20 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <DollarSign className="w-7 h-7 text-green-400" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">Commissions Élevées</h3>
            <p className="text-purple-200 text-sm">Jusqu'à 30% par vente réalisée</p>
          </div>

          <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6 text-center">
            <div className="w-14 h-14 bg-blue-500/20 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <Users className="w-7 h-7 text-blue-400" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">Dashboard Détaillé</h3>
            <p className="text-purple-200 text-sm">Suivez vos performances en temps réel</p>
          </div>

          <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6 text-center">
            <div className="w-14 h-14 bg-purple-500/20 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <TrendingUp className="w-7 h-7 text-purple-400" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">Paiements Rapides</h3>
            <p className="text-purple-200 text-sm">Retraits via Mobile Money</p>
          </div>
        </div>

        {/* Form */}
        <div className="bg-white/5 backdrop-blur-md rounded-3xl border border-white/10 p-8">
          <h2 className="text-2xl font-bold text-white mb-6">Formulaire de Candidature</h2>

          {message && (
            <div className={`mb-6 p-4 rounded-xl border flex items-start gap-3 ${
              message.type === 'success'
                ? 'bg-green-500/10 border-green-500/30'
                : 'bg-red-500/10 border-red-500/30'
            }`}>
              {message.type === 'success' ? (
                <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
              ) : (
                <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
              )}
              <p className={message.type === 'success' ? 'text-green-300' : 'text-red-300'}>
                {message.text}
              </p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-purple-300 text-sm font-medium mb-2">
                Code Promo Souhaité *
              </label>
              <input
                type="text"
                value={formData.promo_code}
                onChange={(e) => setFormData({ ...formData, promo_code: e.target.value.toUpperCase() })}
                placeholder="Ex: MARTAMA2025"
                required
                maxLength={20}
                pattern="[A-Z0-9]+"
                className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-purple-300/50 focus:outline-none focus:ring-2 focus:ring-purple-500 uppercase"
              />
              <p className="text-purple-300 text-xs mt-1">Lettres majuscules et chiffres uniquement, 3-20 caractères</p>
            </div>

            <div>
              <label className="block text-purple-300 text-sm font-medium mb-2">
                Votre Spécialité / Niche
              </label>
              <input
                type="text"
                value={formData.specialty}
                onChange={(e) => setFormData({ ...formData, specialty: e.target.value })}
                placeholder="Ex: Marketing digital, Éducation, Tech..."
                className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-purple-300/50 focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>

            <div>
              <label className="block text-purple-300 text-sm font-medium mb-2">
                Taille de votre Audience
              </label>
              <select
                value={formData.audience_size}
                onChange={(e) => setFormData({ ...formData, audience_size: e.target.value })}
                className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
              >
                <option value="">Sélectionnez une option</option>
                <option value="0-1000">Moins de 1 000</option>
                <option value="1000-5000">1 000 - 5 000</option>
                <option value="5000-10000">5 000 - 10 000</option>
                <option value="10000-50000">10 000 - 50 000</option>
                <option value="50000+">Plus de 50 000</option>
              </select>
            </div>

            <div>
              <label className="block text-purple-300 text-sm font-medium mb-2">
                Liens Réseaux Sociaux
              </label>
              <textarea
                value={formData.social_links}
                onChange={(e) => setFormData({ ...formData, social_links: e.target.value })}
                rows={3}
                placeholder="Instagram: @username&#10;Facebook: facebook.com/page&#10;YouTube: youtube.com/channel"
                className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-purple-300/50 focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>

            <div>
              <label className="block text-purple-300 text-sm font-medium mb-2">
                Pourquoi souhaitez-vous devenir affilié ?
              </label>
              <textarea
                value={formData.motivation}
                onChange={(e) => setFormData({ ...formData, motivation: e.target.value })}
                rows={4}
                placeholder="Parlez-nous de votre motivation et de votre stratégie de promotion..."
                className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-purple-300/50 focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>

            <div>
              <label className="block text-purple-300 text-sm font-medium mb-2">
                Méthode de Paiement Préférée
              </label>
              <select
                value={formData.payment_method}
                onChange={(e) => setFormData({ ...formData, payment_method: e.target.value })}
                className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
              >
                <option value="mobile_money">Mobile Money</option>
                <option value="wave">Wave</option>
                <option value="orange_money">Orange Money</option>
              </select>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-4 bg-white text-purple-900 rounded-2xl font-bold text-lg hover:bg-purple-50 transition-all duration-300 shadow-2xl hover:shadow-purple-500/50 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? "Envoi en cours..." : "Soumettre ma candidature"}
            </button>
          </form>
        </div>
      </main>
    </div>
  );
}
