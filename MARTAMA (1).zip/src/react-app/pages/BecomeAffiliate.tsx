import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "@getmocha/users-service/react";
import Header from "@/react-app/components/Header";
import { TrendingUp, Users, DollarSign, CheckCircle, AlertCircle } from "lucide-react";

const paymentMethods = [
  { value: "mtn", label: "MTN Mobile Money" },
  { value: "moov", label: "Moov Money" },
  { value: "orange", label: "Orange Money" },
  { value: "airtel", label: "Airtel Money" },
  { value: "wave", label: "Wave" },
];

export default function BecomeAffiliate() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [checking, setChecking] = useState(true);
  const [hasExistingRequest, setHasExistingRequest] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error' | 'info', text: string } | null>(null);
  
  const [formData, setFormData] = useState({
    promo_code: "",
    payment_method: "mtn",
    payment_phone_number: "",
  });

  useEffect(() => {
    const loadFont = () => {
      const link = document.createElement("link");
      link.href = "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap";
      link.rel = "stylesheet";
      document.head.appendChild(link);
    };
    loadFont();
  }, []);

  useEffect(() => {
    if (!user) {
      navigate("/");
    } else {
      checkExistingRequest();
    }
  }, [user, navigate]);

  const checkExistingRequest = async () => {
    try {
      setChecking(true);
      const response = await fetch("/api/affiliate-requests/my-status");
      if (response.ok) {
        const data = await response.json();
        if (data.has_request) {
          setHasExistingRequest(true);
          setMessage({
            type: 'info',
            text: `Vous avez déjà soumis une demande d'affiliation (Code: ${data.promo_code}). Statut: ${data.status === 'pending' ? 'En cours de traitement' : data.status}.`
          });
        }
      }
    } catch (error) {
      console.error("Failed to check existing request:", error);
    } finally {
      setChecking(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setMessage(null);

    try {
      const response = await fetch("/api/affiliate-requests", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (response.ok) {
        setMessage({
          type: 'success',
          text: "Votre demande d'affiliation a été soumise avec succès ! Vous recevrez 650F de bonus de bienvenue dès validation. Nous examinerons votre candidature et vous contacterons bientôt."
        });
        setTimeout(() => navigate("/dashboard"), 3000);
      } else {
        setMessage({
          type: 'error',
          text: data.error || "Erreur lors de la soumission de votre demande"
        });
      }
    } catch (error) {
      console.error("Failed to submit affiliate request:", error);
      setMessage({
        type: 'error',
        text: "Erreur lors de la soumission de votre demande"
      });
    } finally {
      setLoading(false);
    }
  };

  if (!user || checking) return (
    <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: 'var(--bg-primary)' }}>
      <div className="w-12 h-12 border-4 rounded-full animate-spin" style={{ borderColor: 'var(--gray-200)', borderTopColor: 'var(--primary)' }}></div>
    </div>
  );

  return (
    <div className="min-h-screen" style={{ fontFamily: "'Outfit', sans-serif", backgroundColor: 'var(--bg-primary)' }}>
      <Header showBackButton onBack={() => navigate("/dashboard")} />

      <main className="px-6 py-12 max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <div className="w-20 h-20 rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-2xl" style={{ background: 'linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%)' }}>
            <TrendingUp className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold mb-4" style={{ color: 'var(--text-primary)' }}>Rejoignez Notre Programme d'Affiliation</h1>
          <p className="text-lg md:text-xl max-w-2xl mx-auto" style={{ color: 'var(--text-secondary)' }}>
            Gagnez jusqu'à 30% de commission sur chaque vente + 650F de bonus de bienvenue
          </p>
        </div>

        {/* Benefits */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          <div className="rounded-2xl border p-6 text-center" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
            <div className="w-14 h-14 rounded-2xl flex items-center justify-center mx-auto mb-4" style={{ backgroundColor: 'rgba(16, 185, 129, 0.2)' }}>
              <DollarSign className="w-7 h-7" style={{ color: 'var(--success)' }} />
            </div>
            <h3 className="text-xl font-bold mb-2" style={{ color: 'var(--text-primary)' }}>Bonus de Bienvenue</h3>
            <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>650F offerts dès validation</p>
          </div>

          <div className="rounded-2xl border p-6 text-center" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
            <div className="w-14 h-14 rounded-2xl flex items-center justify-center mx-auto mb-4" style={{ backgroundColor: 'rgba(59, 130, 246, 0.2)' }}>
              <Users className="w-7 h-7" style={{ color: 'var(--info)' }} />
            </div>
            <h3 className="text-xl font-bold mb-2" style={{ color: 'var(--text-primary)' }}>Dashboard Détaillé</h3>
            <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>Suivez vos performances en temps réel</p>
          </div>

          <div className="rounded-2xl border p-6 text-center" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
            <div className="w-14 h-14 rounded-2xl flex items-center justify-center mx-auto mb-4" style={{ backgroundColor: 'rgba(139, 92, 246, 0.2)' }}>
              <TrendingUp className="w-7 h-7" style={{ color: 'var(--primary)' }} />
            </div>
            <h3 className="text-xl font-bold mb-2" style={{ color: 'var(--text-primary)' }}>Paiements Rapides</h3>
            <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>Retraits dès 2000F via Mobile Money</p>
          </div>
        </div>

        {/* Form */}
        <div className="rounded-3xl border p-6 md:p-8" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
          <h2 className="text-2xl font-bold mb-2" style={{ color: 'var(--text-primary)' }}>Formulaire de Candidature</h2>
          <p className="mb-6" style={{ color: 'var(--text-secondary)' }}>
            Remplissez ce formulaire simple pour commencer à gagner des commissions
          </p>

          {message && (
            <div className={`mb-6 p-4 rounded-xl border flex items-start gap-3 ${
              message.type === 'success'
                ? 'bg-green-500/10 border-green-500/30'
                : message.type === 'info'
                ? 'bg-blue-500/10 border-blue-500/30'
                : 'bg-red-500/10 border-red-500/30'
            }`}>
              {message.type === 'success' ? (
                <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
              ) : message.type === 'info' ? (
                <AlertCircle className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" />
              ) : (
                <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
              )}
              <p className={message.type === 'success' ? 'text-green-300' : message.type === 'info' ? 'text-blue-300' : 'text-red-300'}>
                {message.text}
              </p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                Code Promo Souhaité <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={formData.promo_code}
                onChange={(e) => setFormData({ ...formData, promo_code: e.target.value.toUpperCase() })}
                placeholder="Ex: MARTAMA2025"
                required
                maxLength={20}
                pattern="[A-Z0-9]+"
                className="w-full px-4 py-3 border rounded-xl uppercase focus:outline-none focus:ring-2 text-base md:text-lg font-semibold"
                style={{ 
                  backgroundColor: 'var(--bg-primary)', 
                  borderColor: 'var(--border-color)', 
                  color: 'var(--text-primary)',
                  '--tw-ring-color': 'var(--primary)'
                } as any}
              />
              <p className="text-xs mt-1" style={{ color: 'var(--text-muted)' }}>Lettres majuscules et chiffres uniquement, 3-20 caractères</p>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                Méthode de Paiement Préférée <span className="text-red-500">*</span>
              </label>
              <select
                value={formData.payment_method}
                onChange={(e) => setFormData({ ...formData, payment_method: e.target.value })}
                required
                className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2 text-base"
                style={{ 
                  backgroundColor: 'var(--bg-primary)', 
                  borderColor: 'var(--border-color)', 
                  color: 'var(--text-primary)',
                  '--tw-ring-color': 'var(--primary)'
                } as any}
              >
                {paymentMethods.map((method) => (
                  <option key={method.value} value={method.value}>
                    {method.label}
                  </option>
                ))}
              </select>
              <p className="text-xs mt-1" style={{ color: 'var(--text-muted)' }}>Vous pourrez modifier cette méthode plus tard dans votre profil</p>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                Numéro de Téléphone (Mobile Money) <span className="text-red-500">*</span>
              </label>
              <input
                type="tel"
                value={formData.payment_phone_number}
                onChange={(e) => setFormData({ ...formData, payment_phone_number: e.target.value })}
                placeholder="Ex: +229 XX XXX XX XX"
                required
                className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2 text-base"
                style={{ 
                  backgroundColor: 'var(--bg-primary)', 
                  borderColor: 'var(--border-color)', 
                  color: 'var(--text-primary)',
                  '--tw-ring-color': 'var(--primary)'
                } as any}
              />
              <p className="text-xs mt-1" style={{ color: 'var(--text-muted)' }}>Numéro associé à votre compte Mobile Money</p>
            </div>

            {/* Welcome Bonus Info */}
            <div className="rounded-xl border p-4" style={{ backgroundColor: 'rgba(16, 185, 129, 0.1)', borderColor: 'rgba(16, 185, 129, 0.3)' }}>
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0" style={{ backgroundColor: 'var(--success)' }}>
                  <DollarSign className="w-5 h-5 text-white" />
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold mb-1" style={{ color: 'var(--text-primary)' }}>Bonus de Bienvenue 🎁</h4>
                  <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
                    Recevez 650F gratuits dès validation de votre demande ! Vous pourrez retirer vos gains dès que votre solde atteint 2000F (incluant le bonus et vos commissions).
                  </p>
                </div>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading || hasExistingRequest}
              className="w-full py-4 rounded-2xl font-bold text-lg transition-all duration-300 shadow-lg disabled:opacity-50 disabled:cursor-not-allowed text-white"
              style={{ backgroundColor: 'var(--primary)' }}
            >
              {loading ? "Envoi en cours..." : hasExistingRequest ? "Demande déjà soumise" : "Soumettre ma candidature"}
            </button>
            
            {hasExistingRequest && (
              <button
                type="button"
                onClick={() => navigate("/dashboard")}
                className="w-full py-3 rounded-2xl font-semibold transition-all duration-300 border"
                style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)', color: 'var(--text-primary)', borderColor: 'rgba(139, 92, 246, 0.3)' }}
              >
                Retour au Dashboard
              </button>
            )}
          </form>
        </div>

        {/* How it Works */}
        <div className="mt-8 rounded-2xl border p-6" style={{ backgroundColor: 'rgba(59, 130, 246, 0.1)', borderColor: 'rgba(59, 130, 246, 0.3)' }}>
          <h3 className="font-semibold mb-4 flex items-center gap-2 text-lg" style={{ color: 'var(--text-primary)' }}>
            <svg className="w-5 h-5 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            Comment ça marche ?
          </h3>
          <ul className="space-y-3 text-sm" style={{ color: 'var(--text-secondary)' }}>
            <li className="flex items-start gap-2">
              <span className="text-blue-400 font-bold mt-0.5">1.</span>
              <span>Soumettez votre candidature avec votre code promo et vos informations de paiement</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-blue-400 font-bold mt-0.5">2.</span>
              <span>Notre équipe examine votre demande (généralement sous 24-48h)</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-blue-400 font-bold mt-0.5">3.</span>
              <span>Une fois approuvé, vous recevez 650F de bonus + votre lien d'affiliation unique</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-blue-400 font-bold mt-0.5">4.</span>
              <span>Partagez votre lien et gagnez jusqu'à 30% sur chaque vente</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-blue-400 font-bold mt-0.5">5.</span>
              <span>Demandez un retrait dès que votre solde atteint 2000F</span>
            </li>
          </ul>
        </div>
      </main>
    </div>
  );
}
