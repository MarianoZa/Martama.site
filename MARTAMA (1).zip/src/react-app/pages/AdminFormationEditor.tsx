import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router";
import { ArrowLeft, Plus, Edit, Trash2, Play, FileText, GripVertical, Link as LinkIcon, Youtube, Video, X } from "lucide-react";
import { convertGoogleDriveUrl, getGoogleDriveMessage, isGoogleDriveUrl } from "@/react-app/utils/googleDrive";
import AdminSidebar from "@/react-app/components/AdminSidebar";

interface Module {
  id: number;
  product_id: number;
  title: string;
  description: string | null;
  order_position: number;
  videos?: Video[];
}

interface Resource {
  title: string;
  url: string;
  type?: string;
}

interface Video {
  id: number;
  module_id: number;
  title: string;
  description: string | null;
  video_url: string;
  video_type: 'youtube' | 'vimeo' | 'direct';
  aspect_ratio: string;
  duration_seconds: number | null;
  order_position: number;
  resources?: string | null;
}

export default function AdminFormationEditor() {
  const navigate = useNavigate();
  const { productId } = useParams();
  const [product, setProduct] = useState<any>(null);
  const [modules, setModules] = useState<Module[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModuleModal, setShowModuleModal] = useState(false);
  const [showVideoForm, setShowVideoForm] = useState(false);
  const [editingModule, setEditingModule] = useState<Module | null>(null);
  const [editingVideo, setEditingVideo] = useState<Video | null>(null);
  const [selectedModuleId, setSelectedModuleId] = useState<number | null>(null);

  const [moduleForm, setModuleForm] = useState({
    title: "",
    description: "",
    order_position: 0
  });

  const [videoForm, setVideoForm] = useState({
    title: "",
    description: "",
    video_url: "",
    video_type: "youtube" as 'youtube' | 'vimeo' | 'direct',
    aspect_ratio: "16:9",
    duration_seconds: "",
    order_position: 0
  });

  const [videoResources, setVideoResources] = useState<Resource[]>([]);

  useEffect(() => {
    fetchFormation();
  }, [productId]);

  const fetchFormation = async () => {
    try {
      setLoading(true);
      const response = await fetch(`/api/formations/admin/formation/${productId}`);
      if (response.ok) {
        const data = await response.json();
        setProduct(data.product);
        setModules(data.modules || []);
      }
    } catch (error) {
      console.error("Failed to fetch formation:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleOpenModuleModal = (module?: Module) => {
    if (module) {
      setEditingModule(module);
      setModuleForm({
        title: module.title,
        description: module.description || "",
        order_position: module.order_position
      });
    } else {
      setEditingModule(null);
      setModuleForm({
        title: "",
        description: "",
        order_position: modules.length
      });
    }
    setShowModuleModal(true);
  };

  const handleOpenVideoForm = (moduleId: number, video?: Video) => {
    setSelectedModuleId(moduleId);
    if (video) {
      setEditingVideo(video);
      setVideoForm({
        title: video.title,
        description: video.description || "",
        video_url: video.video_url,
        video_type: video.video_type,
        aspect_ratio: video.aspect_ratio,
        duration_seconds: video.duration_seconds?.toString() || "",
        order_position: video.order_position
      });
      
      // Parse resources if they exist
      if (video.resources) {
        try {
          const parsed = JSON.parse(video.resources);
          setVideoResources(Array.isArray(parsed) ? parsed : []);
        } catch (e) {
          setVideoResources([]);
        }
      } else {
        setVideoResources([]);
      }
    } else {
      setEditingVideo(null);
      const module = modules.find(m => m.id === moduleId);
      setVideoForm({
        title: "",
        description: "",
        video_url: "",
        video_type: "youtube",
        aspect_ratio: "16:9",
        duration_seconds: "",
        order_position: module?.videos?.length || 0
      });
      setVideoResources([]);
    }
    setShowVideoForm(true);
  };

  const handleCloseVideoForm = () => {
    setShowVideoForm(false);
    setEditingVideo(null);
    setSelectedModuleId(null);
    setVideoResources([]);
  };

  const handleSaveModule = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const url = editingModule
        ? `/api/formations/admin/formation/modules/${editingModule.id}`
        : `/api/formations/admin/formation/${productId}/modules`;
      
      const response = await fetch(url, {
        method: editingModule ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(moduleForm)
      });

      if (response.ok) {
        await fetchFormation();
        setShowModuleModal(false);
      }
    } catch (error) {
      console.error("Failed to save module:", error);
    }
  };

  const handleSaveVideo = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const url = editingVideo
        ? `/api/formations/admin/formation/videos/${editingVideo.id}`
        : `/api/formations/admin/formation/modules/${selectedModuleId}/videos`;
      
      // Convert Google Drive URL if detected
      const finalVideoUrl = isGoogleDriveUrl(videoForm.video_url)
        ? convertGoogleDriveUrl(videoForm.video_url)
        : videoForm.video_url;
      
      const payload = {
        ...videoForm,
        video_url: finalVideoUrl,
        duration_seconds: videoForm.duration_seconds ? parseInt(videoForm.duration_seconds) : null,
        resources: videoResources.length > 0 ? videoResources : null
      };

      const response = await fetch(url, {
        method: editingVideo ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      if (response.ok) {
        await fetchFormation();
        handleCloseVideoForm();
      }
    } catch (error) {
      console.error("Failed to save video:", error);
    }
  };

  const handleDeleteModule = async (moduleId: number) => {
    if (!confirm("Supprimer ce module et toutes ses vidéos ?")) return;

    try {
      const response = await fetch(`/api/formations/admin/formation/modules/${moduleId}`, {
        method: "DELETE"
      });

      if (response.ok) {
        await fetchFormation();
      }
    } catch (error) {
      console.error("Failed to delete module:", error);
    }
  };

  const handleDeleteVideo = async (videoId: number) => {
    if (!confirm("Supprimer cette vidéo ?")) return;

    try {
      const response = await fetch(`/api/formations/admin/formation/videos/${videoId}`, {
        method: "DELETE"
      });

      if (response.ok) {
        await fetchFormation();
      }
    } catch (error) {
      console.error("Failed to delete video:", error);
    }
  };

  const getVideoIcon = (type: string) => {
    switch (type) {
      case 'youtube': return <Youtube className="w-4 h-4" style={{ color: '#FF0000' }} />;
      case 'vimeo': return <Video className="w-4 h-4" style={{ color: '#1AB7EA' }} />;
      default: return <Play className="w-4 h-4" style={{ color: 'var(--primary)' }} />;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: 'var(--bg-primary)' }}>
        <div className="inline-block w-12 h-12 border-4 rounded-full animate-spin" style={{ borderColor: 'var(--gray-200)', borderTopColor: 'var(--primary)' }}></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex" style={{ fontFamily: "'Outfit', sans-serif", backgroundColor: 'var(--bg-primary)' }}>
      <AdminSidebar />
      
      <div className="flex-1">
      <header className="px-6 py-6 border-b" style={{ borderColor: 'var(--border-color)' }}>
        <div className="flex items-center gap-4 mb-6">
          <button
            onClick={() => {
              if (showVideoForm) {
                handleCloseVideoForm();
              } else {
                navigate("/admin/products");
              }
            }}
            className="p-2 hover:opacity-80 rounded-xl transition-opacity"
            style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)' }}
          >
            <ArrowLeft className="w-6 h-6" style={{ color: 'var(--primary)' }} />
          </button>
          <div className="flex-1">
            <h1 className="text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>
              {showVideoForm ? (editingVideo ? "Modifier la vidéo" : "Nouvelle vidéo") : "Éditeur de Formation"}
            </h1>
            <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>{product?.name}</p>
          </div>
          {!showVideoForm && (
            <button
              onClick={() => handleOpenModuleModal()}
              className="flex items-center gap-2 px-6 py-3 rounded-xl font-semibold text-white"
              style={{ backgroundColor: 'var(--primary)' }}
            >
              <Plus className="w-5 h-5" />
              Nouveau Module
            </button>
          )}
        </div>
      </header>

      <main className="px-6 py-8">
        {/* Video Form View */}
        {showVideoForm ? (
          <div className="max-w-3xl mx-auto">
            <form onSubmit={handleSaveVideo} className="space-y-6">
              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                  Titre de la leçon *
                </label>
                <input
                  type="text"
                  value={videoForm.title}
                  onChange={(e) => setVideoForm({ ...videoForm, title: e.target.value })}
                  required
                  placeholder="Ex: Les bases de React Hooks"
                  className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                  style={{ 
                    backgroundColor: 'var(--bg-secondary)', 
                    borderColor: 'var(--border-color)', 
                    color: 'var(--text-primary)',
                    '--tw-ring-color': 'var(--primary)'
                  } as any}
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-3" style={{ color: 'var(--text-muted)' }}>
                  Type de vidéo *
                </label>
                <div className="grid grid-cols-3 gap-3">
                  <button
                    type="button"
                    onClick={() => setVideoForm({ ...videoForm, video_type: 'youtube' })}
                    className={`py-4 px-4 rounded-xl font-semibold text-sm transition-all flex flex-col items-center justify-center gap-2 ${
                      videoForm.video_type === 'youtube' ? 'ring-2' : ''
                    }`}
                    style={{
                      backgroundColor: videoForm.video_type === 'youtube' ? 'rgba(255, 0, 0, 0.1)' : 'var(--bg-secondary)',
                      color: videoForm.video_type === 'youtube' ? '#FF0000' : 'var(--text-primary)',
                      '--tw-ring-color': '#FF0000'
                    } as any}
                  >
                    <Youtube className="w-6 h-6" />
                    YouTube
                  </button>
                  <button
                    type="button"
                    onClick={() => setVideoForm({ ...videoForm, video_type: 'vimeo' })}
                    className={`py-4 px-4 rounded-xl font-semibold text-sm transition-all flex flex-col items-center justify-center gap-2 ${
                      videoForm.video_type === 'vimeo' ? 'ring-2' : ''
                    }`}
                    style={{
                      backgroundColor: videoForm.video_type === 'vimeo' ? 'rgba(26, 183, 234, 0.1)' : 'var(--bg-secondary)',
                      color: videoForm.video_type === 'vimeo' ? '#1AB7EA' : 'var(--text-primary)',
                      '--tw-ring-color': '#1AB7EA'
                    } as any}
                  >
                    <Video className="w-6 h-6" />
                    Vimeo
                  </button>
                  <button
                    type="button"
                    onClick={() => setVideoForm({ ...videoForm, video_type: 'direct' })}
                    className={`py-4 px-4 rounded-xl font-semibold text-sm transition-all flex flex-col items-center justify-center gap-2 ${
                      videoForm.video_type === 'direct' ? 'ring-2' : ''
                    }`}
                    style={{
                      backgroundColor: videoForm.video_type === 'direct' ? 'rgba(139, 92, 246, 0.1)' : 'var(--bg-secondary)',
                      color: videoForm.video_type === 'direct' ? 'var(--primary)' : 'var(--text-primary)',
                      '--tw-ring-color': 'var(--primary)'
                    } as any}
                  >
                    <LinkIcon className="w-6 h-6" />
                    Direct
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                  URL de la vidéo * {videoForm.video_type !== 'direct' && '(unlisted recommandé)'}
                </label>
                <input
                  type="url"
                  value={videoForm.video_url}
                  onChange={(e) => setVideoForm({ ...videoForm, video_url: e.target.value })}
                  required
                  placeholder={
                    videoForm.video_type === 'youtube' 
                      ? "https://www.youtube.com/watch?v=..."
                      : videoForm.video_type === 'vimeo'
                      ? "https://vimeo.com/..."
                      : "https://drive.google.com/file/d/.../view ou https://..."
                  }
                  className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2 font-mono text-sm"
                  style={{ 
                    backgroundColor: 'var(--bg-secondary)', 
                    borderColor: 'var(--border-color)', 
                    color: 'var(--text-primary)',
                    '--tw-ring-color': 'var(--primary)'
                  } as any}
                />
                {videoForm.video_url && isGoogleDriveUrl(videoForm.video_url) && (
                  <p className="text-xs mt-2 font-medium" style={{ color: 'var(--success)' }}>
                    {getGoogleDriveMessage(videoForm.video_url)}
                  </p>
                )}
                {videoForm.video_type !== 'direct' && (
                  <p className="text-xs mt-2" style={{ color: 'var(--text-muted)' }}>
                    💡 Pour YouTube/Vimeo, utilisez des vidéos "unlisted" pour qu'elles ne soient visibles que via votre formation
                  </p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                  Ratio d'aspect *
                </label>
                <select
                  value={videoForm.aspect_ratio}
                  onChange={(e) => setVideoForm({ ...videoForm, aspect_ratio: e.target.value })}
                  className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                  style={{ 
                    backgroundColor: 'var(--bg-secondary)', 
                    borderColor: 'var(--border-color)', 
                    color: 'var(--text-primary)',
                    '--tw-ring-color': 'var(--primary)'
                  } as any}
                >
                  <option value="16:9">16:9 (Horizontal standard - YouTube)</option>
                  <option value="9:16">9:16 (Vertical - Stories/Reels/TikTok)</option>
                  <option value="1:1">1:1 (Carré - Instagram)</option>
                  <option value="4:3">4:3 (Classique - Ancien format)</option>
                  <option value="3:4">3:4 (Portrait)</option>
                  <option value="4:5">4:5 (Instagram Portrait)</option>
                  <option value="21:9">21:9 (Cinéma ultra-large)</option>
                </select>
                <p className="text-xs mt-2" style={{ color: 'var(--text-muted)' }}>
                  Le lecteur vidéo s'adaptera automatiquement au format choisi
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                  Description
                </label>
                <textarea
                  value={videoForm.description}
                  onChange={(e) => setVideoForm({ ...videoForm, description: e.target.value })}
                  rows={4}
                  placeholder="Décrivez le contenu de cette leçon..."
                  className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                  style={{ 
                    backgroundColor: 'var(--bg-secondary)', 
                    borderColor: 'var(--border-color)', 
                    color: 'var(--text-primary)',
                    '--tw-ring-color': 'var(--primary)'
                  } as any}
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                  Durée (secondes) - optionnel
                </label>
                <input
                  type="number"
                  min="0"
                  value={videoForm.duration_seconds}
                  onChange={(e) => setVideoForm({ ...videoForm, duration_seconds: e.target.value })}
                  placeholder="Ex: 600 (pour 10 minutes)"
                  className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                  style={{ 
                    backgroundColor: 'var(--bg-secondary)', 
                    borderColor: 'var(--border-color)', 
                    color: 'var(--text-primary)',
                    '--tw-ring-color': 'var(--primary)'
                  } as any}
                />
              </div>

              {/* Resources Section */}
              <div className="border rounded-xl p-4" style={{ borderColor: 'var(--border-color)', backgroundColor: 'var(--bg-secondary)' }}>
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h4 className="text-base font-semibold" style={{ color: 'var(--text-primary)' }}>🔗 Liens et Ressources</h4>
                    <p className="text-xs mt-0.5" style={{ color: 'var(--text-muted)' }}>Ajoutez des liens utiles sous la vidéo</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setVideoResources([...videoResources, { title: '', url: '' }])}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium text-sm text-white"
                    style={{ backgroundColor: 'var(--success)' }}
                  >
                    <Plus className="w-4 h-4" />
                    Ajouter
                  </button>
                </div>

                {videoResources.length === 0 ? (
                  <div className="text-center py-6 border-2 border-dashed rounded-lg" style={{ borderColor: 'var(--border-color)' }}>
                    <LinkIcon className="w-8 h-8 mx-auto mb-2 opacity-30" style={{ color: 'var(--text-muted)' }} />
                    <p className="text-sm" style={{ color: 'var(--text-muted)' }}>Aucun lien ajouté</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {videoResources.map((resource, index) => (
                      <div key={index} className="border rounded-lg p-3" style={{ borderColor: 'var(--border-color)', backgroundColor: 'var(--bg-primary)' }}>
                        <div className="grid gap-3 mb-2">
                          <input
                            type="text"
                            value={resource.title}
                            onChange={(e) => {
                              const newResources = [...videoResources];
                              newResources[index].title = e.target.value;
                              setVideoResources(newResources);
                            }}
                            placeholder="Titre du lien (ex: Documentation officielle)"
                            className="w-full px-3 py-2 border rounded-lg focus:outline-none text-sm"
                            style={{ 
                              backgroundColor: 'var(--bg-secondary)', 
                              borderColor: 'var(--border-color)', 
                              color: 'var(--text-primary)'
                            }}
                          />
                          <input
                            type="url"
                            value={resource.url}
                            onChange={(e) => {
                              const newResources = [...videoResources];
                              newResources[index].url = e.target.value;
                              setVideoResources(newResources);
                            }}
                            placeholder="https://example.com"
                            className="w-full px-3 py-2 border rounded-lg focus:outline-none text-sm font-mono"
                            style={{ 
                              backgroundColor: 'var(--bg-secondary)', 
                              borderColor: 'var(--border-color)', 
                              color: 'var(--text-primary)'
                            }}
                          />
                        </div>
                        <button
                          type="button"
                          onClick={() => setVideoResources(videoResources.filter((_, i) => i !== index))}
                          className="w-full py-1.5 border rounded-lg text-xs font-medium transition-colors"
                          style={{ backgroundColor: 'rgba(239, 68, 68, 0.1)', color: 'var(--error)', borderColor: 'rgba(239, 68, 68, 0.3)' }}
                        >
                          Supprimer
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="flex gap-3 pt-6 border-t sticky bottom-0 pb-6" style={{ borderColor: 'var(--border-color)', backgroundColor: 'var(--bg-primary)' }}>
                <button
                  type="submit"
                  className="flex-1 px-6 py-4 rounded-xl font-bold text-base text-white shadow-lg"
                  style={{ backgroundColor: 'var(--primary)' }}
                >
                  {editingVideo ? "Mettre à jour la vidéo" : "Ajouter la vidéo"}
                </button>
                <button
                  type="button"
                  onClick={handleCloseVideoForm}
                  className="px-6 py-4 rounded-xl font-semibold text-base"
                  style={{ backgroundColor: 'var(--bg-secondary)', color: 'var(--text-primary)' }}
                >
                  Annuler
                </button>
              </div>
            </form>
          </div>
        ) : (
          /* Modules List View */
          <div>
        {modules.length === 0 ? (
          <div className="text-center py-20">
            <FileText className="w-16 h-16 mx-auto mb-4 opacity-30" style={{ color: 'var(--text-muted)' }} />
            <h3 className="text-xl font-bold mb-2" style={{ color: 'var(--text-primary)' }}>
              Aucun module pour l'instant
            </h3>
            <p className="text-sm mb-6" style={{ color: 'var(--text-muted)' }}>
              Commencez par créer un module pour organiser vos vidéos
            </p>
            <button
              onClick={() => handleOpenModuleModal()}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-semibold text-white"
              style={{ backgroundColor: 'var(--primary)' }}
            >
              <Plus className="w-5 h-5" />
              Créer le premier module
            </button>
          </div>
        ) : (
          <div className="space-y-6">
            {modules.map((module, index) => (
              <div
                key={module.id}
                className="border rounded-2xl overflow-hidden"
                style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}
              >
                {/* Module Header */}
                <div className="p-6 border-b" style={{ borderColor: 'var(--border-color)', backgroundColor: 'var(--bg-primary)' }}>
                  <div className="flex items-start gap-4">
                    <div className="p-2" style={{ color: 'var(--text-muted)' }}>
                      <GripVertical className="w-5 h-5" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-lg font-bold mb-1" style={{ color: 'var(--text-primary)' }}>
                        Module {index + 1}: {module.title}
                      </h3>
                      {module.description && (
                        <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
                          {module.description}
                        </p>
                      )}
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={() => handleOpenVideoForm(module.id)}
                        className="px-4 py-2 rounded-lg font-medium text-sm transition-colors"
                        style={{ backgroundColor: 'var(--success)', color: '#fff' }}
                      >
                        <Plus className="w-4 h-4 inline mr-1" />
                        Vidéo
                      </button>
                      <button
                        onClick={() => handleOpenModuleModal(module)}
                        className="p-2 rounded-lg transition-colors"
                        style={{ backgroundColor: 'var(--bg-secondary)', color: 'var(--info)' }}
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteModule(module.id)}
                        className="p-2 rounded-lg transition-colors"
                        style={{ backgroundColor: 'rgba(239, 68, 68, 0.1)', color: 'var(--error)' }}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>

                {/* Videos List */}
                <div className="divide-y" style={{ borderColor: 'var(--border-color)' }}>
                  {!module.videos || module.videos.length === 0 ? (
                    <div className="p-6 text-center">
                      <p className="text-sm" style={{ color: 'var(--text-muted)' }}>
                        Aucune vidéo dans ce module
                      </p>
                    </div>
                  ) : (
                    module.videos.map((video, videoIndex) => (
                      <div key={video.id} className="p-4 hover:opacity-90 transition-opacity">
                        <div className="flex items-center gap-4">
                          <div className="p-2" style={{ color: 'var(--text-muted)' }}>
                            <GripVertical className="w-4 h-4" />
                          </div>
                          <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ backgroundColor: 'var(--bg-primary)' }}>
                            {getVideoIcon(video.video_type)}
                          </div>
                          <div className="flex-1">
                            <h4 className="font-semibold text-sm mb-0.5" style={{ color: 'var(--text-primary)' }}>
                              Leçon {videoIndex + 1}: {video.title}
                            </h4>
                            <div className="flex items-center gap-3 text-xs" style={{ color: 'var(--text-muted)' }}>
                              <span className="px-2 py-0.5 rounded-full" style={{ backgroundColor: 'var(--bg-primary)' }}>
                                {video.aspect_ratio}
                              </span>
                              <span>{video.video_type}</span>
                              {video.duration_seconds && (
                                <span>{Math.floor(video.duration_seconds / 60)}:{(video.duration_seconds % 60).toString().padStart(2, '0')}</span>
                              )}
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <button
                              onClick={() => handleOpenVideoForm(module.id, video)}
                              className="p-2 rounded-lg transition-colors"
                              style={{ backgroundColor: 'var(--bg-primary)', color: 'var(--info)' }}
                            >
                              <Edit className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => handleDeleteVideo(video.id)}
                              className="p-2 rounded-lg transition-colors"
                              style={{ backgroundColor: 'rgba(239, 68, 68, 0.1)', color: 'var(--error)' }}
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
          </div>
        )}
      </main>

      </div>
      
      {/* Module Modal */}
      {showModuleModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-6">
          <div className="rounded-3xl border max-w-2xl w-full" style={{ backgroundColor: 'var(--bg-primary)', borderColor: 'var(--border-color)' }}>
            <div className="p-6 border-b flex items-center justify-between" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-xl font-bold" style={{ color: 'var(--text-primary)' }}>
                {editingModule ? "Modifier le module" : "Nouveau module"}
              </h3>
              <button
                onClick={() => setShowModuleModal(false)}
                className="p-2 hover:opacity-80 rounded-xl transition-opacity"
                style={{ backgroundColor: 'var(--bg-secondary)' }}
              >
                <X className="w-6 h-6" style={{ color: 'var(--text-primary)' }} />
              </button>
            </div>

            <form onSubmit={handleSaveModule} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                  Titre du module *
                </label>
                <input
                  type="text"
                  value={moduleForm.title}
                  onChange={(e) => setModuleForm({ ...moduleForm, title: e.target.value })}
                  required
                  placeholder="Ex: Introduction à React"
                  className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                  style={{ 
                    backgroundColor: 'var(--bg-secondary)', 
                    borderColor: 'var(--border-color)', 
                    color: 'var(--text-primary)',
                    '--tw-ring-color': 'var(--primary)'
                  } as any}
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                  Description
                </label>
                <textarea
                  value={moduleForm.description}
                  onChange={(e) => setModuleForm({ ...moduleForm, description: e.target.value })}
                  rows={3}
                  placeholder="Description du module..."
                  className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                  style={{ 
                    backgroundColor: 'var(--bg-secondary)', 
                    borderColor: 'var(--border-color)', 
                    color: 'var(--text-primary)',
                    '--tw-ring-color': 'var(--primary)'
                  } as any}
                />
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="submit"
                  className="flex-1 px-6 py-3 rounded-xl font-semibold text-white"
                  style={{ backgroundColor: 'var(--primary)' }}
                >
                  {editingModule ? "Mettre à jour" : "Créer le module"}
                </button>
                <button
                  type="button"
                  onClick={() => setShowModuleModal(false)}
                  className="px-6 py-3 rounded-xl font-semibold"
                  style={{ backgroundColor: 'var(--bg-secondary)', color: 'var(--text-primary)' }}
                >
                  Annuler
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      </div>
  );
}
