import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "@getmocha/users-service/react";
import Header from "@/react-app/components/Header";
import Footer from "@/react-app/components/Footer";
import BottomNav from "@/react-app/components/BottomNav";
import SEOHead from "@/react-app/components/SEOHead";
import { Calendar, Clock, ArrowRight, BookOpen } from "lucide-react";
import { formatDateBenin } from "@/react-app/utils/dateFormatter";

interface BlogPost {
  id: number;
  title: string;
  slug: string;
  excerpt: string | null;
  image_url: string | null;
  author_name: string | null;
  category: string | null;
  published_at: string;
  created_at: string;
}

export default function Blog() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [userData, setUserData] = useState<any>(null);
  const [affiliateData, setAffiliateData] = useState<any>(null);

  useEffect(() => {
    const loadFont = () => {
      const link = document.createElement("link");
      link.href = "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap";
      link.rel = "stylesheet";
      document.head.appendChild(link);
    };
    loadFont();
  }, []);

  useEffect(() => {
    fetchPosts();
    if (user) {
      fetchUserData();
      fetchAffiliateData();
    }
  }, [user]);

  const fetchPosts = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/blog/posts');
      if (response.ok) {
        const data = await response.json();
        setPosts(data);
      }
    } catch (error) {
      console.error('Failed to fetch blog posts:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchUserData = async () => {
    try {
      const response = await fetch("/api/users/me");
      if (response.ok) {
        const data = await response.json();
        setUserData(data);
      }
    } catch (error) {
      console.error("Failed to fetch user data:", error);
    }
  };

  const fetchAffiliateData = async () => {
    try {
      const response = await fetch("/api/affiliate/stats");
      if (response.ok) {
        const data = await response.json();
        setAffiliateData(data);
      }
    } catch (error) {
      setAffiliateData(null);
    }
  };

  const categories = Array.from(new Set(posts.map(p => p.category).filter(Boolean)));
  const filteredPosts = selectedCategory
    ? posts.filter(p => p.category === selectedCategory)
    : posts;

  return (
    <div className="min-h-screen pb-20" style={{ fontFamily: "'Outfit', sans-serif", backgroundColor: 'var(--bg-primary)' }}>
      <SEOHead
        title="Blog"
        description="Découvrez nos articles sur les abonnements premium, les formations et les astuces digitales"
        url="https://martama.site/blog"
      />
      <Header />

      <main className="px-6 py-12 max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-3 mb-4">
            <BookOpen className="w-10 h-10" style={{ color: 'var(--primary)' }} />
            <h1 className="text-4xl md:text-5xl font-bold" style={{ color: 'var(--text-primary)' }}>
              Notre Blog
            </h1>
          </div>
          <p className="text-lg md:text-xl max-w-2xl mx-auto" style={{ color: 'var(--text-secondary)' }}>
            Découvrez nos articles, guides et astuces pour tirer le meilleur parti de vos abonnements premium
          </p>
        </div>

        {/* Category filters */}
        {categories.length > 0 && (
          <div className="flex gap-3 mb-8 overflow-x-auto pb-2">
            <button
              onClick={() => setSelectedCategory(null)}
              className={`px-6 py-2 rounded-xl font-medium whitespace-nowrap transition-all ${
                selectedCategory === null ? "text-white" : ""
              }`}
              style={{
                backgroundColor: selectedCategory === null ? 'var(--primary)' : 'var(--bg-secondary)',
                color: selectedCategory === null ? '#ffffff' : 'var(--text-primary)',
                border: selectedCategory === null ? 'none' : '1px solid var(--border-color)'
              }}
            >
              Tous
            </button>
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-6 py-2 rounded-xl font-medium whitespace-nowrap transition-all ${
                  selectedCategory === cat ? "text-white" : ""
                }`}
                style={{
                  backgroundColor: selectedCategory === cat ? 'var(--primary)' : 'var(--bg-secondary)',
                  color: selectedCategory === cat ? '#ffffff' : 'var(--text-primary)',
                  border: selectedCategory === cat ? 'none' : '1px solid var(--border-color)'
                }}
              >
                {cat}
              </button>
            ))}
          </div>
        )}

        {/* Posts grid */}
        {loading ? (
          <div className="text-center py-20">
            <div
              className="inline-block w-12 h-12 border-4 rounded-full animate-spin"
              style={{ borderColor: 'var(--gray-200)', borderTopColor: 'var(--primary)' }}
            ></div>
          </div>
        ) : filteredPosts.length === 0 ? (
          <div className="text-center py-20">
            <BookOpen className="w-16 h-16 mx-auto mb-4 opacity-30" style={{ color: 'var(--text-muted)' }} />
            <p className="text-xl" style={{ color: 'var(--text-muted)' }}>
              Aucun article pour le moment
            </p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredPosts.map((post) => (
              <article
                key={post.id}
                onClick={() => navigate(`/blog/${post.slug}`)}
                className="group rounded-2xl border overflow-hidden cursor-pointer transition-all duration-300 hover:shadow-xl hover:-translate-y-1"
                style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}
              >
                {post.image_url && (
                  <div className="aspect-video overflow-hidden" style={{ backgroundColor: 'var(--gray-100)' }}>
                    <img
                      src={post.image_url}
                      alt={post.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                )}

                <div className="p-6">
                  {post.category && (
                    <span
                      className="inline-block px-3 py-1 rounded-full text-xs font-semibold mb-3"
                      style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)', color: 'var(--primary)' }}
                    >
                      {post.category}
                    </span>
                  )}

                  <h2
                    className="text-xl font-bold mb-3 group-hover:text-purple-600 transition-colors line-clamp-2"
                    style={{ color: 'var(--text-primary)' }}
                  >
                    {post.title}
                  </h2>

                  {post.excerpt && (
                    <p className="text-sm mb-4 line-clamp-3" style={{ color: 'var(--text-secondary)' }}>
                      {post.excerpt}
                    </p>
                  )}

                  <div className="flex items-center gap-4 text-sm mb-4" style={{ color: 'var(--text-muted)' }}>
                    <div className="flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      <span>{formatDateBenin(post.published_at)}</span>
                    </div>
                    {post.author_name && (
                      <div className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        <span>{post.author_name}</span>
                      </div>
                    )}
                  </div>

                  <button
                    className="inline-flex items-center gap-2 text-sm font-semibold group-hover:gap-3 transition-all"
                    style={{ color: 'var(--primary)' }}
                  >
                    Lire l'article
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </article>
            ))}
          </div>
        )}
      </main>

      <Footer />
      
      <BottomNav 
        userRole={userData?.role} 
        isAffiliate={!!affiliateData}
        affiliateCode={affiliateData?.promo_code}
        isAuthenticated={!!user}
      />
    </div>
  );
}
