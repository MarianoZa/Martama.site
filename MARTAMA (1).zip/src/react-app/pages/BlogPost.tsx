import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router";
import Header from "@/react-app/components/Header";
import Footer from "@/react-app/components/Footer";
import SEOHead from "@/react-app/components/SEOHead";
import { Calendar, Clock, ArrowLeft, Share2 } from "lucide-react";
import { formatDateBenin } from "@/react-app/utils/dateFormatter";

interface BlogPostData {
  id: number;
  title: string;
  slug: string;
  excerpt: string | null;
  content: string;
  image_url: string | null;
  author_name: string | null;
  category: string | null;
  published_at: string;
  created_at: string;
}

export default function BlogPost() {
  const navigate = useNavigate();
  const { slug } = useParams<{ slug: string }>();
  const [post, setPost] = useState<BlogPostData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadFont = () => {
      const link = document.createElement("link");
      link.href = "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap";
      link.rel = "stylesheet";
      document.head.appendChild(link);
    };
    loadFont();
  }, []);

  useEffect(() => {
    if (slug) {
      fetchPost();
    }
  }, [slug]);

  const fetchPost = async () => {
    try {
      setLoading(true);
      const response = await fetch(`/api/blog/posts/${slug}`);
      if (response.ok) {
        const data = await response.json();
        setPost(data);
      } else {
        navigate('/blog');
      }
    } catch (error) {
      console.error('Failed to fetch blog post:', error);
      navigate('/blog');
    } finally {
      setLoading(false);
    }
  };

  const handleShare = async () => {
    const url = window.location.href;
    if (navigator.share) {
      try {
        await navigator.share({
          title: post?.title,
          text: post?.excerpt || '',
          url: url,
        });
      } catch (error) {
        console.log('Error sharing:', error);
      }
    } else {
      navigator.clipboard.writeText(url);
      alert('Lien copié dans le presse-papiers !');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: 'var(--bg-primary)' }}>
        <div
          className="w-12 h-12 border-4 rounded-full animate-spin"
          style={{ borderColor: 'var(--gray-200)', borderTopColor: 'var(--primary)' }}
        ></div>
      </div>
    );
  }

  if (!post) {
    return null;
  }

  return (
    <div className="min-h-screen" style={{ fontFamily: "'Outfit', sans-serif", backgroundColor: 'var(--bg-primary)' }}>
      <SEOHead
        title={post.title}
        description={post.excerpt || post.title}
        url={`https://martama.site/blog/${post.slug}`}
      />
      <Header />

      <main className="px-6 py-12 max-w-4xl mx-auto">
        {/* Back button */}
        <button
          onClick={() => navigate('/blog')}
          className="inline-flex items-center gap-2 mb-8 px-4 py-2 rounded-xl transition-colors"
          style={{ backgroundColor: 'var(--bg-secondary)', color: 'var(--text-primary)' }}
        >
          <ArrowLeft className="w-5 h-5" />
          Retour au blog
        </button>

        {/* Article header */}
        <article>
          {post.category && (
            <span
              className="inline-block px-4 py-1.5 rounded-full text-sm font-semibold mb-4"
              style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)', color: 'var(--primary)' }}
            >
              {post.category}
            </span>
          )}

          <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-6" style={{ color: 'var(--text-primary)' }}>
            {post.title}
          </h1>

          <div className="flex items-center justify-between mb-8 pb-6 border-b" style={{ borderColor: 'var(--border-color)' }}>
            <div className="flex items-center gap-6 text-sm" style={{ color: 'var(--text-muted)' }}>
              <div className="flex items-center gap-2">
                <Calendar className="w-5 h-5" />
                <span>{formatDateBenin(post.published_at)}</span>
              </div>
              {post.author_name && (
                <div className="flex items-center gap-2">
                  <Clock className="w-5 h-5" />
                  <span>{post.author_name}</span>
                </div>
              )}
            </div>

            <button
              onClick={handleShare}
              className="flex items-center gap-2 px-4 py-2 rounded-xl transition-colors"
              style={{ backgroundColor: 'var(--bg-secondary)', color: 'var(--text-primary)' }}
            >
              <Share2 className="w-5 h-5" />
              <span className="hidden sm:inline">Partager</span>
            </button>
          </div>

          {/* Featured image */}
          {post.image_url && (
            <div className="aspect-video rounded-2xl overflow-hidden mb-8" style={{ backgroundColor: 'var(--gray-100)' }}>
              <img
                src={post.image_url}
                alt={post.title}
                className="w-full h-full object-cover"
              />
            </div>
          )}

          {/* Content */}
          <div
            className="prose prose-lg max-w-none"
            style={{
              color: 'var(--text-primary)',
              '--tw-prose-body': 'var(--text-primary)',
              '--tw-prose-headings': 'var(--text-primary)',
              '--tw-prose-links': 'var(--primary)',
              '--tw-prose-bold': 'var(--text-primary)',
              '--tw-prose-code': 'var(--text-primary)',
            } as any}
            dangerouslySetInnerHTML={{ __html: post.content }}
          />
        </article>

        {/* Share section */}
        <div className="mt-12 pt-8 border-t text-center" style={{ borderColor: 'var(--border-color)' }}>
          <p className="text-lg mb-4" style={{ color: 'var(--text-secondary)' }}>
            Cet article vous a été utile ?
          </p>
          <button
            onClick={handleShare}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-semibold transition-colors text-white"
            style={{ backgroundColor: 'var(--primary)' }}
          >
            <Share2 className="w-5 h-5" />
            Partager avec vos amis
          </button>
        </div>
      </main>

      <Footer />

      <style>{`
        .prose h2 {
          font-size: 1.875rem;
          font-weight: 700;
          margin-top: 2rem;
          margin-bottom: 1rem;
        }
        .prose h3 {
          font-size: 1.5rem;
          font-weight: 600;
          margin-top: 1.5rem;
          margin-bottom: 0.75rem;
        }
        .prose p {
          margin-bottom: 1.25rem;
          line-height: 1.75;
        }
        .prose ul, .prose ol {
          margin-bottom: 1.25rem;
          padding-left: 1.5rem;
        }
        .prose li {
          margin-bottom: 0.5rem;
        }
        .prose a {
          text-decoration: underline;
        }
        .prose strong {
          font-weight: 600;
        }
        .prose code {
          background-color: var(--bg-secondary);
          padding: 0.25rem 0.5rem;
          border-radius: 0.25rem;
          font-size: 0.875em;
        }
        .prose blockquote {
          border-left: 4px solid var(--primary);
          padding-left: 1rem;
          font-style: italic;
          margin: 1.5rem 0;
        }
        .prose img {
          border-radius: 0.5rem;
          margin: 1.5rem 0;
        }
      `}</style>
    </div>
  );
}
