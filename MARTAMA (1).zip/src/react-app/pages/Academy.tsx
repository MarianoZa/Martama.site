import { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "@getmocha/users-service/react";
import Header from "@/react-app/components/Header";
import Footer from "@/react-app/components/Footer";
import BottomNav from "@/react-app/components/BottomNav";
import SEOHead from "@/react-app/components/SEOHead";
import { Users, Calendar, Clock, CheckCircle, AlertCircle, Loader } from "lucide-react";

interface AcademyClass {
  id: number;
  name: string;
  description: string | null;
  image_url: string | null;
  instructor_name: string | null;
  category: string | null;
  max_members: number | null;
  current_members: number;
  is_active: number;
  start_date: string | null;
  end_date: string | null;
  meeting_schedule: string | null;
  requirements: string | null;
  created_at: string;
}

interface ClassRequest {
  id: number;
  class_id: number;
  status: string;
  class_name: string;
  class_image: string | null;
}

export default function Academy() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [classes, setClasses] = useState<AcademyClass[]>([]);
  const [myRequests, setMyRequests] = useState<ClassRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [showRequestForm, setShowRequestForm] = useState(false);
  const [selectedClass, setSelectedClass] = useState<AcademyClass | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [userData, setUserData] = useState<any>(null);
  const [affiliateData, setAffiliateData] = useState<any>(null);
  
  const [requestForm, setRequestForm] = useState({
    user_name: "",
  });

  useEffect(() => {
    const loadFont = () => {
      const link = document.createElement("link");
      link.href = "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap";
      link.rel = "stylesheet";
      document.head.appendChild(link);
    };
    loadFont();
  }, []);

  useEffect(() => {
    fetchClasses();
    checkAuth();
  }, []);

  useEffect(() => {
    if (user) {
      fetchUserData();
      fetchAffiliateData();
    }
  }, [user]);

  const checkAuth = async () => {
    try {
      const response = await fetch("/api/users/me");
      if (response.ok) {
        const user = await response.json();
        setIsAuthenticated(true);
        setRequestForm({ user_name: user.full_name || "" });
        fetchMyRequests();
      }
    } catch (error) {
      console.error("Auth check failed:", error);
    }
  };

  const fetchClasses = async () => {
    try {
      setLoading(true);
      const response = await fetch("/api/academy/classes");
      if (response.ok) {
        const data = await response.json();
        setClasses(data);
      }
    } catch (error) {
      console.error("Failed to fetch classes:", error);
    } finally {
      setLoading(false);
    }
  };

  const fetchMyRequests = async () => {
    try {
      const response = await fetch("/api/academy/my-requests");
      if (response.ok) {
        const data = await response.json();
        setMyRequests(data);
      }
    } catch (error) {
      console.error("Failed to fetch requests:", error);
    }
  };

  const fetchUserData = async () => {
    try {
      const response = await fetch("/api/users/me");
      if (response.ok) {
        const data = await response.json();
        setUserData(data);
      }
    } catch (error) {
      console.error("Failed to fetch user data:", error);
    }
  };

  const fetchAffiliateData = async () => {
    try {
      const response = await fetch("/api/affiliate/stats");
      if (response.ok) {
        const data = await response.json();
        setAffiliateData(data);
      }
    } catch (error) {
      setAffiliateData(null);
    }
  };

  const handleRequestJoin = (classData: AcademyClass) => {
    if (!isAuthenticated) {
      // Redirect to Google login
      window.location.href = "/api/auth/login";
      return;
    }
    
    setSelectedClass(classData);
    setShowRequestForm(true);
    // Scroll to form
    setTimeout(() => {
      const formElement = document.getElementById('request-form');
      if (formElement) {
        formElement.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }, 100);
  };

  const handleSubmitRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedClass) return;
    
    try {
      const response = await fetch(`/api/academy/classes/${selectedClass.id}/request`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(requestForm),
      });
      
      if (response.ok) {
        alert("Votre demande a été envoyée avec succès !");
        setShowRequestForm(false);
        setSelectedClass(null);
        fetchMyRequests();
        // Scroll back to top
        window.scrollTo({ top: 0, behavior: 'smooth' });
      } else {
        const error = await response.json();
        alert(error.error || "Erreur lors de l'envoi de la demande");
      }
    } catch (error) {
      console.error("Failed to submit request:", error);
      alert("Erreur lors de l'envoi de la demande");
    }
  };

  const getRequestStatus = (classId: number) => {
    return myRequests.find(r => r.class_id === classId);
  };

  const getStatusBadge = (status: string) => {
    const styles: Record<string, { bg: string; text: string; icon: any }> = {
      pending: { bg: "bg-yellow-500/20", text: "text-yellow-600", icon: Clock },
      approved: { bg: "bg-green-500/20", text: "text-green-600", icon: CheckCircle },
      rejected: { bg: "bg-red-500/20", text: "text-red-600", icon: AlertCircle },
    };
    
    const style = styles[status] || styles.pending;
    const Icon = style.icon;
    
    return (
      <span className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-sm font-medium ${style.bg} ${style.text}`}>
        <Icon className="w-4 h-4" />
        {status === 'pending' && 'En attente'}
        {status === 'approved' && 'Approuvé'}
        {status === 'rejected' && 'Rejeté'}
      </span>
    );
  };

  return (
    <div className="min-h-screen pb-20" style={{ fontFamily: "'Outfit', sans-serif", backgroundColor: 'var(--bg-primary)' }}>
      <SEOHead
        title="Academy - Classes et Formations"
        description="Rejoignez nos classes exclusives type Skool pour apprendre en communauté"
        url="https://martama.site/academy"
      />
      <Header />

      {/* Hero Section */}
      <section className="px-6 py-16 md:py-20">
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6" style={{ color: 'var(--text-primary)' }}>
            Martama Academy
          </h1>
          <p className="text-lg md:text-xl mb-8" style={{ color: 'var(--text-secondary)' }}>
            Rejoignez nos classes exclusives et apprenez en communauté 🎓
          </p>
        </div>
      </section>

      {/* Request Form Section */}
      {showRequestForm && selectedClass && (
        <section id="request-form" className="px-6 pb-12 max-w-3xl mx-auto">
          <div 
            className="rounded-3xl border p-8"
            style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}
          >
            <h2 className="text-2xl font-bold mb-2" style={{ color: 'var(--text-primary)' }}>
              Demander à rejoindre
            </h2>
            <p className="mb-6 text-lg" style={{ color: 'var(--text-secondary)' }}>
              Classe: <strong style={{ color: 'var(--primary)' }}>{selectedClass.name}</strong>
            </p>
            
            <form onSubmit={handleSubmitRequest} className="space-y-6">
              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                  Votre nom complet *
                </label>
                <input
                  type="text"
                  value={requestForm.user_name}
                  onChange={(e) => setRequestForm({ ...requestForm, user_name: e.target.value })}
                  required
                  placeholder="Ex: Jean Dupont"
                  className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2 text-lg"
                  style={{ 
                    backgroundColor: 'var(--bg-primary)', 
                    borderColor: 'var(--border-color)', 
                    color: 'var(--text-primary)',
                    '--tw-ring-color': 'var(--primary)'
                  } as any}
                />
                <p className="mt-2 text-sm" style={{ color: 'var(--text-muted)' }}>
                  C'est tout ce dont nous avons besoin ! Votre demande sera examinée par l'administrateur.
                </p>
              </div>
              
              <div className="flex gap-3 pt-4">
                <button
                  type="submit"
                  className="flex-1 px-6 py-4 rounded-xl text-lg font-semibold transition-all hover:shadow-lg text-white"
                  style={{ backgroundColor: 'var(--primary)' }}
                >
                  Envoyer la demande
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowRequestForm(false);
                    setSelectedClass(null);
                  }}
                  className="px-6 py-4 rounded-xl text-lg font-semibold transition-all border"
                  style={{ 
                    backgroundColor: 'transparent', 
                    color: 'var(--text-primary)',
                    borderColor: 'var(--border-color)'
                  }}
                >
                  Annuler
                </button>
              </div>
            </form>
          </div>
        </section>
      )}

      {/* Classes Grid */}
      <section className="px-6 pb-20 max-w-7xl mx-auto">
        {loading ? (
          <div className="text-center py-20">
            <Loader className="w-12 h-12 mx-auto animate-spin" style={{ color: 'var(--primary)' }} />
          </div>
        ) : classes.length === 0 ? (
          <div className="text-center py-20">
            <Users className="w-16 h-16 mx-auto mb-4 opacity-30" style={{ color: 'var(--text-muted)' }} />
            <p className="text-xl" style={{ color: 'var(--text-muted)' }}>
              Aucune classe disponible pour le moment
            </p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {classes.map((classData) => {
              const request = getRequestStatus(classData.id);
              const isFull = classData.max_members && classData.current_members >= classData.max_members;
              
              return (
                <div
                  key={classData.id}
                  className="rounded-2xl border overflow-hidden transition-all hover:shadow-xl"
                  style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}
                >
                  {classData.image_url ? (
                    <div className="aspect-video w-full overflow-hidden" style={{ background: 'linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%)' }}>
                      <img
                        src={classData.image_url}
                        alt={classData.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  ) : (
                    <div 
                      className="aspect-video w-full flex items-center justify-center"
                      style={{ background: 'linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%)' }}
                    >
                      <Users className="w-16 h-16 text-white opacity-50" />
                    </div>
                  )}
                  
                  <div className="p-6">
                    <div className="flex items-start justify-between mb-3">
                      <h3 className="text-xl font-bold" style={{ color: 'var(--text-primary)' }}>
                        {classData.name}
                      </h3>
                      {isFull && (
                        <span className="px-2 py-1 bg-red-500/20 text-red-600 text-xs font-medium rounded-full whitespace-nowrap">
                          Complet
                        </span>
                      )}
                    </div>
                    
                    {classData.description && (
                      <p className="text-sm mb-4 line-clamp-2" style={{ color: 'var(--text-secondary)' }}>
                        {classData.description}
                      </p>
                    )}
                    
                    <div className="space-y-2 mb-4 text-sm">
                      {classData.instructor_name && (
                        <div className="flex items-center gap-2" style={{ color: 'var(--text-muted)' }}>
                          <Users className="w-4 h-4" />
                          <span>Instructeur: {classData.instructor_name}</span>
                        </div>
                      )}
                      
                      {classData.start_date && (
                        <div className="flex items-center gap-2" style={{ color: 'var(--text-muted)' }}>
                          <Calendar className="w-4 h-4" />
                          <span>Début: {new Date(classData.start_date).toLocaleDateString('fr-FR')}</span>
                        </div>
                      )}
                      
                      {classData.max_members && (
                        <div className="flex items-center gap-2" style={{ color: 'var(--text-muted)' }}>
                          <Users className="w-4 h-4" />
                          <span>{classData.current_members} / {classData.max_members} membres</span>
                        </div>
                      )}
                    </div>
                    
                    {request ? (
                      <div className="mt-4">
                        {request.status === 'approved' ? (
                          <button
                            onClick={() => navigate(`/academy/class/${classData.id}`)}
                            className="w-full px-6 py-3 rounded-xl font-semibold transition-all hover:opacity-90"
                            style={{ 
                              backgroundColor: 'var(--primary)', 
                              color: '#ffffff'
                            }}
                          >
                            Accéder à la classe
                          </button>
                        ) : (
                          getStatusBadge(request.status)
                        )}
                      </div>
                    ) : (
                      <button
                        onClick={() => handleRequestJoin(classData)}
                        disabled={!!isFull}
                        className={`w-full px-6 py-3 rounded-xl font-semibold transition-all ${
                          isFull ? 'opacity-50 cursor-not-allowed' : 'hover:opacity-90'
                        }`}
                        style={{ 
                          backgroundColor: 'var(--primary)', 
                          color: '#ffffff'
                        }}
                      >
                        {isFull ? 'Classe complète' : 'Demander à rejoindre'}
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>

      <Footer />
      
      <BottomNav 
        userRole={userData?.role} 
        isAffiliate={!!affiliateData}
        affiliateCode={affiliateData?.promo_code}
      />
    </div>
  );
}
