import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router";
import { ArrowLeft, Play, Lock, Clock, CheckCircle, ExternalLink, MessageCircle, Send, Edit3, Trash2 } from "lucide-react";
import { useAuth } from "@getmocha/users-service/react";

interface Module {
  id: number;
  class_id: number;
  title: string;
  description: string | null;
  display_order: number;
}

interface Resource {
  title: string;
  url: string;
  type?: string;
}

interface Video {
  id: number;
  module_id: number;
  class_id: number;
  title: string;
  video_type: string;
  video_url: string;
  aspect_ratio: string;
  duration_minutes: number | null;
  display_order: number;
  resources?: string | null;
}

interface Comment {
  id: number;
  video_id: number;
  user_email: string;
  user_name: string | null;
  comment: string;
  parent_comment_id: number | null;
  created_at: string;
  updated_at: string;
}

export default function AcademyClassViewer() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [modules, setModules] = useState<Module[]>([]);
  const [videos, setVideos] = useState<{ [moduleId: number]: Video[] }>({});
  const [currentVideo, setCurrentVideo] = useState<Video | null>(null);
  const [loading, setLoading] = useState(true);
  const [hasAccess, setHasAccess] = useState(false);
  const [comments, setComments] = useState<Comment[]>([]);
  const [newComment, setNewComment] = useState("");
  const [replyTo, setReplyTo] = useState<number | null>(null);
  const [editingComment, setEditingComment] = useState<number | null>(null);
  const [editCommentText, setEditCommentText] = useState("");
  const [loadingComments, setLoadingComments] = useState(false);

  useEffect(() => {
    const loadFont = () => {
      const link = document.createElement("link");
      link.href = "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap";
      link.rel = "stylesheet";
      document.head.appendChild(link);
    };
    loadFont();
  }, []);

  useEffect(() => {
    checkAccess();
  }, [id]);

  useEffect(() => {
    if (hasAccess) {
      fetchModules();
    }
  }, [hasAccess]);

  useEffect(() => {
    if (currentVideo) {
      fetchComments();
    }
  }, [currentVideo]);

  useEffect(() => {
    // Anti-abuse protections
    const handleContextMenu = (e: MouseEvent) => {
      e.preventDefault();
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      // Disable view source (Ctrl+U)
      if (e.ctrlKey && e.key === 'u') {
        e.preventDefault();
        return false;
      }
      // Disable save (Ctrl+S)
      if (e.ctrlKey && e.key === 's') {
        e.preventDefault();
        return false;
      }
      // Disable dev tools (Ctrl+Shift+I/J/C)
      if (e.ctrlKey && e.shiftKey && (e.key === 'I' || e.key === 'J' || e.key === 'C')) {
        e.preventDefault();
        return false;
      }
      // Disable F12
      if (e.key === 'F12') {
        e.preventDefault();
        return false;
      }
    };

    document.addEventListener('contextmenu', handleContextMenu);
    document.addEventListener('keydown', handleKeyDown);

    return () => {
      document.removeEventListener('contextmenu', handleContextMenu);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, []);

  const checkAccess = async () => {
    try {
      const response = await fetch(`/api/academy/classes/${id}/access`);
      if (response.ok) {
        const data = await response.json();
        setHasAccess(data.hasAccess);
      }
    } catch (error) {
      console.error("Failed to check access:", error);
      navigate("/academy");
    }
  };

  const fetchModules = async () => {
    try {
      setLoading(true);
      const response = await fetch(`/api/academy/classes/${id}/modules`);
      if (response.ok) {
        const modulesData = await response.json();
        setModules(modulesData);
        
        // Fetch videos for each module
        for (const module of modulesData) {
          fetchModuleVideos(module.id);
        }
      }
    } catch (error) {
      console.error("Failed to fetch modules:", error);
    } finally {
      setLoading(false);
    }
  };

  const fetchModuleVideos = async (moduleId: number) => {
    try {
      const response = await fetch(`/api/academy/modules/${moduleId}/videos`);
      if (response.ok) {
        const videosData = await response.json();
        setVideos(prev => {
          const newVideos = {
            ...prev,
            [moduleId]: videosData
          };
          
          // Set first video as current if none selected
          if (!currentVideo && videosData.length > 0) {
            setCurrentVideo(videosData[0]);
          }
          
          return newVideos;
        });
      }
    } catch (error) {
      console.error("Failed to fetch videos:", error);
    }
  };

  const getEmbedUrl = (url: string, type: string): string => {
    if (type === 'youtube') {
      const videoId = url.match(/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/)?.[1];
      return videoId ? `https://www.youtube.com/embed/${videoId}` : '';
    } else if (type === 'vimeo') {
      const videoId = url.match(/vimeo\.com\/(?:video\/)?(\d+)/)?.[1];
      return videoId ? `https://player.vimeo.com/video/${videoId}` : '';
    } else if (type === 'googledrive') {
      // URL is already in /preview format from conversion
      return url;
    }
    return url;
  };

  const getAspectRatioStyle = (ratio: string): React.CSSProperties => {
    const ratios: { [key: string]: string } = {
      '16:9': '56.25%',
      '9:16': '177.78%',
      '1:1': '100%',
      '4:3': '75%',
      '3:2': '66.67%',
      '2:3': '150%',
    };
    return {
      paddingBottom: ratios[ratio] || '56.25%',
    };
  };

  const fetchComments = async () => {
    if (!currentVideo) return;
    
    try {
      setLoadingComments(true);
      const response = await fetch(`/api/academy/videos/${currentVideo.id}/comments`);
      if (response.ok) {
        const data = await response.json();
        setComments(data);
      }
    } catch (error) {
      console.error("Failed to fetch comments:", error);
    } finally {
      setLoadingComments(false);
    }
  };

  const handlePostComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim() || !currentVideo) return;

    try {
      const response = await fetch(`/api/academy/videos/${currentVideo.id}/comments`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          comment: newComment.trim(),
          parent_comment_id: replyTo
        })
      });

      if (response.ok) {
        setNewComment("");
        setReplyTo(null);
        await fetchComments();
      }
    } catch (error) {
      console.error("Failed to post comment:", error);
    }
  };

  const handleEditComment = async (commentId: number) => {
    if (!editCommentText.trim()) return;

    try {
      const response = await fetch(`/api/academy/comments/${commentId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ comment: editCommentText.trim() })
      });

      if (response.ok) {
        setEditingComment(null);
        setEditCommentText("");
        await fetchComments();
      }
    } catch (error) {
      console.error("Failed to edit comment:", error);
    }
  };

  const handleDeleteComment = async (commentId: number) => {
    if (!confirm("Supprimer ce commentaire ?")) return;

    try {
      const response = await fetch(`/api/academy/comments/${commentId}`, {
        method: "DELETE"
      });

      if (response.ok) {
        await fetchComments();
      }
    } catch (error) {
      console.error("Failed to delete comment:", error);
    }
  };

  const renderVideoPlayer = () => {
    if (!currentVideo) return null;

    return (
      <div className="space-y-6">
        <div className="rounded-2xl overflow-hidden border" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
          <div className="relative w-full overflow-hidden bg-black" style={getAspectRatioStyle(currentVideo.aspect_ratio)}>
            <iframe
              src={getEmbedUrl(currentVideo.video_url, currentVideo.video_type)}
              className="absolute top-0 left-0 w-full h-full"
              sandbox="allow-scripts allow-same-origin allow-presentation"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          </div>
          <div className="p-6">
            <h2 className="text-2xl font-bold mb-2" style={{ color: 'var(--text-primary)' }}>
              {currentVideo.title}
            </h2>
            {currentVideo.duration_minutes && (
              <div className="flex items-center gap-2 text-sm mb-4" style={{ color: 'var(--text-muted)' }}>
                <Clock className="w-4 h-4" />
                <span>{currentVideo.duration_minutes} minutes</span>
              </div>
            )}
            
            {/* Resources Links */}
            {currentVideo.resources && (() => {
              try {
                const resources: Resource[] = JSON.parse(currentVideo.resources);
                if (resources && resources.length > 0) {
                  return (
                    <div className="mt-6 pt-6 border-t" style={{ borderColor: 'var(--border-color)' }}>
                      <h3 className="text-base font-semibold mb-3 flex items-center gap-2" style={{ color: 'var(--text-primary)' }}>
                        🔗 Liens et Ressources
                      </h3>
                      <div className="space-y-2">
                        {resources.map((resource, index) => (
                          <a
                            key={index}
                            href={resource.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center gap-3 p-3 rounded-xl border transition-all hover:scale-[1.02]"
                            style={{ 
                              backgroundColor: 'var(--bg-primary)', 
                              borderColor: 'var(--border-color)',
                            }}
                          >
                            <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0" 
                                 style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)' }}>
                              <ExternalLink className="w-5 h-5" style={{ color: 'var(--primary)' }} />
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="font-medium" style={{ color: 'var(--text-primary)' }}>
                                {resource.title}
                              </p>
                              <p className="text-sm truncate font-mono" style={{ color: 'var(--text-muted)' }}>
                                {resource.url}
                              </p>
                            </div>
                            <ExternalLink className="w-4 h-4 flex-shrink-0" style={{ color: 'var(--text-muted)' }} />
                          </a>
                        ))}
                      </div>
                    </div>
                  );
                }
              } catch (e) {
                return null;
              }
              return null;
            })()}
          </div>
        </div>

        {/* Comments Section */}
        <div className="rounded-2xl border p-6" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
          <h3 className="text-xl font-bold mb-6 flex items-center gap-2" style={{ color: 'var(--text-primary)' }}>
            <MessageCircle className="w-6 h-6" />
            Discussion ({comments.length})
          </h3>

          {/* Comment Form */}
          <form onSubmit={handlePostComment} className="mb-6">
            <div className="flex gap-3">
              <div className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 font-semibold text-white"
                   style={{ backgroundColor: 'var(--primary)' }}>
                {user?.email?.charAt(0).toUpperCase()}
              </div>
              <div className="flex-1">
                {replyTo && (
                  <div className="mb-2 flex items-center gap-2 text-sm" style={{ color: 'var(--text-muted)' }}>
                    <span>Répondre à {comments.find(c => c.id === replyTo)?.user_name || 'un commentaire'}</span>
                    <button
                      type="button"
                      onClick={() => setReplyTo(null)}
                      className="text-xs px-2 py-0.5 rounded"
                      style={{ backgroundColor: 'var(--error)', color: '#fff' }}
                    >
                      Annuler
                    </button>
                  </div>
                )}
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    placeholder={replyTo ? "Écrivez votre réponse..." : "Ajoutez un commentaire..."}
                    className="flex-1 px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                    style={{ 
                      backgroundColor: 'var(--bg-primary)', 
                      borderColor: 'var(--border-color)', 
                      color: 'var(--text-primary)',
                      '--tw-ring-color': 'var(--primary)'
                    } as any}
                  />
                  <button
                    type="submit"
                    disabled={!newComment.trim()}
                    className="px-6 py-3 rounded-xl font-semibold text-white transition-opacity disabled:opacity-50"
                    style={{ backgroundColor: 'var(--primary)' }}
                  >
                    <Send className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>
          </form>

          {/* Comments List */}
          {loadingComments ? (
            <div className="text-center py-8">
              <div className="inline-block w-8 h-8 border-4 rounded-full animate-spin" style={{ borderColor: 'var(--gray-200)', borderTopColor: 'var(--primary)' }}></div>
            </div>
          ) : comments.length === 0 ? (
            <div className="text-center py-12">
              <MessageCircle className="w-12 h-12 mx-auto mb-3 opacity-30" style={{ color: 'var(--text-muted)' }} />
              <p style={{ color: 'var(--text-muted)' }}>Aucun commentaire pour le moment</p>
            </div>
          ) : (
            <div className="space-y-4">
              {comments.filter(c => !c.parent_comment_id).map((comment) => {
                const replies = comments.filter(c => c.parent_comment_id === comment.id);
                const isEditing = editingComment === comment.id;
                const canEdit = user?.email === comment.user_email;

                return (
                  <div key={comment.id} className="border-b pb-4 last:border-b-0" style={{ borderColor: 'var(--border-color)' }}>
                    <div className="flex gap-3">
                      <div className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 font-semibold text-white"
                           style={{ backgroundColor: 'var(--success)' }}>
                        {comment.user_name?.charAt(0).toUpperCase() || comment.user_email.charAt(0).toUpperCase()}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-1">
                          <div>
                            <span className="font-semibold" style={{ color: 'var(--text-primary)' }}>
                              {comment.user_name || comment.user_email}
                            </span>
                            <span className="text-xs ml-2" style={{ color: 'var(--text-muted)' }}>
                              {new Date(comment.created_at).toLocaleString('fr-FR')}
                            </span>
                          </div>
                          {canEdit && (
                            <div className="flex gap-1">
                              <button
                                onClick={() => {
                                  setEditingComment(comment.id);
                                  setEditCommentText(comment.comment);
                                }}
                                className="p-1.5 rounded hover:opacity-80"
                                style={{ backgroundColor: 'var(--bg-primary)' }}
                              >
                                <Edit3 className="w-3.5 h-3.5" style={{ color: 'var(--info)' }} />
                              </button>
                              <button
                                onClick={() => handleDeleteComment(comment.id)}
                                className="p-1.5 rounded hover:opacity-80"
                                style={{ backgroundColor: 'rgba(239, 68, 68, 0.1)' }}
                              >
                                <Trash2 className="w-3.5 h-3.5" style={{ color: 'var(--error)' }} />
                              </button>
                            </div>
                          )}
                        </div>
                        
                        {isEditing ? (
                          <div className="flex gap-2 mt-2">
                            <input
                              type="text"
                              value={editCommentText}
                              onChange={(e) => setEditCommentText(e.target.value)}
                              className="flex-1 px-3 py-2 border rounded-lg focus:outline-none text-sm"
                              style={{ 
                                backgroundColor: 'var(--bg-primary)', 
                                borderColor: 'var(--border-color)', 
                                color: 'var(--text-primary)'
                              }}
                            />
                            <button
                              onClick={() => handleEditComment(comment.id)}
                              className="px-4 py-2 rounded-lg font-medium text-sm text-white"
                              style={{ backgroundColor: 'var(--success)' }}
                            >
                              Sauvegarder
                            </button>
                            <button
                              onClick={() => {
                                setEditingComment(null);
                                setEditCommentText("");
                              }}
                              className="px-4 py-2 rounded-lg font-medium text-sm"
                              style={{ backgroundColor: 'var(--bg-primary)', color: 'var(--text-primary)' }}
                            >
                              Annuler
                            </button>
                          </div>
                        ) : (
                          <>
                            <p className="text-sm mb-2" style={{ color: 'var(--text-secondary)' }}>
                              {comment.comment}
                            </p>
                            <button
                              onClick={() => setReplyTo(comment.id)}
                              className="text-xs font-medium px-3 py-1 rounded-lg transition-colors"
                              style={{ backgroundColor: 'var(--bg-primary)', color: 'var(--primary)' }}
                            >
                              Répondre
                            </button>
                          </>
                        )}

                        {/* Replies */}
                        {replies.length > 0 && (
                          <div className="mt-4 space-y-3 pl-4 border-l-2" style={{ borderColor: 'var(--border-color)' }}>
                            {replies.map((reply) => {
                              const isEditingReply = editingComment === reply.id;
                              const canEditReply = user?.email === reply.user_email;

                              return (
                                <div key={reply.id} className="flex gap-3">
                                  <div className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 text-sm font-semibold text-white"
                                       style={{ backgroundColor: 'var(--info)' }}>
                                    {reply.user_name?.charAt(0).toUpperCase() || reply.user_email.charAt(0).toUpperCase()}
                                  </div>
                                  <div className="flex-1 min-w-0">
                                    <div className="flex items-center justify-between mb-1">
                                      <div>
                                        <span className="font-semibold text-sm" style={{ color: 'var(--text-primary)' }}>
                                          {reply.user_name || reply.user_email}
                                        </span>
                                        <span className="text-xs ml-2" style={{ color: 'var(--text-muted)' }}>
                                          {new Date(reply.created_at).toLocaleString('fr-FR')}
                                        </span>
                                      </div>
                                      {canEditReply && (
                                        <div className="flex gap-1">
                                          <button
                                            onClick={() => {
                                              setEditingComment(reply.id);
                                              setEditCommentText(reply.comment);
                                            }}
                                            className="p-1 rounded hover:opacity-80"
                                            style={{ backgroundColor: 'var(--bg-primary)' }}
                                          >
                                            <Edit3 className="w-3 h-3" style={{ color: 'var(--info)' }} />
                                          </button>
                                          <button
                                            onClick={() => handleDeleteComment(reply.id)}
                                            className="p-1 rounded hover:opacity-80"
                                            style={{ backgroundColor: 'rgba(239, 68, 68, 0.1)' }}
                                          >
                                            <Trash2 className="w-3 h-3" style={{ color: 'var(--error)' }} />
                                          </button>
                                        </div>
                                      )}
                                    </div>
                                    
                                    {isEditingReply ? (
                                      <div className="flex gap-2 mt-2">
                                        <input
                                          type="text"
                                          value={editCommentText}
                                          onChange={(e) => setEditCommentText(e.target.value)}
                                          className="flex-1 px-3 py-1.5 border rounded-lg focus:outline-none text-sm"
                                          style={{ 
                                            backgroundColor: 'var(--bg-primary)', 
                                            borderColor: 'var(--border-color)', 
                                            color: 'var(--text-primary)'
                                          }}
                                        />
                                        <button
                                          onClick={() => handleEditComment(reply.id)}
                                          className="px-3 py-1.5 rounded-lg font-medium text-xs text-white"
                                          style={{ backgroundColor: 'var(--success)' }}
                                        >
                                          OK
                                        </button>
                                        <button
                                          onClick={() => {
                                            setEditingComment(null);
                                            setEditCommentText("");
                                          }}
                                          className="px-3 py-1.5 rounded-lg font-medium text-xs"
                                          style={{ backgroundColor: 'var(--bg-primary)', color: 'var(--text-primary)' }}
                                        >
                                          ×
                                        </button>
                                      </div>
                                    ) : (
                                      <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
                                        {reply.comment}
                                      </p>
                                    )}
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    );
  };

  if (!hasAccess) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ fontFamily: "'Outfit', sans-serif", backgroundColor: 'var(--bg-primary)' }}>
        <div className="text-center max-w-md mx-auto px-6">
          <Lock className="w-16 h-16 mx-auto mb-4" style={{ color: 'var(--text-muted)' }} />
          <h2 className="text-2xl font-bold mb-4" style={{ color: 'var(--text-primary)' }}>
            Accès Refusé
          </h2>
          <p className="mb-6" style={{ color: 'var(--text-secondary)' }}>
            Vous n'avez pas accès à cette classe. Veuillez d'abord soumettre une demande et attendre l'approbation.
          </p>
          <button
            onClick={() => navigate("/academy")}
            className="px-6 py-3 rounded-xl font-semibold text-white"
            style={{ backgroundColor: 'var(--primary)' }}
          >
            Retour à l'Academy
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen select-none" style={{ fontFamily: "'Outfit', sans-serif", backgroundColor: 'var(--bg-primary)', userSelect: 'none' }}>
      {/* Header */}
      <header className="sticky top-0 z-10 px-6 py-4 border-b" style={{ backgroundColor: 'var(--bg-primary)', borderColor: 'var(--border-color)' }}>
        <div className="max-w-7xl mx-auto flex items-center gap-4">
          <button
            onClick={() => navigate("/academy")}
            className="p-2 hover:opacity-80 rounded-xl transition-opacity"
            style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)' }}
          >
            <ArrowLeft className="w-6 h-6" style={{ color: 'var(--primary)' }} />
          </button>
          <div className="flex-1">
            <h1 className="text-xl font-bold" style={{ color: 'var(--text-primary)' }}>
              {currentVideo?.title || "Classe"}
            </h1>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Video Player */}
          <div className="lg:col-span-2">
            {loading ? (
              <div className="aspect-video rounded-2xl flex items-center justify-center" style={{ backgroundColor: 'var(--bg-secondary)' }}>
                <div className="w-12 h-12 border-4 rounded-full animate-spin" style={{ borderColor: 'var(--gray-200)', borderTopColor: 'var(--primary)' }}></div>
              </div>
            ) : currentVideo ? (
              renderVideoPlayer()
            ) : (
              <div className="aspect-video rounded-2xl flex flex-col items-center justify-center border gap-4 p-8" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
                <Play className="w-16 h-16 opacity-30" style={{ color: 'var(--text-muted)' }} />
                <p className="text-xl font-semibold" style={{ color: 'var(--text-primary)' }}>Aucune vidéo disponible</p>
                <p className="text-sm text-center" style={{ color: 'var(--text-muted)' }}>
                  Cette classe n'a pas encore de contenu vidéo. Veuillez contacter l'instructeur.
                </p>
              </div>
            )}
          </div>

          {/* Modules & Videos List */}
          <div className="lg:col-span-1">
            <div className="rounded-2xl border p-4" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-bold mb-4 px-2" style={{ color: 'var(--text-primary)' }}>
                Contenu de la classe
              </h3>
              
              <div className="space-y-4">
                {modules.map((module) => (
                  <div key={module.id} className="border-b pb-4 last:border-b-0" style={{ borderColor: 'var(--border-color)' }}>
                    <h4 className="font-semibold mb-2 px-2" style={{ color: 'var(--text-primary)' }}>
                      {module.title}
                    </h4>
                    
                    <div className="space-y-1">
                      {videos[module.id]?.map((video) => (
                        <button
                          key={video.id}
                          onClick={() => setCurrentVideo(video)}
                          className={`w-full text-left px-3 py-2 rounded-xl transition-all flex items-center gap-3 ${
                            currentVideo?.id === video.id ? 'shadow-md' : 'hover:opacity-80'
                          }`}
                          style={{
                            backgroundColor: currentVideo?.id === video.id ? 'var(--primary)' : 'transparent',
                            color: currentVideo?.id === video.id ? '#ffffff' : 'var(--text-secondary)'
                          }}
                        >
                          {currentVideo?.id === video.id ? (
                            <CheckCircle className="w-4 h-4 flex-shrink-0" />
                          ) : (
                            <Play className="w-4 h-4 flex-shrink-0" />
                          )}
                          <span className="flex-1 text-sm">{video.title}</span>
                          {video.duration_minutes && (
                            <span className="text-xs opacity-75">{video.duration_minutes}min</span>
                          )}
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      <style>{`
        * {
          user-select: none;
          -webkit-user-select: none;
          -moz-user-select: none;
          -ms-user-select: none;
        }
      `}</style>
    </div>
  );
}
