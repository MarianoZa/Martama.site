import { useEffect } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "@getmocha/users-service/react";
import Header from "@/react-app/components/Header";
import { ArrowRight, BookOpen, Users, TrendingUp } from "lucide-react";

export default function Home() {
  const navigate = useNavigate();
  const { user, redirectToLogin } = useAuth();

  useEffect(() => {
    const loadFont = () => {
      const link = document.createElement("link");
      link.href = "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap";
      link.rel = "stylesheet";
      document.head.appendChild(link);
    };
    loadFont();
  }, []);

  const handleGetStarted = () => {
    if (user) {
      navigate("/catalog");
    } else {
      redirectToLogin();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-indigo-900" style={{ fontFamily: "'Outfit', sans-serif" }}>
      <Header />

      {/* Hero Section */}
      <section className="px-6 py-20 max-w-7xl mx-auto">
        <div className="text-center max-w-4xl mx-auto">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 backdrop-blur-sm rounded-full mb-8 border border-white/20">
            <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></span>
            <span className="text-white/90 text-sm font-medium">Plateforme d'apprentissage pour l'Afrique</span>
          </div>
          
          <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 leading-tight">
            Transformez votre
            <span className="block bg-gradient-to-r from-purple-300 via-pink-300 to-purple-300 bg-clip-text text-transparent mt-2">
              Avenir Professionnel
            </span>
          </h1>
          
          <p className="text-xl md:text-2xl text-purple-100 mb-12 leading-relaxed">
            Accédez à des formations premium, des abonnements exclusifs et rejoignez
            un réseau d'affiliés pour monétiser votre influence.
          </p>
          
          <button
            onClick={handleGetStarted}
            className="group inline-flex items-center gap-3 px-8 py-4 bg-white text-purple-900 hover:bg-purple-50 rounded-2xl text-lg font-bold shadow-2xl hover:shadow-purple-500/50 transition-all duration-300 hover:scale-105"
          >
            Commencer maintenant
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        {/* Feature Cards */}
        <div className="grid md:grid-cols-3 gap-6 mt-24">
          <div className="group p-8 bg-white/5 backdrop-blur-md rounded-3xl border border-white/10 hover:bg-white/10 transition-all duration-300 hover:scale-105">
            <div className="w-14 h-14 bg-gradient-to-br from-purple-400 to-pink-500 rounded-2xl flex items-center justify-center mb-6 shadow-lg group-hover:shadow-purple-500/50 transition-shadow">
              <BookOpen className="w-7 h-7 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-white mb-3">Formations Premium</h3>
            <p className="text-purple-200 leading-relaxed">
              Des cours de qualité adaptés aux réalités africaines, créés par des experts reconnus.
            </p>
          </div>

          <div className="group p-8 bg-white/5 backdrop-blur-md rounded-3xl border border-white/10 hover:bg-white/10 transition-all duration-300 hover:scale-105">
            <div className="w-14 h-14 bg-gradient-to-br from-purple-400 to-pink-500 rounded-2xl flex items-center justify-center mb-6 shadow-lg group-hover:shadow-purple-500/50 transition-shadow">
              <Users className="w-7 h-7 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-white mb-3">Programme d'Affiliation</h3>
            <p className="text-purple-200 leading-relaxed">
              Gagnez des commissions en recommandant nos produits à votre réseau.
            </p>
          </div>

          <div className="group p-8 bg-white/5 backdrop-blur-md rounded-3xl border border-white/10 hover:bg-white/10 transition-all duration-300 hover:scale-105">
            <div className="w-14 h-14 bg-gradient-to-br from-purple-400 to-pink-500 rounded-2xl flex items-center justify-center mb-6 shadow-lg group-hover:shadow-purple-500/50 transition-shadow">
              <TrendingUp className="w-7 h-7 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-white mb-3">Paiement Local</h3>
            <p className="text-purple-200 leading-relaxed">
              Mobile Money, Wave, Orange Money - payez comme vous voulez.
            </p>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="px-6 py-16 max-w-7xl mx-auto">
        <div className="grid md:grid-cols-4 gap-8">
          <div className="text-center">
            <div className="text-5xl font-bold text-white mb-2">500+</div>
            <div className="text-purple-200">Étudiants Actifs</div>
          </div>
          <div className="text-center">
            <div className="text-5xl font-bold text-white mb-2">50+</div>
            <div className="text-purple-200">Formations</div>
          </div>
          <div className="text-center">
            <div className="text-5xl font-bold text-white mb-2">100+</div>
            <div className="text-purple-200">Affiliés</div>
          </div>
          <div className="text-center">
            <div className="text-5xl font-bold text-white mb-2">98%</div>
            <div className="text-purple-200">Satisfaction</div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="px-6 py-8 mt-20 border-t border-white/10">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-purple-200">© 2025 Martama. Tous droits réservés.</p>
        </div>
      </footer>
    </div>
  );
}
