import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router";
import Header from "@/react-app/components/Header";
import { Check, Tag } from "lucide-react";
import type { Product } from "@/shared/types";

export default function ProductDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadFont = () => {
      const link = document.createElement("link");
      link.href = "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap";
      link.rel = "stylesheet";
      document.head.appendChild(link);
    };
    loadFont();
  }, []);

  useEffect(() => {
    fetchProduct();
  }, [id]);

  const fetchProduct = async () => {
    try {
      setLoading(true);
      const response = await fetch(`/api/products/${id}`);
      const data = await response.json();
      setProduct(data);
    } catch (error) {
      console.error("Failed to fetch product:", error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-indigo-900 flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-white/20 border-t-white rounded-full animate-spin"></div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-indigo-900 flex items-center justify-center">
        <div className="text-center">
          <p className="text-white text-xl mb-4">Produit introuvable</p>
          <button
            onClick={() => navigate("/catalog")}
            className="px-6 py-3 bg-white text-purple-900 rounded-xl font-semibold"
          >
            Retour au catalogue
          </button>
        </div>
      </div>
    );
  }

  const features = product.features ? JSON.parse(product.features) : [];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-indigo-900" style={{ fontFamily: "'Outfit', sans-serif" }}>
      <Header showBackButton onBack={() => navigate("/catalog")} />

      {/* Content */}
      <main className="px-6 py-12 max-w-5xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-12">
          {/* Left Column - Image */}
          <div>
            {product.image_url ? (
              <div className="aspect-square rounded-3xl overflow-hidden bg-gradient-to-br from-purple-600 to-pink-600 shadow-2xl">
                <img
                  src={product.image_url}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
              </div>
            ) : (
              <div className="aspect-square rounded-3xl bg-gradient-to-br from-purple-600 to-pink-600 shadow-2xl flex items-center justify-center">
                <Tag className="w-24 h-24 text-white/30" />
              </div>
            )}
          </div>

          {/* Right Column - Details */}
          <div>
            <div className="inline-block px-4 py-1.5 bg-white/10 backdrop-blur-sm rounded-full mb-4 border border-white/20">
              <span className="text-sm font-medium text-white capitalize">{product.category}</span>
            </div>
            
            <h1 className="text-4xl font-bold text-white mb-4">{product.name}</h1>
            
            <p className="text-lg text-purple-200 mb-8 leading-relaxed">
              {product.description}
            </p>

            {/* Pricing */}
            <div className="bg-white/5 backdrop-blur-md rounded-2xl p-6 border border-white/10 mb-8">
              <h3 className="text-sm font-semibold text-purple-300 mb-4 uppercase tracking-wide">
                Tarifs
              </h3>
              <div className="space-y-3">
                {product.price_1_months && (
                  <div className="flex justify-between items-center">
                    <span className="text-white">1 mois</span>
                    <span className="text-2xl font-bold text-white">
                      {product.price_1_months.toLocaleString()} FCFA
                    </span>
                  </div>
                )}
                {product.price_3_months && (
                  <div className="flex justify-between items-center">
                    <span className="text-white">3 mois</span>
                    <span className="text-2xl font-bold text-white">
                      {product.price_3_months.toLocaleString()} FCFA
                    </span>
                  </div>
                )}
                {product.price_6_months && (
                  <div className="flex justify-between items-center">
                    <span className="text-white">6 mois</span>
                    <span className="text-2xl font-bold text-white">
                      {product.price_6_months.toLocaleString()} FCFA
                    </span>
                  </div>
                )}
              </div>
            </div>

            {/* Features */}
            {features.length > 0 && (
              <div className="mb-8">
                <h3 className="text-sm font-semibold text-purple-300 mb-4 uppercase tracking-wide">
                  Inclus
                </h3>
                <div className="space-y-3">
                  {features.map((feature: string, index: number) => (
                    <div key={index} className="flex items-start gap-3">
                      <div className="w-5 h-5 bg-green-500 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                        <Check className="w-3 h-3 text-white" />
                      </div>
                      <span className="text-purple-100">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* CTA */}
            <button className="w-full py-4 bg-white text-purple-900 rounded-2xl font-bold text-lg hover:bg-purple-50 transition-all duration-300 shadow-2xl hover:shadow-purple-500/50 hover:scale-105">
              Commander maintenant
            </button>
          </div>
        </div>
      </main>
    </div>
  );
}
