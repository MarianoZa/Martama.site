import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router";
import { useAuth } from "@getmocha/users-service/react";
import Header from "@/react-app/components/Header";
import { BookOpen, Play, ChevronDown, ChevronRight, ExternalLink } from "lucide-react";

interface Module {
  id: number;
  title: string;
  description: string | null;
  order_position: number;
}

interface Resource {
  title: string;
  url: string;
  type?: string;
}

interface Video {
  id: number;
  module_id: number;
  title: string;
  description: string | null;
  video_url: string;
  video_type: string;
  aspect_ratio: string;
  duration_seconds: number | null;
  order_position: number;
  resources?: string | null;
}

interface Formation {
  id: number;
  name: string;
  description: string;
  image_url: string | null;
}

export default function FormationViewer() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [formation, setFormation] = useState<Formation | null>(null);
  const [modules, setModules] = useState<Module[]>([]);
  const [videos, setVideos] = useState<{ [moduleId: number]: Video[] }>({});
  const [currentVideo, setCurrentVideo] = useState<Video | null>(null);
  const [expandedModules, setExpandedModules] = useState<Set<number>>(new Set());
  const [loading, setLoading] = useState(true);
  const [hasAccess, setHasAccess] = useState(false);

  useEffect(() => {
    const loadFont = () => {
      const link = document.createElement("link");
      link.href = "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap";
      link.rel = "stylesheet";
      document.head.appendChild(link);
    };
    loadFont();
  }, []);

  useEffect(() => {
    if (user && id) {
      checkAccess();
      fetchFormation();
    }
  }, [user, id]);

  const checkAccess = async () => {
    try {
      const response = await fetch(`/api/formations/${id}/access?email=${encodeURIComponent(user?.email || '')}`);
      if (response.ok) {
        const data = await response.json();
        setHasAccess(data.hasAccess);
        if (!data.hasAccess) {
          navigate("/dashboard");
        }
      } else {
        navigate("/dashboard");
      }
    } catch (error) {
      console.error("Failed to check access:", error);
      navigate("/dashboard");
    }
  };

  const fetchFormation = async () => {
    try {
      setLoading(true);
      
      // Fetch formation details
      const formationResponse = await fetch(`/api/products/${id}`);
      if (formationResponse.ok) {
        const formationData = await formationResponse.json();
        setFormation(formationData);
      }

      // Fetch modules
      const modulesResponse = await fetch(`/api/formations/${id}/modules`);
      if (modulesResponse.ok) {
        const modulesData = await modulesResponse.json();
        setModules(modulesData);

        // Fetch videos for each module
        const videosMap: { [moduleId: number]: Video[] } = {};
        for (const module of modulesData) {
          const videosResponse = await fetch(`/api/formations/modules/${module.id}/videos`);
          if (videosResponse.ok) {
            const videosData = await videosResponse.json();
            videosMap[module.id] = videosData;
          }
        }
        setVideos(videosMap);

        // Auto-select first video if available
        if (modulesData.length > 0) {
          const firstModule = modulesData[0];
          if (videosMap[firstModule.id]?.length > 0) {
            setCurrentVideo(videosMap[firstModule.id][0]);
            setExpandedModules(new Set([firstModule.id]));
          }
        }
      }
    } catch (error) {
      console.error("Failed to fetch formation:", error);
    } finally {
      setLoading(false);
    }
  };

  const toggleModule = (moduleId: number) => {
    const newExpanded = new Set(expandedModules);
    if (newExpanded.has(moduleId)) {
      newExpanded.delete(moduleId);
    } else {
      newExpanded.add(moduleId);
    }
    setExpandedModules(newExpanded);
  };

  const getEmbedUrl = (url: string, type: string): string => {
    if (type === 'youtube') {
      const videoId = url.match(/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/)?.[1];
      return videoId ? `https://www.youtube.com/embed/${videoId}` : '';
    } else if (type === 'vimeo') {
      const videoId = url.match(/vimeo\.com\/(?:video\/)?(\d+)/)?.[1];
      return videoId ? `https://player.vimeo.com/video/${videoId}` : '';
    }
    return url;
  };

  const getAspectRatioStyle = (ratio: string): React.CSSProperties => {
    const ratios: { [key: string]: string } = {
      '16:9': '56.25%',
      '9:16': '177.78%',
      '1:1': '100%',
      '4:3': '75%',
      '3:2': '66.67%',
      '2:3': '150%',
    };
    return {
      paddingBottom: ratios[ratio] || '56.25%',
    };
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: 'var(--bg-primary)' }}>
        <div className="text-center">
          <p className="text-xl mb-4" style={{ color: 'var(--text-primary)' }}>Veuillez vous connecter</p>
          <button
            onClick={() => navigate("/")}
            className="px-6 py-3 rounded-xl font-semibold text-white"
            style={{ backgroundColor: 'var(--primary)' }}
          >
            Retour à l'accueil
          </button>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: 'var(--bg-primary)' }}>
        <div className="w-12 h-12 border-4 rounded-full animate-spin" style={{ borderColor: 'var(--gray-200)', borderTopColor: 'var(--primary)' }}></div>
      </div>
    );
  }

  if (!hasAccess) {
    return null;
  }

  return (
    <div className="min-h-screen" style={{ fontFamily: "'Outfit', sans-serif", backgroundColor: 'var(--bg-primary)' }}>
      <Header showBackButton onBack={() => navigate("/dashboard")} />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        {/* Formation Header */}
        {formation && (
          <div className="mb-8">
            <h1 className="text-3xl sm:text-4xl font-bold mb-2" style={{ color: 'var(--text-primary)' }}>
              {formation.name}
            </h1>
            <p className="text-lg" style={{ color: 'var(--text-secondary)' }}>
              {formation.description}
            </p>
          </div>
        )}

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Video Player */}
          <div className="lg:col-span-2">
            {currentVideo ? (
              <div className="rounded-2xl overflow-hidden border" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
                <div className="relative w-full overflow-hidden bg-black" style={getAspectRatioStyle(currentVideo.aspect_ratio)}>
                  <iframe
                    src={getEmbedUrl(currentVideo.video_url, currentVideo.video_type)}
                    className="absolute top-0 left-0 w-full h-full"
                    sandbox="allow-scripts allow-same-origin allow-presentation"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  />
                </div>
                <div className="p-6">
                  <h2 className="text-2xl font-bold mb-2" style={{ color: 'var(--text-primary)' }}>
                    {currentVideo.title}
                  </h2>
                  {currentVideo.description && (
                    <p className="text-base mb-4" style={{ color: 'var(--text-secondary)' }}>
                      {currentVideo.description}
                    </p>
                  )}
                  
                  {/* Resources Links */}
                  {currentVideo.resources && (() => {
                    try {
                      const resources: Resource[] = JSON.parse(currentVideo.resources);
                      if (resources && resources.length > 0) {
                        return (
                          <div className="mt-6 pt-6 border-t" style={{ borderColor: 'var(--border-color)' }}>
                            <h3 className="text-base font-semibold mb-3 flex items-center gap-2" style={{ color: 'var(--text-primary)' }}>
                              🔗 Liens et Ressources
                            </h3>
                            <div className="space-y-2">
                              {resources.map((resource, index) => (
                                <a
                                  key={index}
                                  href={resource.url}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="flex items-center gap-3 p-3 rounded-xl border transition-all hover:scale-[1.02]"
                                  style={{ 
                                    backgroundColor: 'var(--bg-primary)', 
                                    borderColor: 'var(--border-color)',
                                  }}
                                >
                                  <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0" 
                                       style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)' }}>
                                    <ExternalLink className="w-5 h-5" style={{ color: 'var(--primary)' }} />
                                  </div>
                                  <div className="flex-1 min-w-0">
                                    <p className="font-medium" style={{ color: 'var(--text-primary)' }}>
                                      {resource.title}
                                    </p>
                                    <p className="text-sm truncate font-mono" style={{ color: 'var(--text-muted)' }}>
                                      {resource.url}
                                    </p>
                                  </div>
                                  <ExternalLink className="w-4 h-4 flex-shrink-0" style={{ color: 'var(--text-muted)' }} />
                                </a>
                              ))}
                            </div>
                          </div>
                        );
                      }
                    } catch (e) {
                      return null;
                    }
                    return null;
                  })()}
                </div>
              </div>
            ) : (
              <div className="rounded-2xl border p-12 text-center" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
                <Play className="w-16 h-16 mx-auto mb-4" style={{ color: 'var(--text-muted)', opacity: 0.3 }} />
                <p className="text-xl" style={{ color: 'var(--text-muted)' }}>
                  Sélectionnez une vidéo pour commencer
                </p>
              </div>
            )}
          </div>

          {/* Module List */}
          <div className="lg:col-span-1">
            <div className="rounded-2xl border overflow-hidden" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
              <div className="p-4 border-b" style={{ borderColor: 'var(--border-color)' }}>
                <h3 className="text-lg font-bold flex items-center gap-2" style={{ color: 'var(--text-primary)' }}>
                  <BookOpen className="w-5 h-5" />
                  Contenu de la formation
                </h3>
              </div>

              <div className="max-h-[600px] overflow-y-auto">
                {modules.length === 0 ? (
                  <div className="p-8 text-center">
                    <BookOpen className="w-12 h-12 mx-auto mb-3" style={{ color: 'var(--text-muted)', opacity: 0.3 }} />
                    <p className="text-sm" style={{ color: 'var(--text-muted)' }}>
                      Aucun module disponible
                    </p>
                  </div>
                ) : (
                  modules.map((module) => (
                    <div key={module.id} className="border-b last:border-b-0" style={{ borderColor: 'var(--border-color)' }}>
                      <button
                        onClick={() => toggleModule(module.id)}
                        className="w-full p-4 flex items-center justify-between hover:opacity-80 transition-opacity text-left"
                      >
                        <div className="flex-1">
                          <h4 className="font-semibold mb-1" style={{ color: 'var(--text-primary)' }}>
                            {module.title}
                          </h4>
                          {module.description && (
                            <p className="text-sm line-clamp-1" style={{ color: 'var(--text-secondary)' }}>
                              {module.description}
                            </p>
                          )}
                        </div>
                        {expandedModules.has(module.id) ? (
                          <ChevronDown className="w-5 h-5 flex-shrink-0 ml-2" style={{ color: 'var(--text-muted)' }} />
                        ) : (
                          <ChevronRight className="w-5 h-5 flex-shrink-0 ml-2" style={{ color: 'var(--text-muted)' }} />
                        )}
                      </button>

                      {expandedModules.has(module.id) && videos[module.id] && (
                        <div className="border-t" style={{ borderColor: 'var(--border-color)' }}>
                          {videos[module.id].map((video) => (
                            <button
                              key={video.id}
                              onClick={() => setCurrentVideo(video)}
                              className={`w-full p-3 flex items-start gap-3 hover:opacity-80 transition-all text-left ${
                                currentVideo?.id === video.id ? 'bg-opacity-50' : ''
                              }`}
                              style={{
                                backgroundColor: currentVideo?.id === video.id ? 'rgba(139, 92, 246, 0.1)' : 'transparent'
                              }}
                            >
                              <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0" 
                                   style={{ backgroundColor: currentVideo?.id === video.id ? 'var(--primary)' : 'var(--gray-200)' }}>
                                {currentVideo?.id === video.id ? (
                                  <Play className="w-4 h-4 text-white" />
                                ) : (
                                  <Play className="w-4 h-4" style={{ color: 'var(--text-muted)' }} />
                                )}
                              </div>
                              <div className="flex-1 min-w-0">
                                <p className="text-sm font-medium mb-1" style={{ color: 'var(--text-primary)' }}>
                                  {video.title}
                                </p>
                                {video.duration_seconds && (
                                  <p className="text-xs" style={{ color: 'var(--text-muted)' }}>
                                    {Math.floor(video.duration_seconds / 60)}:{String(video.duration_seconds % 60).padStart(2, '0')}
                                  </p>
                                )}
                              </div>
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
