import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { useAdminPermissions } from "@/react-app/hooks/useAdminPermissions";
import { ArrowLeft, Plus, Edit, Trash2, Eye, EyeOff, BookOpen } from "lucide-react";
import AdminSidebar from "@/react-app/components/AdminSidebar";
import { formatDateTimeBenin } from "@/react-app/utils/dateFormatter";

interface BlogPost {
  id: number;
  title: string;
  slug: string;
  excerpt: string | null;
  content: string;
  image_url: string | null;
  author_name: string | null;
  category: string | null;
  is_published: number;
  published_at: string | null;
  created_at: string;
}

export default function AdminBlog() {
  const navigate = useNavigate();
  const { hasPermission, loading: permissionsLoading, getDefaultPage } = useAdminPermissions();
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [loading, setLoading] = useState(true);

  // Check permission and redirect if needed
  useEffect(() => {
    if (permissionsLoading) return;
    
    if (!hasPermission('manageBlog')) {
      navigate(getDefaultPage(), { replace: true });
    }
  }, [permissionsLoading, hasPermission, navigate, getDefaultPage]);

  useEffect(() => {
    const loadFont = () => {
      const link = document.createElement("link");
      link.href = "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap";
      link.rel = "stylesheet";
      document.head.appendChild(link);
    };
    loadFont();
  }, []);

  useEffect(() => {
    fetchPosts();
  }, []);

  const fetchPosts = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/blog/admin/posts');
      if (response.status === 403) {
        navigate('/');
        return;
      }
      if (response.ok) {
        const data = await response.json();
        setPosts(data);
      }
    } catch (error) {
      console.error('Failed to fetch blog posts:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Êtes-vous sûr de vouloir supprimer cet article ?")) return;

    try {
      const response = await fetch(`/api/blog/admin/posts/${id}`, {
        method: "DELETE",
      });

      if (response.ok) {
        await fetchPosts();
      }
    } catch (error) {
      console.error("Failed to delete blog post:", error);
    }
  };

  const stats = {
    total: posts.length,
    published: posts.filter(p => p.is_published === 1).length,
    drafts: posts.filter(p => p.is_published === 0).length,
  };

  return (
    <div className="min-h-screen flex" style={{ fontFamily: "'Outfit', sans-serif", backgroundColor: 'var(--bg-primary)' }}>
      <AdminSidebar />
      
      <div className="flex-1">
      <header className="px-6 py-6">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate("/admin")}
              className="p-2 hover:opacity-80 rounded-xl transition-opacity"
              style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)' }}
            >
              <ArrowLeft className="w-6 h-6" style={{ color: 'var(--primary)' }} />
            </button>
            <div>
              <h1 className="text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>Gestion du Blog</h1>
              <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>Créez et gérez vos articles de blog</p>
            </div>
          </div>
          <button
            onClick={() => navigate("/admin/blog/new")}
            className="flex items-center gap-2 px-6 py-3 rounded-xl font-semibold transition-all text-white"
            style={{ backgroundColor: 'var(--primary)' }}
          >
            <Plus className="w-5 h-5" />
            Nouvel Article
          </button>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <div className="rounded-2xl p-6 border" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm" style={{ color: 'var(--text-muted)' }}>Total Articles</span>
              <BookOpen className="w-8 h-8" style={{ color: 'var(--primary)' }} />
            </div>
            <div className="text-3xl font-bold" style={{ color: 'var(--text-primary)' }}>{stats.total}</div>
          </div>

          <div className="rounded-2xl p-6 border" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm" style={{ color: 'var(--text-muted)' }}>Publiés</span>
              <Eye className="w-8 h-8" style={{ color: 'var(--success)' }} />
            </div>
            <div className="text-3xl font-bold" style={{ color: 'var(--text-primary)' }}>{stats.published}</div>
          </div>

          <div className="rounded-2xl p-6 border" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm" style={{ color: 'var(--text-muted)' }}>Brouillons</span>
              <EyeOff className="w-8 h-8" style={{ color: 'var(--warning)' }} />
            </div>
            <div className="text-3xl font-bold" style={{ color: 'var(--text-primary)' }}>{stats.drafts}</div>
          </div>
        </div>
      </header>

      <main className="px-6 pb-12">
        {loading ? (
          <div className="text-center py-20">
            <div className="inline-block w-12 h-12 border-4 rounded-full animate-spin" style={{ borderColor: 'var(--gray-200)', borderTopColor: 'var(--primary)' }}></div>
          </div>
        ) : posts.length === 0 ? (
          <div className="text-center py-20">
            <BookOpen className="w-16 h-16 mx-auto mb-4" style={{ color: 'var(--text-muted)', opacity: 0.3 }} />
            <p className="text-xl mb-4" style={{ color: 'var(--text-muted)' }}>Aucun article</p>
            <button
              onClick={() => navigate("/admin/blog/new")}
              className="px-6 py-3 rounded-xl font-semibold text-white"
              style={{ backgroundColor: 'var(--primary)' }}
            >
              Créer votre premier article
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            {posts.map((post) => (
              <div
                key={post.id}
                className="rounded-2xl border p-6 hover:shadow-lg transition-shadow"
                style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}
              >
                <div className="flex items-start gap-6">
                  {post.image_url && (
                    <div className="w-32 h-32 rounded-xl overflow-hidden flex-shrink-0" style={{ backgroundColor: 'var(--gray-100)' }}>
                      <img
                        src={post.image_url}
                        alt={post.title}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  )}

                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-4 mb-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="text-xl font-bold" style={{ color: 'var(--text-primary)' }}>
                            {post.title}
                          </h3>
                          {post.is_published === 1 ? (
                            <span className="px-2 py-0.5 bg-green-500/20 text-green-600 text-xs font-medium rounded-full flex items-center gap-1">
                              <Eye className="w-3 h-3" />
                              Publié
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 bg-yellow-500/20 text-yellow-600 text-xs font-medium rounded-full flex items-center gap-1">
                              <EyeOff className="w-3 h-3" />
                              Brouillon
                            </span>
                          )}
                        </div>
                        {post.category && (
                          <span className="text-sm" style={{ color: 'var(--text-muted)' }}>
                            {post.category}
                          </span>
                        )}
                      </div>
                    </div>

                    {post.excerpt && (
                      <p className="text-sm mb-3 line-clamp-2" style={{ color: 'var(--text-secondary)' }}>
                        {post.excerpt}
                      </p>
                    )}

                    <div className="flex items-center justify-between">
                      <div className="text-sm" style={{ color: 'var(--text-muted)' }}>
                        {post.is_published === 1 && post.published_at
                          ? `Publié le ${formatDateTimeBenin(post.published_at)}`
                          : `Créé le ${formatDateTimeBenin(post.created_at)}`}
                        {post.author_name && ` • ${post.author_name}`}
                      </div>

                      <div className="flex gap-2">
                        <button
                          onClick={() => navigate(`/admin/blog/edit/${post.id}`)}
                          className="flex items-center gap-2 px-4 py-2 rounded-xl font-medium transition-colors text-white"
                          style={{ backgroundColor: 'var(--info)' }}
                        >
                          <Edit className="w-4 h-4" />
                          Modifier
                        </button>
                        <button
                          onClick={() => handleDelete(post.id)}
                          className="px-4 py-2 border rounded-xl transition-colors"
                          style={{ backgroundColor: 'rgba(239, 68, 68, 0.1)', color: 'var(--error)', borderColor: 'rgba(239, 68, 68, 0.3)' }}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
      </div>
    </div>
  );
}
