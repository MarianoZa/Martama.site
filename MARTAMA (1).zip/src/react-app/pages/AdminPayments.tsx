import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { useAdminPermissions } from "@/react-app/hooks/useAdminPermissions";
import { ArrowLeft, DollarSign, Clock, CheckCircle, XCircle } from "lucide-react";
import AdminSidebar from "@/react-app/components/AdminSidebar";
import { formatDateBenin } from "@/react-app/utils/dateFormatter";

interface WithdrawalRequest {
  id: number;
  affiliate_id: number;
  affiliate_name: string | null;
  affiliate_email: string;
  promo_code: string;
  amount: number;
  payment_method: string;
  payment_details: string | null;
  status: string;
  created_at: string;
  processed_at: string | null;
}

export default function AdminPayments() {
  const navigate = useNavigate();
  const { hasPermission, loading: permissionsLoading, getDefaultPage } = useAdminPermissions();
  const [requests, setRequests] = useState<WithdrawalRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(false);
  const [activeFilter, setActiveFilter] = useState("pending");

  // Check permission and redirect if needed
  useEffect(() => {
    if (permissionsLoading) return;
    
    if (!hasPermission('managePayments')) {
      navigate(getDefaultPage(), { replace: true });
    }
  }, [permissionsLoading, hasPermission, navigate, getDefaultPage]);

  useEffect(() => {
    const loadFont = () => {
      const link = document.createElement("link");
      link.href = "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap";
      link.rel = "stylesheet";
      document.head.appendChild(link);
    };
    loadFont();
  }, []);

  useEffect(() => {
    fetchRequests();
  }, [activeFilter]);

  const fetchRequests = async () => {
    try {
      setLoading(true);
      const url = activeFilter === "all" 
        ? "/api/admin/withdrawal-requests" 
        : `/api/admin/withdrawal-requests?status=${activeFilter}`;
      const response = await fetch(url);
      
      if (response.status === 403) {
        navigate("/");
        return;
      }
      
      const data = await response.json();
      setRequests(data);
    } catch (error) {
      console.error("Failed to fetch withdrawal requests:", error);
    } finally {
      setLoading(false);
    }
  };

  const processRequest = async (requestId: number, newStatus: string) => {
    try {
      setProcessing(true);
      const response = await fetch(`/api/admin/withdrawal-requests/${requestId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: newStatus }),
      });

      if (response.ok) {
        await fetchRequests();
      }
    } catch (error) {
      console.error("Failed to process request:", error);
    } finally {
      setProcessing(false);
    }
  };

  const stats = {
    pending: requests.filter(r => r.status === "pending").length,
    pending_amount: requests.filter(r => r.status === "pending").reduce((sum, r) => sum + r.amount, 0),
    approved: requests.filter(r => r.status === "approved").length,
    completed: requests.filter(r => r.status === "completed").length,
    total_paid: requests.filter(r => r.status === "completed").reduce((sum, r) => sum + r.amount, 0),
  };

  return (
    <div className="min-h-screen flex" style={{ fontFamily: "'Outfit', sans-serif", backgroundColor: 'var(--bg-primary)' }}>
      <AdminSidebar />
      
      <div className="flex-1">
      <header className="px-6 py-6">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate("/admin")}
              className="p-2 hover:opacity-80 rounded-xl transition-opacity"
              style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)' }}
            >
              <ArrowLeft className="w-6 h-6" style={{ color: 'var(--primary)' }} />
            </button>
            <div>
              <h1 className="text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>Gestion des Paiements</h1>
              <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>Approuvez et gérez les demandes de retrait des affiliés</p>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <div className="rounded-2xl border p-6" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm" style={{ color: 'var(--text-muted)' }}>En Attente</span>
              <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ backgroundColor: 'rgba(251, 191, 36, 0.2)' }}>
                <Clock className="w-4 h-4" style={{ color: 'var(--warning)' }} />
              </div>
            </div>
            <div className="text-3xl font-bold mb-1" style={{ color: 'var(--text-primary)' }}>{stats.pending}</div>
            <div className="text-sm" style={{ color: 'var(--text-secondary)' }}>{stats.pending_amount.toLocaleString()} F</div>
          </div>

          <div className="rounded-2xl border p-6" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm" style={{ color: 'var(--text-muted)' }}>Approuvées</span>
              <CheckCircle className="w-8 h-8" style={{ color: 'var(--info)' }} />
            </div>
            <div className="text-3xl font-bold" style={{ color: 'var(--text-primary)' }}>{stats.approved}</div>
          </div>

          <div className="rounded-2xl border p-6" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm" style={{ color: 'var(--text-muted)' }}>Payées</span>
              <CheckCircle className="w-8 h-8" style={{ color: 'var(--success)' }} />
            </div>
            <div className="text-3xl font-bold" style={{ color: 'var(--text-primary)' }}>{stats.completed}</div>
          </div>

          <div className="rounded-2xl border p-6" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm" style={{ color: 'var(--text-muted)' }}>Total Payé</span>
              <DollarSign className="w-8 h-8" style={{ color: 'var(--primary)' }} />
            </div>
            <div className="text-3xl font-bold" style={{ color: 'var(--text-primary)' }}>{stats.total_paid.toLocaleString()} F</div>
          </div>
        </div>

        {/* Filters */}
        <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide">
          <button
            onClick={() => setActiveFilter("pending")}
            className={`px-6 py-3 rounded-xl font-semibold whitespace-nowrap transition-all ${
              activeFilter === "pending" ? "text-white shadow-lg" : ""
            }`}
            style={{
              backgroundColor: activeFilter === "pending" ? 'var(--primary)' : 'var(--bg-secondary)',
              color: activeFilter === "pending" ? '#ffffff' : 'var(--text-primary)',
              borderColor: 'var(--border-color)',
              border: activeFilter === "pending" ? 'none' : '1px solid'
            }}
          >
            En Attente ({stats.pending})
          </button>
          <button
            onClick={() => setActiveFilter("approved")}
            className={`px-6 py-3 rounded-xl font-semibold whitespace-nowrap transition-all ${
              activeFilter === "approved" ? "text-white shadow-lg" : ""
            }`}
            style={{
              backgroundColor: activeFilter === "approved" ? 'var(--primary)' : 'var(--bg-secondary)',
              color: activeFilter === "approved" ? '#ffffff' : 'var(--text-primary)',
              borderColor: 'var(--border-color)',
              border: activeFilter === "approved" ? 'none' : '1px solid'
            }}
          >
            Approuvées
          </button>
          <button
            onClick={() => setActiveFilter("completed")}
            className={`px-6 py-3 rounded-xl font-semibold whitespace-nowrap transition-all ${
              activeFilter === "completed" ? "text-white shadow-lg" : ""
            }`}
            style={{
              backgroundColor: activeFilter === "completed" ? 'var(--primary)' : 'var(--bg-secondary)',
              color: activeFilter === "completed" ? '#ffffff' : 'var(--text-primary)',
              borderColor: 'var(--border-color)',
              border: activeFilter === "completed" ? 'none' : '1px solid'
            }}
          >
            Payées
          </button>
          <button
            onClick={() => setActiveFilter("all")}
            className={`px-6 py-3 rounded-xl font-semibold whitespace-nowrap transition-all ${
              activeFilter === "all" ? "text-white shadow-lg" : ""
            }`}
            style={{
              backgroundColor: activeFilter === "all" ? 'var(--primary)' : 'var(--bg-secondary)',
              color: activeFilter === "all" ? '#ffffff' : 'var(--text-primary)',
              borderColor: 'var(--border-color)',
              border: activeFilter === "all" ? 'none' : '1px solid'
            }}
          >
            Toutes
          </button>
        </div>
      </header>

      <main className="px-6 pb-12">
        {loading ? (
          <div className="text-center py-20">
            <div className="inline-block w-12 h-12 border-4 rounded-full animate-spin" style={{ borderColor: 'var(--gray-200)', borderTopColor: 'var(--primary)' }}></div>
          </div>
        ) : (
          <div className="rounded-3xl border overflow-hidden" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b" style={{ borderColor: 'var(--border-color)' }}>
                    <th className="px-6 py-4 text-left text-sm font-semibold" style={{ color: 'var(--text-muted)' }}>Date</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold" style={{ color: 'var(--text-muted)' }}>Affilié</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold" style={{ color: 'var(--text-muted)' }}>Email</th>
                    <th className="px-6 py-4 text-right text-sm font-semibold" style={{ color: 'var(--text-muted)' }}>Montant</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold" style={{ color: 'var(--text-muted)' }}>Méthode</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold" style={{ color: 'var(--text-muted)' }}>Compte</th>
                    <th className="px-6 py-4 text-center text-sm font-semibold" style={{ color: 'var(--text-muted)' }}>Statut</th>
                    <th className="px-6 py-4 text-center text-sm font-semibold" style={{ color: 'var(--text-muted)' }}>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {requests.map((request) => (
                    <tr key={request.id} className="border-b hover:opacity-90 transition-opacity" style={{ borderColor: 'var(--border-color)' }}>
                      <td className="px-6 py-4 text-sm" style={{ color: 'var(--text-primary)' }}>
                        {formatDateBenin(request.created_at)}
                      </td>
                      <td className="px-6 py-4">
                        <div className="font-medium" style={{ color: 'var(--text-primary)' }}>{request.affiliate_name || "N/A"}</div>
                        <div className="text-xs" style={{ color: 'var(--text-muted)' }}>{request.promo_code}</div>
                      </td>
                      <td className="px-6 py-4 text-sm" style={{ color: 'var(--text-secondary)' }}>{request.affiliate_email}</td>
                      <td className="px-6 py-4 text-right">
                        <div className="font-bold text-lg" style={{ color: 'var(--text-primary)' }}>{request.amount.toLocaleString()} F</div>
                      </td>
                      <td className="px-6 py-4 text-sm capitalize" style={{ color: 'var(--text-primary)' }}>{request.payment_method}</td>
                      <td className="px-6 py-4 text-sm font-mono" style={{ color: 'var(--text-secondary)' }}>
                        {request.payment_details || "N/A"}
                      </td>
                      <td className="px-6 py-4 text-center">
                        <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                          request.status === "pending" 
                            ? "bg-orange-500/20 text-orange-300"
                            : request.status === "approved"
                            ? "bg-blue-500/20 text-blue-300"
                            : request.status === "completed"
                            ? "bg-green-500/20 text-green-300"
                            : "bg-red-500/20 text-red-300"
                        }`}>
                          {request.status === "pending" ? "En attente" :
                           request.status === "approved" ? "Approuvée" :
                           request.status === "completed" ? "Payée" : "Rejetée"}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center justify-center gap-2">
                          {request.status === "pending" && (
                            <>
                              <button
                                onClick={() => processRequest(request.id, "approved")}
                                disabled={processing}
                                className="p-2 bg-blue-500/20 hover:bg-blue-500/30 text-blue-300 border border-blue-500/30 rounded-lg transition-colors disabled:opacity-50"
                                title="Approuver"
                              >
                                <CheckCircle className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => processRequest(request.id, "rejected")}
                                disabled={processing}
                                className="p-2 bg-red-500/20 hover:bg-red-500/30 text-red-300 border border-red-500/30 rounded-lg transition-colors disabled:opacity-50"
                                title="Rejeter"
                              >
                                <XCircle className="w-4 h-4" />
                              </button>
                            </>
                          )}
                          {request.status === "approved" && (
                            <button
                              onClick={() => processRequest(request.id, "completed")}
                              disabled={processing}
                              className="px-4 py-2 bg-green-500 hover:bg-green-600 text-white rounded-lg font-medium transition-colors disabled:opacity-50 text-sm"
                            >
                              Valider le Paiement
                            </button>
                          )}
                          {request.status === "completed" && (
                            <span className="text-green-400 text-sm">
                              ✓ Payé le {request.processed_at ? formatDateBenin(request.processed_at) : 'N/A'}
                            </span>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {requests.length === 0 && (
                <div className="text-center py-12">
                  <DollarSign className="w-12 h-12 mx-auto mb-3" style={{ color: 'var(--text-muted)', opacity: 0.3 }} />
                  <p style={{ color: 'var(--text-muted)' }}>Aucune demande de retrait</p>
                </div>
              )}
            </div>
          </div>
        )}
      </main>
      </div>
    </div>
  );
}
