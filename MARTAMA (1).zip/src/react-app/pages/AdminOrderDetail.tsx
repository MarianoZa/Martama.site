import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router";
import { ArrowLeft, Clock, User, Package, CheckCircle, AlertCircle, XCircle, FileText } from "lucide-react";
import { formatDateTimeBenin } from "@/react-app/utils/dateFormatter";
import AdminSidebar from "@/react-app/components/AdminSidebar";

interface Order {
  id: number;
  product_name: string;
  product_category: string;
  customer_email: string;
  duration_months: number | null;
  amount: number;
  original_amount: number;
  discount_amount: number;
  affiliate_code: string | null;
  status: string;
  payment_method: string;
  payment_reference: string | null;
  access_credentials: string | null;
  created_at: string;
  updated_at: string;
  delivered_at: string | null;
  delivered_by: string | null;
}

interface ActionLog {
  id: number;
  order_id: number;
  action_type: string;
  action_details: string;
  performed_by: string;
  created_at: string;
}

export default function AdminOrderDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [order, setOrder] = useState<Order | null>(null);
  const [actionLogs, setActionLogs] = useState<ActionLog[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadFont = () => {
      const link = document.createElement("link");
      link.href = "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap";
      link.rel = "stylesheet";
      document.head.appendChild(link);
    };
    loadFont();
  }, []);

  useEffect(() => {
    if (id) {
      fetchOrderDetails();
      fetchActionLogs();
    }
  }, [id]);

  const fetchOrderDetails = async () => {
    try {
      setLoading(true);
      const response = await fetch(`/api/admin/orders/${id}`);
      
      if (response.status === 403) {
        navigate("/");
        return;
      }
      
      if (response.ok) {
        const data = await response.json();
        setOrder(data);
      }
    } catch (error) {
      console.error("Failed to fetch order details:", error);
    } finally {
      setLoading(false);
    }
  };

  const fetchActionLogs = async () => {
    try {
      const response = await fetch(`/api/admin/orders/${id}/logs`);
      if (response.ok) {
        const data = await response.json();
        setActionLogs(data);
      }
    } catch (error) {
      console.error("Failed to fetch action logs:", error);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "delivered":
        return { bg: "rgba(16, 185, 129, 0.1)", border: "rgba(16, 185, 129, 0.3)", text: "var(--success)" };
      case "paid":
        return { bg: "rgba(59, 130, 246, 0.1)", border: "rgba(59, 130, 246, 0.3)", text: "var(--info)" };
      case "pending":
        return { bg: "rgba(251, 191, 36, 0.1)", border: "rgba(251, 191, 36, 0.3)", text: "var(--warning)" };
      case "cancelled":
        return { bg: "rgba(239, 68, 68, 0.1)", border: "rgba(239, 68, 68, 0.3)", text: "var(--error)" };
      default:
        return { bg: "var(--bg-secondary)", border: "var(--border-color)", text: "var(--text-muted)" };
    }
  };

  const getActionIcon = (actionType: string) => {
    switch (actionType) {
      case "order_created":
        return <Package className="w-5 h-5" />;
      case "payment_completed":
        return <CheckCircle className="w-5 h-5" />;
      case "order_delivered":
        return <CheckCircle className="w-5 h-5" />;
      case "order_cancelled":
        return <XCircle className="w-5 h-5" />;
      case "status_updated":
        return <AlertCircle className="w-5 h-5" />;
      default:
        return <FileText className="w-5 h-5" />;
    }
  };

  const getActionColor = (actionType: string) => {
    switch (actionType) {
      case "order_created":
        return "var(--info)";
      case "payment_completed":
        return "var(--success)";
      case "order_delivered":
        return "var(--success)";
      case "order_cancelled":
        return "var(--error)";
      case "status_updated":
        return "var(--warning)";
      default:
        return "var(--text-muted)";
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex" style={{ fontFamily: "'Outfit', sans-serif", backgroundColor: 'var(--bg-primary)' }}>
        <AdminSidebar />
        <div className="flex-1 flex items-center justify-center">
          <div className="w-12 h-12 border-4 rounded-full animate-spin" style={{ borderColor: 'var(--gray-200)', borderTopColor: 'var(--primary)' }}></div>
        </div>
      </div>
    );
  }

  if (!order) {
    return (
      <div className="min-h-screen flex" style={{ fontFamily: "'Outfit', sans-serif", backgroundColor: 'var(--bg-primary)' }}>
        <AdminSidebar />
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <p className="text-xl mb-4" style={{ color: 'var(--text-primary)' }}>Commande non trouvée</p>
            <button
              onClick={() => navigate("/admin/orders")}
              className="px-6 py-3 rounded-xl font-semibold text-white"
              style={{ backgroundColor: 'var(--primary)' }}
            >
              Retour aux commandes
            </button>
          </div>
        </div>
      </div>
    );
  }

  const statusColors = getStatusColor(order.status);

  return (
    <div className="min-h-screen flex" style={{ fontFamily: "'Outfit', sans-serif", backgroundColor: 'var(--bg-primary)' }}>
      <AdminSidebar />
      
      <div className="flex-1 overflow-auto">
        <div className="px-6 py-6 max-w-7xl mx-auto">
          {/* Header */}
          <div className="flex items-center gap-4 mb-8">
            <button
              onClick={() => navigate("/admin/orders")}
              className="p-2 hover:opacity-80 rounded-xl transition-opacity"
              style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)' }}
            >
              <ArrowLeft className="w-6 h-6" style={{ color: 'var(--primary)' }} />
            </button>
            <div>
              <h1 className="text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>
                Commande #{order.id}
              </h1>
              <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
                Détails et historique complet
              </p>
            </div>
          </div>

          <div className="grid lg:grid-cols-2 gap-6">
            {/* Order Details */}
            <div className="space-y-6">
              {/* Status Card */}
              <div 
                className="rounded-2xl border p-6"
                style={{ 
                  backgroundColor: statusColors.bg, 
                  borderColor: statusColors.border 
                }}
              >
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold" style={{ color: 'var(--text-primary)' }}>
                    Statut
                  </h3>
                  <span 
                    className="px-4 py-2 rounded-full text-sm font-semibold capitalize"
                    style={{ 
                      backgroundColor: statusColors.bg,
                      color: statusColors.text,
                      border: `1px solid ${statusColors.border}`
                    }}
                  >
                    {order.status === 'delivered' ? '✅ Livré' : 
                     order.status === 'paid' ? '💰 Payé' : 
                     order.status === 'pending' ? '⏳ En attente' : 
                     order.status === 'cancelled' ? '❌ Annulé' : order.status}
                  </span>
                </div>
                
                {order.delivered_at && (
                  <div className="pt-4 border-t" style={{ borderColor: statusColors.border }}>
                    <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
                      Livré le {formatDateTimeBenin(order.delivered_at)}
                    </p>
                    {order.delivered_by && (
                      <p className="text-sm mt-1" style={{ color: 'var(--text-muted)' }}>
                        Par: {order.delivered_by}
                      </p>
                    )}
                  </div>
                )}
              </div>

              {/* Product Info */}
              <div className="rounded-2xl border p-6" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
                <h3 className="text-lg font-semibold mb-4 flex items-center gap-2" style={{ color: 'var(--text-primary)' }}>
                  <Package className="w-5 h-5" />
                  Produit
                </h3>
                <div className="space-y-3">
                  <div>
                    <p className="text-sm" style={{ color: 'var(--text-muted)' }}>Nom</p>
                    <p className="font-semibold" style={{ color: 'var(--text-primary)' }}>{order.product_name}</p>
                  </div>
                  <div>
                    <p className="text-sm" style={{ color: 'var(--text-muted)' }}>Catégorie</p>
                    <p className="capitalize" style={{ color: 'var(--text-primary)' }}>{order.product_category}</p>
                  </div>
                  {order.duration_months && (
                    <div>
                      <p className="text-sm" style={{ color: 'var(--text-muted)' }}>Durée</p>
                      <p style={{ color: 'var(--text-primary)' }}>{order.duration_months} mois</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Customer Info */}
              <div className="rounded-2xl border p-6" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
                <h3 className="text-lg font-semibold mb-4 flex items-center gap-2" style={{ color: 'var(--text-primary)' }}>
                  <User className="w-5 h-5" />
                  Client
                </h3>
                <div className="space-y-3">
                  <div>
                    <p className="text-sm" style={{ color: 'var(--text-muted)' }}>Email</p>
                    <p className="font-mono" style={{ color: 'var(--text-primary)' }}>{order.customer_email}</p>
                  </div>
                  {order.affiliate_code && (
                    <div>
                      <p className="text-sm" style={{ color: 'var(--text-muted)' }}>Code Promo Utilisé</p>
                      <p className="font-mono font-semibold" style={{ color: 'var(--primary)' }}>{order.affiliate_code}</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Payment Info */}
              <div className="rounded-2xl border p-6" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
                <h3 className="text-lg font-semibold mb-4" style={{ color: 'var(--text-primary)' }}>Paiement</h3>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span style={{ color: 'var(--text-muted)' }}>Prix original</span>
                    <span className="font-semibold" style={{ color: 'var(--text-primary)' }}>
                      {order.original_amount.toLocaleString()} FCFA
                    </span>
                  </div>
                  {order.discount_amount > 0 && (
                    <div className="flex justify-between">
                      <span style={{ color: 'var(--text-muted)' }}>Réduction</span>
                      <span className="font-semibold" style={{ color: 'var(--success)' }}>
                        -{order.discount_amount.toLocaleString()} FCFA
                      </span>
                    </div>
                  )}
                  <div className="flex justify-between pt-3 border-t" style={{ borderColor: 'var(--border-color)' }}>
                    <span className="font-semibold" style={{ color: 'var(--text-primary)' }}>Total payé</span>
                    <span className="text-xl font-bold" style={{ color: 'var(--primary)' }}>
                      {order.amount.toLocaleString()} FCFA
                    </span>
                  </div>
                  <div className="pt-3 border-t" style={{ borderColor: 'var(--border-color)' }}>
                    <p className="text-sm" style={{ color: 'var(--text-muted)' }}>
                      Méthode: {order.payment_method}
                    </p>
                    {order.payment_reference && (
                      <p className="text-xs font-mono mt-1" style={{ color: 'var(--text-muted)' }}>
                        Réf: {order.payment_reference}
                      </p>
                    )}
                  </div>
                </div>
              </div>

              {/* Access Credentials */}
              {order.access_credentials && (
                <div 
                  className="rounded-2xl border p-6"
                  style={{ 
                    backgroundColor: 'rgba(16, 185, 129, 0.1)', 
                    borderColor: 'rgba(16, 185, 129, 0.3)' 
                  }}
                >
                  <h3 className="text-lg font-semibold mb-4" style={{ color: 'var(--success)' }}>
                    Identifiants d'accès
                  </h3>
                  <pre 
                    className="text-sm font-mono whitespace-pre-wrap p-4 rounded-xl"
                    style={{ 
                      backgroundColor: 'var(--bg-primary)', 
                      color: 'var(--text-primary)' 
                    }}
                  >
                    {order.access_credentials}
                  </pre>
                </div>
              )}
            </div>

            {/* Activity Timeline */}
            <div>
              <div className="rounded-2xl border p-6" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
                <h3 className="text-lg font-semibold mb-6 flex items-center gap-2" style={{ color: 'var(--text-primary)' }}>
                  <Clock className="w-5 h-5" />
                  Journal d'Activité
                </h3>

                {actionLogs.length === 0 ? (
                  <div className="text-center py-8">
                    <Clock className="w-12 h-12 mx-auto mb-3 opacity-30" style={{ color: 'var(--text-muted)' }} />
                    <p style={{ color: 'var(--text-muted)' }}>Aucune activité enregistrée</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {actionLogs.map((log, index) => (
                      <div 
                        key={log.id} 
                        className="relative pl-8 pb-6"
                      >
                        {/* Timeline line */}
                        {index < actionLogs.length - 1 && (
                          <div 
                            className="absolute left-3 top-8 bottom-0 w-0.5"
                            style={{ backgroundColor: 'var(--border-color)' }}
                          />
                        )}
                        
                        {/* Icon */}
                        <div 
                          className="absolute left-0 top-0 w-6 h-6 rounded-full flex items-center justify-center"
                          style={{ 
                            backgroundColor: 'var(--bg-primary)',
                            color: getActionColor(log.action_type),
                            border: `2px solid ${getActionColor(log.action_type)}`
                          }}
                        >
                          {getActionIcon(log.action_type)}
                        </div>

                        {/* Content */}
                        <div 
                          className="rounded-xl p-4 border"
                          style={{ 
                            backgroundColor: 'var(--bg-primary)', 
                            borderColor: 'var(--border-color)' 
                          }}
                        >
                          <div className="flex items-start justify-between mb-2">
                            <p className="font-semibold" style={{ color: 'var(--text-primary)' }}>
                              {log.action_type.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                            </p>
                            <span className="text-xs" style={{ color: 'var(--text-muted)' }}>
                              {formatDateTimeBenin(log.created_at)}
                            </span>
                          </div>
                          
                          <p className="text-sm mb-2" style={{ color: 'var(--text-secondary)' }}>
                            {log.action_details}
                          </p>
                          
                          <div className="flex items-center gap-2 text-xs" style={{ color: 'var(--text-muted)' }}>
                            <User className="w-3 h-3" />
                            <span>Par: {log.performed_by}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
