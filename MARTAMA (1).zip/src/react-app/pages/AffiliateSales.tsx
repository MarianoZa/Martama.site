import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "@getmocha/users-service/react";
import Header from "@/react-app/components/Header";
import BottomNav from "@/react-app/components/BottomNav";
import StatusBadge from "@/react-app/components/StatusBadge";
import { 
  TrendingUp, 
  DollarSign,
  Package,
  Filter,
  CheckCircle
} from "lucide-react";
import { formatDateTimeBenin } from "@/react-app/utils/dateFormatter";

interface CommissionWithDetails {
  id: number;
  order_id: number;
  amount: number;
  status: string;
  created_at: string;
  product_name: string;
  customer_email: string;
  order_amount: number;
  commission_rate: number;
  purchase_number?: number;
}

interface AffiliateStats {
  id: number;
  promo_code: string;
  balance: number;
  total_sales: number;
  total_commissions: number;
}

export default function AffiliateSales() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [commissions, setCommissions] = useState<CommissionWithDetails[]>([]);
  const [stats, setStats] = useState<AffiliateStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [filterStatus, setFilterStatus] = useState<string>("all");

  useEffect(() => {
    const loadFont = () => {
      const link = document.createElement("link");
      link.href = "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap";
      link.rel = "stylesheet";
      document.head.appendChild(link);
    };
    loadFont();
  }, []);

  useEffect(() => {
    if (user) {
      fetchAffiliateData();
    }
  }, [user]);

  const fetchAffiliateData = async () => {
    try {
      setLoading(true);
      
      // Get affiliate stats
      const statsResponse = await fetch("/api/affiliate/stats");
      if (statsResponse.status === 404) {
        navigate("/become-affiliate");
        return;
      }
      const statsData = await statsResponse.json();
      setStats(statsData);
      
      // Get commissions
      const commissionsResponse = await fetch("/api/affiliate/commissions");
      if (commissionsResponse.ok) {
        const commissionsData = await commissionsResponse.json();
        setCommissions(commissionsData);
      }
    } catch (error) {
      console.error("Failed to fetch affiliate data:", error);
    } finally {
      setLoading(false);
    }
  };

  const filteredCommissions = filterStatus === "all" 
    ? commissions 
    : commissions.filter(c => c.status === filterStatus);

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: 'var(--bg-primary)' }}>
        <div className="text-center">
          <p className="text-xl mb-4" style={{ color: 'var(--text-primary)' }}>Veuillez vous connecter</p>
          <button
            onClick={() => navigate("/")}
            className="px-6 py-3 rounded-xl font-semibold"
            style={{ backgroundColor: 'var(--primary)', color: '#ffffff' }}
          >
            Retour à l'accueil
          </button>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: 'var(--bg-primary)' }}>
        <div className="w-12 h-12 border-4 rounded-full animate-spin" style={{ borderColor: 'var(--gray-200)', borderTopColor: 'var(--primary)' }}></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-20" style={{ fontFamily: "'Outfit', sans-serif", backgroundColor: 'var(--bg-primary)' }}>
      <Header showBackButton onBack={() => navigate("/affiliate/dashboard")} />

      <main className="px-4 sm:px-6 py-6 sm:py-8 max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-2xl sm:text-3xl font-bold mb-2" style={{ color: 'var(--text-primary)' }}>
            Mes Ventes et Commissions
          </h1>
          <p className="text-sm sm:text-base" style={{ color: 'var(--text-secondary)' }}>
            Historique détaillé de vos gains
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 gap-3 sm:gap-4 mb-6">
          <div className="rounded-2xl p-4 sm:p-6 border" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs sm:text-sm font-medium" style={{ color: 'var(--text-muted)' }}>Total des ventes</span>
              <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl flex items-center justify-center" style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)' }}>
                <TrendingUp className="w-4 h-4 sm:w-5 sm:h-5" style={{ color: 'var(--primary)' }} />
              </div>
            </div>
            <div className="text-2xl sm:text-3xl font-bold" style={{ color: 'var(--text-primary)' }}>
              {stats?.total_sales || 0}
            </div>
          </div>

          <div className="rounded-2xl p-4 sm:p-6 border" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs sm:text-sm font-medium" style={{ color: 'var(--text-muted)' }}>Commissions totales</span>
              <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl flex items-center justify-center" style={{ backgroundColor: 'rgba(34, 197, 94, 0.1)' }}>
                <DollarSign className="w-4 h-4 sm:w-5 sm:h-5 text-green-500" />
              </div>
            </div>
            <div className="text-2xl sm:text-3xl font-bold" style={{ color: 'var(--text-primary)' }}>
              {stats?.total_commissions.toLocaleString() || 0} F
            </div>
          </div>
        </div>

        {/* Filter Buttons */}
        <div className="flex gap-2 overflow-x-auto pb-2 mb-6 scrollbar-hide">
          <button
            onClick={() => setFilterStatus("all")}
            className={`px-4 py-2 rounded-xl font-medium whitespace-nowrap text-sm transition-all ${
              filterStatus === "all" ? "text-white" : ""
            }`}
            style={{
              backgroundColor: filterStatus === "all" ? 'var(--primary)' : 'var(--bg-secondary)',
              color: filterStatus === "all" ? '#ffffff' : 'var(--text-primary)',
              border: filterStatus === "all" ? 'none' : '1px solid var(--border-color)'
            }}
          >
            <Filter className="w-4 h-4 inline mr-2" />
            Toutes
          </button>
          <button
            onClick={() => setFilterStatus("pending")}
            className={`px-4 py-2 rounded-xl font-medium whitespace-nowrap text-sm transition-all`}
            style={{
              backgroundColor: filterStatus === "pending" ? 'rgba(251, 191, 36, 0.15)' : 'var(--bg-secondary)',
              color: filterStatus === "pending" ? '#f59e0b' : 'var(--text-primary)',
              border: '1px solid',
              borderColor: filterStatus === "pending" ? 'rgba(251, 191, 36, 0.3)' : 'var(--border-color)'
            }}
          >
            En attente
          </button>
          <button
            onClick={() => setFilterStatus("approved")}
            className={`px-4 py-2 rounded-xl font-medium whitespace-nowrap text-sm transition-all`}
            style={{
              backgroundColor: filterStatus === "approved" ? 'rgba(34, 197, 94, 0.15)' : 'var(--bg-secondary)',
              color: filterStatus === "approved" ? '#10b981' : 'var(--text-primary)',
              border: '1px solid',
              borderColor: filterStatus === "approved" ? 'rgba(34, 197, 94, 0.3)' : 'var(--border-color)'
            }}
          >
            Approuvées
          </button>
        </div>

        {/* Commissions List */}
        {filteredCommissions.length === 0 ? (
          <div className="rounded-2xl p-8 border text-center" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
            <div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4" style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)' }}>
              <Package className="w-8 h-8" style={{ color: 'var(--primary)' }} />
            </div>
            <h3 className="text-lg font-bold mb-2" style={{ color: 'var(--text-primary)' }}>
              {filterStatus === "all" ? "Aucune commission pour le moment" : `Aucune commission ${filterStatus}`}
            </h3>
            <p className="text-sm mb-4" style={{ color: 'var(--text-secondary)' }}>
              Partagez votre code promo pour commencer à gagner !
            </p>
            <button
              onClick={() => navigate("/affiliate/dashboard")}
              className="px-6 py-3 rounded-xl font-semibold text-white transition-all"
              style={{ backgroundColor: 'var(--primary)' }}
            >
              Retour au dashboard
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            {filteredCommissions.map((commission) => (
              <div
                key={commission.id}
                className="rounded-2xl p-4 sm:p-5 border hover:border-opacity-70 transition-all"
                style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}
              >
                {/* Header */}
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <Package className="w-4 h-4" style={{ color: 'var(--primary)' }} />
                      <h3 className="text-sm sm:text-base font-bold" style={{ color: 'var(--text-primary)' }}>
                        {commission.product_name}
                      </h3>
                    </div>
                    <p className="text-xs sm:text-sm" style={{ color: 'var(--text-secondary)' }}>
                      Commande #{commission.order_id}
                    </p>
                  </div>
                  <StatusBadge status={commission.status} />
                </div>

                {/* Details Grid */}
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <span className="text-xs" style={{ color: 'var(--text-muted)' }}>Montant commande</span>
                    <div className="text-sm font-semibold" style={{ color: 'var(--text-primary)' }}>
                      {commission.order_amount.toLocaleString()} F
                    </div>
                  </div>
                  <div>
                    <span className="text-xs" style={{ color: 'var(--text-muted)' }}>Taux commission</span>
                    <div className="text-sm font-semibold" style={{ color: 'var(--text-primary)' }}>
                      {(commission.commission_rate * 100).toFixed(0)}%
                    </div>
                  </div>
                  {commission.purchase_number && (
                    <div>
                      <span className="text-xs" style={{ color: 'var(--text-muted)' }}>Achat n°</span>
                      <div className="text-sm font-semibold" style={{ color: 'var(--text-primary)' }}>
                        {commission.purchase_number}
                      </div>
                    </div>
                  )}
                  <div>
                    <span className="text-xs" style={{ color: 'var(--text-muted)' }}>Date</span>
                    <div className="text-sm font-semibold" style={{ color: 'var(--text-primary)' }}>
                      {formatDateTimeBenin(commission.created_at).split(' à ')[0]}
                    </div>
                  </div>
                </div>

                {/* Commission Amount */}
                <div className="flex items-center justify-between pt-4 border-t" style={{ borderColor: 'var(--border-color)' }}>
                  <span className="text-sm font-medium" style={{ color: 'var(--text-muted)' }}>
                    Votre commission
                  </span>
                  <div className="flex items-center gap-2">
                    {commission.status === "approved" || commission.status === "paid" ? (
                      <CheckCircle className="w-4 h-4 text-green-500" />
                    ) : null}
                    <span className="text-lg font-bold" style={{ color: 'var(--success)' }}>
                      +{commission.amount.toLocaleString()} F
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      <BottomNav 
        isAffiliate={true}
        affiliateCode={stats?.promo_code}
      />
    </div>
  );
}
