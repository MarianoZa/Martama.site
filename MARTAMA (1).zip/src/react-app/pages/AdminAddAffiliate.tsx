import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { ArrowLeft, UserPlus, Send, CheckCircle, AlertCircle } from "lucide-react";
import AdminSidebar from "@/react-app/components/AdminSidebar";

export default function AdminAddAffiliate() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);
  
  const [formData, setFormData] = useState({
    email: "",
    promo_code: "",
  });

  useEffect(() => {
    const loadFont = () => {
      const link = document.createElement("link");
      link.href = "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap";
      link.rel = "stylesheet";
      document.head.appendChild(link);
    };
    loadFont();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setMessage(null);

    try {
      const response = await fetch("/api/admin/affiliates", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: formData.email,
          promo_code: formData.promo_code,
        }),
      });

      const data = await response.json();

      if (response.ok) {
        setMessage({
          type: 'success',
          text: `Affilié ajouté avec succès ! Lien d'affiliation: ${data.referral_link || 'N/A'}. Veuillez envoyer ce lien manuellement à ${formData.email}.`
        });
        // Reset form
        setFormData({
          email: "",
          promo_code: "",
        });
        setTimeout(() => navigate("/admin/affiliates"), 3000);
      } else {
        setMessage({
          type: 'error',
          text: data.error || "Erreur lors de l'ajout de l'affilié"
        });
      }
    } catch (error) {
      console.error("Failed to add affiliate:", error);
      setMessage({
        type: 'error',
        text: "Erreur lors de l'ajout de l'affilié"
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex" style={{ fontFamily: "'Outfit', sans-serif", backgroundColor: 'var(--bg-primary)' }}>
      <AdminSidebar />
      
      <div className="flex-1">
      <header className="px-6 py-6">
        <div className="flex items-center gap-4 mb-8">
          <button
            onClick={() => navigate("/admin/affiliates")}
            className="p-2 rounded-xl transition-colors hover:opacity-80"
            style={{ backgroundColor: 'var(--bg-secondary)' }}
          >
            <ArrowLeft className="w-6 h-6" style={{ color: 'var(--text-primary)' }} />
          </button>
          <div>
            <h1 className="text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>Ajouter un Affilié</h1>
            <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>Invitez un nouvel affilié directement</p>
          </div>
        </div>
      </header>

      <main className="px-6 pb-12 max-w-3xl mx-auto">
        {/* Note: Kept max-w-3xl here for form readability */}
        <div className="rounded-3xl border p-8" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
          <div className="w-16 h-16 rounded-2xl flex items-center justify-center mb-6 text-white" style={{ background: 'linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%)' }}>
            <UserPlus className="w-8 h-8" />
          </div>

          <h2 className="text-xl font-bold mb-2" style={{ color: 'var(--text-primary)' }}>Invitation d'Affilié</h2>
          <p className="mb-8" style={{ color: 'var(--text-secondary)' }}>
            Ajoutez un affilié en renseignant son email et son code promo. Les commissions sont définies au niveau de chaque produit ou via des codes exceptionnels.
          </p>

          {message && (
            <div className={`mb-6 p-4 rounded-xl border flex items-start gap-3 ${
              message.type === 'success'
                ? 'bg-green-500/10 border-green-500/30'
                : 'bg-red-500/10 border-red-500/30'
            }`}>
              {message.type === 'success' ? (
                <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
              ) : (
                <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
              )}
              <p className={message.type === 'success' ? 'text-green-300' : 'text-red-300'}>
                {message.text}
              </p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                Email de l'affilié *
              </label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                placeholder="exemple@email.com"
                required
                className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                style={{ 
                  backgroundColor: 'var(--bg-primary)', 
                  borderColor: 'var(--border-color)', 
                  color: 'var(--text-primary)',
                  '--tw-ring-color': 'var(--primary)'
                } as any}
              />
              <p className="text-xs mt-1" style={{ color: 'var(--text-muted)' }}>Vous devrez envoyer manuellement le lien d'affiliation à cette adresse</p>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                Code Promo *
              </label>
              <input
                type="text"
                value={formData.promo_code}
                onChange={(e) => setFormData({ ...formData, promo_code: e.target.value.toUpperCase() })}
                placeholder="MARTAMA2025"
                required
                maxLength={20}
                pattern="[A-Z0-9]+"
                className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2 uppercase font-mono"
                style={{ 
                  backgroundColor: 'var(--bg-primary)', 
                  borderColor: 'var(--border-color)', 
                  color: 'var(--text-primary)',
                  '--tw-ring-color': 'var(--primary)'
                } as any}
              />
              <p className="text-xs mt-1" style={{ color: 'var(--text-muted)' }}>Lettres majuscules et chiffres uniquement, 3-20 caractères</p>
            </div>

            <div className="rounded-xl border p-4" style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)', borderColor: 'rgba(139, 92, 246, 0.3)' }}>
              <h3 className="font-semibold mb-2" style={{ color: 'var(--text-primary)' }}>Lien de trafic généré:</h3>
              <p className="font-mono text-sm break-all" style={{ color: 'var(--text-secondary)' }}>
                {window.location.origin}/?ref={formData.promo_code || "CODE_PROMO"}
              </p>
            </div>

            <div className="flex gap-3 pt-4">
              <button
                type="submit"
                disabled={loading}
                className="flex-1 flex items-center justify-center gap-2 px-6 py-4 rounded-xl font-bold transition-colors disabled:opacity-50 text-white"
                style={{ backgroundColor: 'var(--primary)' }}
              >
                <Send className="w-5 h-5" />
                {loading ? "Ajout en cours..." : "Ajouter l'Affilié"}
              </button>
              <button
                type="button"
                onClick={() => navigate("/admin/affiliates")}
                className="px-6 py-4 rounded-xl font-semibold transition-colors"
                style={{ backgroundColor: 'var(--bg-secondary)', color: 'var(--text-primary)' }}
              >
                Annuler
              </button>
            </div>
          </form>
        </div>

        {/* Info Box */}
        <div className="mt-6 rounded-2xl border p-6" style={{ backgroundColor: 'rgba(59, 130, 246, 0.1)', borderColor: 'rgba(59, 130, 246, 0.3)' }}>
          <h3 className="font-semibold mb-3 flex items-center gap-2" style={{ color: 'var(--text-primary)' }}>
            <svg className="w-5 h-5 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            Comment ça marche ?
          </h3>
          <ul className="space-y-2 text-sm" style={{ color: 'var(--text-secondary)' }}>
            <li className="flex items-start gap-2">
              <span className="text-blue-400 mt-1">1.</span>
              <span>Vous ajoutez l'email et le code promo de l'affilié</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-blue-400 mt-1">2.</span>
              <span>Un lien de trafic unique est automatiquement généré</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-blue-400 mt-1">3.</span>
              <span>Vous devez envoyer manuellement le lien d'affiliation à l'affilié par email ou WhatsApp</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-blue-400 mt-1">4.</span>
              <span>L'affilié peut commencer à partager son lien et gagner des commissions selon les taux définis pour chaque produit</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-blue-400 mt-1">💡</span>
              <span className="font-semibold">Les commissions sont gérées au niveau de chaque produit ou via des codes exceptionnels</span>
            </li>
          </ul>
        </div>
      </main>
      </div>
    </div>
  );
}
