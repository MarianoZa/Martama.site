import { useEffect } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "@getmocha/users-service/react";
import { Loader2 } from "lucide-react";

export default function AuthCallback() {
  const navigate = useNavigate();
  const { exchangeCodeForSessionToken } = useAuth();

  useEffect(() => {
    const handleCallback = async () => {
      try {
        await exchangeCodeForSessionToken();
        
        // Check for post-auth redirect
        const redirectPath = localStorage.getItem('post_auth_redirect');
        if (redirectPath) {
          localStorage.removeItem('post_auth_redirect');
          navigate(redirectPath);
        } else {
          navigate("/dashboard");
        }
      } catch (error) {
        console.error("Authentication failed:", error);
        navigate("/");
      }
    };

    handleCallback();
  }, [exchangeCodeForSessionToken, navigate]);

  return (
    <div className="flex flex-col items-center justify-center min-h-screen" style={{ backgroundColor: 'var(--bg-primary)' }}>
      <div className="animate-spin mb-4">
        <Loader2 className="w-12 h-12" style={{ color: 'var(--primary)' }} />
      </div>
      <p className="text-lg" style={{ color: 'var(--text-primary)' }}>Connexion en cours...</p>
    </div>
  );
}
