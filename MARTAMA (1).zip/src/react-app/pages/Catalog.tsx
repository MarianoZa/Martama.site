import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import Header from "@/react-app/components/Header";
import { BookOpen, Package, Layers, Sparkles } from "lucide-react";
import type { Product } from "@/shared/types";

export default function Catalog() {
  const navigate = useNavigate();
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeCategory, setActiveCategory] = useState<string>("all");

  useEffect(() => {
    const loadFont = () => {
      const link = document.createElement("link");
      link.href = "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap";
      link.rel = "stylesheet";
      document.head.appendChild(link);
    };
    loadFont();
  }, []);

  useEffect(() => {
    fetchProducts();
  }, [activeCategory]);

  const fetchProducts = async () => {
    try {
      setLoading(true);
      const url = activeCategory === "all" 
        ? "/api/products" 
        : `/api/products?category=${activeCategory}`;
      const response = await fetch(url);
      const data = await response.json();
      setProducts(data);
    } catch (error) {
      console.error("Failed to fetch products:", error);
    } finally {
      setLoading(false);
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "formation": return <BookOpen className="w-5 h-5" />;
      case "abonnement": return <Layers className="w-5 h-5" />;
      case "pack": return <Package className="w-5 h-5" />;
      default: return <Sparkles className="w-5 h-5" />;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "formation": return "from-blue-500 to-cyan-500";
      case "abonnement": return "from-purple-500 to-pink-500";
      case "pack": return "from-orange-500 to-red-500";
      default: return "from-purple-500 to-pink-500";
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-indigo-900" style={{ fontFamily: "'Outfit', sans-serif" }}>
      <Header showBackButton onBack={() => navigate("/")} />

      {/* Content */}
      <main className="px-6 py-12 max-w-7xl mx-auto">
        <div className="mb-12">
          <h1 className="text-5xl font-bold text-white mb-4">Notre Catalogue</h1>
          <p className="text-xl text-purple-200">
            Découvrez nos formations, abonnements et packs premium
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex gap-3 mb-10 overflow-x-auto pb-2">
          <button
            onClick={() => setActiveCategory("all")}
            className={`px-6 py-3 rounded-xl font-semibold whitespace-nowrap transition-all duration-300 ${
              activeCategory === "all"
                ? "bg-white text-purple-900 shadow-lg"
                : "bg-white/10 text-white hover:bg-white/20 backdrop-blur-sm"
            }`}
          >
            Tout
          </button>
          <button
            onClick={() => setActiveCategory("formation")}
            className={`px-6 py-3 rounded-xl font-semibold whitespace-nowrap transition-all duration-300 ${
              activeCategory === "formation"
                ? "bg-white text-purple-900 shadow-lg"
                : "bg-white/10 text-white hover:bg-white/20 backdrop-blur-sm"
            }`}
          >
            Formations
          </button>
          <button
            onClick={() => setActiveCategory("abonnement")}
            className={`px-6 py-3 rounded-xl font-semibold whitespace-nowrap transition-all duration-300 ${
              activeCategory === "abonnement"
                ? "bg-white text-purple-900 shadow-lg"
                : "bg-white/10 text-white hover:bg-white/20 backdrop-blur-sm"
            }`}
          >
            Abonnements
          </button>
          <button
            onClick={() => setActiveCategory("pack")}
            className={`px-6 py-3 rounded-xl font-semibold whitespace-nowrap transition-all duration-300 ${
              activeCategory === "pack"
                ? "bg-white text-purple-900 shadow-lg"
                : "bg-white/10 text-white hover:bg-white/20 backdrop-blur-sm"
            }`}
          >
            Packs
          </button>
        </div>

        {/* Products Grid */}
        {loading ? (
          <div className="text-center py-20">
            <div className="inline-block w-12 h-12 border-4 border-white/20 border-t-white rounded-full animate-spin"></div>
          </div>
        ) : products.length === 0 ? (
          <div className="text-center py-20">
            <div className="w-20 h-20 bg-white/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <Package className="w-10 h-10 text-white/50" />
            </div>
            <p className="text-xl text-white/70">Aucun produit disponible pour le moment</p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {products.map((product) => (
              <div
                key={product.id}
                onClick={() => navigate(`/products/${product.id}`)}
                className="group bg-white/5 backdrop-blur-md rounded-3xl border border-white/10 overflow-hidden hover:bg-white/10 transition-all duration-300 hover:scale-105 cursor-pointer"
              >
                {product.image_url && (
                  <div className="aspect-video w-full overflow-hidden bg-gradient-to-br from-purple-600 to-pink-600">
                    <img
                      src={product.image_url}
                      alt={product.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                )}
                <div className="p-6">
                  <div className="flex items-center gap-2 mb-3">
                    <div className={`w-8 h-8 bg-gradient-to-br ${getCategoryColor(product.category)} rounded-lg flex items-center justify-center text-white`}>
                      {getCategoryIcon(product.category)}
                    </div>
                    <span className="text-sm font-medium text-purple-300 capitalize">
                      {product.category}
                    </span>
                  </div>
                  <h3 className="text-xl font-bold text-white mb-2 line-clamp-2">
                    {product.name}
                  </h3>
                  <p className="text-purple-200 text-sm mb-4 line-clamp-2">
                    {product.description}
                  </p>
                  <div className="flex items-center justify-between">
                    <div>
                      {product.price_1_months && (
                        <div className="text-2xl font-bold text-white">
                          {product.price_1_months.toLocaleString()} FCFA
                          <span className="text-sm text-purple-300 font-normal ml-1">/mois</span>
                        </div>
                      )}
                    </div>
                    <div className="text-purple-300 text-sm font-medium group-hover:text-white transition-colors">
                      Voir détails →
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
