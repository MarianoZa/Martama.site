import { useState, useEffect, useMemo } from "react";
import { useNavigate } from "react-router";
import Header from "@/react-app/components/Header";
import Footer from "@/react-app/components/Footer";
import ProductCard from "@/react-app/components/ProductCard";
import SEOHead from "@/react-app/components/SEOHead";
import AnnouncementBar from "@/react-app/components/AnnouncementBar";
import { Package } from "lucide-react";
import type { Product } from "@/shared/types";

export default function Catalog() {
  const navigate = useNavigate();
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeCategory, setActiveCategory] = useState<string>("all");

  useEffect(() => {
    const loadFont = () => {
      const link = document.createElement("link");
      link.href = "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap";
      link.rel = "stylesheet";
      link.media = "print";
      link.onload = function() { (this as any).media = "all"; };
      document.head.appendChild(link);
    };
    loadFont();
  }, []);

  useEffect(() => {
    fetchProducts();
  }, [activeCategory]);

  const fetchProducts = async () => {
    try {
      setLoading(true);
      const url = activeCategory === "all" 
        ? "/api/products" 
        : `/api/products?category=${activeCategory}`;
      const response = await fetch(url);
      const data = await response.json();
      setProducts(data);
    } catch (error) {
      console.error("Failed to fetch products:", error);
    } finally {
      setLoading(false);
    }
  };

  // Memoize filtered products to avoid unnecessary recalculations
  const filteredProducts = useMemo(() => {
    if (activeCategory === "all") return products;
    return products.filter(p => p.category === activeCategory);
  }, [products, activeCategory]);

  return (
    <div className="min-h-screen" style={{ fontFamily: "'Outfit', sans-serif", backgroundColor: 'var(--bg-primary)' }}>
      <SEOHead
        title="Catalogue"
        description="Découvrez notre catalogue complet de formations premium, abonnements et packs pour l'Afrique. Paiement Mobile Money accepté."
        url="https://martama.site/catalog"
      />
      <AnnouncementBar />
      <Header showBackButton onBack={() => navigate("/")} />

      {/* Content */}
      <main className="px-4 sm:px-6 py-8 sm:py-12 max-w-7xl mx-auto">
        <div className="mb-8 sm:mb-12">
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-3 sm:mb-4" style={{ color: 'var(--text-primary)' }}>Notre Catalogue</h1>
          <p className="text-base sm:text-lg lg:text-xl" style={{ color: 'var(--text-secondary)' }}>
            Découvrez nos formations, abonnements et packs premium
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex gap-2 sm:gap-3 mb-8 sm:mb-10 overflow-x-auto pb-2 scrollbar-hide">
          <button
            onClick={() => setActiveCategory("all")}
            className={`px-4 sm:px-6 py-2.5 sm:py-3 rounded-xl font-semibold whitespace-nowrap transition-all duration-300 text-sm sm:text-base ${
              activeCategory === "all"
                ? "text-white shadow-lg"
                : "hover:opacity-80"
            }`}
            style={{
              backgroundColor: activeCategory === "all" ? 'var(--primary)' : 'var(--gray-100)',
              color: activeCategory === "all" ? '#ffffff' : 'var(--text-primary)'
            }}
          >
            Tout
          </button>
          <button
            onClick={() => setActiveCategory("formation")}
            className={`px-4 sm:px-6 py-2.5 sm:py-3 rounded-xl font-semibold whitespace-nowrap transition-all duration-300 text-sm sm:text-base ${
              activeCategory === "formation"
                ? "text-white shadow-lg"
                : "hover:opacity-80"
            }`}
            style={{
              backgroundColor: activeCategory === "formation" ? 'var(--primary)' : 'var(--gray-100)',
              color: activeCategory === "formation" ? '#ffffff' : 'var(--text-primary)'
            }}
          >
            Formations
          </button>
          <button
            onClick={() => setActiveCategory("abonnement")}
            className={`px-4 sm:px-6 py-2.5 sm:py-3 rounded-xl font-semibold whitespace-nowrap transition-all duration-300 text-sm sm:text-base ${
              activeCategory === "abonnement"
                ? "text-white shadow-lg"
                : "hover:opacity-80"
            }`}
            style={{
              backgroundColor: activeCategory === "abonnement" ? 'var(--primary)' : 'var(--gray-100)',
              color: activeCategory === "abonnement" ? '#ffffff' : 'var(--text-primary)'
            }}
          >
            Abonnements
          </button>
          <button
            onClick={() => setActiveCategory("pack")}
            className={`px-4 sm:px-6 py-2.5 sm:py-3 rounded-xl font-semibold whitespace-nowrap transition-all duration-300 text-sm sm:text-base ${
              activeCategory === "pack"
                ? "text-white shadow-lg"
                : "hover:opacity-80"
            }`}
            style={{
              backgroundColor: activeCategory === "pack" ? 'var(--primary)' : 'var(--gray-100)',
              color: activeCategory === "pack" ? '#ffffff' : 'var(--text-primary)'
            }}
          >
            Packs
          </button>
        </div>

        {/* Products Grid */}
        {loading ? (
          <div className="text-center py-20">
            <div className="inline-block w-12 h-12 border-4 rounded-full animate-spin" style={{ borderColor: 'var(--gray-200)', borderTopColor: 'var(--primary)' }}></div>
          </div>
        ) : filteredProducts.length === 0 ? (
          <div className="text-center py-20">
            <div className="w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-4" style={{ backgroundColor: 'var(--gray-100)' }}>
              <Package className="w-10 h-10" style={{ color: 'var(--text-muted)' }} />
            </div>
            <p className="text-xl" style={{ color: 'var(--text-muted)' }}>Aucun produit disponible pour le moment</p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
}
