import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import Header from "@/react-app/components/Header";
import Footer from "@/react-app/components/Footer";
import SEOHead from "@/react-app/components/SEOHead";
import { 
  ShoppingCart, 
  LogIn, 
  Package, 
  CreditCard, 
  HelpCircle, 
  CheckCircle,
  MessageCircle,
  ChevronDown,
  ChevronUp
} from "lucide-react";

interface FAQItem {
  question: string;
  answer: string;
}

export default function HelpCenter() {
  const navigate = useNavigate();
  const [expandedFAQ, setExpandedFAQ] = useState<number | null>(null);

  useEffect(() => {
    const loadFont = () => {
      const link = document.createElement("link");
      link.href = "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap";
      link.rel = "stylesheet";
      document.head.appendChild(link);
    };
    loadFont();
  }, []);

  const faqs: FAQItem[] = [
    {
      question: "Comment puis-je payer mes abonnements ?",
      answer: "Nous acceptons plusieurs méthodes de paiement adaptées au marché africain : Mobile Money (Orange Money, MTN Money, Moov Money), Wave, et FedaPay. Le paiement est 100% sécurisé."
    },
    {
      question: "Combien de temps faut-il pour recevoir mon abonnement ?",
      answer: "Après validation de votre paiement, votre commande est généralement traitée en moins d'une heure ! Vous recevrez vos identifiants d'accès par email et vous pourrez aussi les retrouver dans votre espace personnel."
    },
    {
      question: "Que faire si je n'ai pas reçu mes accès ?",
      answer: "Vérifiez d'abord vos spams et votre espace personnel sur le site. Si vous ne trouvez toujours rien, contactez-nous immédiatement sur WhatsApp au +229 51 66 13 57."
    },
    {
      question: "Puis-je annuler mon abonnement ?",
      answer: "Oui, vous pouvez nous contacter pour toute demande d'annulation. Consultez notre politique de remboursement pour plus de détails sur les conditions."
    },
    {
      question: "Comment devenir affilié ?",
      answer: "Rendez-vous sur la page 'Devenir Affilié' et remplissez le formulaire de candidature. Notre équipe examinera votre demande et vous contactera sous 48 heures."
    },
    {
      question: "Les abonnements sont-ils partagés ?",
      answer: "Non, chaque abonnement est personnel et ne doit pas être partagé. Nous proposons des comptes individuels pour garantir la meilleure expérience possible."
    }
  ];

  const toggleFAQ = (index: number) => {
    setExpandedFAQ(expandedFAQ === index ? null : index);
  };

  return (
    <div className="min-h-screen" style={{ fontFamily: "'Outfit', sans-serif", backgroundColor: 'var(--bg-primary)' }}>
      <SEOHead
        title="Centre d'Aide"
        description="Trouvez toutes les réponses à vos questions sur l'utilisation de Martama, le processus d'achat, et plus encore."
        url="https://martama.site/help"
      />
      <Header showBackButton onBack={() => navigate("/")} />

      <main className="px-4 sm:px-6 py-8 sm:py-12 max-w-4xl mx-auto pb-24">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <div className="w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-6 text-white" style={{ background: 'linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%)' }}>
            <HelpCircle className="w-10 h-10" />
          </div>
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4" style={{ color: 'var(--text-primary)' }}>
            Centre d'Aide
          </h1>
          <p className="text-lg sm:text-xl" style={{ color: 'var(--text-secondary)' }}>
            Tout ce que vous devez savoir sur Martama
          </p>
        </div>

        {/* WhatsApp Support Banner */}
        <div className="rounded-2xl p-6 mb-12 border-2" style={{ 
          backgroundColor: 'rgba(37, 211, 102, 0.1)', 
          borderColor: '#25D366'
        }}>
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-full flex items-center justify-center flex-shrink-0" style={{ backgroundColor: '#25D366' }}>
              <MessageCircle className="w-7 h-7 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="text-lg font-bold mb-1" style={{ color: 'var(--text-primary)' }}>
                Besoin d'aide immédiate ?
              </h3>
              <p className="text-sm mb-2" style={{ color: 'var(--text-secondary)' }}>
                Notre équipe est disponible 24/7 sur WhatsApp
              </p>
              <a
                href="https://wa.me/22951661357?text=Bonjour%2C%20j%27ai%20besoin%20d%27aide"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-4 py-2 rounded-xl font-semibold text-white text-sm transition-all hover:opacity-90"
                style={{ backgroundColor: '#25D366' }}
              >
                <MessageCircle className="w-4 h-4" />
                Contacter sur WhatsApp
              </a>
            </div>
          </div>
        </div>

        {/* Guide d'utilisation */}
        <section className="mb-12">
          <h2 className="text-2xl sm:text-3xl font-bold mb-6" style={{ color: 'var(--text-primary)' }}>
            Guide d'Utilisation
          </h2>

          <div className="space-y-6">
            {/* Comment acheter */}
            <div className="rounded-2xl border p-6" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
              <div className="flex items-start gap-4 mb-4">
                <div className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 text-white" style={{ background: 'linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%)' }}>
                  <ShoppingCart className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2" style={{ color: 'var(--text-primary)' }}>
                    Comment acheter sur Martama ?
                  </h3>
                </div>
              </div>
              <ol className="space-y-3 pl-4">
                <li className="flex items-start gap-3">
                  <span className="w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 text-xs font-bold text-white" style={{ backgroundColor: 'var(--primary)' }}>1</span>
                  <span style={{ color: 'var(--text-secondary)' }}>Parcourez notre catalogue et choisissez le produit qui vous intéresse</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 text-xs font-bold text-white" style={{ backgroundColor: 'var(--primary)' }}>2</span>
                  <span style={{ color: 'var(--text-secondary)' }}>Sélectionnez la durée d'abonnement souhaitée (1, 3 ou 6 mois)</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 text-xs font-bold text-white" style={{ backgroundColor: 'var(--primary)' }}>3</span>
                  <span style={{ color: 'var(--text-secondary)' }}>Si vous avez un code promo, entrez-le pour bénéficier d'une réduction</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 text-xs font-bold text-white" style={{ backgroundColor: 'var(--primary)' }}>4</span>
                  <span style={{ color: 'var(--text-secondary)' }}>Cliquez sur "Commander maintenant" et remplissez vos informations</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 text-xs font-bold text-white" style={{ backgroundColor: 'var(--primary)' }}>5</span>
                  <span style={{ color: 'var(--text-secondary)' }}>Procédez au paiement via Mobile Money, Wave ou carte bancaire</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 text-xs font-bold text-white" style={{ backgroundColor: 'var(--primary)' }}>6</span>
                  <span style={{ color: 'var(--text-secondary)' }}>Recevez vos accès rapidement, généralement en moins d'une heure !</span>
                </li>
              </ol>
            </div>

            {/* Comment se connecter */}
            <div className="rounded-2xl border p-6" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
              <div className="flex items-start gap-4 mb-4">
                <div className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 text-white" style={{ background: 'linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%)' }}>
                  <LogIn className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2" style={{ color: 'var(--text-primary)' }}>
                    Comment se connecter ?
                  </h3>
                </div>
              </div>
              <div className="space-y-3 pl-4" style={{ color: 'var(--text-secondary)' }}>
                <p>
                  Martama utilise un système de connexion sécurisé. Voici comment cela fonctionne :
                </p>
                <ul className="space-y-2 list-disc pl-5">
                  <li>Cliquez sur le bouton "Connexion" en haut de la page</li>
                  <li>Puis sélectionnez l'adresse email que vous avez utilisée lors de votre commande pour vous connecter directement et accéder à toutes vos commandes</li>
                </ul>
              </div>
            </div>

            {/* Comment recevoir son abonnement */}
            <div className="rounded-2xl border p-6" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
              <div className="flex items-start gap-4 mb-4">
                <div className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 text-white" style={{ background: 'linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%)' }}>
                  <Package className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2" style={{ color: 'var(--text-primary)' }}>
                    Comment recevoir mon abonnement ?
                  </h3>
                </div>
              </div>
              <div className="space-y-3 pl-4" style={{ color: 'var(--text-secondary)' }}>
                <p>
                  Une fois votre paiement validé :
                </p>
                <ol className="space-y-2 list-decimal pl-5">
                  <li>Votre commande est traitée rapidement, généralement en moins d'une heure !</li>
                  <li>Vous recevez vos identifiants d'accès par email</li>
                  <li>Les identifiants sont également disponibles dans votre espace personnel (section "Mes Abonnements")</li>
                  <li>Suivez les instructions fournies pour activer votre abonnement</li>
                </ol>
                <div className="mt-4 p-4 rounded-xl border" style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)', borderColor: 'rgba(139, 92, 246, 0.3)' }}>
                  <p className="text-sm font-semibold mb-1" style={{ color: 'var(--primary)' }}>
                    <CheckCircle className="w-4 h-4 inline mr-1" />
                    Conseil
                  </p>
                  <p className="text-sm">
                    Vérifiez vos spams si vous ne recevez pas l'email rapidement. En cas de problème, contactez-nous immédiatement sur WhatsApp.
                  </p>
                </div>
              </div>
            </div>

            {/* Méthodes de paiement */}
            <div className="rounded-2xl border p-6" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
              <div className="flex items-start gap-4 mb-4">
                <div className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 text-white" style={{ background: 'linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%)' }}>
                  <CreditCard className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2" style={{ color: 'var(--text-primary)' }}>
                    Quelles méthodes de paiement acceptez-vous ?
                  </h3>
                </div>
              </div>
              <div className="space-y-3 pl-4" style={{ color: 'var(--text-secondary)' }}>
                <p>
                  Nous acceptons les méthodes de paiement les plus populaires en Afrique :
                </p>
                <div className="grid sm:grid-cols-2 gap-3 mt-4">
                  <div className="p-4 rounded-xl border" style={{ backgroundColor: 'var(--bg-primary)', borderColor: 'var(--border-color)' }}>
                    <p className="font-semibold mb-1" style={{ color: 'var(--text-primary)' }}>Mobile Money</p>
                    <p className="text-sm">Orange Money, MTN Money, Moov Money</p>
                  </div>
                  <div className="p-4 rounded-xl border" style={{ backgroundColor: 'var(--bg-primary)', borderColor: 'var(--border-color)' }}>
                    <p className="font-semibold mb-1" style={{ color: 'var(--text-primary)' }}>Portefeuilles Électroniques</p>
                    <p className="text-sm">Wave, FedaPay</p>
                  </div>
                  <div className="p-4 rounded-xl border" style={{ backgroundColor: 'var(--bg-primary)', borderColor: 'var(--border-color)' }}>
                    <p className="font-semibold mb-1" style={{ color: 'var(--text-primary)' }}>Cartes Bancaires</p>
                    <p className="text-sm">Visa, Mastercard</p>
                  </div>
                  <div className="p-4 rounded-xl border" style={{ backgroundColor: 'var(--bg-primary)', borderColor: 'var(--border-color)' }}>
                    <p className="font-semibold mb-1" style={{ color: 'var(--text-primary)' }}>Sécurité Garantie</p>
                    <p className="text-sm">Paiements 100% sécurisés</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* FAQ */}
        <section className="mb-12">
          <h2 className="text-2xl sm:text-3xl font-bold mb-6" style={{ color: 'var(--text-primary)' }}>
            Questions Fréquemment Posées
          </h2>

          <div className="space-y-3">
            {faqs.map((faq, index) => (
              <div
                key={index}
                className="rounded-2xl border overflow-hidden"
                style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}
              >
                <button
                  onClick={() => toggleFAQ(index)}
                  className="w-full p-6 flex items-center justify-between text-left transition-colors hover:opacity-80"
                >
                  <span className="font-semibold pr-4" style={{ color: 'var(--text-primary)' }}>
                    {faq.question}
                  </span>
                  {expandedFAQ === index ? (
                    <ChevronUp className="w-5 h-5 flex-shrink-0" style={{ color: 'var(--primary)' }} />
                  ) : (
                    <ChevronDown className="w-5 h-5 flex-shrink-0" style={{ color: 'var(--primary)' }} />
                  )}
                </button>
                {expandedFAQ === index && (
                  <div className="px-6 pb-6 pt-0">
                    <p className="leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
                      {faq.answer}
                    </p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </section>

        {/* Contact Section */}
        <section>
          <div className="rounded-2xl p-8 text-center" style={{ 
            background: 'linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%)'
          }}>
            <h2 className="text-2xl font-bold mb-3 text-white">
              Vous ne trouvez pas la réponse ?
            </h2>
            <p className="text-lg mb-6 text-white/90">
              Notre équipe est là pour vous aider 24/7
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="https://wa.me/22951661357?text=Bonjour%2C%20j%27ai%20besoin%20d%27aide"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl font-semibold transition-all hover:opacity-90"
                style={{ backgroundColor: '#25D366', color: 'white' }}
              >
                <MessageCircle className="w-5 h-5" />
                WhatsApp : +229 51 66 13 57
              </a>
              <a
                href="mailto:contact@martama.site"
                className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl font-semibold transition-all hover:opacity-90"
                style={{ backgroundColor: 'white', color: 'var(--primary)' }}
              >
                Email : contact@martama.site
              </a>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
