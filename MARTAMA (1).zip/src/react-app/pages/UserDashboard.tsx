import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "@getmocha/users-service/react";
import Header from "@/react-app/components/Header";
import { 
  Package, 
  TrendingUp, 
  Users, 
  Calendar,
  ArrowRight,
  CheckCircle,
  Clock,
  BookOpen
} from "lucide-react";

interface UserData {
  role: string;
  has_completed_onboarding: number;
}

interface Subscription {
  id: number;
  product_name: string;
  product_category: string;
  status: string;
  access_credentials: string | null;
  created_at: string;
  expires_at: string | null;
}

interface AffiliateStats {
  total_clicks: number;
  total_sales: number;
  total_commissions: number;
  balance: number;
  promo_code: string;
}

export default function UserDashboard() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [userData, setUserData] = useState<UserData | null>(null);
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
  const [affiliateStats, setAffiliateStats] = useState<AffiliateStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadFont = () => {
      const link = document.createElement("link");
      link.href = "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap";
      link.rel = "stylesheet";
      document.head.appendChild(link);
    };
    loadFont();
  }, []);

  useEffect(() => {
    if (user) {
      fetchUserData();
      fetchSubscriptions();
      checkAffiliateStatus();
    }
  }, [user]);

  const fetchUserData = async () => {
    try {
      const response = await fetch("/api/users/me");
      const data = await response.json();
      setUserData(data);
    } catch (error) {
      console.error("Failed to fetch user data:", error);
    }
  };

  const fetchSubscriptions = async () => {
    try {
      const response = await fetch("/api/subscriptions/my");
      if (response.ok) {
        const data = await response.json();
        setSubscriptions(data);
      }
    } catch (error) {
      console.error("Failed to fetch subscriptions:", error);
    } finally {
      setLoading(false);
    }
  };

  const checkAffiliateStatus = async () => {
    try {
      const response = await fetch("/api/affiliate/stats");
      if (response.ok) {
        const data = await response.json();
        setAffiliateStats(data);
      } else if (response.status === 404) {
        // User is not an affiliate - set explicitly to null
        setAffiliateStats(null);
      }
    } catch (error) {
      // User is not an affiliate
      setAffiliateStats(null);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "delivered": return "bg-green-500/20 text-green-300 border-green-500/30";
      case "paid": return "bg-blue-500/20 text-blue-300 border-blue-500/30";
      case "pending": return "bg-orange-500/20 text-orange-300 border-orange-500/30";
      default: return "bg-purple-500/20 text-purple-300 border-purple-500/30";
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-indigo-900 flex items-center justify-center">
        <div className="text-center">
          <p className="text-white text-xl mb-4">Veuillez vous connecter</p>
          <button
            onClick={() => navigate("/")}
            className="px-6 py-3 bg-white text-purple-900 rounded-xl font-semibold"
          >
            Retour à l'accueil
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-indigo-900" style={{ fontFamily: "'Outfit', sans-serif" }}>
      <Header showBackButton onBack={() => navigate("/")} />

      <main className="px-6 py-8 max-w-7xl mx-auto">
        {/* Welcome Section */}
        <div className="mb-12">
          <h1 className="text-4xl font-bold text-white mb-2">
            Bienvenue, {user.email?.split('@')[0]}
          </h1>
          <p className="text-purple-200 text-lg">Gérez vos abonnements et accédez à vos contenus</p>
        </div>

        {/* Quick Stats */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          <div className="bg-white/5 backdrop-blur-md rounded-3xl border border-white/10 p-6 hover:bg-white/10 transition-all">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-gradient-to-br from-purple-400 to-pink-500 rounded-2xl flex items-center justify-center">
                <Package className="w-6 h-6 text-white" />
              </div>
            </div>
            <div className="text-3xl font-bold text-white mb-1">
              {subscriptions.length}
            </div>
            <div className="text-purple-200 text-sm">Abonnements Actifs</div>
          </div>

          {affiliateStats && (
            <>
              <div className="bg-white/5 backdrop-blur-md rounded-3xl border border-white/10 p-6 hover:bg-white/10 transition-all">
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-green-400 to-green-600 rounded-2xl flex items-center justify-center">
                    <TrendingUp className="w-6 h-6 text-white" />
                  </div>
                </div>
                <div className="text-3xl font-bold text-white mb-1">
                  {affiliateStats.total_sales}
                </div>
                <div className="text-purple-200 text-sm">Ventes Affiliées</div>
              </div>

              <div className="bg-white/5 backdrop-blur-md rounded-3xl border border-white/10 p-6 hover:bg-white/10 transition-all">
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-400 to-blue-600 rounded-2xl flex items-center justify-center">
                    <Users className="w-6 h-6 text-white" />
                  </div>
                </div>
                <div className="text-3xl font-bold text-white mb-1">
                  {affiliateStats.balance.toLocaleString()} F
                </div>
                <div className="text-purple-200 text-sm">Solde Disponible</div>
              </div>
            </>
          )}
        </div>

        {/* Quick Actions */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-white mb-6">Actions Rapides</h2>
          <div className="grid md:grid-cols-3 gap-4">
            <button
              onClick={() => navigate("/catalog")}
              className="p-6 bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 hover:bg-white/10 transition-all text-left group"
            >
              <Package className="w-8 h-8 text-purple-300 mb-3 group-hover:text-white transition-colors" />
              <h3 className="text-lg font-semibold text-white mb-1">Découvrir le Catalogue</h3>
              <p className="text-purple-200 text-sm">Parcourir tous nos produits</p>
            </button>

            {affiliateStats === null && (
              <button
                onClick={() => navigate("/become-affiliate")}
                className="p-6 bg-gradient-to-br from-purple-500/20 to-pink-500/20 backdrop-blur-md rounded-2xl border border-purple-500/30 hover:border-purple-500/50 transition-all text-left group"
              >
                <TrendingUp className="w-8 h-8 text-purple-300 mb-3 group-hover:text-white transition-colors" />
                <h3 className="text-lg font-semibold text-white mb-1">Devenir Affilié</h3>
                <p className="text-purple-200 text-sm">Gagnez des commissions</p>
              </button>
            )}

            {affiliateStats && (
              <button
                onClick={() => navigate("/affiliate/dashboard")}
                className="p-6 bg-gradient-to-br from-purple-500/20 to-pink-500/20 backdrop-blur-md rounded-2xl border border-purple-500/30 hover:border-purple-500/50 transition-all text-left group"
              >
                <TrendingUp className="w-8 h-8 text-purple-300 mb-3 group-hover:text-white transition-colors" />
                <h3 className="text-lg font-semibold text-white mb-1">Tableau de Bord Affilié</h3>
                <p className="text-purple-200 text-sm">Voir vos statistiques</p>
              </button>
            )}

            {userData?.role === 'admin' && (
              <button
                onClick={() => navigate("/admin")}
                className="p-6 bg-gradient-to-br from-orange-500/20 to-red-500/20 backdrop-blur-md rounded-2xl border border-orange-500/30 hover:border-orange-500/50 transition-all text-left group"
              >
                <svg className="w-8 h-8 text-orange-300 mb-3 group-hover:text-white transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" />
                </svg>
                <h3 className="text-lg font-semibold text-white mb-1">Administration</h3>
                <p className="text-purple-200 text-sm">Gérer la plateforme</p>
              </button>
            )}
          </div>
        </div>

        {/* My Subscriptions */}
        <div>
          <h2 className="text-2xl font-bold text-white mb-6">Mes Abonnements</h2>
          {loading ? (
            <div className="text-center py-20">
              <div className="inline-block w-12 h-12 border-4 border-white/20 border-t-white rounded-full animate-spin"></div>
            </div>
          ) : subscriptions.length === 0 ? (
            <div className="bg-white/5 backdrop-blur-md rounded-3xl border border-white/10 p-12 text-center">
              <BookOpen className="w-16 h-16 text-white/30 mx-auto mb-4" />
              <p className="text-xl text-white/70 mb-4">Aucun abonnement actif</p>
              <button
                onClick={() => navigate("/catalog")}
                className="inline-flex items-center gap-2 px-6 py-3 bg-white text-purple-900 rounded-xl font-semibold hover:bg-purple-50 transition-all"
              >
                Découvrir nos offres
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {subscriptions.map((sub) => (
                <div
                  key={sub.id}
                  className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6 hover:bg-white/10 transition-all"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="text-xl font-bold text-white mb-1">{sub.product_name}</h3>
                      <p className="text-purple-200 text-sm capitalize">{sub.product_category}</p>
                    </div>
                    <div className={`px-3 py-1.5 rounded-full border flex items-center gap-2 ${getStatusColor(sub.status)}`}>
                      {sub.status === 'delivered' ? <CheckCircle className="w-4 h-4" /> : <Clock className="w-4 h-4" />}
                      <span className="text-sm font-medium capitalize">{sub.status}</span>
                    </div>
                  </div>

                  {sub.access_credentials && (
                    <div className="mb-4 p-4 bg-green-500/10 rounded-xl border border-green-500/20">
                      <p className="text-green-300 text-sm font-semibold mb-2">Identifiants d'accès :</p>
                      <p className="text-green-200 text-sm font-mono whitespace-pre-wrap">
                        {sub.access_credentials}
                      </p>
                    </div>
                  )}

                  <div className="flex items-center gap-4 text-sm text-purple-200">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4" />
                      <span>Souscrit le {new Date(sub.created_at).toLocaleDateString('fr-FR')}</span>
                    </div>
                    {sub.expires_at && (
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4" />
                        <span>Expire le {new Date(sub.expires_at).toLocaleDateString('fr-FR')}</span>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
