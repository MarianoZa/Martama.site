import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { useAdminPermissions } from "@/react-app/hooks/useAdminPermissions";
import { Plus, Edit, Trash2, Package, BookOpen, Layers, X, Search, Filter, MoreVertical, Download, Eye } from "lucide-react";
import BottomNav from "@/react-app/components/BottomNav";
import AdminSidebar from "@/react-app/components/AdminSidebar";
import StatusBadge from "@/react-app/components/StatusBadge";
import { useDebounce } from "@/react-app/hooks/useDebounce";

interface Product {
  id: number;
  name: string;
  description: string;
  category: string;
  service: string | null;
  price_1_months: number | null;
  price_3_months: number | null;
  price_6_months: number | null;
  price_options: string | null;
  client_discount_rate: number;
  affiliate_commission_rate: number;
  features: string | null;
  image_url: string | null;
  download_url: string | null;
  is_active: number;
  stock: number | null;
  total_sales: number;
}

interface PriceOption {
  months: number;
  price: string;
  lygos_payment_link?: string;
}

export default function AdminProducts() {
  const navigate = useNavigate();
  const { hasPermission, loading: permissionsLoading, getDefaultPage } = useAdminPermissions();
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [activeCategory, setActiveCategory] = useState("all");

  // Check permission and redirect if needed
  useEffect(() => {
    if (permissionsLoading) return;
    
    if (!hasPermission('manageProducts')) {
      navigate(getDefaultPage(), { replace: true });
    }
  }, [permissionsLoading, hasPermission, navigate, getDefaultPage]);
  const [searchQuery, setSearchQuery] = useState("");
  const debouncedSearchQuery = useDebounce(searchQuery, 300);
  const [activeProductMenu, setActiveProductMenu] = useState<number | null>(null);

  const [formData, setFormData] = useState({
    name: "",
    description: "",
    category: "abonnement",
    service: "",
    client_discount_rate: "10",
    affiliate_commission_rate: "15",
    features: "",
    image_url: "",
    download_url: "",
    usage_instructions: "",
    is_active: 1,
    stock: "",
    single_price: "",
  });

  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string>("");
  const [priceOptions, setPriceOptions] = useState<PriceOption[]>([{ months: 1, price: "" }]);
  
  // Pack file upload states
  const [packContentType, setPackContentType] = useState<"file" | "link">("file");
  const [selectedPackFile, setSelectedPackFile] = useState<File | null>(null);
  const [packFileInfo, setPackFileInfo] = useState<{ name: string; size: number } | null>(null);

  useEffect(() => {
    const loadFont = () => {
      const link = document.createElement("link");
      link.href = "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap";
      link.rel = "stylesheet";
      document.head.appendChild(link);
    };
    loadFont();
  }, []);

  useEffect(() => {
    fetchProducts();
  }, [activeCategory]);

  const fetchProducts = async () => {
    try {
      setLoading(true);
      const url = activeCategory === "all" 
        ? "/api/admin/products" 
        : `/api/admin/products?category=${activeCategory}`;
      const response = await fetch(url);
      
      if (response.status === 403) {
        navigate("/");
        return;
      }
      
      const data = await response.json();
      setProducts(data);
    } catch (error) {
      console.error("Failed to fetch products:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleOpenModal = (product?: Product) => {
    if (product) {
      setEditingProduct(product);
      setFormData({
        name: product.name,
        description: product.description || "",
        category: product.category,
        service: product.service || "",
        client_discount_rate: (product.client_discount_rate * 100).toString(),
        affiliate_commission_rate: (product.affiliate_commission_rate * 100).toString(),
        features: product.features || "",
        image_url: product.image_url || "",
        download_url: product.download_url || "",
        usage_instructions: (product as any).usage_instructions || "",
        is_active: product.is_active,
        stock: product.stock?.toString() || "",
        single_price: product.price_1_months?.toString() || "",
      });

      setImagePreview(product.image_url || "");
      setSelectedImage(null);

      if (product.category === "abonnement") {
        if (product.price_options) {
          try {
            const options = JSON.parse(product.price_options);
            setPriceOptions(options);
          } catch (e) {
            console.error("Failed to parse price_options:", e);
            setPriceOptions([{ months: 1, price: "" }]);
          }
        } else {
          const options: PriceOption[] = [];
          if (product.price_1_months) options.push({ months: 1, price: product.price_1_months.toString() });
          if (product.price_3_months) options.push({ months: 3, price: product.price_3_months.toString() });
          if (product.price_6_months) options.push({ months: 6, price: product.price_6_months.toString() });
          setPriceOptions(options.length > 0 ? options : [{ months: 1, price: "" }]);
        }
      } else {
        setPriceOptions([{ months: 1, price: "" }]);
      }
    } else {
      setEditingProduct(null);
      setFormData({
        name: "",
        description: "",
        category: "abonnement",
        service: "",
        client_discount_rate: "10",
        affiliate_commission_rate: "15",
        features: "",
        image_url: "",
        download_url: "",
        usage_instructions: "",
        is_active: 1,
        stock: "",
        single_price: "",
      });
      setPriceOptions([{ months: 1, price: "" }]);
      setSelectedImage(null);
      setImagePreview("");
      setSelectedPackFile(null);
      setPackFileInfo(null);
      setPackContentType("file");
    }
    setShowModal(true);
    setActiveProductMenu(null);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setEditingProduct(null);
    setSelectedImage(null);
    setImagePreview("");
    setSelectedPackFile(null);
    setPackFileInfo(null);
    setPackContentType("file");
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedImage(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handlePackFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Check file size (10MB max)
      const maxSize = 10 * 1024 * 1024;
      if (file.size > maxSize) {
        alert("Fichier trop volumineux. Taille maximale: 10 Mo");
        return;
      }
      
      setSelectedPackFile(file);
      setPackFileInfo({
        name: file.name,
        size: file.size
      });
    }
  };

  const addPriceOption = () => {
    setPriceOptions([...priceOptions, { months: 1, price: "" }]);
  };

  const removePriceOption = (index: number) => {
    if (priceOptions.length > 1) {
      setPriceOptions(priceOptions.filter((_, i) => i !== index));
    }
  };

  const updatePriceOption = (index: number, field: 'months' | 'price' | 'lygos_payment_link', value: string) => {
    const newOptions = [...priceOptions];
    if (field === 'months') {
      newOptions[index].months = parseInt(value) || 1;
    } else if (field === 'price') {
      newOptions[index].price = value;
    } else if (field === 'lygos_payment_link') {
      newOptions[index].lygos_payment_link = value;
    }
    setPriceOptions(newOptions);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      let imageUrl = formData.image_url;
      if (selectedImage) {
        const imageFormData = new FormData();
        imageFormData.append("image", selectedImage);
        
        const uploadResponse = await fetch("/api/admin/upload-image", {
          method: "POST",
          body: imageFormData,
        });
        
        if (uploadResponse.ok) {
          const uploadData = await uploadResponse.json();
          imageUrl = uploadData.url;
        } else {
          console.error("Failed to upload image");
          return;
        }
      }
      
      // Handle pack file upload
      let downloadUrl = formData.download_url;
      if (formData.category === "pack" && packContentType === "file" && selectedPackFile) {
        const fileFormData = new FormData();
        fileFormData.append("file", selectedPackFile);
        
        const uploadResponse = await fetch("/api/admin/upload-file", {
          method: "POST",
          body: fileFormData,
        });
        
        if (uploadResponse.ok) {
          const uploadData = await uploadResponse.json();
          downloadUrl = uploadData.url;
        } else {
          console.error("Failed to upload pack file");
          alert("Erreur lors de l'upload du fichier");
          return;
        }
      }
      
      let priceFields: any = {
        price_1_months: null,
        price_3_months: null,
        price_6_months: null,
        price_options: null,
      };

      if (formData.category === "abonnement") {
        const validOptions = priceOptions.filter(opt => {
          const price = parseFloat(opt.price);
          return !isNaN(price) && price >= 0 && opt.months > 0;
        });
        
        if (validOptions.length > 0) {
          priceFields.price_options = JSON.stringify(validOptions);
          validOptions.forEach(option => {
            const price = parseFloat(option.price);
            if (option.months === 1) priceFields.price_1_months = price;
            else if (option.months === 3) priceFields.price_3_months = price;
            else if (option.months === 6) priceFields.price_6_months = price;
          });
        }
      } else {
        const singlePrice = parseFloat(formData.single_price);
        if (!isNaN(singlePrice) && singlePrice >= 0) {
          priceFields.price_1_months = singlePrice;
          priceFields.price_options = JSON.stringify([{ months: 1, price: singlePrice.toString() }]);
        }
      }

      const payload = {
        name: formData.name,
        description: formData.description,
        category: formData.category,
        service: formData.service || null,
        ...priceFields,
        client_discount_rate: parseFloat(formData.client_discount_rate) / 100,
        affiliate_commission_rate: parseFloat(formData.affiliate_commission_rate) / 100,
        features: formData.features || null,
        image_url: imageUrl || null,
        download_url: downloadUrl || null,
        usage_instructions: formData.usage_instructions || null,
        is_active: formData.is_active,
        stock: formData.stock ? parseInt(formData.stock) : null,
      };

      const url = editingProduct 
        ? `/api/admin/products/${editingProduct.id}`
        : "/api/admin/products";
      
      const response = await fetch(url, {
        method: editingProduct ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (response.ok) {
        await fetchProducts();
        handleCloseModal();
      }
    } catch (error) {
      console.error("Failed to save product:", error);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Êtes-vous sûr de vouloir supprimer ce produit ?")) return;

    try {
      const response = await fetch(`/api/admin/products/${id}`, {
        method: "DELETE",
      });

      if (response.ok) {
        await fetchProducts();
      }
    } catch (error) {
      console.error("Failed to delete product:", error);
    }
    setActiveProductMenu(null);
  };

  const filteredProducts = products.filter(product => {
    const matchesCategory = activeCategory === "all" || product.category === activeCategory;
    const matchesSearch = product.name.toLowerCase().includes(debouncedSearchQuery.toLowerCase()) ||
                         product.description?.toLowerCase().includes(debouncedSearchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="min-h-screen flex" style={{ fontFamily: "'Outfit', sans-serif", backgroundColor: 'var(--bg-primary)' }}>
      <AdminSidebar />
      
      <div className="flex-1 pb-24 lg:pb-0">
      {/* Compact Header - Mobile First */}
      <header className="sticky top-0 z-30 px-4 py-4 border-b" style={{ backgroundColor: 'var(--bg-primary)', borderColor: 'var(--border-color)' }}>
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)' }}>
            <Package className="w-5 h-5" style={{ color: 'var(--primary)' }} />
          </div>
          <div className="flex-1">
            <h1 className="text-lg font-bold" style={{ color: 'var(--text-primary)' }}>Produits</h1>
            <p className="text-xs" style={{ color: 'var(--text-muted)' }}>{products.length} produits</p>
          </div>
        </div>

        {/* Big Yellow Add Button - Chariow Style */}
        <button
          onClick={() => handleOpenModal()}
          className="w-full py-3.5 rounded-xl font-bold text-base shadow-lg mb-4"
          style={{ backgroundColor: '#FFC107', color: '#000' }}
        >
          Ajouter un produit
        </button>

        {/* Search Bar */}
        <div className="relative mb-4">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5" style={{ color: 'var(--text-muted)' }} />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Rechercher"
            className="w-full pl-10 pr-12 py-3 border rounded-xl focus:outline-none"
            style={{ 
              backgroundColor: 'var(--bg-secondary)', 
              borderColor: 'var(--border-color)', 
              color: 'var(--text-primary)'
            }}
          />
          <button className="absolute right-3 top-1/2 -translate-y-1/2 p-1.5 rounded-lg" style={{ backgroundColor: 'var(--bg-primary)' }}>
            <Filter className="w-5 h-5" style={{ color: 'var(--text-muted)' }} />
          </button>
        </div>

        {/* Category Filter Pills - Chariow Style */}
        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
          <button
            onClick={() => setActiveCategory("all")}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-full font-semibold whitespace-nowrap text-sm transition-all ${
              activeCategory === "all" ? "shadow-md" : ""
            }`}
            style={{
              backgroundColor: activeCategory === "all" ? 'var(--gray-200)' : 'transparent',
              color: 'var(--text-primary)',
              border: activeCategory === "all" ? 'none' : '1px solid var(--border-color)'
            }}
          >
            <span className={`w-2.5 h-2.5 rounded-full ${activeCategory === "all" ? "bg-gray-600" : "bg-transparent border border-current"}`}></span>
            Tout
          </button>
          
          <button
            onClick={() => setActiveCategory("abonnement")}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-full font-semibold whitespace-nowrap text-sm transition-all ${
              activeCategory === "abonnement" ? "shadow-md" : ""
            }`}
            style={{
              backgroundColor: activeCategory === "abonnement" ? '#FFC107' : 'transparent',
              color: activeCategory === "abonnement" ? '#000' : 'var(--text-primary)',
              border: activeCategory === "abonnement" ? 'none' : '1px solid var(--border-color)'
            }}
          >
            <span className={`w-2.5 h-2.5 rounded-full ${activeCategory === "abonnement" ? "bg-yellow-800" : "bg-transparent border border-current"}`}></span>
            Abonnement
          </button>
          
          <button
            onClick={() => setActiveCategory("formation")}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-full font-semibold whitespace-nowrap text-sm transition-all ${
              activeCategory === "formation" ? "shadow-md" : ""
            }`}
            style={{
              backgroundColor: activeCategory === "formation" ? '#10b981' : 'transparent',
              color: activeCategory === "formation" ? '#fff' : 'var(--text-primary)',
              border: activeCategory === "formation" ? 'none' : '1px solid var(--border-color)'
            }}
          >
            <span className={`w-2.5 h-2.5 rounded-full ${activeCategory === "formation" ? "bg-green-700" : "bg-transparent border border-current"}`}></span>
            Formation
          </button>
          
          <button
            onClick={() => setActiveCategory("pack")}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-full font-semibold whitespace-nowrap text-sm transition-all ${
              activeCategory === "pack" ? "shadow-md" : ""
            }`}
            style={{
              backgroundColor: activeCategory === "pack" ? 'var(--primary)' : 'transparent',
              color: activeCategory === "pack" ? '#fff' : 'var(--text-primary)',
              border: activeCategory === "pack" ? 'none' : '1px solid var(--border-color)'
            }}
          >
            <span className={`w-2.5 h-2.5 rounded-full ${activeCategory === "pack" ? "bg-purple-700" : "bg-transparent border border-current"}`}></span>
            Pack
          </button>
        </div>
      </header>

      <main className="px-4 py-4">
        <h2 className="text-sm font-bold mb-3" style={{ color: 'var(--text-primary)' }}>Produit</h2>

        {loading ? (
          <div className="text-center py-20">
            <div className="inline-block w-12 h-12 border-4 rounded-full animate-spin" style={{ borderColor: 'var(--gray-200)', borderTopColor: 'var(--primary)' }}></div>
          </div>
        ) : filteredProducts.length === 0 ? (
          <div className="text-center py-20">
            <Package className="w-16 h-16 mx-auto mb-4 opacity-30" style={{ color: 'var(--text-muted)' }} />
            <p className="text-sm" style={{ color: 'var(--text-muted)' }}>Aucun produit</p>
          </div>
        ) : (
          <div className="space-y-3">
            {filteredProducts.map((product) => (
              <div
                key={product.id}
                className="border rounded-2xl p-4 flex items-center gap-3 relative"
                style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}
              >
                {/* Product Image/Icon */}
                <div className="w-12 h-12 rounded-xl flex-shrink-0 overflow-hidden" style={{ backgroundColor: 'var(--gray-100)' }}>
                  {product.image_url ? (
                    <img src={product.image_url} alt={product.name} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      {product.category === "formation" ? (
                        <BookOpen className="w-6 h-6" style={{ color: 'var(--text-muted)' }} />
                      ) : product.category === "pack" ? (
                        <Layers className="w-6 h-6" style={{ color: 'var(--text-muted)' }} />
                      ) : (
                        <Package className="w-6 h-6" style={{ color: 'var(--text-muted)' }} />
                      )}
                    </div>
                  )}
                </div>

                {/* Product Info */}
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-sm mb-0.5 truncate" style={{ color: 'var(--text-primary)' }}>
                    {product.name}
                  </h3>
                  <p className="text-xs mb-1" style={{ color: 'var(--text-muted)' }}>
                    {product.price_1_months ? `${product.price_1_months.toLocaleString()} FCFA` : '0 FCFA'}
                  </p>
                </div>

                {/* Download Icon */}
                {product.download_url && (
                  <button className="p-2 rounded-lg transition-colors" style={{ backgroundColor: 'var(--bg-primary)' }}>
                    <Download className="w-4 h-4" style={{ color: 'var(--text-muted)' }} />
                  </button>
                )}

                {/* Status Badge */}
                <StatusBadge status={product.is_active === 1 ? "active" : "cancelled"} size="sm" />

                {/* Menu Button */}
                <button 
                  onClick={() => setActiveProductMenu(activeProductMenu === product.id ? null : product.id)}
                  className="p-2 rounded-lg transition-colors"
                  style={{ backgroundColor: 'var(--bg-primary)' }}
                >
                  <MoreVertical className="w-5 h-5" style={{ color: 'var(--text-primary)' }} />
                </button>

                {/* Dropdown Menu */}
                {activeProductMenu === product.id && (
                  <>
                    <div 
                      className="fixed inset-0 z-40" 
                      onClick={() => setActiveProductMenu(null)}
                    />
                    <div 
                      className="absolute right-4 top-16 z-50 rounded-2xl border shadow-xl overflow-hidden min-w-[180px]"
                      style={{ backgroundColor: 'var(--bg-primary)', borderColor: 'var(--border-color)' }}
                    >
                      <button
                        onClick={() => {
                          navigate(`/product/${product.id}`);
                          setActiveProductMenu(null);
                        }}
                        className="w-full px-4 py-3 text-left text-sm font-medium flex items-center gap-2 hover:opacity-80 transition-opacity"
                        style={{ color: 'var(--info)' }}
                      >
                        <Eye className="w-4 h-4" />
                        Voir
                      </button>
                      <button
                        onClick={() => handleOpenModal(product)}
                        className="w-full px-4 py-3 text-left text-sm font-medium flex items-center gap-2 hover:opacity-80 transition-opacity border-t"
                        style={{ color: 'var(--text-primary)', borderColor: 'var(--border-color)' }}
                      >
                        <Edit className="w-4 h-4" />
                        Modifier
                      </button>
                      <button
                        onClick={() => handleDelete(product.id)}
                        className="w-full px-4 py-3 text-left text-sm font-medium flex items-center gap-2 hover:opacity-80 transition-opacity border-t"
                        style={{ color: 'var(--error)', borderColor: 'var(--border-color)' }}
                      >
                        <Trash2 className="w-4 h-4" />
                        Supprimer
                      </button>
                    </div>
                  </>
                )}
              </div>
            ))}
          </div>
        )}
      </main>

      <BottomNav userRole="admin" />
      </div>

      {/* Product Modal - Keep existing modal code */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-end sm:items-center justify-center z-[60] overflow-y-auto">
          <div 
            className="rounded-t-3xl sm:rounded-3xl border w-full sm:max-w-3xl sm:my-8 max-h-[90vh] overflow-y-auto" 
            style={{ backgroundColor: 'var(--bg-primary)', borderColor: 'var(--border-color)' }}
          >
            <div className="sticky top-0 z-10 p-6 border-b flex items-center justify-between" style={{ backgroundColor: 'var(--bg-primary)', borderColor: 'var(--border-color)' }}>
              <h3 className="text-xl font-bold" style={{ color: 'var(--text-primary)' }}>
                {editingProduct ? "Modifier" : "Nouveau produit"}
              </h3>
              <button
                onClick={handleCloseModal}
                className="p-2 hover:opacity-80 rounded-xl transition-opacity"
                style={{ backgroundColor: 'var(--bg-secondary)' }}
              >
                <X className="w-6 h-6" style={{ color: 'var(--text-primary)' }} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-6">
              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                  Nom du produit *
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                  placeholder="Ex: ChatGPT Premium"
                  className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                  style={{ 
                    backgroundColor: 'var(--bg-secondary)', 
                    borderColor: 'var(--border-color)', 
                    color: 'var(--text-primary)',
                    '--tw-ring-color': 'var(--primary)'
                  } as any}
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                  Type de produit *
                </label>
                <select
                  value={formData.category}
                  onChange={(e) => {
                    setFormData({ ...formData, category: e.target.value });
                    if (e.target.value !== "abonnement") {
                      setPriceOptions([{ months: 1, price: "" }]);
                    }
                  }}
                  className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                  style={{ 
                    backgroundColor: 'var(--bg-secondary)', 
                    borderColor: 'var(--border-color)', 
                    color: 'var(--text-primary)',
                    '--tw-ring-color': 'var(--primary)'
                  } as any}
                >
                  <option value="abonnement">Abonnement</option>
                  <option value="formation">Formation</option>
                  <option value="pack">Pack / Ebook</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                  Description
                </label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  rows={3}
                  placeholder="Décrivez les fonctionnalités"
                  className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                  style={{ 
                    backgroundColor: 'var(--bg-secondary)', 
                    borderColor: 'var(--border-color)', 
                    color: 'var(--text-primary)',
                    '--tw-ring-color': 'var(--primary)'
                  } as any}
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                  Image du produit
                </label>
                <div className="space-y-3">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageSelect}
                    className="w-full px-4 py-3 border rounded-xl focus:outline-none text-sm"
                    style={{ 
                      backgroundColor: 'var(--bg-secondary)', 
                      borderColor: 'var(--border-color)', 
                      color: 'var(--text-primary)'
                    }}
                  />
                  {imagePreview && (
                    <div className="relative w-full aspect-video rounded-xl overflow-hidden border" style={{ borderColor: 'var(--border-color)' }}>
                      <img src={imagePreview} alt="Aperçu" className="w-full h-full object-cover" />
                    </div>
                  )}
                </div>
              </div>

              {formData.category === "abonnement" && (
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                    Nom du service
                  </label>
                  <input
                    type="text"
                    value={formData.service}
                    onChange={(e) => setFormData({ ...formData, service: e.target.value })}
                    placeholder="Ex: ChatGPT, Netflix..."
                    className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                    style={{ 
                      backgroundColor: 'var(--bg-secondary)', 
                      borderColor: 'var(--border-color)', 
                      color: 'var(--text-primary)',
                      '--tw-ring-color': 'var(--primary)'
                    } as any}
                  />
                </div>
              )}

              {/* Pack Content Type Selection */}
              {formData.category === "pack" && (
                <div className="border rounded-xl p-4 space-y-4" style={{ borderColor: 'var(--border-color)', backgroundColor: 'var(--bg-secondary)' }}>
                  <h4 className="text-base font-semibold mb-3" style={{ color: 'var(--text-primary)' }}>
                    📦 Contenu du Pack
                  </h4>
                  
                  {/* Content Type Toggle */}
                  <div className="flex gap-3">
                    <button
                      type="button"
                      onClick={() => setPackContentType("file")}
                      className={`flex-1 py-3 px-4 rounded-xl font-semibold text-sm transition-all ${
                        packContentType === "file" ? "shadow-md" : ""
                      }`}
                      style={{
                        backgroundColor: packContentType === "file" ? 'var(--primary)' : 'var(--bg-primary)',
                        color: packContentType === "file" ? '#fff' : 'var(--text-primary)',
                        border: `1px solid ${packContentType === "file" ? 'transparent' : 'var(--border-color)'}`
                      }}
                    >
                      📁 Fichier téléchargeable
                    </button>
                    <button
                      type="button"
                      onClick={() => setPackContentType("link")}
                      className={`flex-1 py-3 px-4 rounded-xl font-semibold text-sm transition-all ${
                        packContentType === "link" ? "shadow-md" : ""
                      }`}
                      style={{
                        backgroundColor: packContentType === "link" ? 'var(--primary)' : 'var(--bg-primary)',
                        color: packContentType === "link" ? '#fff' : 'var(--text-primary)',
                        border: `1px solid ${packContentType === "link" ? 'transparent' : 'var(--border-color)'}`
                      }}
                    >
                      🔗 Lien externe
                    </button>
                  </div>

                  {/* File Upload */}
                  {packContentType === "file" && (
                    <div>
                      <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                        Fichier (PDF, DOCX, ZIP - Max 10 Mo)
                      </label>
                      <input
                        type="file"
                        accept=".pdf,.docx,.doc,.zip"
                        onChange={handlePackFileSelect}
                        className="w-full px-4 py-3 border rounded-xl focus:outline-none text-sm"
                        style={{ 
                          backgroundColor: 'var(--bg-primary)', 
                          borderColor: 'var(--border-color)', 
                          color: 'var(--text-primary)'
                        }}
                      />
                      {packFileInfo && (
                        <div className="mt-2 p-3 rounded-lg" style={{ backgroundColor: 'var(--bg-primary)' }}>
                          <p className="text-sm font-medium" style={{ color: 'var(--text-primary)' }}>
                            📄 {packFileInfo.name}
                          </p>
                          <p className="text-xs mt-1" style={{ color: 'var(--text-muted)' }}>
                            {(packFileInfo.size / 1024 / 1024).toFixed(2)} Mo
                          </p>
                        </div>
                      )}
                      {formData.download_url && !selectedPackFile && (
                        <div className="mt-2 p-3 rounded-lg border" style={{ backgroundColor: 'var(--bg-primary)', borderColor: 'var(--success)' }}>
                          <p className="text-xs font-medium" style={{ color: 'var(--success)' }}>
                            ✓ Fichier actuel: {formData.download_url.split('/').pop()}
                          </p>
                        </div>
                      )}
                    </div>
                  )}

                  {/* External Link */}
                  {packContentType === "link" && (
                    <div>
                      <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                        Lien de téléchargement
                      </label>
                      <input
                        type="url"
                        value={formData.download_url}
                        onChange={(e) => setFormData({ ...formData, download_url: e.target.value })}
                        placeholder="https://drive.google.com/..."
                        className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2 font-mono text-sm"
                        style={{ 
                          backgroundColor: 'var(--bg-primary)', 
                          borderColor: 'var(--border-color)', 
                          color: 'var(--text-primary)',
                          '--tw-ring-color': 'var(--primary)'
                        } as any}
                      />
                      <p className="text-xs mt-1.5" style={{ color: 'var(--text-muted)' }}>
                        💡 Utilisez des liens Google Drive, Dropbox, etc.
                      </p>
                    </div>
                  )}
                </div>
              )}

              {/* Formation Module Builder */}
              {formData.category === "formation" && (
                <div className="border rounded-xl p-4 space-y-4" style={{ borderColor: 'var(--border-color)', backgroundColor: 'var(--bg-secondary)' }}>
                  <div className="flex items-center justify-between">
                    <h4 className="text-base font-semibold" style={{ color: 'var(--text-primary)' }}>
                      🎓 Modules et Vidéos
                    </h4>
                    {editingProduct && (
                      <button
                        type="button"
                        onClick={() => navigate(`/admin/formation/${editingProduct.id}`)}
                        className="px-4 py-2 rounded-lg font-medium text-sm text-white"
                        style={{ backgroundColor: 'var(--primary)' }}
                      >
                        Gérer les modules
                      </button>
                    )}
                  </div>
                  
                  {!editingProduct && (
                    <div className="p-4 rounded-lg text-center" style={{ backgroundColor: 'var(--bg-primary)' }}>
                      <BookOpen className="w-12 h-12 mx-auto mb-2" style={{ color: 'var(--text-muted)' }} />
                      <p className="text-sm font-medium mb-1" style={{ color: 'var(--text-primary)' }}>
                        Créez d'abord la formation
                      </p>
                      <p className="text-xs" style={{ color: 'var(--text-muted)' }}>
                        Vous pourrez ajouter des modules et des vidéos YouTube/Vimeo après la création
                      </p>
                    </div>
                  )}

                  {editingProduct && (
                    <div className="space-y-3">
                      <div className="p-3 rounded-lg" style={{ backgroundColor: 'var(--bg-primary)' }}>
                        <p className="text-sm mb-2" style={{ color: 'var(--text-primary)' }}>
                          <strong>Fonctionnalités disponibles:</strong>
                        </p>
                        <ul className="text-xs space-y-1" style={{ color: 'var(--text-muted)' }}>
                          <li>✓ Créer des modules de formation</li>
                          <li>✓ Ajouter des vidéos YouTube/Vimeo (unlisted)</li>
                          <li>✓ Choisir le ratio d'aspect (16:9, 9:16, 1:1, etc.)</li>
                          <li>✓ Ajouter des ressources téléchargeables par leçon</li>
                          <li>✓ Réorganiser les modules et vidéos</li>
                        </ul>
                      </div>
                      
                      <div className="p-3 rounded-lg border-2 border-dashed text-center" style={{ borderColor: 'var(--primary)' }}>
                        <p className="text-xs font-medium" style={{ color: 'var(--primary)' }}>
                          💡 Cliquez sur "Gérer les modules" pour construire votre formation
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {formData.category === "abonnement" ? (
                <div className="border rounded-xl p-4" style={{ borderColor: 'var(--border-color)', backgroundColor: 'var(--bg-secondary)' }}>
                  <div className="flex items-center justify-between mb-4">
                    <h4 className="text-base font-semibold" style={{ color: 'var(--text-primary)' }}>Options d'abonnement</h4>
                    <button
                      type="button"
                      onClick={addPriceOption}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium text-sm text-white"
                      style={{ backgroundColor: 'var(--success)' }}
                    >
                      <Plus className="w-4 h-4" />
                      Ajouter
                    </button>
                  </div>
                  
                  <div className="space-y-3">
                    {priceOptions.map((option, index) => (
                      <div key={index} className="border rounded-xl p-3" style={{ borderColor: 'var(--border-color)', backgroundColor: 'var(--bg-primary)' }}>
                        <div className="grid grid-cols-2 gap-3 mb-3">
                          <div>
                            <label className="block text-xs font-medium mb-1.5" style={{ color: 'var(--text-muted)' }}>
                              Mois
                            </label>
                            <input
                              type="number"
                              min="1"
                              value={option.months}
                              onChange={(e) => updatePriceOption(index, 'months', e.target.value)}
                              className="w-full px-3 py-2 border rounded-lg focus:outline-none text-sm"
                              style={{ 
                                backgroundColor: 'var(--bg-secondary)', 
                                borderColor: 'var(--border-color)', 
                                color: 'var(--text-primary)'
                              }}
                            />
                          </div>
                          <div>
                            <label className="block text-xs font-medium mb-1.5" style={{ color: 'var(--text-muted)' }}>
                              Prix (FCFA)
                            </label>
                            <input
                              type="number"
                              min="0"
                              value={option.price}
                              onChange={(e) => updatePriceOption(index, 'price', e.target.value)}
                              className="w-full px-3 py-2 border rounded-lg focus:outline-none text-sm"
                              style={{ 
                                backgroundColor: 'var(--bg-secondary)', 
                                borderColor: 'var(--border-color)', 
                                color: 'var(--text-primary)'
                              }}
                            />
                          </div>
                        </div>
                        <div className="mb-3">
                          <label className="block text-xs font-medium mb-1.5" style={{ color: 'var(--text-muted)' }}>
                            Lien Lygos (optionnel)
                          </label>
                          <input
                            type="url"
                            value={option.lygos_payment_link || ''}
                            onChange={(e) => updatePriceOption(index, 'lygos_payment_link', e.target.value)}
                            placeholder="https://lygos.co/pay/..."
                            className="w-full px-3 py-2 border rounded-lg focus:outline-none text-xs font-mono"
                            style={{ 
                              backgroundColor: 'var(--bg-secondary)', 
                              borderColor: 'var(--border-color)', 
                              color: 'var(--text-primary)'
                            }}
                          />
                        </div>
                        {priceOptions.length > 1 && (
                          <button
                            type="button"
                            onClick={() => removePriceOption(index)}
                            className="w-full py-2 border rounded-lg text-xs font-medium transition-colors"
                            style={{ backgroundColor: 'rgba(239, 68, 68, 0.1)', color: 'var(--error)', borderColor: 'rgba(239, 68, 68, 0.3)' }}
                          >
                            Supprimer
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                    Prix (FCFA) *
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={formData.single_price}
                    onChange={(e) => setFormData({ ...formData, single_price: e.target.value })}
                    required
                    placeholder="Ex: 5000 (ou 0 pour gratuit)"
                    className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                    style={{ 
                      backgroundColor: 'var(--bg-secondary)', 
                      borderColor: 'var(--border-color)', 
                      color: 'var(--text-primary)',
                      '--tw-ring-color': 'var(--primary)'
                    } as any}
                  />
                  <p className="text-xs mt-1.5" style={{ color: 'var(--text-muted)' }}>
                    💡 Entrez 0 pour offrir ce produit gratuitement
                  </p>
                </div>
              )}

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                    Réduction (%) *
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="100"
                    value={formData.client_discount_rate}
                    onChange={(e) => setFormData({ ...formData, client_discount_rate: e.target.value })}
                    required
                    className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                    style={{ 
                      backgroundColor: 'var(--bg-secondary)', 
                      borderColor: 'var(--border-color)', 
                      color: 'var(--text-primary)',
                      '--tw-ring-color': 'var(--primary)'
                    } as any}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                    Commission (%) *
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="100"
                    value={formData.affiliate_commission_rate}
                    onChange={(e) => setFormData({ ...formData, affiliate_commission_rate: e.target.value })}
                    required
                    className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                    style={{ 
                      backgroundColor: 'var(--bg-secondary)', 
                      borderColor: 'var(--border-color)', 
                      color: 'var(--text-primary)',
                      '--tw-ring-color': 'var(--primary)'
                    } as any}
                  />
                </div>
              </div>

              <div className="flex items-center gap-3">
                <input
                  type="checkbox"
                  id="is_active"
                  checked={formData.is_active === 1}
                  onChange={(e) => setFormData({ ...formData, is_active: e.target.checked ? 1 : 0 })}
                  className="w-5 h-5 rounded"
                />
                <label htmlFor="is_active" className="font-medium text-sm" style={{ color: 'var(--text-primary)' }}>
                  Produit actif (visible dans le catalogue)
                </label>
              </div>

              <div className="flex gap-3 pt-4 border-t" style={{ borderColor: 'var(--border-color)' }}>
                <button
                  type="submit"
                  className="flex-1 px-6 py-3.5 rounded-xl font-bold text-base shadow-lg"
                  style={{ backgroundColor: '#FFC107', color: '#000' }}
                >
                  {editingProduct ? "Mettre à jour" : "Créer"}
                </button>
                <button
                  type="button"
                  onClick={handleCloseModal}
                  className="px-6 py-3.5 rounded-xl font-semibold text-sm"
                  style={{ backgroundColor: 'var(--bg-secondary)', color: 'var(--text-primary)' }}
                >
                  Annuler
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
