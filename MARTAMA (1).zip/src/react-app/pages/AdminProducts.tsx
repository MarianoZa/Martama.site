import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { ArrowLeft, Plus, Edit, Trash2, Package, BookOpen, Layers, X } from "lucide-react";

interface Product {
  id: number;
  name: string;
  description: string;
  category: string;
  service: string | null;
  price_1_months: number | null;
  price_3_months: number | null;
  price_6_months: number | null;
  client_discount_rate: number;
  affiliate_commission_rate: number;
  features: string | null;
  image_url: string | null;
  download_url: string | null;
  is_active: number;
  stock: number | null;
  total_sales: number;
}

export default function AdminProducts() {
  const navigate = useNavigate();
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [activeCategory, setActiveCategory] = useState("all");

  const [formData, setFormData] = useState({
    name: "",
    description: "",
    category: "abonnement",
    service: "",
    price_1_months: "",
    price_3_months: "",
    price_6_months: "",
    client_discount_rate: "0",
    affiliate_commission_rate: "0",
    features: "",
    image_url: "",
    download_url: "",
    is_active: 1,
    stock: "",
  });

  useEffect(() => {
    const loadFont = () => {
      const link = document.createElement("link");
      link.href = "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap";
      link.rel = "stylesheet";
      document.head.appendChild(link);
    };
    loadFont();
  }, []);

  useEffect(() => {
    fetchProducts();
  }, [activeCategory]);

  const fetchProducts = async () => {
    try {
      setLoading(true);
      const url = activeCategory === "all" 
        ? "/api/admin/products" 
        : `/api/admin/products?category=${activeCategory}`;
      const response = await fetch(url);
      
      if (response.status === 403) {
        navigate("/");
        return;
      }
      
      const data = await response.json();
      setProducts(data);
    } catch (error) {
      console.error("Failed to fetch products:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleOpenModal = (product?: Product) => {
    if (product) {
      setEditingProduct(product);
      setFormData({
        name: product.name,
        description: product.description || "",
        category: product.category,
        service: product.service || "",
        price_1_months: product.price_1_months?.toString() || "",
        price_3_months: product.price_3_months?.toString() || "",
        price_6_months: product.price_6_months?.toString() || "",
        client_discount_rate: (product.client_discount_rate * 100).toString(),
        affiliate_commission_rate: (product.affiliate_commission_rate * 100).toString(),
        features: product.features || "",
        image_url: product.image_url || "",
        download_url: product.download_url || "",
        is_active: product.is_active,
        stock: product.stock?.toString() || "",
      });
    } else {
      setEditingProduct(null);
      setFormData({
        name: "",
        description: "",
        category: "abonnement",
        service: "",
        price_1_months: "",
        price_3_months: "",
        price_6_months: "",
        client_discount_rate: "10",
        affiliate_commission_rate: "15",
        features: "",
        image_url: "",
        download_url: "",
        is_active: 1,
        stock: "",
      });
    }
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setEditingProduct(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const payload = {
      name: formData.name,
      description: formData.description,
      category: formData.category,
      service: formData.service || null,
      price_1_months: formData.price_1_months ? parseFloat(formData.price_1_months) : null,
      price_3_months: formData.price_3_months ? parseFloat(formData.price_3_months) : null,
      price_6_months: formData.price_6_months ? parseFloat(formData.price_6_months) : null,
      client_discount_rate: parseFloat(formData.client_discount_rate) / 100,
      affiliate_commission_rate: parseFloat(formData.affiliate_commission_rate) / 100,
      features: formData.features || null,
      image_url: formData.image_url || null,
      download_url: formData.download_url || null,
      is_active: formData.is_active,
      stock: formData.stock ? parseInt(formData.stock) : null,
    };

    try {
      const url = editingProduct 
        ? `/api/admin/products/${editingProduct.id}`
        : "/api/admin/products";
      
      const response = await fetch(url, {
        method: editingProduct ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (response.ok) {
        await fetchProducts();
        handleCloseModal();
      }
    } catch (error) {
      console.error("Failed to save product:", error);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Êtes-vous sûr de vouloir supprimer ce produit ?")) return;

    try {
      const response = await fetch(`/api/admin/products/${id}`, {
        method: "DELETE",
      });

      if (response.ok) {
        await fetchProducts();
      }
    } catch (error) {
      console.error("Failed to delete product:", error);
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "formation": return <BookOpen className="w-5 h-5" />;
      case "abonnement": return <Layers className="w-5 h-5" />;
      case "pack": return <Package className="w-5 h-5" />;
      default: return <Package className="w-5 h-5" />;
    }
  };

  const filteredProducts = activeCategory === "all" 
    ? products 
    : products.filter(p => p.category === activeCategory);

  const stats = {
    total: products.length,
    active: products.filter(p => p.is_active === 1).length,
    formations: products.filter(p => p.category === "formation").length,
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-indigo-900" style={{ fontFamily: "'Outfit', sans-serif" }}>
      <header className="px-6 py-6 max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate("/admin")}
              className="p-2 hover:bg-white/10 rounded-xl transition-colors"
            >
              <ArrowLeft className="w-6 h-6 text-white" />
            </button>
            <div>
              <h1 className="text-2xl font-bold text-white">Gestion des Produits</h1>
              <p className="text-purple-200 text-sm">Gérez vos abonnements, formations et ebooks</p>
            </div>
          </div>
          <button
            onClick={() => handleOpenModal()}
            className="flex items-center gap-2 px-6 py-3 bg-white text-purple-900 rounded-xl font-semibold hover:bg-purple-50 transition-all"
          >
            <Plus className="w-5 h-5" />
            Nouveau Produit
          </button>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-purple-300 text-sm">Total Produits</span>
              <Package className="w-8 h-8 text-purple-400" />
            </div>
            <div className="text-3xl font-bold text-white">{stats.total}</div>
          </div>

          <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-purple-300 text-sm">Produits Actifs</span>
              <Layers className="w-8 h-8 text-green-400" />
            </div>
            <div className="text-3xl font-bold text-white">{stats.active}</div>
          </div>

          <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-purple-300 text-sm">Formations</span>
              <BookOpen className="w-8 h-8 text-orange-400" />
            </div>
            <div className="text-3xl font-bold text-white">{stats.formations}</div>
          </div>
        </div>

        {/* Filters */}
        <div className="flex gap-3 overflow-x-auto pb-2">
          <button
            onClick={() => setActiveCategory("all")}
            className={`px-6 py-3 rounded-xl font-semibold whitespace-nowrap transition-all ${
              activeCategory === "all"
                ? "bg-white text-purple-900 shadow-lg"
                : "bg-white/10 text-white hover:bg-white/20 backdrop-blur-sm"
            }`}
          >
            Tous
          </button>
          <button
            onClick={() => setActiveCategory("abonnement")}
            className={`px-6 py-3 rounded-xl font-semibold whitespace-nowrap transition-all ${
              activeCategory === "abonnement"
                ? "bg-white text-purple-900 shadow-lg"
                : "bg-white/10 text-white hover:bg-white/20 backdrop-blur-sm"
            }`}
          >
            Abonnements
          </button>
          <button
            onClick={() => setActiveCategory("formation")}
            className={`px-6 py-3 rounded-xl font-semibold whitespace-nowrap transition-all ${
              activeCategory === "formation"
                ? "bg-white text-purple-900 shadow-lg"
                : "bg-white/10 text-white hover:bg-white/20 backdrop-blur-sm"
            }`}
          >
            Formations
          </button>
          <button
            onClick={() => setActiveCategory("pack")}
            className={`px-6 py-3 rounded-xl font-semibold whitespace-nowrap transition-all ${
              activeCategory === "pack"
                ? "bg-white text-purple-900 shadow-lg"
                : "bg-white/10 text-white hover:bg-white/20 backdrop-blur-sm"
            }`}
          >
            Packs & Ebooks
          </button>
        </div>
      </header>

      <main className="px-6 pb-12 max-w-7xl mx-auto">
        {loading ? (
          <div className="text-center py-20">
            <div className="inline-block w-12 h-12 border-4 border-white/20 border-t-white rounded-full animate-spin"></div>
          </div>
        ) : filteredProducts.length === 0 ? (
          <div className="text-center py-20">
            <Package className="w-16 h-16 text-white/30 mx-auto mb-4" />
            <p className="text-xl text-white/70">Aucun produit</p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 gap-6">
            {filteredProducts.map((product) => (
              <div
                key={product.id}
                className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 overflow-hidden hover:bg-white/10 transition-all"
              >
                {product.image_url && (
                  <div className="aspect-video w-full overflow-hidden bg-gradient-to-br from-purple-600 to-pink-600">
                    <img
                      src={product.image_url}
                      alt={product.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}
                
                <div className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="text-purple-300">
                          {getCategoryIcon(product.category)}
                        </div>
                        <span className="text-sm text-purple-300 capitalize">{product.category}</span>
                        {product.is_active === 1 ? (
                          <span className="px-2 py-0.5 bg-green-500/20 text-green-300 text-xs font-medium rounded-full">
                            Actif
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 bg-red-500/20 text-red-300 text-xs font-medium rounded-full">
                            Inactif
                          </span>
                        )}
                      </div>
                      <h3 className="text-xl font-bold text-white mb-1">{product.name}</h3>
                      <p className="text-purple-200 text-sm line-clamp-2">{product.description}</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
                    {product.price_1_months && (
                      <div>
                        <span className="text-purple-300">Prix (1 mois)</span>
                        <div className="text-white font-semibold">{product.price_1_months.toLocaleString()} F</div>
                      </div>
                    )}
                    <div>
                      <span className="text-purple-300">Réduction affiliés</span>
                      <div className="text-white font-semibold">{(product.client_discount_rate * 100).toFixed(0)}%</div>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <button
                      onClick={() => handleOpenModal(product)}
                      className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-xl font-medium transition-colors"
                    >
                      <Edit className="w-4 h-4" />
                      Modifier
                    </button>
                    <button
                      onClick={() => handleDelete(product.id)}
                      className="px-4 py-2 bg-red-500/20 hover:bg-red-500/30 text-red-300 border border-red-500/30 rounded-xl transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      {/* Product Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-6 z-50 overflow-y-auto">
          <div className="bg-gradient-to-br from-purple-900 to-indigo-900 rounded-3xl border border-white/20 p-8 max-w-3xl w-full my-8">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-bold text-white">
                {editingProduct ? "Modifier le produit" : "Nouveau produit"}
              </h3>
              <button
                onClick={handleCloseModal}
                className="p-2 hover:bg-white/10 rounded-xl transition-colors"
              >
                <X className="w-6 h-6 text-white" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-purple-300 text-sm font-medium mb-2">
                    Nom du produit *
                  </label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    required
                    className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-purple-300/50 focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>

                <div>
                  <label className="block text-purple-300 text-sm font-medium mb-2">
                    Catégorie *
                  </label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                    className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                  >
                    <option value="abonnement">Abonnement</option>
                    <option value="formation">Formation</option>
                    <option value="pack">Pack / Ebook</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-purple-300 text-sm font-medium mb-2">
                  Description
                </label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  rows={3}
                  className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-purple-300/50 focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
              </div>

              {formData.category !== "pack" && (
                <div>
                  <label className="block text-purple-300 text-sm font-medium mb-2">
                    Service (pour abonnements)
                  </label>
                  <input
                    type="text"
                    value={formData.service}
                    onChange={(e) => setFormData({ ...formData, service: e.target.value })}
                    placeholder="Ex: ChatGPT, Capcut Pro, etc."
                    className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-purple-300/50 focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>
              )}

              <div className="grid md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-purple-300 text-sm font-medium mb-2">
                    {formData.category === "pack" ? "Prix (FCFA)" : "Prix 1 mois (FCFA)"}
                  </label>
                  <input
                    type="number"
                    value={formData.price_1_months}
                    onChange={(e) => setFormData({ ...formData, price_1_months: e.target.value })}
                    className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-purple-300/50 focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>

                {formData.category !== "pack" && (
                  <>
                    <div>
                      <label className="block text-purple-300 text-sm font-medium mb-2">
                        Prix 3 mois (FCFA)
                      </label>
                      <input
                        type="number"
                        value={formData.price_3_months}
                        onChange={(e) => setFormData({ ...formData, price_3_months: e.target.value })}
                        className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-purple-300/50 focus:outline-none focus:ring-2 focus:ring-purple-500"
                      />
                    </div>

                    <div>
                      <label className="block text-purple-300 text-sm font-medium mb-2">
                        Prix 6 mois (FCFA)
                      </label>
                      <input
                        type="number"
                        value={formData.price_6_months}
                        onChange={(e) => setFormData({ ...formData, price_6_months: e.target.value })}
                        className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-purple-300/50 focus:outline-none focus:ring-2 focus:ring-purple-500"
                      />
                    </div>
                  </>
                )}
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-purple-300 text-sm font-medium mb-2">
                    Réduction client (%) *
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    value={formData.client_discount_rate}
                    onChange={(e) => setFormData({ ...formData, client_discount_rate: e.target.value })}
                    required
                    className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-purple-300/50 focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                  <p className="text-purple-300 text-xs mt-1">Réduction pour clients avec code promo affilié</p>
                </div>

                <div>
                  <label className="block text-purple-300 text-sm font-medium mb-2">
                    Commission affilié (%) *
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    value={formData.affiliate_commission_rate}
                    onChange={(e) => setFormData({ ...formData, affiliate_commission_rate: e.target.value })}
                    required
                    className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-purple-300/50 focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                  <p className="text-purple-300 text-xs mt-1">Commission versée à l'affilié par vente</p>
                </div>
              </div>

              <div>
                <label className="block text-purple-300 text-sm font-medium mb-2">
                  URL de l'image
                </label>
                <input
                  type="url"
                  value={formData.image_url}
                  onChange={(e) => setFormData({ ...formData, image_url: e.target.value })}
                  placeholder="https://example.com/image.jpg"
                  className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-purple-300/50 focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
              </div>

              {formData.category === "pack" && (
                <div>
                  <label className="block text-purple-300 text-sm font-medium mb-2">
                    URL de téléchargement (pour Ebook/Pack)
                  </label>
                  <input
                    type="url"
                    value={formData.download_url}
                    onChange={(e) => setFormData({ ...formData, download_url: e.target.value })}
                    placeholder="https://example.com/ebook.pdf"
                    className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-purple-300/50 focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>
              )}

              <div className="flex items-center gap-3">
                <input
                  type="checkbox"
                  id="is_active"
                  checked={formData.is_active === 1}
                  onChange={(e) => setFormData({ ...formData, is_active: e.target.checked ? 1 : 0 })}
                  className="w-5 h-5 rounded"
                />
                <label htmlFor="is_active" className="text-white font-medium">
                  Produit actif (visible dans le catalogue)
                </label>
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="submit"
                  className="flex-1 px-6 py-3 bg-white text-purple-900 rounded-xl font-semibold hover:bg-purple-50 transition-colors"
                >
                  {editingProduct ? "Mettre à jour" : "Créer le produit"}
                </button>
                <button
                  type="button"
                  onClick={handleCloseModal}
                  className="px-6 py-3 bg-white/10 hover:bg-white/20 text-white rounded-xl font-semibold transition-colors"
                >
                  Annuler
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
