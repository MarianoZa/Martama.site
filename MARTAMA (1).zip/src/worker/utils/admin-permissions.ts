// Admin role definitions and permissions
export type AdminRole = 
  | 'super_admin'           // Accès total, gestion des admins
  | 'data_analyst'          // Analyste de données & performances
  | 'delivery_agent'        // Agent de livraison
  | 'affiliate_manager'     // Gestionnaire d'affiliation
  | 'content_moderator';    // Modérateur de contenu

export interface AdminPermissions {
  // Dashboard & Stats
  viewDashboard: boolean;
  viewStats: boolean;
  exportData: boolean;

  // Products & Content
  manageProducts: boolean;
  manageFormations: boolean;
  manageAcademy: boolean;
  manageBlog: boolean;
  manageTestimonials: boolean;

  // Orders & Delivery
  viewOrders: boolean;
  deliverOrders: boolean;
  manageInventory: boolean;

  // Affiliates
  viewAffiliates: boolean;
  manageAffiliates: boolean;
  manageExceptionalCodes: boolean;
  processWithdrawals: boolean;

  // Payments
  viewPayments: boolean;
  managePaymentGateways: boolean;

  // Users & Admins
  viewUsers: boolean;
  manageUsers: boolean;
  manageAdmins: boolean;

  // Settings
  manageAnnouncements: boolean;
}

export const ROLE_PERMISSIONS: Record<AdminRole, AdminPermissions> = {
  super_admin: {
    // Full access to everything
    viewDashboard: true,
    viewStats: true,
    exportData: true,
    manageProducts: true,
    manageFormations: true,
    manageAcademy: true,
    manageBlog: true,
    manageTestimonials: true,
    viewOrders: true,
    deliverOrders: true,
    manageInventory: true,
    viewAffiliates: true,
    manageAffiliates: true,
    manageExceptionalCodes: true,
    processWithdrawals: true,
    viewPayments: true,
    managePaymentGateways: true,
    viewUsers: true,
    manageUsers: true,
    manageAdmins: true,
    manageAnnouncements: true,
  },

  data_analyst: {
    // Analytics & data export only
    viewDashboard: true,
    viewStats: true,
    exportData: true,
    manageProducts: false,
    manageFormations: false,
    manageAcademy: false,
    manageBlog: false,
    manageTestimonials: false,
    viewOrders: true,
    deliverOrders: false,
    manageInventory: false,
    viewAffiliates: true,
    manageAffiliates: false,
    manageExceptionalCodes: false,
    processWithdrawals: false,
    viewPayments: true,
    managePaymentGateways: false,
    viewUsers: true,
    manageUsers: false,
    manageAdmins: false,
    manageAnnouncements: false,
  },

  delivery_agent: {
    // Order delivery & inventory only
    viewDashboard: false,
    viewStats: false,
    exportData: false,
    manageProducts: false,
    manageFormations: false,
    manageAcademy: false,
    manageBlog: false,
    manageTestimonials: false,
    viewOrders: true,
    deliverOrders: true,
    manageInventory: true,
    viewAffiliates: false,
    manageAffiliates: false,
    manageExceptionalCodes: false,
    processWithdrawals: false,
    viewPayments: false,
    managePaymentGateways: false,
    viewUsers: false,
    manageUsers: false,
    manageAdmins: false,
    manageAnnouncements: false,
  },

  affiliate_manager: {
    // Affiliate management only
    viewDashboard: false,
    viewStats: true,
    exportData: true,
    manageProducts: false,
    manageFormations: false,
    manageAcademy: false,
    manageBlog: false,
    manageTestimonials: false,
    viewOrders: false,
    deliverOrders: false,
    manageInventory: false,
    viewAffiliates: true,
    manageAffiliates: true,
    manageExceptionalCodes: true,
    processWithdrawals: true,
    viewPayments: false,
    managePaymentGateways: false,
    viewUsers: false,
    manageUsers: false,
    manageAdmins: false,
    manageAnnouncements: false,
  },

  content_moderator: {
    // Content management only
    viewDashboard: false,
    viewStats: false,
    exportData: false,
    manageProducts: true,
    manageFormations: true,
    manageAcademy: true,
    manageBlog: true,
    manageTestimonials: true,
    viewOrders: false,
    deliverOrders: false,
    manageInventory: false,
    viewAffiliates: false,
    manageAffiliates: false,
    manageExceptionalCodes: false,
    processWithdrawals: false,
    viewPayments: false,
    managePaymentGateways: false,
    viewUsers: false,
    manageUsers: false,
    manageAdmins: false,
    manageAnnouncements: false,
  },
};

export function getAdminPermissions(role: AdminRole): AdminPermissions {
  return ROLE_PERMISSIONS[role];
}

export function hasPermission(role: AdminRole, permission: keyof AdminPermissions): boolean {
  const permissions = getAdminPermissions(role);
  return permissions[permission];
}

export const ROLE_LABELS: Record<AdminRole, string> = {
  super_admin: 'Super Administrateur',
  data_analyst: 'Analyste de Données',
  delivery_agent: 'Agent de Livraison',
  affiliate_manager: 'Gestionnaire d\'Affiliation',
  content_moderator: 'Modérateur de Contenu',
};

export const ROLE_DESCRIPTIONS: Record<AdminRole, string> = {
  super_admin: 'Accès complet à toutes les fonctionnalités et gestion des autres administrateurs',
  data_analyst: 'Accès en lecture aux statistiques, exports de données et analyses de performances',
  delivery_agent: 'Gestion des commandes, livraisons et inventaire',
  affiliate_manager: 'Gestion des affiliés, codes promotionnels et retraits',
  content_moderator: 'Gestion des produits, formations, classes Academy, blog et témoignages',
};
