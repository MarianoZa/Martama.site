import { Hono } from "hono";
import { authMiddleware } from "@getmocha/users-service/backend";

const app = new Hono<{ Bindings: Env }>();

// Update affiliate payment info
app.put("/api/admin/affiliates/:id", authMiddleware, async (c) => {
  const id = c.req.param("id");
  const body = await c.req.json();
  const user = c.get("user");
  
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }
  
  // Check if user owns this affiliate or is admin
  const affiliate = await c.env.DB.prepare(
    "SELECT * FROM affiliates WHERE id = ?"
  ).bind(id).first();
  
  if (!affiliate) {
    return c.json({ error: "Affiliate not found" }, 404);
  }
  
  const userRecord = await c.env.DB.prepare(
    "SELECT * FROM users WHERE id = ?"
  ).bind(user.id).first();
  
  const isOwner = affiliate.user_id === user.id;
  const isAdmin = userRecord?.role === 'admin';
  
  if (!isOwner && !isAdmin) {
    return c.json({ error: "Forbidden" }, 403);
  }
  
  // Update affiliate
  if (body.payment_phone_number !== undefined) {
    await c.env.DB.prepare(
      "UPDATE affiliates SET payment_phone_number = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?"
    ).bind(body.payment_phone_number, id).run();
  }
  
  const updated = await c.env.DB.prepare(
    "SELECT * FROM affiliates WHERE id = ?"
  ).bind(id).first();
  
  return c.json(updated);
});

// Toggle affiliate status (admin only)
app.put("/api/admin/affiliates/:id/toggle-status", authMiddleware, async (c) => {
  const id = c.req.param("id");
  const body = await c.req.json();
  const user = c.get("user");
  
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }
  
  // Check if user is admin
  const userRecord = await c.env.DB.prepare(
    "SELECT * FROM users WHERE email = ?"
  ).bind(user.email).first();
  
  if (!userRecord || !userRecord.admin_role) {
    return c.json({ error: "Forbidden - Admin access required" }, 403);
  }
  
  const { status } = body;
  
  if (!status || !["active", "inactive"].includes(status)) {
    return c.json({ error: "Invalid status. Must be 'active' or 'inactive'" }, 400);
  }
  
  // Update affiliate status
  await c.env.DB.prepare(
    "UPDATE affiliates SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?"
  ).bind(status, id).run();
  
  const updated = await c.env.DB.prepare(
    "SELECT * FROM affiliates WHERE id = ?"
  ).bind(id).first();
  
  return c.json(updated);
});

// Delete affiliate completely (admin only)
app.delete("/api/admin/affiliates/:id", authMiddleware, async (c) => {
  const id = c.req.param("id");
  const user = c.get("user");
  
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }
  
  // Check if user is admin
  const userRecord = await c.env.DB.prepare(
    "SELECT * FROM users WHERE email = ?"
  ).bind(user.email).first();
  
  if (!userRecord || !userRecord.admin_role) {
    return c.json({ error: "Forbidden - Admin access required" }, 403);
  }
  
  // Get affiliate info before deletion
  const affiliate = await c.env.DB.prepare(
    "SELECT * FROM affiliates WHERE id = ?"
  ).bind(id).first();
  
  if (!affiliate) {
    return c.json({ error: "Affiliate not found" }, 404);
  }
  
  // Delete related records first (commissions, withdrawal requests, link clicks)
  await c.env.DB.prepare(
    "DELETE FROM commissions WHERE affiliate_id = ?"
  ).bind(id).run();
  
  await c.env.DB.prepare(
    "DELETE FROM withdrawal_requests WHERE affiliate_id = ?"
  ).bind(id).run();
  
  await c.env.DB.prepare(
    "DELETE FROM link_clicks WHERE affiliate_id = ?"
  ).bind(id).run();
  
  await c.env.DB.prepare(
    "DELETE FROM customer_purchase_history WHERE affiliate_id = ?"
  ).bind(id).run();
  
  await c.env.DB.prepare(
    "DELETE FROM exceptional_promo_codes WHERE affiliate_id = ?"
  ).bind(id).run();
  
  // Update orders to remove affiliate reference
  await c.env.DB.prepare(
    "UPDATE orders SET affiliate_id = NULL, affiliate_code = NULL WHERE affiliate_id = ?"
  ).bind(id).run();
  
  // Finally delete the affiliate
  await c.env.DB.prepare(
    "DELETE FROM affiliates WHERE id = ?"
  ).bind(id).run();
  
  // Remove affiliate status from user (they can now reapply)
  await c.env.DB.prepare(
    "UPDATE users SET affiliate_status = 'none', affiliate_code = NULL WHERE id = ?"
  ).bind(affiliate.user_id).run();
  
  return c.json({ 
    success: true, 
    message: "Affiliate deleted successfully. They can now reapply."
  });
});

export default app;
