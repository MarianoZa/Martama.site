import { Hono } from 'hono';

const app = new Hono<{ Bindings: Env }>();

// Check if user has access to a formation
app.get('/:id/access', async (c) => {
  try {
    const db = c.env.DB;
    const formationId = c.req.param('id');
    const userEmail = c.req.query('email');
    
    if (!userEmail) {
      return c.json({ hasAccess: false, error: 'Email requis' }, 400);
    }
    
    // Check if user has access via user_formations table
    const access = await db.prepare(`
      SELECT * FROM user_formations 
      WHERE user_email = ? AND product_id = ?
    `).bind(userEmail, formationId).first();
    
    if (access) {
      return c.json({ hasAccess: true });
    }
    
    // Also check via orders table for delivered formations
    const order = await db.prepare(`
      SELECT * FROM orders 
      WHERE customer_email = ? 
      AND product_id = ? 
      AND status IN ('paid', 'delivered')
    `).bind(userEmail, formationId).first();
    
    return c.json({ hasAccess: !!order });
  } catch (error) {
    console.error('Failed to check formation access:', error);
    return c.json({ hasAccess: false, error: 'Erreur lors de la vérification' }, 500);
  }
});

// Get formation modules
app.get('/:id/modules', async (c) => {
  try {
    const db = c.env.DB;
    const formationId = c.req.param('id');
    
    const modules = await db.prepare(`
      SELECT * FROM formation_modules 
      WHERE product_id = ? 
      ORDER BY order_position ASC
    `).bind(formationId).all();
    
    return c.json(modules.results || []);
  } catch (error) {
    console.error('Failed to fetch modules:', error);
    return c.json({ error: 'Erreur lors de la récupération des modules' }, 500);
  }
});

// Get videos for a module
app.get('/modules/:moduleId/videos', async (c) => {
  try {
    const db = c.env.DB;
    const moduleId = c.req.param('moduleId');
    
    const videos = await db.prepare(`
      SELECT * FROM formation_videos 
      WHERE module_id = ? 
      ORDER BY order_position ASC
    `).bind(moduleId).all();
    
    return c.json(videos.results || []);
  } catch (error) {
    console.error('Failed to fetch videos:', error);
    return c.json({ error: 'Erreur lors de la récupération des vidéos' }, 500);
  }
});

// Get user's purchased formations
app.get('/user/formations', async (c) => {
  try {
    const db = c.env.DB;
    const userEmail = c.req.query('email');
    
    if (!userEmail) {
      return c.json({ error: 'Email requis' }, 400);
    }
    
    const formations = await db.prepare(`
      SELECT 
        p.*,
        uf.access_granted_at,
        uf.last_accessed_at,
        uf.progress_data,
        o.id as order_id
      FROM user_formations uf
      JOIN products p ON uf.product_id = p.id
      JOIN orders o ON uf.order_id = o.id
      WHERE uf.user_email = ?
      ORDER BY uf.access_granted_at DESC
    `).bind(userEmail).all();
    
    return c.json(formations.results || []);
  } catch (error) {
    console.error('Failed to fetch user formations:', error);
    return c.json({ error: 'Erreur lors de la récupération des formations' }, 500);
  }
});

// Get formation details with modules and videos
app.get('/formation/:productId', async (c) => {
  try {
    const db = c.env.DB;
    const productId = c.req.param('productId');
    const userEmail = c.req.query('email');
    
    // Verify user has access
    if (userEmail) {
      const access = await db.prepare(`
        SELECT * FROM user_formations 
        WHERE user_email = ? AND product_id = ?
      `).bind(userEmail, productId).first();
      
      if (!access) {
        return c.json({ error: 'Accès non autorisé' }, 403);
      }
      
      // Update last accessed
      await db.prepare(`
        UPDATE user_formations 
        SET last_accessed_at = CURRENT_TIMESTAMP 
        WHERE user_email = ? AND product_id = ?
      `).bind(userEmail, productId).run();
    }
    
    // Get product details
    const product = await db.prepare('SELECT * FROM products WHERE id = ?').bind(productId).first();
    
    if (!product) {
      return c.json({ error: 'Formation non trouvée' }, 404);
    }
    
    // Get modules with videos
    const modules = await db.prepare(`
      SELECT * FROM formation_modules 
      WHERE product_id = ? 
      ORDER BY order_position ASC
    `).bind(productId).all();
    
    const modulesWithVideos = await Promise.all(
      (modules.results || []).map(async (module: any) => {
        const videos = await db.prepare(`
          SELECT * FROM formation_videos 
          WHERE module_id = ? 
          ORDER BY order_position ASC
        `).bind(module.id).all();
        
        return {
          ...module,
          videos: videos.results || []
        };
      })
    );
    
    return c.json({
      product,
      modules: modulesWithVideos
    });
  } catch (error) {
    console.error('Failed to fetch formation:', error);
    return c.json({ error: 'Erreur lors de la récupération de la formation' }, 500);
  }
});

// Admin: Get formation structure
app.get('/admin/formation/:productId', async (c) => {
  try {
    const db = c.env.DB;
    const productId = c.req.param('productId');
    
    const product = await db.prepare('SELECT * FROM products WHERE id = ?').bind(productId).first();
    
    if (!product) {
      return c.json({ error: 'Formation non trouvée' }, 404);
    }
    
    const modules = await db.prepare(`
      SELECT * FROM formation_modules 
      WHERE product_id = ? 
      ORDER BY order_position ASC
    `).bind(productId).all();
    
    const modulesWithVideos = await Promise.all(
      (modules.results || []).map(async (module: any) => {
        const videos = await db.prepare(`
          SELECT * FROM formation_videos 
          WHERE module_id = ? 
          ORDER BY order_position ASC
        `).bind(module.id).all();
        
        return {
          ...module,
          videos: videos.results || []
        };
      })
    );
    
    return c.json({
      product,
      modules: modulesWithVideos
    });
  } catch (error) {
    console.error('Failed to fetch formation:', error);
    return c.json({ error: 'Erreur lors de la récupération de la formation' }, 500);
  }
});

// Admin: Create module
app.post('/admin/formation/:productId/modules', async (c) => {
  try {
    const db = c.env.DB;
    const productId = c.req.param('productId');
    const body = await c.req.json();
    
    const { title, description, order_position } = body;
    
    if (!title) {
      return c.json({ error: 'Titre requis' }, 400);
    }
    
    const result = await db.prepare(`
      INSERT INTO formation_modules (product_id, title, description, order_position)
      VALUES (?, ?, ?, ?)
    `).bind(productId, title, description || null, order_position || 0).run();
    
    return c.json({ success: true, id: result.meta.last_row_id });
  } catch (error) {
    console.error('Failed to create module:', error);
    return c.json({ error: 'Erreur lors de la création du module' }, 500);
  }
});

// Admin: Update module
app.put('/admin/formation/modules/:moduleId', async (c) => {
  try {
    const db = c.env.DB;
    const moduleId = c.req.param('moduleId');
    const body = await c.req.json();
    
    const { title, description, order_position } = body;
    
    await db.prepare(`
      UPDATE formation_modules 
      SET title = ?, description = ?, order_position = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).bind(title, description || null, order_position, moduleId).run();
    
    return c.json({ success: true });
  } catch (error) {
    console.error('Failed to update module:', error);
    return c.json({ error: 'Erreur lors de la mise à jour du module' }, 500);
  }
});

// Admin: Delete module
app.delete('/admin/formation/modules/:moduleId', async (c) => {
  try {
    const db = c.env.DB;
    const moduleId = c.req.param('moduleId');
    
    // Delete videos first
    await db.prepare('DELETE FROM formation_videos WHERE module_id = ?').bind(moduleId).run();
    
    // Delete module
    await db.prepare('DELETE FROM formation_modules WHERE id = ?').bind(moduleId).run();
    
    return c.json({ success: true });
  } catch (error) {
    console.error('Failed to delete module:', error);
    return c.json({ error: 'Erreur lors de la suppression du module' }, 500);
  }
});

// Admin: Add video to module
app.post('/admin/formation/modules/:moduleId/videos', async (c) => {
  try {
    const db = c.env.DB;
    const moduleId = c.req.param('moduleId');
    const body = await c.req.json();
    
    const { title, description, video_url, video_type, aspect_ratio, duration_seconds, order_position, resources } = body;
    
    if (!title || !video_url || !video_type) {
      return c.json({ error: 'Titre, URL et type de vidéo requis' }, 400);
    }
    
    // Validate video type
    if (!['youtube', 'vimeo', 'direct'].includes(video_type)) {
      return c.json({ error: 'Type de vidéo invalide (youtube, vimeo ou direct)' }, 400);
    }
    
    const result = await db.prepare(`
      INSERT INTO formation_videos (
        module_id, title, description, video_url, video_type, aspect_ratio, 
        duration_seconds, order_position, resources
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      moduleId, 
      title,
      description || null,
      video_url, 
      video_type, 
      aspect_ratio || '16:9',
      duration_seconds || null,
      order_position || 0,
      resources ? JSON.stringify(resources) : null
    ).run();
    
    return c.json({ success: true, id: result.meta.last_row_id });
  } catch (error) {
    console.error('Failed to add video:', error);
    return c.json({ error: 'Erreur lors de l\'ajout de la vidéo' }, 500);
  }
});

// Admin: Update video
app.put('/admin/formation/videos/:videoId', async (c) => {
  try {
    const db = c.env.DB;
    const videoId = c.req.param('videoId');
    const body = await c.req.json();
    
    const { title, description, video_url, video_type, aspect_ratio, duration_seconds, order_position, resources } = body;
    
    await db.prepare(`
      UPDATE formation_videos 
      SET title = ?, description = ?, video_url = ?, video_type = ?, aspect_ratio = ?,
          duration_seconds = ?, order_position = ?, resources = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).bind(
      title,
      description || null,
      video_url, 
      video_type, 
      aspect_ratio || '16:9',
      duration_seconds || null,
      order_position,
      resources ? JSON.stringify(resources) : null,
      videoId
    ).run();
    
    return c.json({ success: true });
  } catch (error) {
    console.error('Failed to update video:', error);
    return c.json({ error: 'Erreur lors de la mise à jour de la vidéo' }, 500);
  }
});

// Admin: Delete video
app.delete('/admin/formation/videos/:videoId', async (c) => {
  try {
    const db = c.env.DB;
    const videoId = c.req.param('videoId');
    
    await db.prepare('DELETE FROM formation_videos WHERE id = ?').bind(videoId).run();
    
    return c.json({ success: true });
  } catch (error) {
    console.error('Failed to delete video:', error);
    return c.json({ error: 'Erreur lors de la suppression de la vidéo' }, 500);
  }
});

// Mark lesson as completed
app.post('/lesson/:videoId/complete', async (c) => {
  try {
    const db = c.env.DB;
    const videoId = c.req.param('videoId');
    const body = await c.req.json();
    
    const { user_email, product_id, watch_time_seconds } = body;
    
    if (!user_email || !product_id) {
      return c.json({ error: 'Email et product_id requis' }, 400);
    }
    
    // Check if progress exists
    const existing = await db.prepare(`
      SELECT * FROM lesson_progress 
      WHERE user_email = ? AND product_id = ? AND video_id = ?
    `).bind(user_email, product_id, videoId).first();
    
    if (existing) {
      await db.prepare(`
        UPDATE lesson_progress 
        SET is_completed = 1, watch_time_seconds = ?, completed_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).bind(watch_time_seconds || 0, existing.id).run();
    } else {
      await db.prepare(`
        INSERT INTO lesson_progress (user_email, product_id, video_id, is_completed, watch_time_seconds, completed_at)
        VALUES (?, ?, ?, 1, ?, CURRENT_TIMESTAMP)
      `).bind(user_email, product_id, videoId, watch_time_seconds || 0).run();
    }
    
    // Check if all lessons are completed to issue certificate
    const totalLessons = await db.prepare(`
      SELECT COUNT(*) as count FROM formation_videos fv
      JOIN formation_modules fm ON fv.module_id = fm.id
      WHERE fm.product_id = ?
    `).bind(product_id).first();
    
    const completedLessons = await db.prepare(`
      SELECT COUNT(*) as count FROM lesson_progress
      WHERE user_email = ? AND product_id = ? AND is_completed = 1
    `).bind(user_email, product_id).first();
    
    let certificateIssued = false;
    if (totalLessons && completedLessons && 
        Number(totalLessons.count) > 0 && 
        Number(completedLessons.count) === Number(totalLessons.count)) {
      
      // Check if certificate already exists
      const existingCert = await db.prepare(`
        SELECT * FROM course_certificates WHERE user_email = ? AND product_id = ?
      `).bind(user_email, product_id).first();
      
      if (!existingCert) {
        const certCode = `CERT-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
        await db.prepare(`
          INSERT INTO course_certificates (user_email, product_id, certificate_code)
          VALUES (?, ?, ?)
        `).bind(user_email, product_id, certCode).run();
        certificateIssued = true;
      }
    }
    
    return c.json({ 
      success: true, 
      certificateIssued,
      progress: {
        total: Number(totalLessons?.count || 0),
        completed: Number(completedLessons?.count || 0)
      }
    });
  } catch (error) {
    console.error('Failed to mark lesson complete:', error);
    return c.json({ error: 'Erreur lors de la mise à jour de la progression' }, 500);
  }
});

// Get user progress for a formation
app.get('/formation/:productId/progress', async (c) => {
  try {
    const db = c.env.DB;
    const productId = c.req.param('productId');
    const userEmail = c.req.query('email');
    
    if (!userEmail) {
      return c.json({ error: 'Email requis' }, 400);
    }
    
    const progress = await db.prepare(`
      SELECT * FROM lesson_progress 
      WHERE user_email = ? AND product_id = ?
    `).bind(userEmail, productId).all();
    
    // Get certificate if exists
    const certificate = await db.prepare(`
      SELECT * FROM course_certificates 
      WHERE user_email = ? AND product_id = ?
    `).bind(userEmail, productId).first();
    
    return c.json({
      lessons: progress.results || [],
      certificate: certificate || null
    });
  } catch (error) {
    console.error('Failed to fetch progress:', error);
    return c.json({ error: 'Erreur lors de la récupération de la progression' }, 500);
  }
});

// Get certificate
app.get('/certificate/:code', async (c) => {
  try {
    const db = c.env.DB;
    const code = c.req.param('code');
    
    const certificate = await db.prepare(`
      SELECT c.*, p.name as course_name, p.description as course_description
      FROM course_certificates c
      JOIN products p ON c.product_id = p.id
      WHERE c.certificate_code = ?
    `).bind(code).first();
    
    if (!certificate) {
      return c.json({ error: 'Certificat non trouvé' }, 404);
    }
    
    return c.json(certificate);
  } catch (error) {
    console.error('Failed to fetch certificate:', error);
    return c.json({ error: 'Erreur lors de la récupération du certificat' }, 500);
  }
});

// Admin: Add resource to lesson
app.post('/admin/formation/videos/:videoId/resources', async (c) => {
  try {
    const db = c.env.DB;
    const videoId = c.req.param('videoId');
    const body = await c.req.json();
    
    const { title, resource_type, resource_url, file_size } = body;
    
    if (!title || !resource_type || !resource_url) {
      return c.json({ error: 'Titre, type et URL requis' }, 400);
    }
    
    const result = await db.prepare(`
      INSERT INTO lesson_resources (video_id, title, resource_type, resource_url, file_size)
      VALUES (?, ?, ?, ?, ?)
    `).bind(videoId, title, resource_type, resource_url, file_size || null).run();
    
    return c.json({ success: true, id: result.meta.last_row_id });
  } catch (error) {
    console.error('Failed to add resource:', error);
    return c.json({ error: 'Erreur lors de l\'ajout de la ressource' }, 500);
  }
});

// Admin: Delete resource
app.delete('/admin/formation/resources/:resourceId', async (c) => {
  try {
    const db = c.env.DB;
    const resourceId = c.req.param('resourceId');
    
    await db.prepare('DELETE FROM lesson_resources WHERE id = ?').bind(resourceId).run();
    
    return c.json({ success: true });
  } catch (error) {
    console.error('Failed to delete resource:', error);
    return c.json({ error: 'Erreur lors de la suppression de la ressource' }, 500);
  }
});

// Get resources for a lesson
app.get('/lesson/:videoId/resources', async (c) => {
  try {
    const db = c.env.DB;
    const videoId = c.req.param('videoId');
    
    const resources = await db.prepare(`
      SELECT * FROM lesson_resources WHERE video_id = ? ORDER BY created_at DESC
    `).bind(videoId).all();
    
    return c.json(resources.results || []);
  } catch (error) {
    console.error('Failed to fetch resources:', error);
    return c.json({ error: 'Erreur lors de la récupération des ressources' }, 500);
  }
});

export default app;
