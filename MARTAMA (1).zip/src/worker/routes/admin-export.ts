import { Hono } from "hono";
import { authMiddleware } from "@getmocha/users-service/backend";

const app = new Hono<{ Bindings: Env }>();

// Admin middleware - check by email instead of ID for Mocha authentication
const adminMiddleware = async (c: any, next: any) => {
  const mochaUser = c.get("user");
  
  if (!mochaUser) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  // Check by email instead of ID to handle Mocha authentication properly
  const userResult = await c.env.DB.prepare(
    "SELECT * FROM users WHERE email = ? AND role = 'admin'"
  ).bind(mochaUser.email).first();

  if (!userResult) {
    return c.json({ 
      error: "Forbidden - Admin access required",
      debug: {
        email: mochaUser.email,
        message: "Veuillez contacter un super administrateur pour obtenir l'accès"
      }
    }, 403);
  }

  await next();
};

// Export customers data as CSV
app.get("/customers", authMiddleware, adminMiddleware, async (c) => {
  try {
    // Get all orders with customer information
    const { results } = await c.env.DB.prepare(
      `SELECT 
        o.customer_email,
        COUNT(DISTINCT o.id) as total_orders,
        SUM(CASE WHEN o.status IN ('paid', 'delivered') THEN o.amount ELSE 0 END) as total_spent,
        MIN(o.created_at) as first_order_date,
        MAX(o.created_at) as last_order_date,
        GROUP_CONCAT(DISTINCT p.name) as products_purchased,
        u.full_name,
        u.phone_number,
        u.country,
        u.role_type
      FROM orders o
      JOIN products p ON o.product_id = p.id
      LEFT JOIN users u ON o.customer_email = u.email
      GROUP BY o.customer_email
      ORDER BY total_spent DESC`
    ).all();

    // Create CSV content
    const headers = [
      "Email",
      "Nom Complet",
      "Téléphone",
      "Pays",
      "Type de Client",
      "Nombre de Commandes",
      "Total Dépensé (FCFA)",
      "Première Commande",
      "Dernière Commande",
      "Produits Achetés"
    ];

    let csvContent = headers.join(",") + "\n";

    for (const row of results) {
      const values = [
        `"${row.customer_email}"`,
        `"${row.full_name || 'N/A'}"`,
        `"${row.phone_number || 'N/A'}"`,
        `"${row.country || 'N/A'}"`,
        `"${row.role_type || 'client'}"`,
        row.total_orders,
        row.total_spent,
        `"${new Date(row.first_order_date as string).toLocaleDateString('fr-FR')}"`,
        `"${new Date(row.last_order_date as string).toLocaleDateString('fr-FR')}"`,
        `"${(row.products_purchased as string)?.replace(/,/g, ' | ') || 'N/A'}"`
      ];
      csvContent += values.join(",") + "\n";
    }

    // Add BOM for proper UTF-8 encoding in Excel
    const bom = '\uFEFF';
    const csvWithBom = bom + csvContent;
    
    // Set response headers for file download
    const filename = `martama_clients_${new Date().toISOString().split('T')[0]}.csv`;
    
    return new Response(csvWithBom, {
      status: 200,
      headers: {
        "Content-Type": "text/csv; charset=utf-8",
        "Content-Disposition": `attachment; filename="${filename}"`,
        "Cache-Control": "no-cache"
      }
    });

  } catch (error) {
    console.error("Error exporting customers:", error);
    return c.json({ error: "Erreur lors de l'export" }, 500);
  }
});

// Export orders data as CSV
app.get("/orders", authMiddleware, adminMiddleware, async (c) => {
  try {
    const { results } = await c.env.DB.prepare(
      `SELECT 
        o.id,
        o.customer_email,
        p.name as product_name,
        p.category as product_category,
        o.duration_months,
        o.amount,
        o.original_amount,
        o.discount_amount,
        o.affiliate_code,
        o.status,
        o.payment_method,
        o.payment_reference,
        o.created_at,
        o.delivered_at
      FROM orders o
      JOIN products p ON o.product_id = p.id
      ORDER BY o.created_at DESC`
    ).all();

    const headers = [
      "ID Commande",
      "Email Client",
      "Produit",
      "Catégorie",
      "Durée (mois)",
      "Montant Payé (FCFA)",
      "Montant Original (FCFA)",
      "Réduction (FCFA)",
      "Code Promo",
      "Statut",
      "Méthode de Paiement",
      "Référence Paiement",
      "Date de Commande",
      "Date de Livraison"
    ];

    let csvContent = headers.join(",") + "\n";

    for (const row of results) {
      const values = [
        row.id,
        `"${row.customer_email}"`,
        `"${row.product_name}"`,
        `"${row.product_category}"`,
        row.duration_months || 'N/A',
        row.amount,
        row.original_amount,
        row.discount_amount,
        `"${row.affiliate_code || 'N/A'}"`,
        `"${row.status}"`,
        `"${row.payment_method}"`,
        `"${row.payment_reference || 'N/A'}"`,
        `"${new Date(row.created_at as string).toLocaleString('fr-FR')}"`,
        `"${row.delivered_at ? new Date(row.delivered_at as string).toLocaleString('fr-FR') : 'N/A'}"`
      ];
      csvContent += values.join(",") + "\n";
    }

    // Add BOM for proper UTF-8 encoding in Excel
    const bom = '\uFEFF';
    const csvWithBom = bom + csvContent;
    
    const filename = `martama_commandes_${new Date().toISOString().split('T')[0]}.csv`;
    
    return new Response(csvWithBom, {
      status: 200,
      headers: {
        "Content-Type": "text/csv; charset=utf-8",
        "Content-Disposition": `attachment; filename="${filename}"`,
        "Cache-Control": "no-cache"
      }
    });

  } catch (error) {
    console.error("Error exporting orders:", error);
    return c.json({ error: "Erreur lors de l'export" }, 500);
  }
});

// Export affiliates data as CSV
app.get("/affiliates", authMiddleware, adminMiddleware, async (c) => {
  try {
    const { results } = await c.env.DB.prepare(
      `SELECT 
        a.id,
        u.email,
        u.full_name,
        u.phone_number,
        a.promo_code,
        a.total_clicks,
        a.total_sales,
        a.total_commissions,
        a.balance,
        a.status,
        a.created_at
      FROM affiliates a
      JOIN users u ON a.user_id = u.id
      ORDER BY a.total_sales DESC`
    ).all();

    const headers = [
      "ID Affilié",
      "Email",
      "Nom Complet",
      "Téléphone",
      "Code Promo",
      "Total Clics",
      "Total Ventes",
      "Commissions Totales (FCFA)",
      "Solde Disponible (FCFA)",
      "Statut",
      "Date d'Inscription"
    ];

    let csvContent = headers.join(",") + "\n";

    for (const row of results) {
      const values = [
        row.id,
        `"${row.email}"`,
        `"${row.full_name || 'N/A'}"`,
        `"${row.phone_number || 'N/A'}"`,
        `"${row.promo_code}"`,
        row.total_clicks,
        row.total_sales,
        row.total_commissions,
        row.balance,
        `"${row.status}"`,
        `"${new Date(row.created_at as string).toLocaleDateString('fr-FR')}"`
      ];
      csvContent += values.join(",") + "\n";
    }

    // Add BOM for proper UTF-8 encoding in Excel
    const bom = '\uFEFF';
    const csvWithBom = bom + csvContent;
    
    const filename = `martama_affilies_${new Date().toISOString().split('T')[0]}.csv`;
    
    return new Response(csvWithBom, {
      status: 200,
      headers: {
        "Content-Type": "text/csv; charset=utf-8",
        "Content-Disposition": `attachment; filename="${filename}"`,
        "Cache-Control": "no-cache"
      }
    });

  } catch (error) {
    console.error("Error exporting affiliates:", error);
    return c.json({ error: "Erreur lors de l'export" }, 500);
  }
});

// Export customers as JSON (alternative format)
app.get("/customers-json", authMiddleware, adminMiddleware, async (c) => {
  try {
    const { results } = await c.env.DB.prepare(
      `SELECT 
        o.customer_email,
        COUNT(DISTINCT o.id) as total_orders,
        SUM(CASE WHEN o.status IN ('paid', 'delivered') THEN o.amount ELSE 0 END) as total_spent,
        MIN(o.created_at) as first_order_date,
        MAX(o.created_at) as last_order_date,
        u.full_name,
        u.phone_number,
        u.country,
        u.role_type
      FROM orders o
      LEFT JOIN users u ON o.customer_email = u.email
      GROUP BY o.customer_email
      ORDER BY total_spent DESC`
    ).all();

    const filename = `martama_clients_${new Date().toISOString().split('T')[0]}.json`;
    
    return new Response(JSON.stringify(results, null, 2), {
      status: 200,
      headers: {
        "Content-Type": "application/json; charset=utf-8",
        "Content-Disposition": `attachment; filename="${filename}"`,
        "Cache-Control": "no-cache"
      }
    });
  } catch (error) {
    console.error("Error exporting customers:", error);
    return c.json({ error: "Erreur lors de l'export" }, 500);
  }
});

// Export orders as JSON (alternative format)
app.get("/orders-json", authMiddleware, adminMiddleware, async (c) => {
  try {
    const { results } = await c.env.DB.prepare(
      `SELECT 
        o.id,
        o.customer_email,
        p.name as product_name,
        p.category as product_category,
        o.duration_months,
        o.amount,
        o.original_amount,
        o.discount_amount,
        o.affiliate_code,
        o.status,
        o.payment_method,
        o.payment_reference,
        o.created_at,
        o.delivered_at
      FROM orders o
      JOIN products p ON o.product_id = p.id
      ORDER BY o.created_at DESC`
    ).all();

    const filename = `martama_commandes_${new Date().toISOString().split('T')[0]}.json`;
    
    return new Response(JSON.stringify(results, null, 2), {
      status: 200,
      headers: {
        "Content-Type": "application/json; charset=utf-8",
        "Content-Disposition": `attachment; filename="${filename}"`,
        "Cache-Control": "no-cache"
      }
    });
  } catch (error) {
    console.error("Error exporting orders:", error);
    return c.json({ error: "Erreur lors de l'export" }, 500);
  }
});

// Export affiliates as JSON (alternative format)
app.get("/affiliates-json", authMiddleware, adminMiddleware, async (c) => {
  try {
    const { results } = await c.env.DB.prepare(
      `SELECT 
        a.id,
        u.email,
        u.full_name,
        u.phone_number,
        a.promo_code,
        a.total_clicks,
        a.total_sales,
        a.total_commissions,
        a.balance,
        a.status,
        a.created_at
      FROM affiliates a
      JOIN users u ON a.user_id = u.id
      ORDER BY a.total_sales DESC`
    ).all();

    const filename = `martama_affilies_${new Date().toISOString().split('T')[0]}.json`;
    
    return new Response(JSON.stringify(results, null, 2), {
      status: 200,
      headers: {
        "Content-Type": "application/json; charset=utf-8",
        "Content-Disposition": `attachment; filename="${filename}"`,
        "Cache-Control": "no-cache"
      }
    });
  } catch (error) {
    console.error("Error exporting affiliates:", error);
    return c.json({ error: "Erreur lors de l'export" }, 500);
  }
});

export default app;
