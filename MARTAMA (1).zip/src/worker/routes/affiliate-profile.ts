import { Hono } from "hono";
import { authMiddleware } from "@getmocha/users-service/backend";

const app = new Hono<{ Bindings: Env }>();

// Get affiliate profile (payment info and promo code)
app.get("/api/affiliate/profile", authMiddleware, async (c) => {
  const user = c.get("user");
  
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }
  
  const affiliate = await c.env.DB.prepare(
    "SELECT * FROM affiliates WHERE user_id = ? AND status = 'active'"
  ).bind(user.id).first();
  
  if (!affiliate) {
    return c.json({ error: "Not an affiliate" }, 404);
  }
  
  return c.json(affiliate);
});

// Update affiliate promo code
app.put("/api/affiliate/update-promo-code", authMiddleware, async (c) => {
  const user = c.get("user");
  
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }
  
  const body = await c.req.json();
  const newPromoCode = body.promo_code?.toUpperCase().trim();
  
  if (!newPromoCode) {
    return c.json({ error: "Code promo requis" }, 400);
  }
  
  // Validate promo code format (alphanumeric, 3-20 characters)
  if (!/^[A-Z0-9]{3,20}$/.test(newPromoCode)) {
    return c.json({ error: "Code promo invalide. Utilisez 3-20 caractères alphanumériques." }, 400);
  }
  
  // Get affiliate
  const affiliate = await c.env.DB.prepare(
    "SELECT * FROM affiliates WHERE user_id = ? AND status = 'active'"
  ).bind(user.id).first();
  
  if (!affiliate) {
    return c.json({ error: "Not an affiliate" }, 404);
  }
  
  // Check if new promo code is already taken by another affiliate
  const existingAffiliate = await c.env.DB.prepare(
    "SELECT id FROM affiliates WHERE promo_code = ? AND id != ?"
  ).bind(newPromoCode, affiliate.id).first();
  
  if (existingAffiliate) {
    return c.json({ error: "Ce code promo est déjà utilisé par un autre affilié" }, 400);
  }
  
  // Check if code is in pending affiliate requests
  const pendingRequest = await c.env.DB.prepare(
    "SELECT id FROM affiliate_requests WHERE promo_code = ? AND status = 'pending'"
  ).bind(newPromoCode).first();
  
  if (pendingRequest) {
    return c.json({ error: "Ce code promo est déjà demandé dans une demande en attente" }, 400);
  }
  
  // Update affiliates table
  await c.env.DB.prepare(
    "UPDATE affiliates SET promo_code = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?"
  ).bind(newPromoCode, affiliate.id).run();
  
  // CRITICAL: Synchronize with users table
  await c.env.DB.prepare(
    "UPDATE users SET affiliate_code = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?"
  ).bind(newPromoCode, user.id).run();
  
  // Update exceptional promo codes if any reference this affiliate
  await c.env.DB.prepare(
    "UPDATE exceptional_promo_codes SET code = ?, updated_at = CURRENT_TIMESTAMP WHERE affiliate_id = ? AND code = ?"
  ).bind(newPromoCode, affiliate.id, affiliate.promo_code).run();
  
  const updatedAffiliate = await c.env.DB.prepare(
    "SELECT * FROM affiliates WHERE id = ?"
  ).bind(affiliate.id).first();
  
  return c.json({
    success: true,
    message: "Code promo mis à jour avec succès",
    affiliate: updatedAffiliate
  });
});

// Update affiliate payment information
app.put("/api/affiliate/update-payment-info", authMiddleware, async (c) => {
  const user = c.get("user");
  
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }
  
  const body = await c.req.json();
  
  // Get affiliate
  const affiliate = await c.env.DB.prepare(
    "SELECT * FROM affiliates WHERE user_id = ? AND status = 'active'"
  ).bind(user.id).first();
  
  if (!affiliate) {
    return c.json({ error: "Not an affiliate" }, 404);
  }
  
  // Update payment info in affiliates table
  await c.env.DB.prepare(
    `UPDATE affiliates SET 
     payment_phone_number = ?,
     updated_at = CURRENT_TIMESTAMP
     WHERE id = ?`
  ).bind(body.payment_phone_number || null, affiliate.id).run();
  
  // CRITICAL: Synchronize with users table
  await c.env.DB.prepare(
    `UPDATE users SET 
     payment_method = ?,
     payment_account_number = ?,
     payment_account_name = ?,
     updated_at = CURRENT_TIMESTAMP
     WHERE id = ?`
  ).bind(
    body.payment_method || null,
    body.payment_account_number || null,
    body.payment_account_name || null,
    user.id
  ).run();
  
  const updatedAffiliate = await c.env.DB.prepare(
    "SELECT * FROM affiliates WHERE id = ?"
  ).bind(affiliate.id).first();
  
  return c.json({
    success: true,
    message: "Informations de paiement mises à jour",
    affiliate: updatedAffiliate
  });
});

export default app;
