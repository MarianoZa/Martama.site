import { Hono } from "hono";
import { authMiddleware } from "@getmocha/users-service/backend";

const app = new Hono<{ Bindings: Env }>();

// Admin middleware
const adminMiddleware = async (c: any, next: any) => {
  const mochaUser = c.get("user");
  
  if (!mochaUser) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const userResult = await c.env.DB.prepare(
    "SELECT * FROM users WHERE id = ? AND role = 'admin'"
  ).bind(mochaUser.id).first();

  if (!userResult) {
    return c.json({ error: "Forbidden - Admin access required" }, 403);
  }

  await next();
};

// Get single order details (admin)
app.get("/:id", authMiddleware, adminMiddleware, async (c) => {
  const id = c.req.param("id");
  
  const order = await c.env.DB.prepare(
    `SELECT o.*, p.name as product_name, p.category as product_category
     FROM orders o
     JOIN products p ON o.product_id = p.id
     WHERE o.id = ?`
  ).bind(id).first();
  
  if (!order) {
    return c.json({ error: "Order not found" }, 404);
  }
  
  return c.json(order);
});

// Get order action logs (admin)
app.get("/:id/logs", authMiddleware, adminMiddleware, async (c) => {
  const id = c.req.param("id");
  
  const { results } = await c.env.DB.prepare(
    `SELECT * FROM order_action_logs 
     WHERE order_id = ? 
     ORDER BY created_at DESC`
  ).bind(id).all();
  
  return c.json(results);
});

export default app;
