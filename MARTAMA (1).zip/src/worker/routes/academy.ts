import { Hono } from "hono";
import { authMiddleware } from "@getmocha/users-service/backend";

const app = new Hono<{ Bindings: Env }>();

// Admin middleware
const adminMiddleware = async (c: any, next: any) => {
  const mochaUser = c.get("user");
  
  if (!mochaUser) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const userResult = await c.env.DB.prepare(
    "SELECT * FROM users WHERE id = ? AND role = 'admin'"
  ).bind(mochaUser.id).first();

  if (!userResult) {
    return c.json({ error: "Forbidden - Admin access required" }, 403);
  }

  await next();
};

// ============================================================================
// Public Academy Routes
// ============================================================================

// Get all active classes
app.get("/classes", async (c) => {
  const { results } = await c.env.DB.prepare(
    `SELECT * FROM academy_classes 
     WHERE is_active = 1 
     ORDER BY created_at DESC`
  ).all();
  
  return c.json(results);
});

// Get single class details
app.get("/classes/:id", async (c) => {
  const id = c.req.param("id");
  
  const classData = await c.env.DB.prepare(
    "SELECT * FROM academy_classes WHERE id = ? AND is_active = 1"
  ).bind(id).first();
  
  if (!classData) {
    return c.json({ error: "Class not found" }, 404);
  }
  
  return c.json(classData);
});

// Submit class join request
app.post("/classes/:id/request", authMiddleware, async (c) => {
  const user = c.get("user");
  const classId = c.req.param("id");
  const body = await c.req.json();
  
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }
  
  // Check if class exists and is active
  const classData = await c.env.DB.prepare(
    "SELECT * FROM academy_classes WHERE id = ? AND is_active = 1"
  ).bind(classId).first();
  
  if (!classData) {
    return c.json({ error: "Class not found" }, 404);
  }
  
  // Check if class is full
  if (classData.max_members && Number(classData.current_members) >= Number(classData.max_members)) {
    return c.json({ error: "Cette classe est complète" }, 400);
  }
  
  // Check if user already has a pending or approved request
  const existingRequest = await c.env.DB.prepare(
    "SELECT * FROM academy_class_requests WHERE class_id = ? AND user_email = ? AND status IN ('pending', 'approved')"
  ).bind(classId, user.email).first();
  
  if (existingRequest) {
    if (existingRequest.status === 'approved') {
      return c.json({ error: "Vous êtes déjà membre de cette classe" }, 400);
    }
    return c.json({ error: "Vous avez déjà une demande en attente pour cette classe" }, 400);
  }
  
  // Create request
  const result = await c.env.DB.prepare(
    `INSERT INTO academy_class_requests (
      class_id, user_email, user_name, user_phone, motivation, status
    ) VALUES (?, ?, ?, ?, ?, 'pending')`
  ).bind(
    classId,
    user.email,
    body.user_name || user.google_user_data?.name || '',
    body.user_phone || '',
    body.motivation || ''
  ).run();
  
  const request = await c.env.DB.prepare(
    "SELECT * FROM academy_class_requests WHERE id = ?"
  ).bind(result.meta.last_row_id).first();
  
  return c.json(request, 201);
});

// Get user's class requests
app.get("/my-requests", authMiddleware, async (c) => {
  const user = c.get("user");
  
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }
  
  const { results } = await c.env.DB.prepare(
    `SELECT cr.*, c.name as class_name, c.image_url as class_image
     FROM academy_class_requests cr
     JOIN academy_classes c ON cr.class_id = c.id
     WHERE cr.user_email = ?
     ORDER BY cr.created_at DESC`
  ).bind(user.email).all();
  
  return c.json(results);
});

// Get user's joined classes
app.get("/my-classes", authMiddleware, async (c) => {
  const user = c.get("user");
  
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }
  
  const { results } = await c.env.DB.prepare(
    `SELECT cm.*, c.*
     FROM academy_class_members cm
     JOIN academy_classes c ON cm.class_id = c.id
     WHERE cm.user_email = ? AND cm.is_active = 1
     ORDER BY cm.joined_at DESC`
  ).bind(user.email).all();
  
  return c.json(results);
});

// Check if user has access to a class
app.get("/classes/:id/access", authMiddleware, async (c) => {
  const user = c.get("user");
  const classId = c.req.param("id");
  
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }
  
  const member = await c.env.DB.prepare(
    `SELECT * FROM academy_class_members 
     WHERE class_id = ? AND user_email = ? AND is_active = 1`
  ).bind(classId, user.email).first();
  
  return c.json({ hasAccess: !!member });
});

// Get class modules with videos
app.get("/classes/:id/modules", authMiddleware, async (c) => {
  const user = c.get("user");
  const classId = c.req.param("id");
  
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }
  
  // Check access
  const member = await c.env.DB.prepare(
    `SELECT * FROM academy_class_members 
     WHERE class_id = ? AND user_email = ? AND is_active = 1`
  ).bind(classId, user.email).first();
  
  if (!member) {
    return c.json({ error: "Accès refusé" }, 403);
  }
  
  const { results } = await c.env.DB.prepare(
    `SELECT * FROM academy_modules 
     WHERE class_id = ? 
     ORDER BY display_order ASC, created_at ASC`
  ).bind(classId).all();
  
  return c.json(results);
});

// Get videos for a module
app.get("/modules/:moduleId/videos", authMiddleware, async (c) => {
  const user = c.get("user");
  const moduleId = c.req.param("moduleId");
  
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }
  
  // Get module and check access
  const module = await c.env.DB.prepare(
    "SELECT * FROM academy_modules WHERE id = ?"
  ).bind(moduleId).first();
  
  if (!module) {
    return c.json({ error: "Module non trouvé" }, 404);
  }
  
  const member = await c.env.DB.prepare(
    `SELECT * FROM academy_class_members 
     WHERE class_id = ? AND user_email = ? AND is_active = 1`
  ).bind(module.class_id, user.email).first();
  
  if (!member) {
    return c.json({ error: "Accès refusé" }, 403);
  }
  
  const { results } = await c.env.DB.prepare(
    `SELECT * FROM academy_videos 
     WHERE module_id = ? 
     ORDER BY display_order ASC, created_at ASC`
  ).bind(moduleId).all();
  
  return c.json(results);
});

// ============================================================================
// Admin Academy Routes
// ============================================================================

// Get all classes (admin)
app.get("/admin/classes", authMiddleware, adminMiddleware, async (c) => {
  const { results } = await c.env.DB.prepare(
    "SELECT * FROM academy_classes ORDER BY created_at DESC"
  ).all();
  
  return c.json(results);
});

// Create class (admin)
app.post("/admin/classes", authMiddleware, adminMiddleware, async (c) => {
  const body = await c.req.json();
  
  const result = await c.env.DB.prepare(
    `INSERT INTO academy_classes (
      name, description, image_url, instructor_name, category,
      max_members, start_date, end_date, meeting_schedule, requirements, is_active
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).bind(
    body.name,
    body.description || null,
    body.image_url || null,
    body.instructor_name || null,
    body.category || null,
    body.max_members || null,
    body.start_date || null,
    body.end_date || null,
    body.meeting_schedule || null,
    body.requirements || null,
    body.is_active !== undefined ? body.is_active : 1
  ).run();
  
  const classData = await c.env.DB.prepare(
    "SELECT * FROM academy_classes WHERE id = ?"
  ).bind(result.meta.last_row_id).first();
  
  return c.json(classData, 201);
});

// Update class (admin)
app.put("/admin/classes/:id", authMiddleware, adminMiddleware, async (c) => {
  const id = c.req.param("id");
  const body = await c.req.json();
  
  await c.env.DB.prepare(
    `UPDATE academy_classes SET
     name = ?, description = ?, image_url = ?, instructor_name = ?,
     category = ?, max_members = ?, start_date = ?, end_date = ?,
     meeting_schedule = ?, requirements = ?, is_active = ?,
     updated_at = CURRENT_TIMESTAMP
     WHERE id = ?`
  ).bind(
    body.name,
    body.description || null,
    body.image_url || null,
    body.instructor_name || null,
    body.category || null,
    body.max_members || null,
    body.start_date || null,
    body.end_date || null,
    body.meeting_schedule || null,
    body.requirements || null,
    body.is_active !== undefined ? body.is_active : 1,
    id
  ).run();
  
  const classData = await c.env.DB.prepare(
    "SELECT * FROM academy_classes WHERE id = ?"
  ).bind(id).first();
  
  return c.json(classData);
});

// Delete class (admin)
app.delete("/admin/classes/:id", authMiddleware, adminMiddleware, async (c) => {
  const id = c.req.param("id");
  
  await c.env.DB.prepare(
    "DELETE FROM academy_classes WHERE id = ?"
  ).bind(id).run();
  
  return c.json({ success: true });
});

// Get all class requests (admin)
app.get("/admin/requests", authMiddleware, adminMiddleware, async (c) => {
  const status = c.req.query("status");
  const classId = c.req.query("class_id");
  
  let query = `SELECT cr.*, c.name as class_name
               FROM academy_class_requests cr
               JOIN academy_classes c ON cr.class_id = c.id`;
  const params: any[] = [];
  const conditions: string[] = [];
  
  if (status && status !== 'all') {
    conditions.push("cr.status = ?");
    params.push(status);
  }
  
  if (classId) {
    conditions.push("cr.class_id = ?");
    params.push(classId);
  }
  
  if (conditions.length > 0) {
    query += " WHERE " + conditions.join(" AND ");
  }
  
  query += " ORDER BY cr.created_at DESC";
  
  const { results } = await c.env.DB.prepare(query).bind(...params).all();
  
  return c.json(results);
});

// Approve class request (admin)
app.post("/admin/requests/:id/approve", authMiddleware, adminMiddleware, async (c) => {
  const id = c.req.param("id");
  const body = await c.req.json();
  const adminUser = c.get("user");
  
  if (!adminUser) {
    return c.json({ error: "Unauthorized" }, 401);
  }
  
  const request = await c.env.DB.prepare(
    "SELECT * FROM academy_class_requests WHERE id = ?"
  ).bind(id).first();
  
  if (!request) {
    return c.json({ error: "Request not found" }, 404);
  }
  
  if (request.status !== 'pending') {
    return c.json({ error: "Request already processed" }, 400);
  }
  
  // Check if class is full
  const classData = await c.env.DB.prepare(
    "SELECT * FROM academy_classes WHERE id = ?"
  ).bind(request.class_id).first();
  
  if (classData?.max_members && Number(classData.current_members) >= Number(classData.max_members)) {
    return c.json({ error: "Class is full" }, 400);
  }
  
  // Update request status
  await c.env.DB.prepare(
    `UPDATE academy_class_requests SET 
     status = 'approved',
     reviewed_by = ?,
     reviewed_at = CURRENT_TIMESTAMP,
     admin_notes = ?,
     updated_at = CURRENT_TIMESTAMP
     WHERE id = ?`
  ).bind(adminUser.id, body.admin_notes || null, id).run();
  
  // Add user as member
  const existingMember = await c.env.DB.prepare(
    "SELECT * FROM academy_class_members WHERE class_id = ? AND user_email = ?"
  ).bind(request.class_id, request.user_email).first();
  
  if (!existingMember) {
    await c.env.DB.prepare(
      `INSERT INTO academy_class_members (class_id, user_email)
       VALUES (?, ?)`
    ).bind(request.class_id, request.user_email).run();
    
    // Increment class member count
    await c.env.DB.prepare(
      "UPDATE academy_classes SET current_members = current_members + 1 WHERE id = ?"
    ).bind(request.class_id).run();
  }
  
  const updatedRequest = await c.env.DB.prepare(
    "SELECT * FROM academy_class_requests WHERE id = ?"
  ).bind(id).first();
  
  return c.json(updatedRequest);
});

// Reject class request (admin)
app.post("/admin/requests/:id/reject", authMiddleware, adminMiddleware, async (c) => {
  const id = c.req.param("id");
  const body = await c.req.json();
  const adminUser = c.get("user");
  
  if (!adminUser) {
    return c.json({ error: "Unauthorized" }, 401);
  }
  
  const request = await c.env.DB.prepare(
    "SELECT * FROM academy_class_requests WHERE id = ?"
  ).bind(id).first();
  
  if (!request) {
    return c.json({ error: "Request not found" }, 404);
  }
  
  if (request.status !== 'pending') {
    return c.json({ error: "Request already processed" }, 400);
  }
  
  await c.env.DB.prepare(
    `UPDATE academy_class_requests SET 
     status = 'rejected',
     reviewed_by = ?,
     reviewed_at = CURRENT_TIMESTAMP,
     admin_notes = ?,
     updated_at = CURRENT_TIMESTAMP
     WHERE id = ?`
  ).bind(adminUser.id, body.admin_notes || null, id).run();
  
  const updatedRequest = await c.env.DB.prepare(
    "SELECT * FROM academy_class_requests WHERE id = ?"
  ).bind(id).first();
  
  return c.json(updatedRequest);
});

// Get class members (admin)
app.get("/admin/classes/:id/members", authMiddleware, adminMiddleware, async (c) => {
  const id = c.req.param("id");
  
  const { results } = await c.env.DB.prepare(
    "SELECT * FROM academy_class_members WHERE class_id = ? ORDER BY joined_at DESC"
  ).bind(id).all();
  
  return c.json(results);
});

// Remove member from class (admin)
app.delete("/admin/classes/:classId/members/:memberId", authMiddleware, adminMiddleware, async (c) => {
  const classId = c.req.param("classId");
  const memberId = c.req.param("memberId");
  
  await c.env.DB.prepare(
    "DELETE FROM academy_class_members WHERE id = ?"
  ).bind(memberId).run();
  
  // Decrement class member count
  await c.env.DB.prepare(
    "UPDATE academy_classes SET current_members = CASE WHEN current_members > 0 THEN current_members - 1 ELSE 0 END WHERE id = ?"
  ).bind(classId).run();
  
  return c.json({ success: true });
});

// ============================================================================
// Admin Video Management Routes
// ============================================================================

// Get class modules (admin)
app.get("/admin/classes/:classId/modules", authMiddleware, adminMiddleware, async (c) => {
  const classId = c.req.param("classId");
  
  const { results } = await c.env.DB.prepare(
    `SELECT * FROM academy_modules 
     WHERE class_id = ? 
     ORDER BY display_order ASC, created_at ASC`
  ).bind(classId).all();
  
  return c.json(results);
});

// Create module (admin)
app.post("/admin/modules", authMiddleware, adminMiddleware, async (c) => {
  const body = await c.req.json();
  
  const result = await c.env.DB.prepare(
    `INSERT INTO academy_modules (class_id, title, description, display_order)
     VALUES (?, ?, ?, ?)`
  ).bind(
    body.class_id,
    body.title,
    body.description || null,
    body.display_order || 0
  ).run();
  
  const module = await c.env.DB.prepare(
    "SELECT * FROM academy_modules WHERE id = ?"
  ).bind(result.meta.last_row_id).first();
  
  return c.json(module, 201);
});

// Update module (admin)
app.put("/admin/modules/:id", authMiddleware, adminMiddleware, async (c) => {
  const id = c.req.param("id");
  const body = await c.req.json();
  
  await c.env.DB.prepare(
    `UPDATE academy_modules SET
     title = ?, description = ?, display_order = ?, updated_at = CURRENT_TIMESTAMP
     WHERE id = ?`
  ).bind(
    body.title,
    body.description || null,
    body.display_order || 0,
    id
  ).run();
  
  const module = await c.env.DB.prepare(
    "SELECT * FROM academy_modules WHERE id = ?"
  ).bind(id).first();
  
  return c.json(module);
});

// Delete module (admin)
app.delete("/admin/modules/:id", authMiddleware, adminMiddleware, async (c) => {
  const id = c.req.param("id");
  
  // Delete videos first
  await c.env.DB.prepare(
    "DELETE FROM academy_videos WHERE module_id = ?"
  ).bind(id).run();
  
  // Delete module
  await c.env.DB.prepare(
    "DELETE FROM academy_modules WHERE id = ?"
  ).bind(id).run();
  
  return c.json({ success: true });
});

// Get module videos (admin)
app.get("/admin/modules/:moduleId/videos", authMiddleware, adminMiddleware, async (c) => {
  const moduleId = c.req.param("moduleId");
  
  const { results } = await c.env.DB.prepare(
    `SELECT * FROM academy_videos 
     WHERE module_id = ? 
     ORDER BY display_order ASC, created_at ASC`
  ).bind(moduleId).all();
  
  return c.json(results);
});

// Create video (admin)
app.post("/admin/videos", authMiddleware, adminMiddleware, async (c) => {
  const body = await c.req.json();
  
  const result = await c.env.DB.prepare(
    `INSERT INTO academy_videos (
      module_id, class_id, title, video_type, video_url, aspect_ratio, duration_minutes, display_order, resources
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).bind(
    body.module_id,
    body.class_id,
    body.title,
    body.video_type,
    body.video_url,
    body.aspect_ratio || '16:9',
    body.duration_minutes || null,
    body.display_order || 0,
    body.resources ? JSON.stringify(body.resources) : null
  ).run();
  
  const video = await c.env.DB.prepare(
    "SELECT * FROM academy_videos WHERE id = ?"
  ).bind(result.meta.last_row_id).first();
  
  return c.json(video, 201);
});

// Update video (admin)
app.put("/admin/videos/:id", authMiddleware, adminMiddleware, async (c) => {
  const id = c.req.param("id");
  const body = await c.req.json();
  
  await c.env.DB.prepare(
    `UPDATE academy_videos SET
     title = ?, video_type = ?, video_url = ?, aspect_ratio = ?, 
     duration_minutes = ?, display_order = ?, resources = ?, updated_at = CURRENT_TIMESTAMP
     WHERE id = ?`
  ).bind(
    body.title,
    body.video_type,
    body.video_url,
    body.aspect_ratio || '16:9',
    body.duration_minutes || null,
    body.display_order || 0,
    body.resources ? JSON.stringify(body.resources) : null,
    id
  ).run();
  
  const video = await c.env.DB.prepare(
    "SELECT * FROM academy_videos WHERE id = ?"
  ).bind(id).first();
  
  return c.json(video);
});

// Delete video (admin)
app.delete("/admin/videos/:id", authMiddleware, adminMiddleware, async (c) => {
  const id = c.req.param("id");
  
  await c.env.DB.prepare(
    "DELETE FROM academy_videos WHERE id = ?"
  ).bind(id).run();
  
  return c.json({ success: true });
});

// ============================================================================
// Academy Video Comments Routes
// ============================================================================

// Get comments for a video
app.get("/videos/:videoId/comments", authMiddleware, async (c) => {
  const videoId = c.req.param("videoId");
  const user = c.get("user");
  
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }
  
  // Verify user has access to this video's class
  const video = await c.env.DB.prepare(
    "SELECT * FROM academy_videos WHERE id = ?"
  ).bind(videoId).first();
  
  if (!video) {
    return c.json({ error: "Vidéo non trouvée" }, 404);
  }
  
  const member = await c.env.DB.prepare(
    `SELECT * FROM academy_class_members 
     WHERE class_id = ? AND user_email = ? AND is_active = 1`
  ).bind(video.class_id, user.email).first();
  
  if (!member) {
    return c.json({ error: "Accès refusé" }, 403);
  }
  
  // Get all comments with user info
  const { results } = await c.env.DB.prepare(
    `SELECT c.*, u.full_name as user_name
     FROM academy_video_comments c
     LEFT JOIN users u ON c.user_email = u.email
     WHERE c.video_id = ?
     ORDER BY c.created_at ASC`
  ).bind(videoId).all();
  
  return c.json(results);
});

// Post a comment on a video
app.post("/videos/:videoId/comments", authMiddleware, async (c) => {
  const videoId = c.req.param("videoId");
  const user = c.get("user");
  const body = await c.req.json();
  
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }
  
  if (!body.comment || body.comment.trim().length === 0) {
    return c.json({ error: "Le commentaire ne peut pas être vide" }, 400);
  }
  
  // Verify user has access to this video's class
  const video = await c.env.DB.prepare(
    "SELECT * FROM academy_videos WHERE id = ?"
  ).bind(videoId).first();
  
  if (!video) {
    return c.json({ error: "Vidéo non trouvée" }, 404);
  }
  
  const member = await c.env.DB.prepare(
    `SELECT * FROM academy_class_members 
     WHERE class_id = ? AND user_email = ? AND is_active = 1`
  ).bind(video.class_id, user.email).first();
  
  if (!member) {
    return c.json({ error: "Accès refusé" }, 403);
  }
  
  // If parent_comment_id is provided, verify it exists
  if (body.parent_comment_id) {
    const parentComment = await c.env.DB.prepare(
      "SELECT * FROM academy_video_comments WHERE id = ? AND video_id = ?"
    ).bind(body.parent_comment_id, videoId).first();
    
    if (!parentComment) {
      return c.json({ error: "Commentaire parent non trouvé" }, 404);
    }
  }
  
  const result = await c.env.DB.prepare(
    `INSERT INTO academy_video_comments (video_id, user_email, comment, parent_comment_id)
     VALUES (?, ?, ?, ?)`
  ).bind(
    videoId,
    user.email,
    body.comment.trim(),
    body.parent_comment_id || null
  ).run();
  
  const comment = await c.env.DB.prepare(
    `SELECT c.*, u.full_name as user_name
     FROM academy_video_comments c
     LEFT JOIN users u ON c.user_email = u.email
     WHERE c.id = ?`
  ).bind(result.meta.last_row_id).first();
  
  return c.json(comment, 201);
});

// Update a comment
app.put("/comments/:commentId", authMiddleware, async (c) => {
  const commentId = c.req.param("commentId");
  const user = c.get("user");
  const body = await c.req.json();
  
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }
  
  if (!body.comment || body.comment.trim().length === 0) {
    return c.json({ error: "Le commentaire ne peut pas être vide" }, 400);
  }
  
  const comment = await c.env.DB.prepare(
    "SELECT * FROM academy_video_comments WHERE id = ?"
  ).bind(commentId).first();
  
  if (!comment) {
    return c.json({ error: "Commentaire non trouvé" }, 404);
  }
  
  // Only the author can update their comment
  if (comment.user_email !== user.email) {
    return c.json({ error: "Vous ne pouvez modifier que vos propres commentaires" }, 403);
  }
  
  await c.env.DB.prepare(
    `UPDATE academy_video_comments 
     SET comment = ?, updated_at = CURRENT_TIMESTAMP
     WHERE id = ?`
  ).bind(body.comment.trim(), commentId).run();
  
  const updatedComment = await c.env.DB.prepare(
    `SELECT c.*, u.full_name as user_name
     FROM academy_video_comments c
     LEFT JOIN users u ON c.user_email = u.email
     WHERE c.id = ?`
  ).bind(commentId).first();
  
  return c.json(updatedComment);
});

// Delete a comment
app.delete("/comments/:commentId", authMiddleware, async (c) => {
  const commentId = c.req.param("commentId");
  const user = c.get("user");
  
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }
  
  const comment = await c.env.DB.prepare(
    "SELECT * FROM academy_video_comments WHERE id = ?"
  ).bind(commentId).first();
  
  if (!comment) {
    return c.json({ error: "Commentaire non trouvé" }, 404);
  }
  
  // Check if user is admin
  const adminUser = await c.env.DB.prepare(
    "SELECT * FROM users WHERE email = ? AND role = 'admin'"
  ).bind(user.email).first();
  
  // Only the author or an admin can delete the comment
  if (comment.user_email !== user.email && !adminUser) {
    return c.json({ error: "Vous ne pouvez supprimer que vos propres commentaires" }, 403);
  }
  
  // Delete the comment and all its replies (CASCADE)
  await c.env.DB.prepare(
    "DELETE FROM academy_video_comments WHERE id = ?"
  ).bind(commentId).run();
  
  return c.json({ success: true });
});

export default app;
