import { Hono } from "hono";
import { authMiddleware } from "@getmocha/users-service/backend";
import { AdminRole, ROLE_LABELS, ROLE_DESCRIPTIONS } from "../utils/admin-permissions";

const app = new Hono<{ Bindings: Env }>();

// Super admin middleware - only super admins can manage other admins
const superAdminMiddleware = async (c: any, next: any) => {
  const mochaUser = c.get("user");
  
  if (!mochaUser) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  // Check by email instead of ID to handle Mocha authentication properly
  const userResult = await c.env.DB.prepare(
    "SELECT * FROM users WHERE email = ? AND role = 'admin' AND admin_role = 'super_admin'"
  ).bind(mochaUser.email).first();

  if (!userResult) {
    return c.json({ 
      error: "Forbidden - Super admin access required",
      debug: {
        email: mochaUser.email,
        message: "Please contact a super administrator to grant you access"
      }
    }, 403);
  }

  // Store the local user data in context for later use
  c.set("localUser", userResult);

  await next();
};

// Get all admin users (super admin only)
app.get("/", authMiddleware, superAdminMiddleware, async (c) => {
  try {
    const { results } = await c.env.DB.prepare(
      `SELECT 
        id, email, full_name, phone_number, role, admin_role,
        is_active, created_at, updated_at
       FROM users 
       WHERE role = 'admin'
       ORDER BY 
         CASE admin_role
           WHEN 'super_admin' THEN 1
           WHEN 'data_analyst' THEN 2
           WHEN 'delivery_agent' THEN 3
           WHEN 'affiliate_manager' THEN 4
           WHEN 'content_moderator' THEN 5
           ELSE 6
         END,
         created_at DESC`
    ).all();

    return c.json(results);
  } catch (error) {
    console.error("Error fetching admin users:", error);
    return c.json({ error: "Failed to fetch admin users" }, 500);
  }
});

// Get all regular users (non-admins) for selection
app.get("/users", authMiddleware, superAdminMiddleware, async (c) => {
  try {
    const { results } = await c.env.DB.prepare(
      `SELECT id, email, full_name, phone_number, created_at
       FROM users 
       WHERE role != 'admin'
       ORDER BY created_at DESC
       LIMIT 500`
    ).all();

    return c.json(results);
  } catch (error) {
    console.error("Error fetching regular users:", error);
    return c.json({ error: "Failed to fetch users" }, 500);
  }
});

// Get available roles and their descriptions
app.get("/roles", authMiddleware, superAdminMiddleware, async (c) => {
  const roles = Object.keys(ROLE_LABELS).map(role => ({
    value: role,
    label: ROLE_LABELS[role as AdminRole],
    description: ROLE_DESCRIPTIONS[role as AdminRole],
  }));

  return c.json(roles);
});

// Add admin role to existing user (super admin only)
app.post("/", authMiddleware, superAdminMiddleware, async (c) => {
  try {
    const body = await c.req.json();
    const adminUser = c.get("user");

    if (!adminUser) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    // Validate required fields
    if (!body.user_id || !body.admin_role) {
      return c.json({ error: "User ID and admin role are required" }, 400);
    }

    // Validate admin role
    const validRoles: AdminRole[] = ['super_admin', 'data_analyst', 'delivery_agent', 'affiliate_manager', 'content_moderator'];
    if (!validRoles.includes(body.admin_role)) {
      return c.json({ error: "Invalid admin role" }, 400);
    }

    // Check if user exists
    const existingUser = await c.env.DB.prepare(
      "SELECT * FROM users WHERE id = ?"
    ).bind(body.user_id).first();

    if (!existingUser) {
      return c.json({ error: "User not found" }, 404);
    }

    // Check if already an admin
    if (existingUser.role === 'admin') {
      return c.json({ error: "User is already an admin" }, 400);
    }

    // Promote user to admin
    await c.env.DB.prepare(
      `UPDATE users SET 
       role = 'admin',
       admin_role = ?,
       is_active = 1,
       updated_at = CURRENT_TIMESTAMP
       WHERE id = ?`
    ).bind(body.admin_role, body.user_id).run();

    // Log the action
    const ipAddress = c.req.header('CF-Connecting-IP') || c.req.header('X-Forwarded-For') || 'unknown';
    await c.env.DB.prepare(
      `INSERT INTO admin_activity_logs (
        admin_id, admin_email, admin_role, action_type, 
        action_details, target_user_id, ip_address
      ) VALUES (?, ?, 'super_admin', 'promote_to_admin', ?, ?, ?)`
    ).bind(
      adminUser.id,
      adminUser.email,
      `Promoted user to admin with role: ${body.admin_role}`,
      body.user_id,
      ipAddress
    ).run();

    const newAdmin = await c.env.DB.prepare(
      "SELECT id, email, full_name, role, admin_role, is_active, created_at FROM users WHERE id = ?"
    ).bind(body.user_id).first();

    return c.json(newAdmin, 201);
  } catch (error) {
    console.error("Error promoting user to admin:", error);
    return c.json({ error: "Failed to promote user to admin" }, 500);
  }
});

// Update admin role (super admin only)
app.put("/:id", authMiddleware, superAdminMiddleware, async (c) => {
  try {
    const id = c.req.param("id");
    const body = await c.req.json();
    const adminUser = c.get("user");

    if (!adminUser) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    // Prevent super admin from changing their own role
    if (id === adminUser.id) {
      return c.json({ error: "Cannot change your own admin role" }, 400);
    }

    const targetUser = await c.env.DB.prepare(
      "SELECT * FROM users WHERE id = ? AND role = 'admin'"
    ).bind(id).first();

    if (!targetUser) {
      return c.json({ error: "Admin not found" }, 404);
    }

    // Update admin role
    await c.env.DB.prepare(
      `UPDATE users SET 
       admin_role = ?,
       is_active = ?,
       updated_at = CURRENT_TIMESTAMP
       WHERE id = ?`
    ).bind(
      body.admin_role,
      body.is_active !== undefined ? body.is_active : 1,
      id
    ).run();

    // Log the action
    const ipAddress = c.req.header('CF-Connecting-IP') || c.req.header('X-Forwarded-For') || 'unknown';
    await c.env.DB.prepare(
      `INSERT INTO admin_activity_logs (
        admin_id, admin_email, admin_role, action_type, 
        action_details, target_user_id, ip_address
      ) VALUES (?, ?, 'super_admin', 'update_admin', ?, ?, ?)`
    ).bind(
      adminUser.id,
      adminUser.email,
      `Updated admin role to: ${body.admin_role}, active: ${body.is_active}`,
      id,
      ipAddress
    ).run();

    const updatedAdmin = await c.env.DB.prepare(
      "SELECT id, email, full_name, role, admin_role, is_active, created_at FROM users WHERE id = ?"
    ).bind(id).first();

    return c.json(updatedAdmin);
  } catch (error) {
    console.error("Error updating admin:", error);
    return c.json({ error: "Failed to update admin" }, 500);
  }
});

// Remove admin role (super admin only)
app.delete("/:id", authMiddleware, superAdminMiddleware, async (c) => {
  try {
    const id = c.req.param("id");
    const adminUser = c.get("user");

    if (!adminUser) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    // Prevent super admin from removing themselves
    if (id === adminUser.id) {
      return c.json({ error: "Cannot remove your own admin role" }, 400);
    }

    const targetUser = await c.env.DB.prepare(
      "SELECT * FROM users WHERE id = ? AND role = 'admin'"
    ).bind(id).first();

    if (!targetUser) {
      return c.json({ error: "Admin not found" }, 404);
    }

    // Downgrade to regular user
    await c.env.DB.prepare(
      `UPDATE users SET 
       role = 'user',
       admin_role = NULL,
       updated_at = CURRENT_TIMESTAMP
       WHERE id = ?`
    ).bind(id).run();

    // Log the action
    const ipAddress = c.req.header('CF-Connecting-IP') || c.req.header('X-Forwarded-For') || 'unknown';
    await c.env.DB.prepare(
      `INSERT INTO admin_activity_logs (
        admin_id, admin_email, admin_role, action_type, 
        action_details, target_user_id, ip_address
      ) VALUES (?, ?, 'super_admin', 'remove_admin', ?, ?, ?)`
    ).bind(
      adminUser.id,
      adminUser.email,
      `Removed admin role from user`,
      id,
      ipAddress
    ).run();

    return c.json({ success: true });
  } catch (error) {
    console.error("Error removing admin:", error);
    return c.json({ error: "Failed to remove admin" }, 500);
  }
});

// Get admin activity logs (super admin only)
app.get("/activity-logs", authMiddleware, superAdminMiddleware, async (c) => {
  try {
    const { results } = await c.env.DB.prepare(
      `SELECT * FROM admin_activity_logs 
       ORDER BY created_at DESC 
       LIMIT 100`
    ).all();

    return c.json(results);
  } catch (error) {
    console.error("Error fetching activity logs:", error);
    return c.json({ error: "Failed to fetch activity logs" }, 500);
  }
});

export default app;
