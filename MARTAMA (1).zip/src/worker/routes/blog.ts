import { Hono } from 'hono';

const app = new Hono<{ Bindings: Env }>();

// Get all published blog posts (public)
app.get('/posts', async (c) => {
  try {
    const db = c.env.DB;
    
    const posts = await db.prepare(`
      SELECT id, title, slug, excerpt, image_url, author_name, category, published_at, created_at
      FROM blog_posts
      WHERE is_published = 1
      ORDER BY published_at DESC
    `).all();
    
    return c.json(posts.results || []);
  } catch (error) {
    console.error('Failed to fetch blog posts:', error);
    return c.json({ error: 'Failed to fetch blog posts' }, 500);
  }
});

// Get single blog post by slug (public)
app.get('/posts/:slug', async (c) => {
  try {
    const db = c.env.DB;
    const slug = c.req.param('slug');
    
    const post = await db.prepare(`
      SELECT *
      FROM blog_posts
      WHERE slug = ? AND is_published = 1
    `).bind(slug).first();
    
    if (!post) {
      return c.json({ error: 'Blog post not found' }, 404);
    }
    
    return c.json(post);
  } catch (error) {
    console.error('Failed to fetch blog post:', error);
    return c.json({ error: 'Failed to fetch blog post' }, 500);
  }
});

// Admin routes
app.get('/admin/posts', async (c) => {
  try {
    const db = c.env.DB;
    
    const posts = await db.prepare(`
      SELECT *
      FROM blog_posts
      ORDER BY created_at DESC
    `).all();
    
    return c.json(posts.results || []);
  } catch (error) {
    console.error('Failed to fetch blog posts:', error);
    return c.json({ error: 'Failed to fetch blog posts' }, 500);
  }
});

app.get('/admin/posts/:id', async (c) => {
  try {
    const db = c.env.DB;
    const id = c.req.param('id');
    
    const post = await db.prepare(`
      SELECT *
      FROM blog_posts
      WHERE id = ?
    `).bind(id).first();
    
    if (!post) {
      return c.json({ error: 'Blog post not found' }, 404);
    }
    
    return c.json(post);
  } catch (error) {
    console.error('Failed to fetch blog post:', error);
    return c.json({ error: 'Failed to fetch blog post' }, 500);
  }
});

app.post('/admin/posts', async (c) => {
  try {
    const db = c.env.DB;
    const body = await c.req.json();
    
    const { title, slug, excerpt, content, image_url, author_name, category, is_published } = body;
    
    // Validate required fields
    if (!title || !slug || !content) {
      return c.json({ error: 'Title, slug, and content are required' }, 400);
    }
    
    // Check if slug already exists
    const existing = await db.prepare('SELECT id FROM blog_posts WHERE slug = ?').bind(slug).first();
    if (existing) {
      return c.json({ error: 'A post with this slug already exists' }, 400);
    }
    
    const published_at = is_published ? new Date().toISOString() : null;
    
    const result = await db.prepare(`
      INSERT INTO blog_posts (title, slug, excerpt, content, image_url, author_name, category, is_published, published_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      title,
      slug,
      excerpt || null,
      content,
      image_url || null,
      author_name || null,
      category || null,
      is_published ? 1 : 0,
      published_at
    ).run();
    
    return c.json({ success: true, id: result.meta.last_row_id });
  } catch (error) {
    console.error('Failed to create blog post:', error);
    return c.json({ error: 'Failed to create blog post' }, 500);
  }
});

app.put('/admin/posts/:id', async (c) => {
  try {
    const db = c.env.DB;
    const id = c.req.param('id');
    const body = await c.req.json();
    
    const { title, slug, excerpt, content, image_url, author_name, category, is_published } = body;
    
    // Validate required fields
    if (!title || !slug || !content) {
      return c.json({ error: 'Title, slug, and content are required' }, 400);
    }
    
    // Check if slug is used by another post
    const existing = await db.prepare('SELECT id FROM blog_posts WHERE slug = ? AND id != ?').bind(slug, id).first();
    if (existing) {
      return c.json({ error: 'A post with this slug already exists' }, 400);
    }
    
    // Get current post to check if we need to set published_at
    const currentPost = await db.prepare('SELECT is_published, published_at FROM blog_posts WHERE id = ?').bind(id).first();
    
    if (!currentPost) {
      return c.json({ error: 'Post not found' }, 404);
    }
    
    let published_at = currentPost.published_at;
    if (is_published && !currentPost.is_published) {
      // Being published for the first time
      published_at = new Date().toISOString();
    } else if (!is_published) {
      // Being unpublished
      published_at = null;
    }
    
    await db.prepare(`
      UPDATE blog_posts
      SET title = ?, slug = ?, excerpt = ?, content = ?, image_url = ?, 
          author_name = ?, category = ?, is_published = ?, published_at = ?,
          updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).bind(
      title,
      slug,
      excerpt || null,
      content,
      image_url || null,
      author_name || null,
      category || null,
      is_published ? 1 : 0,
      published_at,
      id
    ).run();
    
    return c.json({ success: true });
  } catch (error) {
    console.error('Failed to update blog post:', error);
    return c.json({ error: 'Failed to update blog post' }, 500);
  }
});

app.delete('/admin/posts/:id', async (c) => {
  try {
    const db = c.env.DB;
    const id = c.req.param('id');
    
    await db.prepare('DELETE FROM blog_posts WHERE id = ?').bind(id).run();
    
    return c.json({ success: true });
  } catch (error) {
    console.error('Failed to delete blog post:', error);
    return c.json({ error: 'Failed to delete blog post' }, 500);
  }
});

export default app;
