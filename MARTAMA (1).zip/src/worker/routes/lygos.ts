import { Hono } from "hono";

const app = new Hono<{ Bindings: Env }>();

interface LygosGatewayResponse {
  id?: string;
  gateway_id?: string;
  link: string;
  status?: string;
}

interface LygosPayinStatusResponse {
  status: string;
  amount?: number;
  order_id?: string;
}

// Create Lygospay payment gateway
app.post("/api/create-lygos-payment", async (c) => {
  try {
    const body = await c.req.json();
    const { product_id, duration_months, affiliate_code } = body;

    // Get product details
    const product = await c.env.DB.prepare(
      "SELECT * FROM products WHERE id = ? AND is_active = 1"
    ).bind(product_id).first();

    if (!product) {
      return c.json({ error: "Produit non trouvé" }, 404);
    }

    // Check if product is formation or pack - can only be purchased once
    if (product.category === 'formation' || product.category === 'pack') {
      const existingOrder = await c.env.DB.prepare(
        `SELECT id FROM orders 
         WHERE customer_email = ? 
         AND product_id = ? 
         AND status IN ('paid', 'delivered')
         LIMIT 1`
      ).bind(body.customer_email || 'pending@martama.app', product_id).first();
      
      if (existingOrder) {
        return c.json({ 
          error: `Vous avez déjà acheté cette ${product.category === 'formation' ? 'formation' : 'pack'}. Les mises à jour futures sont automatiques et incluses dans votre achat initial.`,
          already_purchased: true
        }, 400);
      }
    }

    // Calculate price
    let originalPrice = 0;
    if (product.price_options) {
      try {
        const options = JSON.parse(product.price_options as string);
        const selectedOption = options.find((opt: any) => opt.months === duration_months);
        if (selectedOption) {
          originalPrice = parseFloat(selectedOption.price);
        }
      } catch (e) {
        console.error("Failed to parse price_options:", e);
      }
    }

    // Fallback to old pricing system
    if (originalPrice === 0) {
      if (duration_months === 1 && product.price_1_months) {
        originalPrice = Number(product.price_1_months);
      } else if (duration_months === 3 && product.price_3_months) {
        originalPrice = Number(product.price_3_months);
      } else if (duration_months === 6 && product.price_6_months) {
        originalPrice = Number(product.price_6_months);
      }
    }

    if (originalPrice === 0) {
      return c.json({ error: "Prix non disponible pour cette durée" }, 400);
    }

    // Validate affiliate code if provided
    let affiliateId: number | null = null;
    let discountRate = 0;
    let affiliateCommissionRate = 0;

    if (affiliate_code) {
      // Check exceptional codes first
      const exceptionalCode = await c.env.DB.prepare(
        `SELECT * FROM exceptional_promo_codes 
         WHERE code = ? 
         AND is_active = 1 
         AND (start_date IS NULL OR start_date <= datetime('now'))
         AND (end_date IS NULL OR end_date >= datetime('now'))`
      ).bind(affiliate_code).first();

      if (exceptionalCode) {
        affiliateId = Number(exceptionalCode.affiliate_id);
        discountRate = Number(exceptionalCode.discount_rate);
        affiliateCommissionRate = Number(exceptionalCode.commission_rate);
      } else {
        // Check regular affiliate codes
        const affiliate = await c.env.DB.prepare(
          "SELECT * FROM affiliates WHERE promo_code = ? AND status = 'active'"
        ).bind(affiliate_code).first();

        if (!affiliate) {
          // REJECT invalid promo code - do NOT proceed with original price
          return c.json({ 
            error: "Code promo invalide ou inactif - Veuillez vérifier votre code",
            invalid_promo: true
          }, 400);
        }
        
        affiliateId = Number(affiliate.id);
        discountRate = Number(product.client_discount_rate || 0);
        affiliateCommissionRate = Number(product.affiliate_commission_rate || 0);
      }
    }

    // Calculate final amounts
    const discountAmount = originalPrice * discountRate;
    const finalAmount = originalPrice - discountAmount;
    const affiliateCommission = affiliateId ? finalAmount * affiliateCommissionRate : 0;

    // Generate unique order ID
    const uniqueOrderId = `MART_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

    // Create pending order
    const orderResult = await c.env.DB.prepare(
      `INSERT INTO orders (
        product_id, customer_email, duration_months, 
        amount, original_amount, discount_amount,
        affiliate_code, affiliate_id, affiliate_commission,
        status, payment_method, payment_reference
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', 'lygos', ?)`
    ).bind(
      product_id,
      body.customer_email || 'pending@martama.app',
      duration_months,
      finalAmount,
      originalPrice,
      discountAmount,
      affiliate_code || null,
      affiliateId,
      affiliateCommission,
      uniqueOrderId
    ).run();

    const orderId = orderResult.meta.last_row_id;

    // Call Lygospay API to create gateway
    const lygosApiKey = c.env.LYGOSPAY_API_KEY;
    if (!lygosApiKey) {
      return c.json({ error: "Clé API Lygospay non configurée" }, 500);
    }

    const lygosPayload = {
      amount: Math.round(finalAmount),
      shop_name: "Martama",
      message: `${product.name} - ${duration_months} mois`,
      order_id: uniqueOrderId,
      success_url: `https://martama.site/lygos-success?order_id=${orderId}`,
      failure_url: `https://martama.site/lygos-failure?order_id=${orderId}`,
    };

    const lygosResponse = await fetch("https://api.lygosapp.com/v1/gateway", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "api-key": lygosApiKey,
      },
      body: JSON.stringify(lygosPayload),
    });

    if (!lygosResponse.ok) {
      const errorText = await lygosResponse.text();
      console.error("Lygospay API error:", errorText);
      
      // Delete the pending order
      await c.env.DB.prepare("DELETE FROM orders WHERE id = ?").bind(orderId).run();
      
      return c.json({ error: "Erreur lors de la création du paiement Lygospay" }, 500);
    }

    const lygosData = await lygosResponse.json() as LygosGatewayResponse;

    // Update order with Lygos gateway ID and details
    await c.env.DB.prepare(
      "UPDATE orders SET payment_reference = ?, payment_gateway = 'Lygospay', transaction_details = ? WHERE id = ?"
    ).bind(
      lygosData.id || lygosData.gateway_id,
      JSON.stringify({ gateway_id: lygosData.id || lygosData.gateway_id, created_at: new Date().toISOString() }),
      orderId
    ).run();

    // Log order creation
    await c.env.DB.prepare(
      `INSERT INTO order_action_logs (order_id, action_type, action_details, performed_by)
       VALUES (?, 'order_created', ?, 'customer')`
    ).bind(
      orderId,
      `Commande créée via Lygospay | Montant: ${finalAmount.toLocaleString()} FCFA | Produit: ${product.name}`
    ).run();

    // Track affiliate click if applicable
    if (affiliateId) {
      await c.env.DB.prepare(
        "INSERT INTO link_clicks (affiliate_id, product_id, created_at) VALUES (?, ?, CURRENT_TIMESTAMP)"
      ).bind(affiliateId, product_id).run();

      await c.env.DB.prepare(
        "UPDATE affiliates SET total_clicks = total_clicks + 1 WHERE id = ?"
      ).bind(affiliateId).run();
    }

    return c.json({
      orderId: orderId,
      paymentUrl: lygosData.link,
      lygosGatewayId: lygosData.id || lygosData.gateway_id,
    });

  } catch (error) {
    console.error("Error creating Lygospay payment:", error);
    return c.json({ error: "Erreur lors de la création du paiement" }, 500);
  }
});

// Verify Lygospay payment status
app.get("/api/verify-lygos-payment/:orderId", async (c) => {
  try {
    const orderId = c.req.param("orderId");

    // Get order from database
    const order = await c.env.DB.prepare(
      "SELECT * FROM orders WHERE id = ?"
    ).bind(orderId).first();

    if (!order) {
      return c.json({ error: "Commande non trouvée" }, 404);
    }

    // If already completed, return success
    if (order.status === 'paid' || order.status === 'delivered') {
      return c.json({
        status: "success",
        order: order,
      });
    }

    // Get Lygos reference from order
    const lygosOrderId = order.payment_reference;
    if (!lygosOrderId) {
      return c.json({ error: "Référence Lygospay introuvable" }, 400);
    }

    // Call Lygospay API to verify payment
    const lygosApiKey = c.env.LYGOSPAY_API_KEY;
    if (!lygosApiKey) {
      return c.json({ error: "Clé API Lygospay non configurée" }, 500);
    }

    const lygosResponse = await fetch(`https://api.lygosapp.com/v1/gateway/payin/${lygosOrderId}`, {
      method: "GET",
      headers: {
        "api-key": lygosApiKey,
      },
    });

    if (!lygosResponse.ok) {
      console.error("Lygospay verification failed");
      return c.json({ status: "pending", order: order });
    }

    const lygosData = await lygosResponse.json() as LygosPayinStatusResponse;

    // Update order status based on Lygospay response
    if (lygosData.status === "success" || lygosData.status === "completed") {
      // Update order to paid
      await c.env.DB.prepare(
        "UPDATE orders SET status = 'paid', updated_at = CURRENT_TIMESTAMP WHERE id = ?"
      ).bind(orderId).run();

      // Create user account if doesn't exist
      if (order.customer_email && order.customer_email !== 'pending@martama.app') {
        const existingUser = await c.env.DB.prepare(
          "SELECT * FROM users WHERE email = ?"
        ).bind(order.customer_email).first();

        if (!existingUser) {
          const userId = `user_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
          await c.env.DB.prepare(
            "INSERT INTO users (id, email, role, has_completed_onboarding, is_active) VALUES (?, ?, 'user', 0, 1)"
          ).bind(userId, order.customer_email).run();
        }
      }

      // Handle affiliate commission
      if (order.affiliate_id && Number(order.affiliate_commission) > 0) {
        const existingCommission = await c.env.DB.prepare(
          "SELECT * FROM commissions WHERE order_id = ?"
        ).bind(orderId).first();

        if (!existingCommission) {
          // Get purchase history
          const history = await c.env.DB.prepare(
            "SELECT total_purchases FROM customer_purchase_history WHERE customer_email = ? AND affiliate_id = ?"
          ).bind(order.customer_email, order.affiliate_id).first();

          const purchaseNumber = history ? Number(history.total_purchases) : 1;

          // Get product commission rate
          const product = await c.env.DB.prepare(
            "SELECT affiliate_commission_rate FROM products WHERE id = ?"
          ).bind(order.product_id).first();

          const baseCommissionRate = product ? Number(product.affiliate_commission_rate) : 0;

          // Calculate actual commission rate based on purchase number
          let actualCommissionRate = 0;
          if (purchaseNumber === 1) {
            actualCommissionRate = baseCommissionRate;
          } else if (purchaseNumber === 2) {
            actualCommissionRate = baseCommissionRate / 2;
          } else {
            actualCommissionRate = 0.05;
          }

          // Create commission record
          await c.env.DB.prepare(
            "INSERT INTO commissions (order_id, affiliate_id, amount, status, purchase_number, commission_rate) VALUES (?, ?, ?, 'pending', ?, ?)"
          ).bind(orderId, order.affiliate_id, order.affiliate_commission, purchaseNumber, actualCommissionRate).run();

          // Update affiliate totals
          await c.env.DB.prepare(
            `UPDATE affiliates SET 
             total_sales = total_sales + 1,
             total_commissions = total_commissions + ?,
             balance = balance + ?,
             updated_at = CURRENT_TIMESTAMP
             WHERE id = ?`
          ).bind(order.affiliate_commission, order.affiliate_commission, order.affiliate_id).run();

          // Update or create purchase history
          if (history) {
            await c.env.DB.prepare(
              "UPDATE customer_purchase_history SET total_purchases = total_purchases + 1, updated_at = CURRENT_TIMESTAMP WHERE customer_email = ? AND affiliate_id = ?"
            ).bind(order.customer_email, order.affiliate_id).run();
          } else {
            await c.env.DB.prepare(
              "INSERT INTO customer_purchase_history (customer_email, affiliate_id, first_purchase_date, total_purchases) VALUES (?, ?, CURRENT_TIMESTAMP, 1)"
            ).bind(order.customer_email, order.affiliate_id).run();
          }
        }
      }

      // Create notification for admin
      await c.env.DB.prepare(
        "INSERT INTO order_notifications (order_id, is_read) VALUES (?, 0)"
      ).bind(orderId).run();

      return c.json({
        status: "success",
        order: { ...order, status: 'paid' },
      });
    }

    return c.json({
      status: lygosData.status || "pending",
      order: order,
    });

  } catch (error) {
    console.error("Error verifying Lygospay payment:", error);
    return c.json({ error: "Erreur lors de la vérification du paiement" }, 500);
  }
});

// Lygospay webhook endpoint
app.post("/api/webhook/lygospay", async (c) => {
  try {
    const rawBody = await c.req.text();
    let event;
    
    try {
      event = JSON.parse(rawBody);
    } catch (e) {
      console.error("Invalid JSON payload from Lygospay:", e);
      return c.json({ error: "Invalid payload" }, 400);
    }
    
    // Log the received webhook for debugging
    console.log("Lygospay webhook received:", event);
    
    // Extract key information from Lygospay webhook
    const eventId = event.id || event.transaction_id || `lygos_${Date.now()}`;
    const transactionId = event.transaction_id || event.id;
    const status = event.status || event.payment_status;
    const amount = event.amount || 0;
    const orderId = event.order_id || event.metadata?.order_id || event.custom_data?.order_id;
    
    // Check for duplicate webhook
    const existingWebhook = await c.env.DB.prepare(
      "SELECT id FROM lygos_webhooks WHERE event_id = ?"
    ).bind(eventId).first();
    
    if (existingWebhook) {
      console.log("Duplicate Lygospay webhook ignored:", eventId);
      return c.json({ received: true, message: "Duplicate event" }, 200);
    }
    
    // Store webhook event
    await c.env.DB.prepare(
      `INSERT INTO lygos_webhooks (event_id, order_id, transaction_id, status, amount, raw_payload)
       VALUES (?, ?, ?, ?, ?, ?)`
    ).bind(eventId, orderId || null, transactionId, status, amount, rawBody).run();
    
    // Process webhook asynchronously
    c.executionCtx.waitUntil(processLygosWebhook(event, c.env));
    
    return c.json({ received: true }, 200);
  } catch (error) {
    console.error("Lygospay webhook error:", error);
    return c.json({ received: true }, 200);
  }
});

async function processLygosWebhook(event: any, env: Env) {
  try {
    // Extract order ID
    const lygosOrderId = event.order_id || event.metadata?.order_id || event.custom_data?.order_id;
    
    if (!lygosOrderId) {
      console.error("No order ID found in Lygospay webhook");
      return;
    }
    
    // Get order from database using Lygos reference
    const order = await env.DB.prepare(
      "SELECT * FROM orders WHERE payment_reference = ?"
    ).bind(lygosOrderId).first();
    
    if (!order) {
      console.error("Order not found for Lygospay webhook:", lygosOrderId);
      return;
    }
    
    // CRITICAL: Verify payment status directly with Lygospay API
    const lygosApiKey = env.LYGOSPAY_API_KEY;
    if (!lygosApiKey) {
      console.error("Lygospay API key not configured");
      return;
    }

    const verifyResponse = await fetch(`https://api.lygosapp.com/v1/gateway/payin/${lygosOrderId}`, {
      method: "GET",
      headers: {
        "api-key": lygosApiKey,
      },
    });

    if (!verifyResponse.ok) {
      console.error("Failed to verify payment with Lygospay API");
      return;
    }

    const verifiedData = await verifyResponse.json() as LygosPayinStatusResponse;
    const verifiedStatus = verifiedData.status;
    
    // Only proceed if verified status is success
    if (verifiedStatus !== 'success' && verifiedStatus !== 'completed') {
      console.log("Payment not successful, skipping:", verifiedStatus);
      await env.DB.prepare(
        "UPDATE lygos_webhooks SET processed = 1, updated_at = CURRENT_TIMESTAMP WHERE event_id = ?"
      ).bind(event.id || event.transaction_id).run();
      return;
    }
    
    // Check if order is already processed
    if (order.status === 'paid' || order.status === 'delivered') {
      console.log("Order already processed:", order.id);
      await env.DB.prepare(
        "UPDATE lygos_webhooks SET processed = 1, updated_at = CURRENT_TIMESTAMP WHERE event_id = ?"
      ).bind(event.id || event.transaction_id).run();
      return;
    }
    
    // Update order status to paid
    await env.DB.prepare(
      `UPDATE orders SET 
       status = 'paid',
       updated_at = CURRENT_TIMESTAMP
       WHERE id = ?`
    ).bind(order.id).run();
    
    // Create user account if needed
    if (order.customer_email && order.customer_email !== 'pending@martama.app') {
      const existingUser = await env.DB.prepare(
        "SELECT * FROM users WHERE email = ?"
      ).bind(order.customer_email).first();
      
      if (!existingUser) {
        const userId = `user_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        await env.DB.prepare(
          `INSERT INTO users (id, email, role, has_completed_onboarding, is_active)
           VALUES (?, ?, 'user', 0, 1)`
        ).bind(userId, order.customer_email).run();
      }
    }
    
    // Handle affiliate commission
    if (order.affiliate_id && Number(order.affiliate_commission) > 0) {
      const existingCommission = await env.DB.prepare(
        "SELECT * FROM commissions WHERE order_id = ?"
      ).bind(order.id).first();
      
      if (!existingCommission) {
        const history = await env.DB.prepare(
          "SELECT total_purchases FROM customer_purchase_history WHERE customer_email = ? AND affiliate_id = ?"
        ).bind(order.customer_email, order.affiliate_id).first();
        
        const purchaseNumber = history ? Number(history.total_purchases) : 1;
        
        const product = await env.DB.prepare(
          "SELECT affiliate_commission_rate FROM products WHERE id = ?"
        ).bind(order.product_id).first();
        
        const baseCommissionRate = product ? Number(product.affiliate_commission_rate) : 0;
        
        let actualCommissionRate = 0;
        if (purchaseNumber === 1) {
          actualCommissionRate = baseCommissionRate;
        } else if (purchaseNumber === 2) {
          actualCommissionRate = baseCommissionRate / 2;
        } else {
          actualCommissionRate = 0.05;
        }
        
        await env.DB.prepare(
          "INSERT INTO commissions (order_id, affiliate_id, amount, status, purchase_number, commission_rate) VALUES (?, ?, ?, 'pending', ?, ?)"
        ).bind(order.id, order.affiliate_id, order.affiliate_commission, purchaseNumber, actualCommissionRate).run();
        
        await env.DB.prepare(
          `UPDATE affiliates SET 
           total_sales = total_sales + 1,
           total_commissions = total_commissions + ?,
           balance = balance + ?,
           updated_at = CURRENT_TIMESTAMP
           WHERE id = ?`
        ).bind(order.affiliate_commission, order.affiliate_commission, order.affiliate_id).run();

        if (history) {
          await env.DB.prepare(
            "UPDATE customer_purchase_history SET total_purchases = total_purchases + 1, updated_at = CURRENT_TIMESTAMP WHERE customer_email = ? AND affiliate_id = ?"
          ).bind(order.customer_email, order.affiliate_id).run();
        } else {
          await env.DB.prepare(
            "INSERT INTO customer_purchase_history (customer_email, affiliate_id, first_purchase_date, total_purchases) VALUES (?, ?, CURRENT_TIMESTAMP, 1)"
          ).bind(order.customer_email, order.affiliate_id).run();
        }
      }
    }
    
    // AUTO-DELIVERY: Deliver packs and formations automatically
    // CRITICAL: Subscriptions (abonnements) are NEVER auto-delivered, even when paid
    const product = await env.DB.prepare(
      "SELECT * FROM products WHERE id = ?"
    ).bind(order.product_id).first();
    
    if (product && product.auto_delivery && product.category !== 'abonnement') {
      // Check product category for auto-delivery (ONLY packs and formations)
      if (product.category === 'pack' || product.category === 'formation') {
        // Determine access credentials based on product type
        let accessCredentials = '';
        if (product.category === 'pack') {
          // For packs, use file_url or download_url
          accessCredentials = (product.file_url as string) || (product.download_url as string) || '';
        } else {
          // For formations, just a placeholder
          accessCredentials = 'Accès à la formation';
        }
        
        // Update order status to delivered
        await env.DB.prepare(
          `UPDATE orders SET 
           status = 'delivered',
           delivered_at = CURRENT_TIMESTAMP,
           delivered_by = 'system_auto',
           access_credentials = ?
           WHERE id = ?`
        ).bind(accessCredentials, order.id).run();
        
        // For formations, create user access record
        if (product.category === 'formation') {
          const existingAccess = await env.DB.prepare(
            "SELECT id FROM user_formations WHERE user_email = ? AND product_id = ?"
          ).bind(order.customer_email, order.product_id).first();
          
          if (!existingAccess) {
            await env.DB.prepare(
              `INSERT INTO user_formations (user_email, product_id, order_id, access_granted_at)
               VALUES (?, ?, ?, CURRENT_TIMESTAMP)`
            ).bind(order.customer_email, order.product_id, order.id).run();
          }
        }
        
        // Log auto-delivery
        await env.DB.prepare(
          `INSERT INTO order_action_logs (order_id, action_type, action_details, performed_by)
           VALUES (?, 'order_delivered', ?, 'system_auto')`
        ).bind(
          order.id,
          `Livraison automatique effectuée | Type: ${product.category} | Produit: ${product.name}`
        ).run();
        
        console.log(`Auto-delivered ${product.category} for order:`, order.id);
      }
    }
    
    // Create notification for admin
    const existingNotification = await env.DB.prepare(
      "SELECT id FROM order_notifications WHERE order_id = ?"
    ).bind(order.id).first();
    
    if (!existingNotification) {
      await env.DB.prepare(
        "INSERT INTO order_notifications (order_id, is_read) VALUES (?, 0)"
      ).bind(order.id).run();
    }
    
    // Mark webhook as processed
    await env.DB.prepare(
      "UPDATE lygos_webhooks SET processed = 1, updated_at = CURRENT_TIMESTAMP WHERE event_id = ?"
    ).bind(event.id || event.transaction_id).run();
    
    console.log("Lygospay webhook processed successfully for order:", order.id);
  } catch (error) {
    console.error("Error processing Lygospay webhook:", error);
  }
}

export default app;
