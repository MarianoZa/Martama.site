import { Hono } from "hono";
import { authMiddleware } from "@getmocha/users-service/backend";

const app = new Hono<{ Bindings: Env }>();

// Admin middleware
const adminMiddleware = async (c: any, next: any) => {
  const mochaUser = c.get("user");
  
  if (!mochaUser) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const userResult = await c.env.DB.prepare(
    "SELECT * FROM users WHERE id = ? AND role = 'admin'"
  ).bind(mochaUser.id).first();

  if (!userResult) {
    return c.json({ error: "Forbidden - Admin access required" }, 403);
  }

  await next();
};

// Log an order action
async function logOrderAction(
  env: Env,
  orderId: number,
  actionType: string,
  actionDetails: string,
  performedBy?: string
) {
  await env.DB.prepare(
    `INSERT INTO order_action_logs (order_id, action_type, action_details, performed_by)
     VALUES (?, ?, ?, ?)`
  ).bind(orderId, actionType, actionDetails, performedBy || 'system').run();
}

// Get order action logs
app.get("/api/admin/orders/:id/action-logs", authMiddleware, adminMiddleware, async (c) => {
  const orderId = c.req.param("id");
  
  const { results } = await c.env.DB.prepare(
    `SELECT * FROM order_action_logs 
     WHERE order_id = ? 
     ORDER BY created_at DESC`
  ).bind(orderId).all();
  
  return c.json(results);
});

// Override the order update endpoint to include action logging
app.put("/api/admin/orders/:id/with-log", authMiddleware, adminMiddleware, async (c) => {
  const id = c.req.param("id");
  const body = await c.req.json();
  const adminUser = c.get("user");
  
  const order = await c.env.DB.prepare(
    "SELECT * FROM orders WHERE id = ?"
  ).bind(id).first();
  
  if (!order) {
    return c.json({ error: "Order not found" }, 404);
  }
  
  const previousStatus = order.status;
  
  // Update order status
  let updateQuery = "UPDATE orders SET status = ?, payment_gateway = ?, transaction_details = ?, updated_at = CURRENT_TIMESTAMP";
  const params: any[] = [
    body.status,
    body.payment_gateway || order.payment_gateway || null,
    body.transaction_details || order.transaction_details || null
  ];
  
  // If delivering, try to auto-assign credentials from inventory
  if (body.status === 'delivered' && !body.access_credentials) {
    const inventoryItem = await c.env.DB.prepare(
      "SELECT * FROM inventory WHERE product_id = ? AND is_used = 0 LIMIT 1"
    ).bind(order.product_id).first();
    
    if (inventoryItem) {
      body.access_credentials = inventoryItem.access_credentials;
      
      // Mark inventory item as used
      await c.env.DB.prepare(
        "UPDATE inventory SET is_used = 1, order_id = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?"
      ).bind(id, inventoryItem.id).run();
    }
  }
  
  if (body.access_credentials) {
    updateQuery += ", access_credentials = ?";
    params.push(body.access_credentials);
  }
  
  if (body.status === 'delivered') {
    updateQuery += ", delivered_at = CURRENT_TIMESTAMP, delivered_by = ?";
    params.push(adminUser?.email || 'admin');
  }
  
  updateQuery += " WHERE id = ?";
  params.push(id);
  
  await c.env.DB.prepare(updateQuery).bind(...params).run();
  
  // Log the action
  let actionDetails = `Statut changé de "${previousStatus}" à "${body.status}"`;
  if (body.status === 'delivered' && body.access_credentials) {
    actionDetails += ` | Accès livrés`;
  }
  if (body.transaction_details) {
    actionDetails += ` | Détails: ${body.transaction_details}`;
  }
  
  await logOrderAction(
    c.env,
    Number(id),
    `status_change_${body.status}`,
    actionDetails,
    adminUser?.email || 'admin'
  );
  
  // If order is delivered, create or update subscription
  if (body.status === 'delivered') {
    const product = await c.env.DB.prepare(
      "SELECT usage_instructions FROM products WHERE id = ?"
    ).bind(order.product_id).first();
    
    const existingSubscription = await c.env.DB.prepare(
      "SELECT * FROM subscriptions WHERE order_id = ?"
    ).bind(id).first();
    
    if (!existingSubscription) {
      let expiresAt = null;
      if (order.duration_months) {
        const expiryDate = new Date();
        expiryDate.setMonth(expiryDate.getMonth() + Number(order.duration_months));
        expiresAt = expiryDate.toISOString();
      }
      
      const user = await c.env.DB.prepare(
        "SELECT id FROM users WHERE email = ?"
      ).bind(order.customer_email).first();
      
      let accessCredentials = body.access_credentials || '';
      if (product && product.usage_instructions) {
        accessCredentials = `${accessCredentials}\n\nInstructions d'utilisation:\n${product.usage_instructions}`;
      }
      
      await c.env.DB.prepare(
        `INSERT INTO subscriptions (
          order_id, user_id, product_id, access_credentials, expires_at, is_active
        ) VALUES (?, ?, ?, ?, ?, 1)`
      ).bind(
        id,
        user ? user.id : null,
        order.product_id,
        accessCredentials,
        expiresAt
      ).run();
      
      await logOrderAction(
        c.env,
        Number(id),
        'subscription_created',
        `Abonnement créé jusqu'au ${expiresAt ? new Date(expiresAt).toLocaleDateString('fr-FR') : 'durée indéterminée'}`,
        'system'
      );
    }
  }
  
  // If order is marked as paid, create commission if affiliate exists
  if (body.status === 'paid' && order.affiliate_id && Number(order.affiliate_commission) > 0) {
    const existingCommission = await c.env.DB.prepare(
      "SELECT * FROM commissions WHERE order_id = ?"
    ).bind(id).first();
    
    if (!existingCommission) {
      const history = await c.env.DB.prepare(
        "SELECT total_purchases FROM customer_purchase_history WHERE customer_email = ? AND affiliate_id = ?"
      ).bind(order.customer_email, order.affiliate_id).first();
      
      const purchaseNumber = history ? Number(history.total_purchases) : 1;
      
      const product = await c.env.DB.prepare(
        "SELECT affiliate_commission_rate FROM products WHERE id = ?"
      ).bind(order.product_id).first();
      
      const baseCommissionRate = product ? Number(product.affiliate_commission_rate) : 0;
      
      let actualCommissionRate = 0;
      if (purchaseNumber === 1) {
        actualCommissionRate = baseCommissionRate;
      } else if (purchaseNumber === 2) {
        actualCommissionRate = baseCommissionRate / 2;
      } else {
        actualCommissionRate = 0.05;
      }
      
      await c.env.DB.prepare(
        "INSERT INTO commissions (order_id, affiliate_id, amount, status, purchase_number, commission_rate) VALUES (?, ?, ?, 'pending', ?, ?)"
      ).bind(id, order.affiliate_id, order.affiliate_commission, purchaseNumber, actualCommissionRate).run();
      
      await c.env.DB.prepare(
        `UPDATE affiliates SET 
         total_sales = total_sales + 1,
         total_commissions = total_commissions + ?,
         balance = balance + ?,
         updated_at = CURRENT_TIMESTAMP
         WHERE id = ?`
      ).bind(order.affiliate_commission, order.affiliate_commission, order.affiliate_id).run();
      
      const commissionAmount = Number(order.affiliate_commission || 0);
      await logOrderAction(
        c.env,
        Number(id),
        'commission_created',
        `Commission créée: ${commissionAmount.toLocaleString()} FCFA (taux: ${(actualCommissionRate * 100).toFixed(1)}%)`,
        'system'
      );
    }
  }
  
  const updatedOrder = await c.env.DB.prepare(
    "SELECT * FROM orders WHERE id = ?"
  ).bind(id).first();
  
  return c.json(updatedOrder);
});

export default app;
