import { Hono } from "hono";
import { cors } from "hono/cors";
import { getCookie, setCookie } from "hono/cookie";
import {
  exchangeCodeForSessionToken,
  getOAuthRedirectUrl,
  authMiddleware,
  deleteSession,
  MOCHA_SESSION_TOKEN_COOKIE_NAME,
} from "@getmocha/users-service/backend";

const app = new Hono<{ Bindings: Env }>();

// CORS middleware
app.use("*", cors({
  origin: "*",
  credentials: true,
}));

// ============================================================================
// Authentication routes
// ============================================================================

app.get("/api/oauth/google/redirect_url", async (c) => {
  const redirectUrl = await getOAuthRedirectUrl("google", {
    apiUrl: (c.env as any).MOCHA_USERS_SERVICE_API_URL,
    apiKey: (c.env as any).MOCHA_USERS_SERVICE_API_KEY,
  });

  return c.json({ redirectUrl }, 200);
});

app.post("/api/sessions", async (c) => {
  const body = await c.req.json();

  if (!body.code) {
    return c.json({ error: "No authorization code provided" }, 400);
  }

  const sessionToken = await exchangeCodeForSessionToken(body.code, {
    apiUrl: (c.env as any).MOCHA_USERS_SERVICE_API_URL,
    apiKey: (c.env as any).MOCHA_USERS_SERVICE_API_KEY,
  });

  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, sessionToken, {
    httpOnly: true,
    path: "/",
    sameSite: "none",
    secure: true,
    maxAge: 60 * 24 * 60 * 60, // 60 days
  });

  return c.json({ success: true }, 200);
});

app.get("/api/users/me", authMiddleware, async (c) => {
  const mochaUser = c.get("user");
  
  if (!mochaUser) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  // Check if user exists in our database
  const userResult = await c.env.DB.prepare(
    "SELECT * FROM users WHERE id = ?"
  ).bind(mochaUser.id).first();

  if (!userResult) {
    // Check if this is one of our admin emails
    const adminEmails = ['arsuzannou@gmail.com', 'bnb887991@gmail.com'];
    const role = adminEmails.includes(mochaUser.email) ? 'admin' : 'user';
    
    // Create user record on first login
    await c.env.DB.prepare(
      `INSERT INTO users (id, email, full_name, role, has_completed_onboarding)
       VALUES (?, ?, ?, ?, 0)`
    ).bind(
      mochaUser.id,
      mochaUser.email,
      mochaUser.google_user_data.name || null,
      role
    ).run();

    const newUser = await c.env.DB.prepare(
      "SELECT * FROM users WHERE id = ?"
    ).bind(mochaUser.id).first();

    return c.json(newUser);
  }

  return c.json(userResult);
});

// Update user profile
app.put("/api/users/profile", authMiddleware, async (c) => {
  const mochaUser = c.get("user");
  
  if (!mochaUser) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const body = await c.req.json();
  
  await c.env.DB.prepare(
    `UPDATE users SET 
     full_name = ?,
     phone_number = ?,
     updated_at = CURRENT_TIMESTAMP
     WHERE id = ?`
  ).bind(
    body.full_name || null,
    body.phone_number || null,
    mochaUser.id
  ).run();

  const updatedUser = await c.env.DB.prepare(
    "SELECT * FROM users WHERE id = ?"
  ).bind(mochaUser.id).first();

  return c.json(updatedUser);
});

app.get("/api/logout", async (c) => {
  const sessionToken = getCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME);

  if (typeof sessionToken === "string") {
    await deleteSession(sessionToken, {
      apiUrl: (c.env as any).MOCHA_USERS_SERVICE_API_URL,
      apiKey: (c.env as any).MOCHA_USERS_SERVICE_API_KEY,
    });
  }

  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, "", {
    httpOnly: true,
    path: "/",
    sameSite: "none",
    secure: true,
    maxAge: 0,
  });

  return c.json({ success: true }, 200);
});



app.get("/api/users/me", authMiddleware, async (c) => {
  const mochaUser = c.get("user");
  if (!mochaUser) return c.json({ error: "Unauthorized" }, 401);

  const user = await c.env.DB.prepare(
    "SELECT * FROM users WHERE id = ?"
  ).bind(mochaUser.id).first();

  const adminEmails = [
    'arsuzannou@gmail.com',
    'bnb887991@gmail.com',
    'martama2pro@gmail.com',
    'thelucidshadow7@gmail.com',
    'naturebienetre40@gmail.com'
  ];
if (!user) {
    const role = adminEmails.includes(mochaUser.email) ? 'admin' : 'user';

    await c.env.DB.prepare(`
      INSERT INTO users (
        id, email, full_name, role, role_type,
        affiliate_status, affiliate_commission_rate, loyalty_points,
        loyalty_tier, has_completed_onboarding
      ) VALUES (?, ?, ?, ?, 'client', 'none', 30, 0, NULL, 0)
    `).bind(
      mochaUser.id,
      mochaUser.email,
      mochaUser.google_user_data.name || null,
      role
    ).run();
const newUser = await c.env.DB.prepare(
      "SELECT * FROM users WHERE id = ?"
    ).bind(mochaUser.id).first();

    return c.json(newUser);
  }

  return c.json(user);
});

  
// ============================================================================
// Products routes
// ============================================================================

app.get("/api/products", async (c) => {
  const category = c.req.query("category");
  
  let query = "SELECT * FROM products WHERE is_active = 1";
  const params: any[] = [];
  
  if (category) {
    query += " AND category = ?";
    params.push(category);
  }
  
  query += " ORDER BY created_at DESC";
  
  const { results } = await c.env.DB.prepare(query).bind(...params).all();
  
  return c.json(results);
});

app.get("/api/products/:id", async (c) => {
  const id = c.req.param("id");
  
  const product = await c.env.DB.prepare(
    "SELECT * FROM products WHERE id = ? AND is_active = 1"
  ).bind(id).first();
  
  if (!product) {
    return c.json({ error: "Product not found" }, 404);
  }
  
  return c.json(product);
});

// ============================================================================
// Orders routes
// ============================================================================

app.post("/api/orders", async (c) => {
  const body = await c.req.json();
  
  // Get product
  const product = await c.env.DB.prepare(
    "SELECT * FROM products WHERE id = ?"
  ).bind(body.product_id).first();
  
  if (!product) {
    return c.json({ error: "Product not found" }, 404);
  }
  
  // Calculate price based on duration
  let originalAmount = 0;
  const price1 = product.price_1_months as any;
  const price3 = product.price_3_months as any;
  const price6 = product.price_6_months as any;
  
  if (body.duration_months === 1 && price1) {
    originalAmount = Number(price1);
  } else if (body.duration_months === 3 && price3) {
    originalAmount = Number(price3);
  } else if (body.duration_months === 6 && price6) {
    originalAmount = Number(price6);
  }
  
  let discountAmount = 0;
  let affiliateId = null;
  let affiliateCommission = 0;
  
  // Check affiliate code
  if (body.affiliate_code) {
    const affiliate = await c.env.DB.prepare(
      "SELECT * FROM affiliates WHERE promo_code = ? AND status = 'active'"
    ).bind(body.affiliate_code).first();
    
    if (affiliate) {
      affiliateId = Number(affiliate.id);
      // Calculate client discount
      const discountRate = Number((product.client_discount_rate as any) || 0);
      discountAmount = originalAmount * discountRate;
      // Calculate affiliate commission
      const commissionRate = Number((product.affiliate_commission_rate as any) || 0);
      affiliateCommission = originalAmount * commissionRate;
    }
  }
  
  const finalAmount = originalAmount - discountAmount;
  
  // Create order
  const result = await c.env.DB.prepare(
    `INSERT INTO orders (
      product_id, customer_email, duration_months, amount, original_amount,
      discount_amount, affiliate_code, affiliate_id, affiliate_commission,
      status, payment_method
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?)`
  ).bind(
    body.product_id,
    body.customer_email,
    body.duration_months || null,
    finalAmount,
    originalAmount,
    discountAmount,
    body.affiliate_code || null,
    affiliateId,
    affiliateCommission,
    body.payment_method
  ).run();
  
  const order = await c.env.DB.prepare(
    "SELECT * FROM orders WHERE id = ?"
  ).bind(result.meta.last_row_id).first();
  
  return c.json(order, 201);
});

// Get user's orders
app.get("/api/orders/my", authMiddleware, async (c) => {
  const user = c.get("user");
  
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }
  
  const { results } = await c.env.DB.prepare(
    `SELECT o.*, p.name as product_name, p.category as product_category
     FROM orders o
     JOIN products p ON o.product_id = p.id
     WHERE o.customer_email = ?
     ORDER BY o.created_at DESC`
  ).bind(user.email).all();
  
  return c.json(results);
});

// Get user's subscriptions
app.get("/api/subscriptions/my", authMiddleware, async (c) => {
  const user = c.get("user");
  
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }
  
  const { results } = await c.env.DB.prepare(
    `SELECT s.*, p.name as product_name, p.category as product_category, o.status
     FROM subscriptions s
     JOIN products p ON s.product_id = p.id
     LEFT JOIN orders o ON s.order_id = o.id
     WHERE s.user_id = ? OR o.customer_email = ?
     ORDER BY s.created_at DESC`
  ).bind(user.id, user.email).all();
  
  return c.json(results);
});

// Get affiliate stats
app.get("/api/affiliate/stats", authMiddleware, async (c) => {
  const user = c.get("user");
  
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }
  
  const affiliate = await c.env.DB.prepare(
    "SELECT * FROM affiliates WHERE user_id = ? AND status = 'active'"
  ).bind(user.id).first();
  
  if (!affiliate) {
    return c.json({ error: "Not an affiliate" }, 404);
  }
  
  return c.json(affiliate);
});

// Submit affiliate request
app.post("/api/affiliate-requests", authMiddleware, async (c) => {
  const user = c.get("user");
  
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }
  
  const body = await c.req.json();
  
  // Check if user already has an affiliate request
  const existingRequest = await c.env.DB.prepare(
    "SELECT * FROM affiliate_requests WHERE user_id = ? AND status = 'pending'"
  ).bind(user.id).first();
  
  if (existingRequest) {
    return c.json({ error: "Vous avez déjà une demande en attente" }, 400);
  }
  
  // Check if user is already an affiliate
  const existingAffiliate = await c.env.DB.prepare(
    "SELECT * FROM affiliates WHERE user_id = ?"
  ).bind(user.id).first();
  
  if (existingAffiliate) {
    return c.json({ error: "Vous êtes déjà affilié" }, 400);
  }
  
  // Check if promo code is already taken
  const existingPromo = await c.env.DB.prepare(
    "SELECT * FROM affiliates WHERE promo_code = ?"
  ).bind(body.promo_code).first();
  
  if (existingPromo) {
    return c.json({ error: "Ce code promo est déjà utilisé" }, 400);
  }
  
  const existingPromoRequest = await c.env.DB.prepare(
    "SELECT * FROM affiliate_requests WHERE promo_code = ? AND status = 'pending'"
  ).bind(body.promo_code).first();
  
  if (existingPromoRequest) {
    return c.json({ error: "Ce code promo est déjà demandé" }, 400);
  }
  
  // Create affiliate request
  const result = await c.env.DB.prepare(
    `INSERT INTO affiliate_requests (
      user_id, promo_code, specialty, audience_size, social_links,
      motivation, payment_method, status
    ) VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')`
  ).bind(
    user.id,
    body.promo_code,
    body.specialty || null,
    body.audience_size || null,
    body.social_links || null,
    body.motivation || null,
    body.payment_method || null
  ).run();
  
  const request = await c.env.DB.prepare(
    "SELECT * FROM affiliate_requests WHERE id = ?"
  ).bind(result.meta.last_row_id).first();
  
  return c.json(request, 201);
});

// ============================================================================
// Admin routes
// ============================================================================

// Admin middleware
const adminMiddleware = async (c: any, next: any) => {
  const mochaUser = c.get("user");
  
  if (!mochaUser) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const userResult = await c.env.DB.prepare(
    "SELECT * FROM users WHERE id = ? AND role = 'admin'"
  ).bind(mochaUser.id).first();

  if (!userResult) {
    return c.json({ error: "Forbidden - Admin access required" }, 403);
  }

  await next();
};

// Get all orders (admin)
app.get("/api/admin/orders", authMiddleware, adminMiddleware, async (c) => {
  const status = c.req.query("status");
  
  let query = `SELECT o.*, p.name as product_name, p.category as product_category
               FROM orders o
               JOIN products p ON o.product_id = p.id`;
  const params: any[] = [];
  
  if (status) {
    query += " WHERE o.status = ?";
    params.push(status);
  }
  
  query += " ORDER BY o.created_at DESC";
  
  const { results } = await c.env.DB.prepare(query).bind(...params).all();
  
  return c.json(results);
});

// Update order status and deliver (admin)
app.put("/api/admin/orders/:id", authMiddleware, adminMiddleware, async (c) => {
  const id = c.req.param("id");
  const body = await c.req.json();
  
  const order = await c.env.DB.prepare(
    "SELECT * FROM orders WHERE id = ?"
  ).bind(id).first();
  
  if (!order) {
    return c.json({ error: "Order not found" }, 404);
  }
  
  // Update order status
  let updateQuery = "UPDATE orders SET status = ?, updated_at = CURRENT_TIMESTAMP";
  const params: any[] = [body.status];
  
  // If delivering, try to auto-assign credentials from inventory
  if (body.status === 'delivered' && !body.access_credentials) {
    const inventoryItem = await c.env.DB.prepare(
      "SELECT * FROM inventory WHERE product_id = ? AND is_used = 0 LIMIT 1"
    ).bind(order.product_id).first();
    
    if (inventoryItem) {
      body.access_credentials = inventoryItem.access_credentials;
      
      // Mark inventory item as used
      await c.env.DB.prepare(
        "UPDATE inventory SET is_used = 1, order_id = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?"
      ).bind(id, inventoryItem.id).run();
    }
  }
  
  if (body.access_credentials) {
    updateQuery += ", access_credentials = ?";
    params.push(body.access_credentials);
  }
  
  updateQuery += " WHERE id = ?";
  params.push(id);
  
  await c.env.DB.prepare(updateQuery).bind(...params).run();
  
  // If order is marked as paid, create commission if affiliate exists
  if (body.status === 'paid' && order.affiliate_id && Number(order.affiliate_commission) > 0) {
    // Check if commission already exists
    const existingCommission = await c.env.DB.prepare(
      "SELECT * FROM commissions WHERE order_id = ?"
    ).bind(id).first();
    
    if (!existingCommission) {
      await c.env.DB.prepare(
        "INSERT INTO commissions (order_id, affiliate_id, amount, status) VALUES (?, ?, ?, 'pending')"
      ).bind(id, order.affiliate_id, order.affiliate_commission).run();
      
      // Update affiliate stats
      await c.env.DB.prepare(
        `UPDATE affiliates SET 
         total_sales = total_sales + 1,
         total_commissions = total_commissions + ?,
         balance = balance + ?,
         updated_at = CURRENT_TIMESTAMP
         WHERE id = ?`
      ).bind(order.affiliate_commission, order.affiliate_commission, order.affiliate_id).run();
    }
  }
  
  const updatedOrder = await c.env.DB.prepare(
    "SELECT * FROM orders WHERE id = ?"
  ).bind(id).first();
  
  return c.json(updatedOrder);
});

// Get all affiliate requests (admin)
app.get("/api/admin/affiliate-requests", authMiddleware, adminMiddleware, async (c) => {
  const status = c.req.query("status");
  
  let query = `SELECT ar.*, u.email, u.full_name
               FROM affiliate_requests ar
               JOIN users u ON ar.user_id = u.id`;
  const params: any[] = [];
  
  if (status) {
    query += " WHERE ar.status = ?";
    params.push(status);
  }
  
  query += " ORDER BY ar.created_at DESC";
  
  const { results } = await c.env.DB.prepare(query).bind(...params).all();
  
  return c.json(results);
});

// Approve affiliate request (admin)
app.post("/api/admin/affiliate-requests/:id/approve", authMiddleware, adminMiddleware, async (c) => {
  const id = c.req.param("id");
  const body = await c.req.json();
  const adminUser = c.get("user");
  
  if (!adminUser) {
    return c.json({ error: "Unauthorized" }, 401);
  }
  
  const request = await c.env.DB.prepare(
    "SELECT * FROM affiliate_requests WHERE id = ?"
  ).bind(id).first();
  
  if (!request) {
    return c.json({ error: "Affiliate request not found" }, 404);
  }
  
  if (request.status !== 'pending') {
    return c.json({ error: "Request already processed" }, 400);
  }
  
  // Check if affiliate already exists
  const existingAffiliate = await c.env.DB.prepare(
    "SELECT * FROM affiliates WHERE user_id = ?"
  ).bind(request.user_id).first();
  
  if (existingAffiliate) {
    return c.json({ error: "User is already an affiliate" }, 400);
  }
  
  // Create affiliate
  await c.env.DB.prepare(
    `INSERT INTO affiliates (user_id, promo_code, status)
     VALUES (?, ?, 'active')`
  ).bind(request.user_id, request.promo_code).run();
  
  // Update request status
  await c.env.DB.prepare(
    `UPDATE affiliate_requests SET 
     status = 'approved',
     reviewed_by = ?,
     reviewed_at = CURRENT_TIMESTAMP,
     admin_notes = ?,
     updated_at = CURRENT_TIMESTAMP
     WHERE id = ?`
  ).bind(adminUser.id, body.admin_notes || null, id).run();
  
  const updatedRequest = await c.env.DB.prepare(
    "SELECT * FROM affiliate_requests WHERE id = ?"
  ).bind(id).first();
  
  return c.json(updatedRequest);
});

// Reject affiliate request (admin)
app.post("/api/admin/affiliate-requests/:id/reject", authMiddleware, adminMiddleware, async (c) => {
  const id = c.req.param("id");
  const body = await c.req.json();
  const adminUser = c.get("user");
  
  if (!adminUser) {
    return c.json({ error: "Unauthorized" }, 401);
  }
  
  const request = await c.env.DB.prepare(
    "SELECT * FROM affiliate_requests WHERE id = ?"
  ).bind(id).first();
  
  if (!request) {
    return c.json({ error: "Affiliate request not found" }, 404);
  }
  
  if (request.status !== 'pending') {
    return c.json({ error: "Request already processed" }, 400);
  }
  
  await c.env.DB.prepare(
    `UPDATE affiliate_requests SET 
     status = 'rejected',
     reviewed_by = ?,
     reviewed_at = CURRENT_TIMESTAMP,
     admin_notes = ?,
     updated_at = CURRENT_TIMESTAMP
     WHERE id = ?`
  ).bind(adminUser.id, body.admin_notes || null, id).run();
  
  const updatedRequest = await c.env.DB.prepare(
    "SELECT * FROM affiliate_requests WHERE id = ?"
  ).bind(id).first();
  
  return c.json(updatedRequest);
});

// Get all affiliates (admin)
app.get("/api/admin/affiliates", authMiddleware, adminMiddleware, async (c) => {
  const { results } = await c.env.DB.prepare(
    `SELECT a.*, u.email, u.full_name
     FROM affiliates a
     JOIN users u ON a.user_id = u.id
     ORDER BY a.created_at DESC`
  ).all();
  
  return c.json(results);
});

// Add inventory items (admin)
app.post("/api/admin/inventory", authMiddleware, adminMiddleware, async (c) => {
  const body = await c.req.json();
  
  const result = await c.env.DB.prepare(
    "INSERT INTO inventory (product_id, access_credentials) VALUES (?, ?)"
  ).bind(body.product_id, body.access_credentials).run();
  
  const item = await c.env.DB.prepare(
    "SELECT * FROM inventory WHERE id = ?"
  ).bind(result.meta.last_row_id).first();
  
  return c.json(item, 201);
});

// Get inventory for a product (admin)
app.get("/api/admin/inventory/:productId", authMiddleware, adminMiddleware, async (c) => {
  const productId = c.req.param("productId");
  
  const { results } = await c.env.DB.prepare(
    "SELECT * FROM inventory WHERE product_id = ? ORDER BY is_used ASC, created_at DESC"
  ).bind(productId).all();
  
  const available = results.filter((item: any) => item.is_used === 0).length;
  const used = results.filter((item: any) => item.is_used === 1).length;
  
  return c.json({
    items: results,
    stats: {
      total: results.length,
      available,
      used,
    },
  });
});

// Get all products (admin)
app.get("/api/admin/products", authMiddleware, adminMiddleware, async (c) => {
  const category = c.req.query("category");
  
  let query = "SELECT * FROM products";
  const params: any[] = [];
  
  if (category) {
    query += " WHERE category = ?";
    params.push(category);
  }
  
  query += " ORDER BY created_at DESC";
  
  const { results } = await c.env.DB.prepare(query).bind(...params).all();
  
  return c.json(results);
});

// Create product (admin)
app.post("/api/admin/products", authMiddleware, adminMiddleware, async (c) => {
  const body = await c.req.json();
  
  const result = await c.env.DB.prepare(
    `INSERT INTO products (
      name, description, category, service, price_1_months, price_3_months,
      price_6_months, client_discount_rate, affiliate_commission_rate,
      features, image_url, download_url, is_active, stock
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).bind(
    body.name,
    body.description || null,
    body.category,
    body.service || null,
    body.price_1_months || null,
    body.price_3_months || null,
    body.price_6_months || null,
    body.client_discount_rate || 0,
    body.affiliate_commission_rate || 0,
    body.features || null,
    body.image_url || null,
    body.download_url || null,
    body.is_active !== undefined ? body.is_active : 1,
    body.stock || null
  ).run();
  
  const product = await c.env.DB.prepare(
    "SELECT * FROM products WHERE id = ?"
  ).bind(result.meta.last_row_id).first();
  
  return c.json(product, 201);
});

// Update product (admin)
app.put("/api/admin/products/:id", authMiddleware, adminMiddleware, async (c) => {
  const id = c.req.param("id");
  const body = await c.req.json();
  
  await c.env.DB.prepare(
    `UPDATE products SET
     name = ?, description = ?, category = ?, service = ?,
     price_1_months = ?, price_3_months = ?, price_6_months = ?,
     client_discount_rate = ?, affiliate_commission_rate = ?,
     features = ?, image_url = ?, download_url = ?, is_active = ?, stock = ?,
     updated_at = CURRENT_TIMESTAMP
     WHERE id = ?`
  ).bind(
    body.name,
    body.description || null,
    body.category,
    body.service || null,
    body.price_1_months || null,
    body.price_3_months || null,
    body.price_6_months || null,
    body.client_discount_rate || 0,
    body.affiliate_commission_rate || 0,
    body.features || null,
    body.image_url || null,
    body.download_url || null,
    body.is_active !== undefined ? body.is_active : 1,
    body.stock || null,
    id
  ).run();
  
  const product = await c.env.DB.prepare(
    "SELECT * FROM products WHERE id = ?"
  ).bind(id).first();
  
  return c.json(product);
});

// Delete product (admin)
app.delete("/api/admin/products/:id", authMiddleware, adminMiddleware, async (c) => {
  const id = c.req.param("id");
  
  await c.env.DB.prepare(
    "DELETE FROM products WHERE id = ?"
  ).bind(id).run();
  
  return c.json({ success: true });
});

// Get dashboard stats (admin)
app.get("/api/admin/stats", authMiddleware, adminMiddleware, async (c) => {
  const totalOrders = await c.env.DB.prepare(
    "SELECT COUNT(*) as count FROM orders"
  ).first();
  
  const pendingOrders = await c.env.DB.prepare(
    "SELECT COUNT(*) as count FROM orders WHERE status = 'pending'"
  ).first();
  
  const paidOrders = await c.env.DB.prepare(
    "SELECT COUNT(*) as count FROM orders WHERE status = 'paid'"
  ).first();
  
  const totalRevenue = await c.env.DB.prepare(
    "SELECT SUM(amount) as total FROM orders WHERE status IN ('paid', 'delivered')"
  ).first();
  
  const totalAffiliates = await c.env.DB.prepare(
    "SELECT COUNT(*) as count FROM affiliates WHERE status = 'active'"
  ).first();
  
  const pendingRequests = await c.env.DB.prepare(
    "SELECT COUNT(*) as count FROM affiliate_requests WHERE status = 'pending'"
  ).first();
  
  return c.json({
    orders: {
      total: Number(totalOrders?.count || 0),
      pending: Number(pendingOrders?.count || 0),
      paid: Number(paidOrders?.count || 0),
    },
    revenue: {
      total: Number(totalRevenue?.total || 0),
    },
    affiliates: {
      total: Number(totalAffiliates?.count || 0),
      pending_requests: Number(pendingRequests?.count || 0),
    },
  });
});

export default app;
