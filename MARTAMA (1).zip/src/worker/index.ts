import { Hono } from "hono";
import { cors } from "hono/cors";
import { getCookie, setCookie } from "hono/cookie";
import {
  exchangeCodeForSessionToken,
  getOAuthRedirectUrl,
  authMiddleware,
  deleteSession,
  MOCHA_SESSION_TOKEN_COOKIE_NAME,
} from "@getmocha/users-service/backend";
import announcementRoutes from "./routes/announcement";
import exceptionalCodesRoutes from "./routes/exceptional-codes";
import notificationsRoutes from "./routes/notifications";
import lygosRoutes from "./routes/lygos";
import testimonialsRoutes from "./routes/testimonials";
import orderActionsRoutes from "./routes/order-actions";
import affiliatesAdminRoutes from "./routes/affiliates-admin";
import blogRoutes from "./routes/blog";
import formationsRoutes from "./routes/formations";
import academyRoutes from "./routes/academy";
import adminOrdersRoutes from "./routes/admin-orders";
import adminExportRoutes from "./routes/admin-export";
import adminRolesRoutes from "./routes/admin-roles";
import affiliateProfileRoutes from "./routes/affiliate-profile";

const app = new Hono<{ Bindings: Env }>();

// Mount route modules
app.route("/", announcementRoutes);
app.route("/", exceptionalCodesRoutes);
app.route("/", notificationsRoutes);
app.route("/", lygosRoutes);
app.route("/", testimonialsRoutes);
app.route("/", orderActionsRoutes);
app.route("/", affiliatesAdminRoutes);
app.route("/api/blog", blogRoutes);
app.route("/api/formations", formationsRoutes);
app.route("/api/academy", academyRoutes);
app.route("/api/admin/orders", adminOrdersRoutes);
app.route("/api/admin/export", adminExportRoutes);
app.route("/api/admin/roles", adminRolesRoutes);
app.route("/", affiliateProfileRoutes);

// CORS middleware
app.use("*", cors({
  origin: "*",
  credentials: true,
}));

// ============================================================================
// Authentication routes
// ============================================================================

app.get("/api/oauth/google/redirect_url", async (c) => {
  const redirectUrl = await getOAuthRedirectUrl("google", {
    apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
  });

  return c.json({ redirectUrl }, 200);
});

app.post("/api/sessions", async (c) => {
  const body = await c.req.json();

  if (!body.code) {
    return c.json({ error: "No authorization code provided" }, 400);
  }

  const sessionToken = await exchangeCodeForSessionToken(body.code, {
    apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
  });

  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, sessionToken, {
    httpOnly: true,
    path: "/",
    sameSite: "none",
    secure: true,
    maxAge: 60 * 24 * 60 * 60, // 60 days
  });

  return c.json({ success: true }, 200);
});

app.get("/api/users/me", authMiddleware, async (c) => {
  const mochaUser = c.get("user");
  
  if (!mochaUser) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  // Check if user exists in our database
  const userResult = await c.env.DB.prepare(
    "SELECT * FROM users WHERE id = ?"
  ).bind(mochaUser.id).first();

  if (!userResult) {
    // Check if this is one of our admin emails
    const adminEmails = [
      'arsuzannou@gmail.com', 
      'bnb887991@gmail.com', 
      'thelucidshadow7@gmail.com'
    ];
    const role = adminEmails.includes(mochaUser.email) ? 'admin' : 'user';
    
    // Create user record on first login with enhanced fields
    await c.env.DB.prepare(
      `INSERT INTO users (
        id, email, full_name, role, role_type,
        affiliate_status, affiliate_commission_rate, 
        loyalty_points, is_active, has_completed_onboarding
      ) VALUES (?, ?, ?, ?, 'client', 'none', 30, 0, 1, 0)`
    ).bind(
      mochaUser.id,
      mochaUser.email,
      mochaUser.google_user_data.name || null,
      role
    ).run();

    const newUser = await c.env.DB.prepare(
      "SELECT * FROM users WHERE id = ?"
    ).bind(mochaUser.id).first();

    return c.json(newUser);
  }

  return c.json(userResult);
});

// Update user profile
app.put("/api/users/profile", authMiddleware, async (c) => {
  const mochaUser = c.get("user");
  
  if (!mochaUser) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  const body = await c.req.json();
  
  await c.env.DB.prepare(
    `UPDATE users SET 
     full_name = ?,
     phone_number = ?,
     country = ?,
     updated_at = CURRENT_TIMESTAMP
     WHERE id = ?`
  ).bind(
    body.full_name || null,
    body.phone_number || null,
    body.country || null,
    mochaUser.id
  ).run();

  const updatedUser = await c.env.DB.prepare(
    "SELECT * FROM users WHERE id = ?"
  ).bind(mochaUser.id).first();

  return c.json(updatedUser);
});

// Mark onboarding as completed
app.post("/api/users/complete-onboarding", authMiddleware, async (c) => {
  const mochaUser = c.get("user");
  
  if (!mochaUser) {
    return c.json({ error: "Unauthorized" }, 401);
  }
  
  await c.env.DB.prepare(
    "UPDATE users SET has_completed_onboarding = 1, updated_at = CURRENT_TIMESTAMP WHERE id = ?"
  ).bind(mochaUser.id).run();
  
  return c.json({ success: true });
});

app.get("/api/logout", async (c) => {
  const sessionToken = getCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME);

  if (typeof sessionToken === "string") {
    await deleteSession(sessionToken, {
      apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
      apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
    });
  }

  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, "", {
    httpOnly: true,
    path: "/",
    sameSite: "none",
    secure: true,
    maxAge: 0,
  });

  return c.json({ success: true }, 200);
});





  
// ============================================================================
// Products routes
// ============================================================================

app.get("/api/products", async (c) => {
  const category = c.req.query("category");
  
  let query = "SELECT * FROM products WHERE is_active = 1";
  const params: any[] = [];
  
  if (category) {
    query += " AND category = ?";
    params.push(category);
  }
  
  query += " ORDER BY created_at DESC";
  
  const { results } = await c.env.DB.prepare(query).bind(...params).all();
  
  return c.json(results);
});

app.get("/api/products/:id", async (c) => {
  const id = c.req.param("id");
  
  const product = await c.env.DB.prepare(
    "SELECT * FROM products WHERE id = ? AND is_active = 1"
  ).bind(id).first();
  
  if (!product) {
    return c.json({ error: "Product not found" }, 404);
  }
  
  return c.json(product);
});

// Get top products
app.get("/api/products/top", async (c) => {
  const { results } = await c.env.DB.prepare(
    "SELECT * FROM products WHERE is_active = 1 ORDER BY total_sales DESC, created_at DESC LIMIT 3"
  ).all();
  
  return c.json(results);
});

// ============================================================================
// FedaPay routes
// ============================================================================

app.get("/api/fedapay/public-key", async (c) => {
  return c.json({ 
    public_key: c.env.FEDAPAY_PUBLIC_KEY || ''
  });
});

// Create FedaPay transaction (server-side)
app.post("/api/fedapay/create-transaction", async (c) => {
  try {
    const body = await c.req.json();
    const { amount, description, orderId, customerEmail } = body;

    if (!c.env.FEDAPAY_SECRET_KEY) {
      return c.json({ error: 'Clé secrète FedaPay non configurée.' }, 500);
    }

    // Create transaction via FedaPay API directly using fetch
    // This is more reliable in Cloudflare Workers than the Node.js SDK
    const fedapayResponse = await fetch('https://sandbox-api.fedapay.com/v1/transactions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${c.env.FEDAPAY_SECRET_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        description: description || `Commande #${orderId}`,
        amount: amount,
        currency: {
          iso: 'XOF'
        },
        callback_url: `${new URL(c.req.url).origin}/api/fedapay/webhook`,
        custom_metadata: {
          order_id: orderId.toString(),
          customer_email: customerEmail,
        }
      }),
    });

    if (!fedapayResponse.ok) {
      const errorData = await fedapayResponse.json();
      console.error('FedaPay API error:', errorData);
      return c.json({ error: 'Échec de l\'initialisation du paiement.' }, 500);
    }

    const transactionData = await fedapayResponse.json() as any;

    return c.json({
      transactionId: transactionData.v1?.id || transactionData.id,
      transactionToken: transactionData.v1?.token || transactionData.token,
      message: 'Transaction créée avec succès'
    });

  } catch (error) {
    console.error('Erreur lors de la création de la transaction FedaPay:', error);
    return c.json({ error: 'Échec de l\'initialisation du paiement.' }, 500);
  }
});

// FedaPay webhook to handle payment notifications
// Best practices implemented according to FedaPay documentation
app.post("/api/fedapay/webhook", async (c) => {
  try {
    // Get raw body for signature verification
    const rawBody = await c.req.text();
    const signature = c.req.header('X-FEDAPAY-SIGNATURE') || '';
    
    // Parse the webhook event
    let event;
    try {
      event = JSON.parse(rawBody);
    } catch (e) {
      console.error("Invalid JSON payload:", e);
      return c.json({ error: "Invalid payload" }, 400);
    }
    
    // Verify webhook signature using FEDAPAY_WEBHOOK_SECRET
    // This prevents replay attacks and ensures authenticity
    if (c.env.FEDAPAY_WEBHOOK_SECRET && signature) {
      // Extract timestamp and signature from header
      const parts = signature.split(',');
      let timestamp = '';
      let receivedSignature = '';
      
      for (const part of parts) {
        const [key, value] = part.split('=');
        if (key === 't') timestamp = value;
        if (key === 'v1') receivedSignature = value;
      }
      
      // Verify timestamp is recent (within 5 minutes) to prevent replay attacks
      const currentTime = Math.floor(Date.now() / 1000);
      const timeDiff = currentTime - parseInt(timestamp);
      
      if (timeDiff > 300) { // 5 minutes
        console.error("Webhook timestamp too old:", timeDiff);
        return c.json({ error: "Webhook timestamp too old" }, 400);
      }
      
      // Compute expected signature
      const signedPayload = `${timestamp}.${rawBody}`;
      const expectedSignature = await crypto.subtle.digest(
        'SHA-256',
        new TextEncoder().encode(`${c.env.FEDAPAY_WEBHOOK_SECRET}${signedPayload}`)
      ).then(hash => 
        Array.from(new Uint8Array(hash))
          .map(b => b.toString(16).padStart(2, '0'))
          .join('')
      );
      
      // Compare signatures
      if (receivedSignature !== expectedSignature) {
        console.error("Invalid webhook signature");
        return c.json({ error: "Invalid signature" }, 400);
      }
    }
    
    // Return 200 immediately as per FedaPay best practices
    // Process the event asynchronously
    c.executionCtx.waitUntil(processWebhookEvent(event, c.env));
    
    return c.json({ received: true }, 200);
  } catch (error) {
    console.error("Webhook error:", error);
    // Still return 200 to prevent retries for malformed requests
    return c.json({ received: true }, 200);
  }
});

// Async function to process webhook events
async function processWebhookEvent(event: any, env: Env) {
  try {
    const eventName = event.name;
    const eventId = event.id;
    
    // Prevent duplicate event processing
    const existingEvent = await env.DB.prepare(
      "SELECT id FROM webhook_events WHERE event_id = ?"
    ).bind(eventId).first();
    
    if (existingEvent) {
      console.log("Duplicate event ignored:", eventId);
      return;
    }
    
    // Store event to prevent duplicates
    await env.DB.prepare(
      "INSERT INTO webhook_events (event_id, event_name, processed_at) VALUES (?, ?, CURRENT_TIMESTAMP)"
    ).bind(eventId, eventName).run();
    
    // Handle different event types
    switch (eventName) {
      case 'transaction.created':
        await handleTransactionCreated(event, env);
        break;
      
      case 'transaction.approved':
        await handleTransactionApproved(event, env);
        break;
      
      case 'transaction.declined':
        await handleTransactionDeclined(event, env);
        break;
      
      case 'transaction.canceled':
        await handleTransactionCanceled(event, env);
        break;
      
      case 'transaction.transferred':
        await handleTransactionTransferred(event, env);
        break;
      
      default:
        console.log("Unhandled event type:", eventName);
    }
  } catch (error) {
    console.error("Error processing webhook event:", error);
  }
}

async function handleTransactionCreated(event: any, _env: Env) {
  // Transaction created - just log for now
  console.log("Transaction created:", event.entity?.transaction?.id);
}

async function handleTransactionApproved(event: any, env: Env) {
  const transaction = event.entity?.transaction;
  if (!transaction) return;
  
  // Find order by payment reference or custom metadata
  const orderId = transaction.custom_metadata?.order_id || 
                  await findOrderByPaymentReference(transaction.id, env);
  
  if (!orderId) {
    console.error("Order not found for transaction:", transaction.id);
    return;
  }
  
  // Update order status to paid
  await env.DB.prepare(
    `UPDATE orders SET 
     status = 'paid',
     payment_reference = ?,
     updated_at = CURRENT_TIMESTAMP
     WHERE id = ?`
  ).bind(transaction.id, orderId).run();
  
  // Get order details
  const order = await env.DB.prepare(
    "SELECT * FROM orders WHERE id = ?"
  ).bind(orderId).first();
  
  if (!order) return;
  
  // Handle affiliate commission if applicable
  if (order.affiliate_id && Number(order.affiliate_commission) > 0) {
    const existingCommission = await env.DB.prepare(
      "SELECT * FROM commissions WHERE order_id = ?"
    ).bind(orderId).first();
    
    if (!existingCommission) {
      // Get purchase number
      const history = await env.DB.prepare(
        "SELECT total_purchases FROM customer_purchase_history WHERE customer_email = ? AND affiliate_id = ?"
      ).bind(order.customer_email, order.affiliate_id).first();
      
      const purchaseNumber = history ? Number(history.total_purchases) : 1;
      
      // Get product commission rate
      const product = await env.DB.prepare(
        "SELECT affiliate_commission_rate FROM products WHERE id = ?"
      ).bind(order.product_id).first();
      
      const baseCommissionRate = product ? Number(product.affiliate_commission_rate) : 0;
      
      // Calculate actual rate
      let actualCommissionRate = 0;
      if (purchaseNumber === 1) {
        actualCommissionRate = baseCommissionRate;
      } else if (purchaseNumber >= 2 && purchaseNumber <= 4) {
        actualCommissionRate = baseCommissionRate / 3;
      }
      
      // Create commission
      await env.DB.prepare(
        "INSERT INTO commissions (order_id, affiliate_id, amount, status, purchase_number, commission_rate) VALUES (?, ?, ?, 'pending', ?, ?)"
      ).bind(orderId, order.affiliate_id, order.affiliate_commission, purchaseNumber, actualCommissionRate).run();
      
      // Update affiliate stats
      await env.DB.prepare(
        `UPDATE affiliates SET 
         total_sales = total_sales + 1,
         total_commissions = total_commissions + ?,
         balance = balance + ?,
         updated_at = CURRENT_TIMESTAMP
         WHERE id = ?`
      ).bind(order.affiliate_commission, order.affiliate_commission, order.affiliate_id).run();
    }
  }
  
  console.log("Transaction approved and processed:", transaction.id);
}

async function handleTransactionDeclined(event: any, env: Env) {
  const transaction = event.entity?.transaction;
  if (!transaction) return;
  
  const orderId = transaction.custom_metadata?.order_id || 
                  await findOrderByPaymentReference(transaction.id, env);
  
  if (!orderId) return;
  
  await env.DB.prepare(
    `UPDATE orders SET 
     status = 'cancelled',
     payment_reference = ?,
     updated_at = CURRENT_TIMESTAMP
     WHERE id = ?`
  ).bind(transaction.id, orderId).run();
  
  console.log("Transaction declined:", transaction.id);
}

async function handleTransactionCanceled(event: any, env: Env) {
  const transaction = event.entity?.transaction;
  if (!transaction) return;
  
  const orderId = transaction.custom_metadata?.order_id || 
                  await findOrderByPaymentReference(transaction.id, env);
  
  if (!orderId) return;
  
  await env.DB.prepare(
    `UPDATE orders SET 
     status = 'cancelled',
     payment_reference = ?,
     updated_at = CURRENT_TIMESTAMP
     WHERE id = ?`
  ).bind(transaction.id, orderId).run();
  
  console.log("Transaction canceled:", transaction.id);
}

async function handleTransactionTransferred(event: any, _env: Env) {
  // Funds have been transferred - just log for now
  console.log("Transaction transferred:", event.entity?.transaction?.id);
}

async function findOrderByPaymentReference(transactionId: string, env: Env): Promise<number | null> {
  const order = await env.DB.prepare(
    "SELECT id FROM orders WHERE payment_reference = ?"
  ).bind(transactionId).first();
  
  return order ? Number(order.id) : null;
}

// Update order with payment info
app.post("/api/orders/:id/payment", async (c) => {
  const id = c.req.param("id");
  const body = await c.req.json();
  
  const order = await c.env.DB.prepare(
    "SELECT * FROM orders WHERE id = ?"
  ).bind(id).first();
  
  if (!order) {
    return c.json({ error: "Order not found" }, 404);
  }
  
  // Update order with payment reference and status
  let orderStatus = 'pending';
  if (body.status === 'approved') {
    orderStatus = 'paid';
  } else if (body.status === 'canceled' || body.status === 'declined' || body.status === 'abandoned') {
    orderStatus = 'cancelled';
  }
  
  await c.env.DB.prepare(
    `UPDATE orders SET 
     status = ?,
     payment_reference = ?,
     payment_method = 'FedaPay',
     updated_at = CURRENT_TIMESTAMP
     WHERE id = ?`
  ).bind(orderStatus, body.transaction_id, id).run();
  
  // If payment successful, ensure user account exists
  if (orderStatus === 'paid' && body.customer_email) {
    const existingUser = await c.env.DB.prepare(
      "SELECT * FROM users WHERE email = ?"
    ).bind(body.customer_email).first();
    
    if (!existingUser) {
      // Create user account automatically for guest checkout
      const userId = `user_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      await c.env.DB.prepare(
        `INSERT INTO users (id, email, role, has_completed_onboarding, is_active)
         VALUES (?, ?, 'user', 0, 1)`
      ).bind(userId, body.customer_email).run();
    }
  }
  
  // Handle affiliate commission if paid
  if (orderStatus === 'paid' && order.affiliate_id && Number(order.affiliate_commission) > 0) {
    const existingCommission = await c.env.DB.prepare(
      "SELECT * FROM commissions WHERE order_id = ?"
    ).bind(id).first();
    
    if (!existingCommission) {
      // Get purchase number
      const history = await c.env.DB.prepare(
        "SELECT total_purchases FROM customer_purchase_history WHERE customer_email = ? AND affiliate_id = ?"
      ).bind(order.customer_email, order.affiliate_id).first();
      
      const purchaseNumber = history ? Number(history.total_purchases) : 1;
      
      // Get product commission rate
      const product = await c.env.DB.prepare(
        "SELECT affiliate_commission_rate FROM products WHERE id = ?"
      ).bind(order.product_id).first();
      
      const baseCommissionRate = product ? Number(product.affiliate_commission_rate) : 0;
      
      // Calculate actual rate
      let actualCommissionRate = 0;
      if (purchaseNumber === 1) {
        actualCommissionRate = baseCommissionRate;
      } else if (purchaseNumber >= 2 && purchaseNumber <= 4) {
        actualCommissionRate = baseCommissionRate / 3;
      }
      
      await c.env.DB.prepare(
        "INSERT INTO commissions (order_id, affiliate_id, amount, status, purchase_number, commission_rate) VALUES (?, ?, ?, 'pending', ?, ?)"
      ).bind(id, order.affiliate_id, order.affiliate_commission, purchaseNumber, actualCommissionRate).run();
      
      await c.env.DB.prepare(
        `UPDATE affiliates SET 
         total_sales = total_sales + 1,
         total_commissions = total_commissions + ?,
         balance = balance + ?,
         updated_at = CURRENT_TIMESTAMP
         WHERE id = ?`
      ).bind(order.affiliate_commission, order.affiliate_commission, order.affiliate_id).run();
    }
  }
  
  const updatedOrder = await c.env.DB.prepare(
    "SELECT * FROM orders WHERE id = ?"
  ).bind(id).first();
  
  return c.json(updatedOrder);
});

// ============================================================================
// Affiliate validation routes
// ============================================================================

app.get("/api/affiliates/validate", async (c) => {
  const code = c.req.query("code");
  
  if (!code) {
    return c.json({ valid: false, error: "No code provided" }, 400);
  }
  
  // First check if it's an exceptional code
  const exceptionalCode = await c.env.DB.prepare(
    `SELECT * FROM exceptional_promo_codes 
     WHERE code = ? AND is_active = 1
     AND (start_date IS NULL OR start_date <= CURRENT_TIMESTAMP)
     AND (end_date IS NULL OR end_date >= CURRENT_TIMESTAMP)`
  ).bind(code).first();
  
  if (exceptionalCode) {
    return c.json({ 
      valid: true,
      discountRate: Number(exceptionalCode.discount_rate || 0),
      affiliateId: exceptionalCode.affiliate_id,
      isExceptional: true
    });
  }
  
  // Otherwise check if it's a regular affiliate code
  const affiliate = await c.env.DB.prepare(
    "SELECT a.*, u.email FROM affiliates a JOIN users u ON a.user_id = u.id WHERE a.promo_code = ? AND a.status = 'active'"
  ).bind(code).first();
  
  if (!affiliate) {
    return c.json({ 
      valid: false, 
      error: "Code promo invalide ou inactif" 
    }, 404);
  }
  
  // Note: discount rate will come from the product, not the affiliate
  // This endpoint is just for validation, actual rates are determined during order creation
  return c.json({ 
    valid: true,
    discountRate: 0, // Will be determined by product or exceptional code
    affiliateId: affiliate.id,
    isExceptional: false
  });
});

// Track affiliate click
app.post("/api/affiliates/track-click", async (c) => {
  const code = c.req.query("code");
  
  if (!code) {
    return c.json({ error: "No code provided" }, 400);
  }
  
  // Find affiliate
  const affiliate = await c.env.DB.prepare(
    "SELECT * FROM affiliates WHERE promo_code = ? AND status = 'active'"
  ).bind(code).first();
  
  if (!affiliate) {
    return c.json({ error: "Invalid affiliate code" }, 404);
  }
  
  // Get request info
  const ipAddress = c.req.header('CF-Connecting-IP') || c.req.header('X-Forwarded-For') || 'unknown';
  const userAgent = c.req.header('User-Agent') || '';
  const referrer = c.req.header('Referer') || '';
  
  // Record click
  await c.env.DB.prepare(
    "INSERT INTO link_clicks (affiliate_id, ip_address, user_agent, referrer) VALUES (?, ?, ?, ?)"
  ).bind(affiliate.id, ipAddress, userAgent, referrer).run();
  
  // Update affiliate total clicks
  await c.env.DB.prepare(
    "UPDATE affiliates SET total_clicks = total_clicks + 1, updated_at = CURRENT_TIMESTAMP WHERE id = ?"
  ).bind(affiliate.id).run();
  
  return c.json({ success: true });
});

// ============================================================================
// Orders routes
// ============================================================================

app.post("/api/orders", async (c) => {
  const body = await c.req.json();
  
  // Get product
  const product = await c.env.DB.prepare(
    "SELECT * FROM products WHERE id = ?"
  ).bind(body.product_id).first();
  
  if (!product) {
    return c.json({ error: "Product not found" }, 404);
  }
  
  // Check if product is formation or pack - can only be purchased once
  if (product.category === 'formation' || product.category === 'pack') {
    const existingOrder = await c.env.DB.prepare(
      `SELECT id FROM orders 
       WHERE customer_email = ? 
       AND product_id = ? 
       AND status IN ('paid', 'delivered')
       LIMIT 1`
    ).bind(body.customer_email, body.product_id).first();
    
    if (existingOrder) {
      return c.json({ 
        error: `Vous avez déjà acheté ce ${product.category === 'formation' ? 'formation' : 'pack'}. Les mises à jour futures sont automatiques et incluses dans votre achat initial.`,
        already_purchased: true
      }, 400);
    }
  }
  
  // Calculate price based on duration
  let originalAmount = 0;
  const price1 = product.price_1_months as any;
  const price3 = product.price_3_months as any;
  const price6 = product.price_6_months as any;
  
  if (body.duration_months === 1 && price1) {
    originalAmount = Number(price1);
  } else if (body.duration_months === 3 && price3) {
    originalAmount = Number(price3);
  } else if (body.duration_months === 6 && price6) {
    originalAmount = Number(price6);
  }
  
  // Initialize discount and commission variables
  let clientDiscountRate = 0;
  let affiliateBaseCommissionRate = 0;
  let affiliateId = null;
  let affiliateCode = null;
  let discountAmount = 0;
  let affiliateCommission = 0;
  let previousDiscountRate = 0;
  let purchaseNumber = 1;
  
  // 1. Determine base rates (product or exceptional code)
  if (body.affiliate_code) {
    // First check if it's an exceptional code
    const exceptionalCode = await c.env.DB.prepare(
      `SELECT * FROM exceptional_promo_codes 
       WHERE code = ? AND is_active = 1
       AND (start_date IS NULL OR start_date <= CURRENT_TIMESTAMP)
       AND (end_date IS NULL OR end_date >= CURRENT_TIMESTAMP)`
    ).bind(body.affiliate_code).first();
    
    if (exceptionalCode) {
      // It's an exceptional code - use its rates
      clientDiscountRate = Number(exceptionalCode.discount_rate || 0);
      affiliateBaseCommissionRate = Number(exceptionalCode.commission_rate || 0);
      affiliateCode = body.affiliate_code;
      affiliateId = Number(exceptionalCode.affiliate_id);
      
      // Verify the exceptional code applies to this product
      if (exceptionalCode.applies_to === 'product') {
        const targetIds = exceptionalCode.target_ids ? JSON.parse(exceptionalCode.target_ids as string) : [];
        if (!targetIds.includes(Number(product.id))) {
          // Code doesn't apply to this product - use product rates instead
          clientDiscountRate = Number(product.client_discount_rate || 0);
          affiliateBaseCommissionRate = Number(product.affiliate_commission_rate || 0);
        }
      } else if (exceptionalCode.applies_to === 'category') {
        const targetIds = exceptionalCode.target_ids ? JSON.parse(exceptionalCode.target_ids as string) : [];
        if (!targetIds.includes(product.category as string)) {
          // Code doesn't apply to this category - use product rates instead
          clientDiscountRate = Number(product.client_discount_rate || 0);
          affiliateBaseCommissionRate = Number(product.affiliate_commission_rate || 0);
        }
      }
      // If applies_to === 'all', keep exceptional rates
    } else {
      // Not an exceptional code - check if it's a valid affiliate code
      const affiliate = await c.env.DB.prepare(
        "SELECT * FROM affiliates WHERE promo_code = ? AND status = 'active'"
      ).bind(body.affiliate_code).first();
      
      if (!affiliate) {
        // REJECT invalid code - apply NORMAL price without discount
        return c.json({ 
          error: "Code promo invalide ou inactif - Tarif normal appliqué",
          price: originalAmount,
          discount_applied: 0
        }, 400);
      }
      
      // Valid affiliate code - use product rates
      clientDiscountRate = Number(product.client_discount_rate || 0);
      affiliateBaseCommissionRate = Number(product.affiliate_commission_rate || 0);
      affiliateId = Number(affiliate.id);
      affiliateCode = body.affiliate_code;
    }
  } else {
    // NO promo code provided - use product default rates
    clientDiscountRate = Number(product.client_discount_rate || 0);
    affiliateBaseCommissionRate = Number(product.affiliate_commission_rate || 0);
    
    // Check if customer has purchase history with any affiliate
    const customerHistory = await c.env.DB.prepare(
      "SELECT * FROM customer_purchase_history WHERE customer_email = ? AND used_promo_previously = 1 ORDER BY first_purchase_date DESC LIMIT 1"
    ).bind(body.customer_email).first();
    
    if (customerHistory) {
      // Customer has purchased with promo before - maintain affiliate link
      affiliateId = Number(customerHistory.affiliate_id);
      // Use the previously applied discount rate
      clientDiscountRate = Number(customerHistory.previous_discount_rate || clientDiscountRate);
      
      // Get affiliate code for order record
      const affiliate = await c.env.DB.prepare(
        "SELECT promo_code FROM affiliates WHERE id = ?"
      ).bind(affiliateId).first();
      
      if (affiliate) {
        affiliateCode = affiliate.promo_code as string;
      }
    }
  }
  
  // 2. Calculate client discount
  discountAmount = originalAmount * clientDiscountRate;
  previousDiscountRate = clientDiscountRate;
  
  // 3. Calculate affiliate commission (with pyramid)
  if (affiliateId) {
    const history = await c.env.DB.prepare(
      "SELECT total_purchases FROM customer_purchase_history WHERE customer_email = ? AND affiliate_id = ?"
    ).bind(body.customer_email, affiliateId).first();
    
    if (history) {
      purchaseNumber = Number(history.total_purchases) + 1;
    }
    
    // Apply pyramid to base commission rate
    let finalCommissionRate = 0;
    if (purchaseNumber === 1) {
      finalCommissionRate = affiliateBaseCommissionRate;
    } else if (purchaseNumber === 2) {
      finalCommissionRate = affiliateBaseCommissionRate / 2;
    } else {
      finalCommissionRate = 0.05; // 5% for 3rd+ purchases
    }
    
    // Commission is calculated on the original amount (before discount)
    affiliateCommission = originalAmount * finalCommissionRate;
  }
  
  // Calculate final amount
  const finalAmount = originalAmount - discountAmount;
  
  // Determine initial status - free products are automatically paid
  const initialStatus = finalAmount === 0 ? 'paid' : 'pending';
  
  // Create order
  const result = await c.env.DB.prepare(
    `INSERT INTO orders (
      product_id, customer_email, duration_months, amount, original_amount,
      discount_amount, affiliate_code, affiliate_id, affiliate_commission,
      status, payment_method
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).bind(
    body.product_id,
    body.customer_email,
    body.duration_months || null,
    finalAmount,
    originalAmount,
    discountAmount,
    affiliateCode,
    affiliateId,
    affiliateCommission,
    initialStatus,
    body.payment_method || 'FedaPay'
  ).run();
  
  // Create notification for new order
  await c.env.DB.prepare(
    "INSERT INTO order_notifications (order_id, is_read) VALUES (?, 0)"
  ).bind(result.meta.last_row_id).run();
  
  // For free products, auto-deliver ONLY packs and formations
  // Subscriptions (abonnements) always require manual admin delivery
  if (finalAmount === 0) {
    const orderId = result.meta.last_row_id;
    
    // Get product details
    const productForDelivery = await c.env.DB.prepare(
      "SELECT * FROM products WHERE id = ?"
    ).bind(body.product_id).first();
    
    // Create user if doesn't exist
    const existingUser = await c.env.DB.prepare(
      "SELECT * FROM users WHERE email = ?"
    ).bind(body.customer_email).first();
    
    let userId = existingUser ? existingUser.id : null;
    
    if (!existingUser) {
      userId = `user_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      await c.env.DB.prepare(
        "INSERT INTO users (id, email, role, has_completed_onboarding, is_active) VALUES (?, ?, 'user', 0, 1)"
      ).bind(userId, body.customer_email).run();
    }
    
    // CRITICAL: Only auto-deliver packs and formations, NOT subscriptions
    if (productForDelivery?.category === 'formation' && productForDelivery.auto_delivery === 1) {
      // Create user_formations access
      await c.env.DB.prepare(
        "INSERT OR IGNORE INTO user_formations (user_email, product_id, order_id, access_granted_at) VALUES (?, ?, ?, CURRENT_TIMESTAMP)"
      ).bind(body.customer_email, body.product_id, orderId).run();
      
      // Update order status to delivered
      await c.env.DB.prepare(
        "UPDATE orders SET status = 'delivered', delivered_at = CURRENT_TIMESTAMP, delivered_by = 'system_auto', updated_at = CURRENT_TIMESTAMP WHERE id = ?"
      ).bind(orderId).run();
      
      // Log auto-delivery
      await c.env.DB.prepare(
        `INSERT INTO order_action_logs (order_id, action_type, action_details, performed_by)
         VALUES (?, 'order_delivered', 'Livraison automatique - Formation gratuite', 'system_auto')`
      ).bind(orderId).run();
    } else if (productForDelivery?.category === 'pack' && productForDelivery.auto_delivery === 1) {
      // For packs, mark as delivered and set access_credentials to download_url
      const downloadUrl = (productForDelivery as any).download_url || (productForDelivery as any).file_url || '';
      await c.env.DB.prepare(
        "UPDATE orders SET status = 'delivered', access_credentials = ?, delivered_at = CURRENT_TIMESTAMP, delivered_by = 'system_auto', updated_at = CURRENT_TIMESTAMP WHERE id = ?"
      ).bind(downloadUrl, orderId).run();
      
      // Log auto-delivery
      await c.env.DB.prepare(
        `INSERT INTO order_action_logs (order_id, action_type, action_details, performed_by)
         VALUES (?, 'order_delivered', 'Livraison automatique - Pack gratuit', 'system_auto')`
      ).bind(orderId).run();
    }
    // For abonnements (subscriptions), even if free, do NOT auto-deliver
    // Admin must manually deliver with access_credentials and usage_instructions
  }
  
  // Update or create customer purchase history if affiliate involved
  if (affiliateId) {
    const existingHistory = await c.env.DB.prepare(
      "SELECT * FROM customer_purchase_history WHERE customer_email = ? AND affiliate_id = ?"
    ).bind(body.customer_email, affiliateId).first();
    
    if (existingHistory) {
      // Update existing history
      await c.env.DB.prepare(
        `UPDATE customer_purchase_history SET
         total_purchases = ?,
         current_commission_tier = ?,
         updated_at = CURRENT_TIMESTAMP
         WHERE id = ?`
      ).bind(purchaseNumber, purchaseNumber, existingHistory.id).run();
    } else {
      // Create new history record
      await c.env.DB.prepare(
        `INSERT INTO customer_purchase_history (
          customer_email, affiliate_id, first_purchase_date,
          total_purchases, used_promo_previously, previous_discount_rate,
          current_commission_tier
        ) VALUES (?, ?, CURRENT_TIMESTAMP, 1, 1, ?, 1)`
      ).bind(body.customer_email, affiliateId, previousDiscountRate).run();
    }
  }
  
  const order = await c.env.DB.prepare(
    "SELECT * FROM orders WHERE id = ?"
  ).bind(result.meta.last_row_id).first();
  
  return c.json(order, 201);
});

// Get user's orders
app.get("/api/orders/my", authMiddleware, async (c) => {
  const user = c.get("user");
  
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }
  
  const { results } = await c.env.DB.prepare(
    `SELECT o.*, p.name as product_name, p.category as product_category
     FROM orders o
     JOIN products p ON o.product_id = p.id
     WHERE o.customer_email = ?
     ORDER BY o.created_at DESC`
  ).bind(user.email).all();
  
  return c.json(results);
});

// Get user's subscriptions
app.get("/api/subscriptions/my", authMiddleware, async (c) => {
  const user = c.get("user");
  
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }
  
  // Get classic subscriptions
  const { results: subscriptions } = await c.env.DB.prepare(
    `SELECT s.*, p.name as product_name, p.category as product_category, o.status
     FROM subscriptions s
     JOIN products p ON s.product_id = p.id
     LEFT JOIN orders o ON s.order_id = o.id
     WHERE s.user_id = ? OR o.customer_email = ?
     ORDER BY s.created_at DESC`
  ).bind(user.id, user.email).all();
  
  // Get formations from user_formations
  const { results: formations } = await c.env.DB.prepare(
    `SELECT 
      uf.id,
      uf.order_id,
      p.id as product_id,
      p.name as product_name,
      p.category as product_category,
      o.status,
      NULL as access_credentials,
      uf.access_granted_at as created_at,
      NULL as expires_at,
      NULL as is_active,
      NULL as user_id,
      NULL as updated_at
     FROM user_formations uf
     JOIN products p ON uf.product_id = p.id
     JOIN orders o ON uf.order_id = o.id
     WHERE uf.user_email = ?
     ORDER BY uf.access_granted_at DESC`
  ).bind(user.email).all();
  
  // Get packs from delivered orders
  const { results: packs } = await c.env.DB.prepare(
    `SELECT 
      o.id,
      o.id as order_id,
      p.id as product_id,
      p.name as product_name,
      p.category as product_category,
      o.status,
      o.access_credentials,
      o.created_at,
      NULL as expires_at,
      NULL as is_active,
      NULL as user_id,
      o.updated_at
     FROM orders o
     JOIN products p ON o.product_id = p.id
     WHERE o.customer_email = ? 
     AND p.category = 'pack'
     AND o.status IN ('paid', 'delivered')
     ORDER BY o.created_at DESC`
  ).bind(user.email).all();
  
  // Combine all results
  const allSubscriptions = [...subscriptions, ...formations, ...packs];
  
  // Remove duplicates (same product_id might appear in both tables)
  const uniqueSubscriptions = allSubscriptions.reduce((acc: any[], current) => {
    const exists = acc.find(item => 
      item.product_id === current.product_id && 
      item.order_id === current.order_id
    );
    if (!exists) {
      acc.push(current);
    }
    return acc;
  }, []);
  
  // Sort by created_at descending
  uniqueSubscriptions.sort((a, b) => {
    const dateA = new Date(a.created_at).getTime();
    const dateB = new Date(b.created_at).getTime();
    return dateB - dateA;
  });
  
  return c.json(uniqueSubscriptions);
});

// Get affiliate stats
app.get("/api/affiliate/stats", authMiddleware, async (c) => {
  const user = c.get("user");
  
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }
  
  const affiliate = await c.env.DB.prepare(
    "SELECT * FROM affiliates WHERE user_id = ? AND status = 'active'"
  ).bind(user.id).first();
  
  if (!affiliate) {
    return c.json({ error: "Not an affiliate" }, 404);
  }
  
  return c.json(affiliate);
});

// Get affiliate commissions
app.get("/api/affiliate/commissions", authMiddleware, async (c) => {
  const user = c.get("user");
  
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }
  
  const affiliate = await c.env.DB.prepare(
    "SELECT * FROM affiliates WHERE user_id = ? AND status = 'active'"
  ).bind(user.id).first();
  
  if (!affiliate) {
    return c.json({ error: "Not an affiliate" }, 404);
  }
  
  // Get commissions with order and product details
  const { results } = await c.env.DB.prepare(
    `SELECT 
      c.id,
      c.order_id,
      c.amount,
      c.status,
      c.created_at,
      c.commission_rate,
      c.purchase_number,
      p.name as product_name,
      o.customer_email,
      o.amount as order_amount
     FROM commissions c
     JOIN orders o ON c.order_id = o.id
     JOIN products p ON o.product_id = p.id
     WHERE c.affiliate_id = ?
     ORDER BY c.created_at DESC`
  ).bind(affiliate.id).all();
  
  return c.json(results);
});

// Get affiliate withdrawal requests
app.get("/api/affiliate/withdrawal-requests", authMiddleware, async (c) => {
  const user = c.get("user");
  
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }
  
  const affiliate = await c.env.DB.prepare(
    "SELECT * FROM affiliates WHERE user_id = ? AND status = 'active'"
  ).bind(user.id).first();
  
  if (!affiliate) {
    return c.json({ error: "Not an affiliate" }, 404);
  }
  
  const { results } = await c.env.DB.prepare(
    `SELECT * FROM withdrawal_requests 
     WHERE affiliate_id = ?
     ORDER BY created_at DESC`
  ).bind(affiliate.id).all();
  
  return c.json(results);
});

// Get user's affiliate request status
app.get("/api/affiliate-requests/my-status", authMiddleware, async (c) => {
  const user = c.get("user");
  
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }
  
  // Check if user has any affiliate request
  const request = await c.env.DB.prepare(
    "SELECT * FROM affiliate_requests WHERE user_id = ? ORDER BY created_at DESC LIMIT 1"
  ).bind(user.id).first();
  
  if (!request) {
    return c.json({ has_request: false, status: null, promo_code: null });
  }
  
  return c.json({
    has_request: true,
    status: request.status,
    promo_code: request.promo_code,
    created_at: request.created_at
  });
});

// Submit affiliate request
app.post("/api/affiliate-requests", authMiddleware, async (c) => {
  const user = c.get("user");
  
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }
  
  const body = await c.req.json();
  
  // Check if user already has an affiliate request
  const existingRequest = await c.env.DB.prepare(
    "SELECT * FROM affiliate_requests WHERE user_id = ? AND status = 'pending'"
  ).bind(user.id).first();
  
  if (existingRequest) {
    return c.json({ error: "Vous avez déjà une demande en attente" }, 400);
  }
  
  // Check if user is already an affiliate
  const existingAffiliate = await c.env.DB.prepare(
    "SELECT * FROM affiliates WHERE user_id = ?"
  ).bind(user.id).first();
  
  if (existingAffiliate) {
    return c.json({ error: "Vous êtes déjà affilié" }, 400);
  }
  
  // Check if promo code is already taken
  const existingPromo = await c.env.DB.prepare(
    "SELECT * FROM affiliates WHERE promo_code = ?"
  ).bind(body.promo_code).first();
  
  if (existingPromo) {
    return c.json({ error: "Ce code promo est déjà utilisé" }, 400);
  }
  
  const existingPromoRequest = await c.env.DB.prepare(
    "SELECT * FROM affiliate_requests WHERE promo_code = ? AND status = 'pending'"
  ).bind(body.promo_code).first();
  
  if (existingPromoRequest) {
    return c.json({ error: "Ce code promo est déjà demandé" }, 400);
  }
  
  // Create affiliate request
  const result = await c.env.DB.prepare(
    `INSERT INTO affiliate_requests (
      user_id, promo_code, specialty, audience_size, social_links,
      motivation, payment_method, payment_phone_number, status
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending')`
  ).bind(
    user.id,
    body.promo_code,
    body.specialty || null,
    body.audience_size || null,
    body.social_links || null,
    body.motivation || null,
    body.payment_method || null,
    body.payment_phone_number || null
  ).run();
  
  const request = await c.env.DB.prepare(
    "SELECT * FROM affiliate_requests WHERE id = ?"
  ).bind(result.meta.last_row_id).first();
  
  return c.json(request, 201);
});

// ============================================================================
// Admin routes
// ============================================================================

// Admin middleware
const adminMiddleware = async (c: any, next: any) => {
  const mochaUser = c.get("user");
  
  if (!mochaUser) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  // Check by email instead of ID to handle Mocha authentication properly
  const userResult = await c.env.DB.prepare(
    "SELECT * FROM users WHERE email = ? AND role = 'admin'"
  ).bind(mochaUser.email).first();

  if (!userResult) {
    return c.json({ 
      error: "Forbidden - Admin access required",
      debug: {
        email: mochaUser.email,
        message: "Veuillez contacter un super administrateur pour obtenir l'accès"
      }
    }, 403);
  }

  // Store the local user data in context for later use
  c.set("localUser", userResult);

  await next();
};

// Get all orders (admin)
app.get("/api/admin/orders", authMiddleware, adminMiddleware, async (c) => {
  const status = c.req.query("status");
  
  let query = `SELECT o.*, p.name as product_name, p.category as product_category
               FROM orders o
               JOIN products p ON o.product_id = p.id`;
  const params: any[] = [];
  
  if (status) {
    query += " WHERE o.status = ?";
    params.push(status);
  }
  
  query += " ORDER BY o.created_at DESC";
  
  const { results } = await c.env.DB.prepare(query).bind(...params).all();
  
  return c.json(results);
});

// Update order status and deliver (admin)
app.put("/api/admin/orders/:id", authMiddleware, adminMiddleware, async (c) => {
  const id = c.req.param("id");
  const body = await c.req.json();
  
  const order = await c.env.DB.prepare(
    "SELECT * FROM orders WHERE id = ?"
  ).bind(id).first();
  
  if (!order) {
    return c.json({ error: "Order not found" }, 404);
  }
  
  // Update order status
  let updateQuery = "UPDATE orders SET status = ?, updated_at = CURRENT_TIMESTAMP";
  const params: any[] = [body.status];
  
  // If delivering, try to auto-assign credentials from inventory
  if (body.status === 'delivered' && !body.access_credentials) {
    const inventoryItem = await c.env.DB.prepare(
      "SELECT * FROM inventory WHERE product_id = ? AND is_used = 0 LIMIT 1"
    ).bind(order.product_id).first();
    
    if (inventoryItem) {
      body.access_credentials = inventoryItem.access_credentials;
      
      // Mark inventory item as used
      await c.env.DB.prepare(
        "UPDATE inventory SET is_used = 1, order_id = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?"
      ).bind(id, inventoryItem.id).run();
    }
  }
  
  if (body.access_credentials) {
    updateQuery += ", access_credentials = ?";
    params.push(body.access_credentials);
  }
  
  updateQuery += " WHERE id = ?";
  params.push(id);
  
  await c.env.DB.prepare(updateQuery).bind(...params).run();
  
  // If order is delivered, create or update subscription
  if (body.status === 'delivered') {
    // Get product to fetch usage instructions
    const product = await c.env.DB.prepare(
      "SELECT usage_instructions FROM products WHERE id = ?"
    ).bind(order.product_id).first();
    
    // Check if subscription already exists
    const existingSubscription = await c.env.DB.prepare(
      "SELECT * FROM subscriptions WHERE order_id = ?"
    ).bind(id).first();
    
    if (!existingSubscription) {
      // Calculate expiry date based on duration
      let expiresAt = null;
      if (order.duration_months) {
        const expiryDate = new Date();
        expiryDate.setMonth(expiryDate.getMonth() + Number(order.duration_months));
        expiresAt = expiryDate.toISOString();
      }
      
      // Get user_id from email if user exists
      const user = await c.env.DB.prepare(
        "SELECT id FROM users WHERE email = ?"
      ).bind(order.customer_email).first();
      
      // Create subscription with usage instructions in access_credentials if provided
      let accessCredentials = body.access_credentials || '';
      if (product && product.usage_instructions) {
        accessCredentials = `${accessCredentials}\n\nInstructions d'utilisation:\n${product.usage_instructions}`;
      }
      
      await c.env.DB.prepare(
        `INSERT INTO subscriptions (
          order_id, user_id, product_id, access_credentials, expires_at, is_active
        ) VALUES (?, ?, ?, ?, ?, 1)`
      ).bind(
        id,
        user ? user.id : null,
        order.product_id,
        accessCredentials,
        expiresAt
      ).run();
    } else {
      // Update existing subscription with new credentials and instructions
      let accessCredentials = body.access_credentials || existingSubscription.access_credentials || '';
      const product = await c.env.DB.prepare(
        "SELECT usage_instructions FROM products WHERE id = ?"
      ).bind(order.product_id).first();
      
      if (product && product.usage_instructions && !accessCredentials.includes('Instructions d\'utilisation:')) {
        accessCredentials = `${accessCredentials}\n\nInstructions d'utilisation:\n${product.usage_instructions}`;
      }
      
      await c.env.DB.prepare(
        "UPDATE subscriptions SET access_credentials = ?, is_active = 1, updated_at = CURRENT_TIMESTAMP WHERE order_id = ?"
      ).bind(accessCredentials, id).run();
    }
  }
  
  // If order is marked as paid, create commission if affiliate exists
  if (body.status === 'paid' && order.affiliate_id && Number(order.affiliate_commission) > 0) {
    // Check if commission already exists
    const existingCommission = await c.env.DB.prepare(
      "SELECT * FROM commissions WHERE order_id = ?"
    ).bind(id).first();
    
    if (!existingCommission) {
      // Get purchase number for this customer-affiliate combination
      const history = await c.env.DB.prepare(
        "SELECT total_purchases FROM customer_purchase_history WHERE customer_email = ? AND affiliate_id = ?"
      ).bind(order.customer_email, order.affiliate_id).first();
      
      const purchaseNumber = history ? Number(history.total_purchases) : 1;
      
      // Get product to calculate commission rate
      const product = await c.env.DB.prepare(
        "SELECT affiliate_commission_rate FROM products WHERE id = ?"
      ).bind(order.product_id).first();
      
      const baseCommissionRate = product ? Number(product.affiliate_commission_rate) : 0;
      
      // Calculate actual commission rate based on purchase number
      let actualCommissionRate = 0;
      if (purchaseNumber === 1) {
        actualCommissionRate = baseCommissionRate;
      } else if (purchaseNumber === 2) {
        actualCommissionRate = baseCommissionRate / 2;
      } else {
        actualCommissionRate = 0.05; // 5% for 3rd+ purchases
      }
      
      // Create commission record with purchase number and rate
      await c.env.DB.prepare(
        "INSERT INTO commissions (order_id, affiliate_id, amount, status, purchase_number, commission_rate) VALUES (?, ?, ?, 'pending', ?, ?)"
      ).bind(id, order.affiliate_id, order.affiliate_commission, purchaseNumber, actualCommissionRate).run();
      
      // Update affiliate stats
      await c.env.DB.prepare(
        `UPDATE affiliates SET 
         total_sales = total_sales + 1,
         total_commissions = total_commissions + ?,
         balance = balance + ?,
         updated_at = CURRENT_TIMESTAMP
         WHERE id = ?`
      ).bind(order.affiliate_commission, order.affiliate_commission, order.affiliate_id).run();
    }
  }
  
  const updatedOrder = await c.env.DB.prepare(
    "SELECT * FROM orders WHERE id = ?"
  ).bind(id).first();
  
  return c.json(updatedOrder);
});

// Get all affiliate requests (admin)
app.get("/api/admin/affiliate-requests", authMiddleware, adminMiddleware, async (c) => {
  const status = c.req.query("status");
  
  let query = `SELECT ar.*, u.email, u.full_name
               FROM affiliate_requests ar
               JOIN users u ON ar.user_id = u.id`;
  const params: any[] = [];
  
  if (status) {
    query += " WHERE ar.status = ?";
    params.push(status);
  }
  
  query += " ORDER BY ar.created_at DESC";
  
  const { results } = await c.env.DB.prepare(query).bind(...params).all();
  
  return c.json(results);
});

// Approve affiliate request (admin)
app.post("/api/admin/affiliate-requests/:id/approve", authMiddleware, adminMiddleware, async (c) => {
  const id = c.req.param("id");
  const body = await c.req.json();
  const adminUser = c.get("user");
  
  if (!adminUser) {
    return c.json({ error: "Unauthorized" }, 401);
  }
  
  const request = await c.env.DB.prepare(
    "SELECT * FROM affiliate_requests WHERE id = ?"
  ).bind(id).first();
  
  if (!request) {
    return c.json({ error: "Affiliate request not found" }, 404);
  }
  
  if (request.status !== 'pending') {
    return c.json({ error: "Request already processed" }, 400);
  }
  
  // Check if affiliate already exists
  const existingAffiliate = await c.env.DB.prepare(
    "SELECT * FROM affiliates WHERE user_id = ?"
  ).bind(request.user_id).first();
  
  if (existingAffiliate) {
    return c.json({ error: "User is already an affiliate" }, 400);
  }
  
  // Create affiliate with welcome bonus
  await c.env.DB.prepare(
    `INSERT INTO affiliates (user_id, promo_code, status, balance, payment_phone_number, welcome_bonus_paid)
     VALUES (?, ?, 'active', 650, ?, 1)`
  ).bind(request.user_id, request.promo_code, request.payment_phone_number).run();
  
  // Update request status
  await c.env.DB.prepare(
    `UPDATE affiliate_requests SET 
     status = 'approved',
     reviewed_by = ?,
     reviewed_at = CURRENT_TIMESTAMP,
     admin_notes = ?,
     updated_at = CURRENT_TIMESTAMP
     WHERE id = ?`
  ).bind(adminUser.id, body.admin_notes || null, id).run();
  
  const updatedRequest = await c.env.DB.prepare(
    "SELECT * FROM affiliate_requests WHERE id = ?"
  ).bind(id).first();
  
  return c.json(updatedRequest);
});

// Reject affiliate request (admin)
app.post("/api/admin/affiliate-requests/:id/reject", authMiddleware, adminMiddleware, async (c) => {
  const id = c.req.param("id");
  const body = await c.req.json();
  const adminUser = c.get("user");
  
  if (!adminUser) {
    return c.json({ error: "Unauthorized" }, 401);
  }
  
  const request = await c.env.DB.prepare(
    "SELECT * FROM affiliate_requests WHERE id = ?"
  ).bind(id).first();
  
  if (!request) {
    return c.json({ error: "Affiliate request not found" }, 404);
  }
  
  if (request.status !== 'pending') {
    return c.json({ error: "Request already processed" }, 400);
  }
  
  await c.env.DB.prepare(
    `UPDATE affiliate_requests SET 
     status = 'rejected',
     reviewed_by = ?,
     reviewed_at = CURRENT_TIMESTAMP,
     admin_notes = ?,
     updated_at = CURRENT_TIMESTAMP
     WHERE id = ?`
  ).bind(adminUser.id, body.admin_notes || null, id).run();
  
  const updatedRequest = await c.env.DB.prepare(
    "SELECT * FROM affiliate_requests WHERE id = ?"
  ).bind(id).first();
  
  return c.json(updatedRequest);
});

// Get all affiliates (admin)
app.get("/api/admin/affiliates", authMiddleware, adminMiddleware, async (c) => {
  const { results } = await c.env.DB.prepare(
    `SELECT a.*, u.email, u.full_name
     FROM affiliates a
     JOIN users u ON a.user_id = u.id
     ORDER BY a.created_at DESC`
  ).all();
  
  return c.json(results);
});

// Add affiliate directly (admin)
app.post("/api/admin/affiliates", authMiddleware, adminMiddleware, async (c) => {
  const body = await c.req.json();
  
  // Check if promo code already exists
  const existingPromo = await c.env.DB.prepare(
    "SELECT * FROM affiliates WHERE promo_code = ?"
  ).bind(body.promo_code).first();
  
  if (existingPromo) {
    return c.json({ error: "Ce code promo est déjà utilisé" }, 400);
  }
  
  // Check if user exists, create if not
  let user = await c.env.DB.prepare(
    "SELECT * FROM users WHERE email = ?"
  ).bind(body.email).first();
  
  if (!user) {
    // Create user record that will work with Mocha auth
    // Use email as a temporary ID - user will need to connect via Google OAuth to activate
    const userId = `pending_${body.email.replace(/[^a-zA-Z0-9]/g, '_')}`;
    
    await c.env.DB.prepare(
      `INSERT INTO users (id, email, role, affiliate_status, affiliate_code, is_active, has_completed_onboarding)
       VALUES (?, ?, 'user', 'approved', ?, 1, 0)`
    ).bind(userId, body.email, body.promo_code).run();
    
    user = await c.env.DB.prepare(
      "SELECT * FROM users WHERE id = ?"
    ).bind(userId).first();
  } else {
    // Update existing user to affiliate status
    await c.env.DB.prepare(
      `UPDATE users SET affiliate_status = 'approved', affiliate_code = ? WHERE id = ?`
    ).bind(body.promo_code, user.id).run();
  }
  
  if (!user) {
    return c.json({ error: "Failed to create user" }, 500);
  }
  
  // Create affiliate with welcome bonus
  const result = await c.env.DB.prepare(
    `INSERT INTO affiliates (user_id, promo_code, status, balance, welcome_bonus_paid)
     VALUES (?, ?, 'active', 650, 1)`
  ).bind(user.id, body.promo_code).run();
  
  const affiliate = await c.env.DB.prepare(
    "SELECT * FROM affiliates WHERE id = ?"
  ).bind(result.meta.last_row_id).first();
  
  return c.json({ 
    ...affiliate, 
    message: "Affilié créé avec succès. Les commissions sont gérées au niveau de chaque produit.",
    referral_link: `${c.req.url.split('/api')[0]}/?ref=${body.promo_code}`
  }, 201);
});

// Get withdrawal requests (admin)
app.get("/api/admin/withdrawal-requests", authMiddleware, adminMiddleware, async (c) => {
  const status = c.req.query("status");
  
  let query = `SELECT wr.*, a.promo_code, u.email as affiliate_email, u.full_name as affiliate_name,
               u.payment_method, u.payment_account_number as payment_details
               FROM withdrawal_requests wr
               JOIN affiliates a ON wr.affiliate_id = a.id
               JOIN users u ON a.user_id = u.id`;
  const params: any[] = [];
  
  if (status && status !== "all") {
    query += " WHERE wr.status = ?";
    params.push(status);
  }
  
  query += " ORDER BY wr.created_at DESC";
  
  const { results } = await c.env.DB.prepare(query).bind(...params).all();
  
  return c.json(results);
});

// Update withdrawal request status (admin)
app.put("/api/admin/withdrawal-requests/:id", authMiddleware, adminMiddleware, async (c) => {
  const id = c.req.param("id");
  const body = await c.req.json();
  
  const request = await c.env.DB.prepare(
    "SELECT * FROM withdrawal_requests WHERE id = ?"
  ).bind(id).first();
  
  if (!request) {
    return c.json({ error: "Withdrawal request not found" }, 404);
  }
  
  // Update request status
  await c.env.DB.prepare(
    `UPDATE withdrawal_requests SET 
     status = ?,
     processed_at = CURRENT_TIMESTAMP,
     updated_at = CURRENT_TIMESTAMP
     WHERE id = ?`
  ).bind(body.status, id).run();
  
  // If completed, deduct from affiliate balance
  if (body.status === "completed") {
    await c.env.DB.prepare(
      `UPDATE affiliates SET 
       balance = balance - ?,
       updated_at = CURRENT_TIMESTAMP
       WHERE id = ?`
    ).bind(request.amount, request.affiliate_id).run();
  }
  
  const updatedRequest = await c.env.DB.prepare(
    "SELECT * FROM withdrawal_requests WHERE id = ?"
  ).bind(id).first();
  
  return c.json(updatedRequest);
});

// Create withdrawal request (affiliate)
app.post("/api/affiliate/withdrawal-requests", authMiddleware, async (c) => {
  const user = c.get("user");
  
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }
  
  const body = await c.req.json();
  
  // Get affiliate
  const affiliate = await c.env.DB.prepare(
    "SELECT * FROM affiliates WHERE user_id = ? AND status = 'active'"
  ).bind(user.id).first();
  
  if (!affiliate) {
    return c.json({ error: "Not an affiliate" }, 404);
  }
  
  // Check minimum withdrawal amount (2000F total balance required)
  if (Number(affiliate.balance) < 2000) {
    return c.json({ error: "Solde insuffisant. Minimum requis: 2000 FCFA" }, 400);
  }
  
  // Check withdrawal amount is valid
  if (body.amount < 2000) {
    return c.json({ error: "Le montant minimum de retrait est de 2000 FCFA" }, 400);
  }
  
  // Check balance
  if (Number(affiliate.balance) < body.amount) {
    return c.json({ error: "Solde insuffisant" }, 400);
  }
  
  // Create withdrawal request
  const result = await c.env.DB.prepare(
    `INSERT INTO withdrawal_requests (affiliate_id, amount, payment_method, payment_details, status)
     VALUES (?, ?, ?, ?, 'pending')`
  ).bind(affiliate.id, body.amount, body.payment_method, body.payment_details).run();
  
  const request = await c.env.DB.prepare(
    "SELECT * FROM withdrawal_requests WHERE id = ?"
  ).bind(result.meta.last_row_id).first();
  
  return c.json(request, 201);
});

// Add inventory items (admin)
app.post("/api/admin/inventory", authMiddleware, adminMiddleware, async (c) => {
  const body = await c.req.json();
  
  const result = await c.env.DB.prepare(
    "INSERT INTO inventory (product_id, access_credentials) VALUES (?, ?)"
  ).bind(body.product_id, body.access_credentials).run();
  
  const item = await c.env.DB.prepare(
    "SELECT * FROM inventory WHERE id = ?"
  ).bind(result.meta.last_row_id).first();
  
  return c.json(item, 201);
});

// Get inventory for a product (admin)
app.get("/api/admin/inventory/:productId", authMiddleware, adminMiddleware, async (c) => {
  const productId = c.req.param("productId");
  
  const { results } = await c.env.DB.prepare(
    "SELECT * FROM inventory WHERE product_id = ? ORDER BY is_used ASC, created_at DESC"
  ).bind(productId).all();
  
  const available = results.filter((item: any) => item.is_used === 0).length;
  const used = results.filter((item: any) => item.is_used === 1).length;
  
  return c.json({
    items: results,
    stats: {
      total: results.length,
      available,
      used,
    },
  });
});

// Get payment gateways configuration
app.get("/api/payment-gateways", async (c) => {
  const { results } = await c.env.DB.prepare(
    "SELECT * FROM payment_gateways ORDER BY id"
  ).all();
  
  return c.json(results);
});

// Update payment gateway status (admin)
app.put("/api/admin/payment-gateways/:id", authMiddleware, adminMiddleware, async (c) => {
  const id = c.req.param("id");
  const body = await c.req.json();
  
  await c.env.DB.prepare(
    "UPDATE payment_gateways SET is_enabled = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?"
  ).bind(body.is_enabled ? 1 : 0, id).run();
  
  const gateway = await c.env.DB.prepare(
    "SELECT * FROM payment_gateways WHERE id = ?"
  ).bind(id).first();
  
  return c.json(gateway);
});

// Get all products (admin)
app.get("/api/admin/products", authMiddleware, adminMiddleware, async (c) => {
  const category = c.req.query("category");
  
  let query = "SELECT * FROM products";
  const params: any[] = [];
  
  if (category) {
    query += " WHERE category = ?";
    params.push(category);
  }
  
  query += " ORDER BY created_at DESC";
  
  const { results } = await c.env.DB.prepare(query).bind(...params).all();
  
  return c.json(results);
});

// Create product (admin)
app.post("/api/admin/products", authMiddleware, adminMiddleware, async (c) => {
  const body = await c.req.json();
  
  const result = await c.env.DB.prepare(
    `INSERT INTO products (
      name, description, category, service, price_1_months, price_3_months,
      price_6_months, price_options, client_discount_rate, affiliate_commission_rate,
      features, image_url, download_url, usage_instructions, is_active, stock
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).bind(
    body.name,
    body.description || null,
    body.category,
    body.service || null,
    body.price_1_months || null,
    body.price_3_months || null,
    body.price_6_months || null,
    body.price_options || null,
    body.client_discount_rate || 0,
    body.affiliate_commission_rate || 0,
    body.features || null,
    body.image_url || null,
    body.download_url || null,
    body.usage_instructions || null,
    body.is_active !== undefined ? body.is_active : 1,
    body.stock || null
  ).run();
  
  const product = await c.env.DB.prepare(
    "SELECT * FROM products WHERE id = ?"
  ).bind(result.meta.last_row_id).first();
  
  return c.json(product, 201);
});

// Update product (admin)
app.put("/api/admin/products/:id", authMiddleware, adminMiddleware, async (c) => {
  const id = c.req.param("id");
  const body = await c.req.json();
  
  await c.env.DB.prepare(
    `UPDATE products SET
     name = ?, description = ?, category = ?, service = ?,
     price_1_months = ?, price_3_months = ?, price_6_months = ?, price_options = ?,
     client_discount_rate = ?, affiliate_commission_rate = ?,
     features = ?, image_url = ?, download_url = ?, usage_instructions = ?, is_active = ?, stock = ?,
     updated_at = CURRENT_TIMESTAMP
     WHERE id = ?`
  ).bind(
    body.name,
    body.description || null,
    body.category,
    body.service || null,
    body.price_1_months || null,
    body.price_3_months || null,
    body.price_6_months || null,
    body.price_options || null,
    body.client_discount_rate || 0,
    body.affiliate_commission_rate || 0,
    body.features || null,
    body.image_url || null,
    body.download_url || null,
    body.usage_instructions || null,
    body.is_active !== undefined ? body.is_active : 1,
    body.stock || null,
    id
  ).run();
  
  const product = await c.env.DB.prepare(
    "SELECT * FROM products WHERE id = ?"
  ).bind(id).first();
  
  return c.json(product);
});

// Delete product (admin)
app.delete("/api/admin/products/:id", authMiddleware, adminMiddleware, async (c) => {
  const id = c.req.param("id");
  
  await c.env.DB.prepare(
    "DELETE FROM products WHERE id = ?"
  ).bind(id).run();
  
  return c.json({ success: true });
});

// Upload product image (admin)
app.post("/api/admin/upload-image", authMiddleware, adminMiddleware, async (c) => {
  try {
    const formData = await c.req.formData();
    const file = formData.get("image") as File;
    
    if (!file) {
      return c.json({ error: "No file provided" }, 400);
    }
    
    // Generate unique filename
    const timestamp = Date.now();
    const randomString = Math.random().toString(36).substring(2, 15);
    const extension = file.name.split('.').pop() || 'jpg';
    const key = `products/${timestamp}_${randomString}.${extension}`;
    
    // Upload to R2
    await c.env.R2_BUCKET.put(key, file.stream(), {
      httpMetadata: {
        contentType: file.type,
      },
    });
    
    // Return the key/URL
    return c.json({ 
      success: true,
      key,
      url: `/api/images/${key}`
    });
  } catch (error) {
    console.error("Upload error:", error);
    return c.json({ error: "Failed to upload image" }, 500);
  }
});

// Upload pack file (admin) - PDF, DOCX, ZIP up to 10MB
app.post("/api/admin/upload-file", authMiddleware, adminMiddleware, async (c) => {
  try {
    const formData = await c.req.formData();
    const file = formData.get("file") as File;
    
    if (!file) {
      return c.json({ error: "No file provided" }, 400);
    }
    
    // Check file size (10MB max)
    const maxSize = 10 * 1024 * 1024; // 10MB in bytes
    if (file.size > maxSize) {
      return c.json({ error: "File too large. Maximum size is 10MB" }, 400);
    }
    
    // Validate file type
    const allowedTypes = [
      'application/pdf',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'application/msword',
      'application/zip',
      'application/x-zip-compressed'
    ];
    
    if (!allowedTypes.includes(file.type)) {
      return c.json({ error: "Invalid file type. Only PDF, DOCX, and ZIP files are allowed" }, 400);
    }
    
    // Generate unique filename
    const timestamp = Date.now();
    const randomString = Math.random().toString(36).substring(2, 15);
    const extension = file.name.split('.').pop() || 'pdf';
    const key = `packs/${timestamp}_${randomString}.${extension}`;
    
    // Upload to R2
    await c.env.R2_BUCKET.put(key, file.stream(), {
      httpMetadata: {
        contentType: file.type,
      },
    });
    
    // Return the key/URL and file info
    return c.json({ 
      success: true,
      key,
      url: `/api/files/${key}`,
      size: file.size,
      type: file.type,
      originalName: file.name
    });
  } catch (error) {
    console.error("Upload error:", error);
    return c.json({ error: "Failed to upload file" }, 500);
  }
});

// Serve images from R2
app.get("/api/images/*", async (c) => {
  const key = c.req.path.replace("/api/images/", "");
  
  try {
    const object = await c.env.R2_BUCKET.get(key);
    
    if (!object) {
      return c.json({ error: "Image not found" }, 404);
    }
    
    const headers = new Headers();
    object.writeHttpMetadata(headers);
    headers.set("etag", object.httpEtag);
    headers.set("cache-control", "public, max-age=31536000");
    
    return c.body(object.body, { headers });
  } catch (error) {
    console.error("Error serving image:", error);
    return c.json({ error: "Failed to serve image" }, 500);
  }
});

// Serve files from R2 (packs, resources)
app.get("/api/files/*", async (c) => {
  const key = c.req.path.replace("/api/files/", "");
  
  try {
    const object = await c.env.R2_BUCKET.get(key);
    
    if (!object) {
      return c.json({ error: "File not found" }, 404);
    }
    
    const headers = new Headers();
    object.writeHttpMetadata(headers);
    headers.set("etag", object.httpEtag);
    headers.set("cache-control", "public, max-age=31536000");
    
    // Set content-disposition to trigger download
    const filename = key.split('/').pop() || 'download';
    headers.set("content-disposition", `attachment; filename="${filename}"`);
    
    return c.body(object.body, { headers });
  } catch (error) {
    console.error("Error serving file:", error);
    return c.json({ error: "Failed to serve file" }, 500);
  }
});

// Get dashboard stats (admin)
app.get("/api/admin/stats", authMiddleware, adminMiddleware, async (c) => {
  const totalOrders = await c.env.DB.prepare(
    "SELECT COUNT(*) as count FROM orders"
  ).first();
  
  const pendingOrders = await c.env.DB.prepare(
    "SELECT COUNT(*) as count FROM orders WHERE status = 'pending'"
  ).first();
  
  const paidOrders = await c.env.DB.prepare(
    "SELECT COUNT(*) as count FROM orders WHERE status = 'paid'"
  ).first();
  
  const totalRevenue = await c.env.DB.prepare(
    "SELECT SUM(amount) as total FROM orders WHERE status IN ('paid', 'delivered')"
  ).first();
  
  const totalAffiliates = await c.env.DB.prepare(
    "SELECT COUNT(*) as count FROM affiliates WHERE status = 'active'"
  ).first();
  
  const pendingRequests = await c.env.DB.prepare(
    "SELECT COUNT(*) as count FROM affiliate_requests WHERE status = 'pending'"
  ).first();
  
  return c.json({
    orders: {
      total: Number(totalOrders?.count || 0),
      pending: Number(pendingOrders?.count || 0),
      paid: Number(paidOrders?.count || 0),
    },
    revenue: {
      total: Number(totalRevenue?.total || 0),
    },
    affiliates: {
      total: Number(totalAffiliates?.count || 0),
      pending_requests: Number(pendingRequests?.count || 0),
    },
  });
});

// Get all users (admin)
app.get("/api/admin/users", authMiddleware, adminMiddleware, async (c) => {
  const { results } = await c.env.DB.prepare(
    "SELECT * FROM users ORDER BY created_at DESC"
  ).all();
  
  return c.json(results);
});

// Update user (admin)
app.put("/api/admin/users/:id", authMiddleware, adminMiddleware, async (c) => {
  const id = c.req.param("id");
  const body = await c.req.json();
  
  // Update user
  await c.env.DB.prepare(
    `UPDATE users SET
     role = ?,
     role_type = ?,
     country = ?,
     affiliate_status = ?,
     affiliate_code = ?,
     affiliate_commission_rate = ?,
     payment_method = ?,
     payment_account_number = ?,
     payment_account_name = ?,
     is_active = ?,
     loyalty_tier = ?,
     updated_at = CURRENT_TIMESTAMP
     WHERE id = ?`
  ).bind(
    body.role,
    body.role_type || null,
    body.country || null,
    body.affiliate_status || null,
    body.affiliate_code || null,
    body.affiliate_commission_rate || null,
    body.payment_method || null,
    body.payment_account_number || null,
    body.payment_account_name || null,
    body.is_active !== undefined ? body.is_active : 1,
    body.loyalty_tier || null,
    id
  ).run();
  
  // CRITICAL: Synchronize with affiliates table if user is an affiliate
  const affiliate = await c.env.DB.prepare(
    "SELECT * FROM affiliates WHERE user_id = ?"
  ).bind(id).first();
  
  if (affiliate) {
    // Update affiliate promo_code if changed
    if (body.affiliate_code && body.affiliate_code !== affiliate.promo_code) {
      await c.env.DB.prepare(
        "UPDATE affiliates SET promo_code = ?, updated_at = CURRENT_TIMESTAMP WHERE user_id = ?"
      ).bind(body.affiliate_code, id).run();
      
      // Also update any exceptional promo codes that reference this affiliate
      await c.env.DB.prepare(
        "UPDATE exceptional_promo_codes SET code = ?, updated_at = CURRENT_TIMESTAMP WHERE affiliate_id = ? AND code = ?"
      ).bind(body.affiliate_code, affiliate.id, affiliate.promo_code).run();
    }
    
    // Update affiliate payment info if changed
    if (body.payment_method || body.payment_account_number) {
      await c.env.DB.prepare(
        `UPDATE affiliates SET 
         payment_phone_number = ?,
         updated_at = CURRENT_TIMESTAMP 
         WHERE user_id = ?`
      ).bind(body.payment_account_number || affiliate.payment_phone_number, id).run();
    }
    
    // Update affiliate status based on user affiliate_status
    let affiliateStatus = 'active';
    if (body.affiliate_status === 'rejected') {
      affiliateStatus = 'rejected';
    } else if (body.affiliate_status === 'pending') {
      affiliateStatus = 'pending';
    } else if (body.is_active === 0) {
      affiliateStatus = 'suspended';
    }
    
    await c.env.DB.prepare(
      "UPDATE affiliates SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE user_id = ?"
    ).bind(affiliateStatus, id).run();
  }
  
  const user = await c.env.DB.prepare(
    "SELECT * FROM users WHERE id = ?"
  ).bind(id).first();
  
  return c.json(user);
});

// Delete user (admin)
app.delete("/api/admin/users/:id", authMiddleware, adminMiddleware, async (c) => {
  const id = c.req.param("id");
  
  // Check if user exists
  const user = await c.env.DB.prepare(
    "SELECT * FROM users WHERE id = ?"
  ).bind(id).first();
  
  if (!user) {
    return c.json({ error: "User not found" }, 404);
  }
  
  try {
    // Check if user is an affiliate and delete from affiliates table first
    const affiliate = await c.env.DB.prepare(
      "SELECT * FROM affiliates WHERE user_id = ?"
    ).bind(id).first();
    
    if (affiliate) {
      // Delete related data for this affiliate
      // Delete withdrawal requests
      await c.env.DB.prepare(
        "DELETE FROM withdrawal_requests WHERE affiliate_id = ?"
      ).bind(affiliate.id).run();
      
      // Delete commissions
      await c.env.DB.prepare(
        "DELETE FROM commissions WHERE affiliate_id = ?"
      ).bind(affiliate.id).run();
      
      // Delete link clicks
      await c.env.DB.prepare(
        "DELETE FROM link_clicks WHERE affiliate_id = ?"
      ).bind(affiliate.id).run();
      
      // Delete customer purchase history
      await c.env.DB.prepare(
        "DELETE FROM customer_purchase_history WHERE affiliate_id = ?"
      ).bind(affiliate.id).run();
      
      // Delete exceptional promo codes
      await c.env.DB.prepare(
        "DELETE FROM exceptional_promo_codes WHERE affiliate_id = ?"
      ).bind(affiliate.id).run();
      
      // Delete affiliate
      await c.env.DB.prepare(
        "DELETE FROM affiliates WHERE user_id = ?"
      ).bind(id).run();
    }
    
    // Delete affiliate requests
    await c.env.DB.prepare(
      "DELETE FROM affiliate_requests WHERE user_id = ?"
    ).bind(id).run();
    
    // Delete subscriptions (only where user_id matches - allow null user_id to remain)
    await c.env.DB.prepare(
      "DELETE FROM subscriptions WHERE user_id = ?"
    ).bind(id).run();
    
    // Delete user
    await c.env.DB.prepare(
      "DELETE FROM users WHERE id = ?"
    ).bind(id).run();
    
    return c.json({ success: true });
  } catch (error) {
    console.error("Error deleting user:", error);
    return c.json({ 
      error: "Erreur lors de la suppression de l'utilisateur", 
      details: error instanceof Error ? error.message : String(error)
    }, 500);
  }
});

export default app;
