
DROP INDEX idx_order_action_logs_created_at;
DROP INDEX idx_order_action_logs_order_id;
DROP TABLE order_action_logs;

ALTER TABLE orders DROP COLUMN delivered_by;
ALTER TABLE orders DROP COLUMN delivered_at;
ALTER TABLE orders DROP COLUMN payment_gateway;
ALTER TABLE orders DROP COLUMN transaction_details;
