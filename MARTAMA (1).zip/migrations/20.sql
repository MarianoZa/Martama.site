
-- Add welcome bonus tracking to affiliates table
ALTER TABLE affiliates ADD COLUMN welcome_bonus_paid BOOLEAN DEFAULT 0;
ALTER TABLE affiliates ADD COLUMN payment_phone_number TEXT;

-- Add payment info to affiliate_requests
ALTER TABLE affiliate_requests ADD COLUMN payment_phone_number TEXT;
