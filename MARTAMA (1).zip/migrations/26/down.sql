
DROP INDEX idx_certificates_user;
DROP INDEX idx_lesson_resources_video;
DROP INDEX idx_lesson_progress_user;
DROP TABLE course_certificates;
DROP TABLE lesson_progress;
DROP TABLE lesson_resources;
