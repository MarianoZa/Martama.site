
ALTER TABLE products DROP COLUMN drip_interval_days;
ALTER TABLE products DROP COLUMN drip_content;
ALTER TABLE products DROP COLUMN access_duration;
ALTER TABLE products DROP COLUMN content_type;
ALTER TABLE formation_videos DROP COLUMN description;
