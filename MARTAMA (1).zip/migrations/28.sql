
CREATE TABLE academy_classes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  description TEXT,
  image_url TEXT,
  instructor_name TEXT,
  category TEXT,
  max_members INTEGER,
  current_members INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT 1,
  start_date DATE,
  end_date DATE,
  meeting_schedule TEXT,
  requirements TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE academy_class_requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  class_id INTEGER NOT NULL,
  user_email TEXT NOT NULL,
  user_name TEXT,
  user_phone TEXT,
  motivation TEXT,
  status TEXT DEFAULT 'pending',
  admin_notes TEXT,
  reviewed_by TEXT,
  reviewed_at DATETIME,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (class_id) REFERENCES academy_classes(id) ON DELETE CASCADE
);

CREATE TABLE academy_class_members (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  class_id INTEGER NOT NULL,
  user_email TEXT NOT NULL,
  joined_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  is_active BOOLEAN DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (class_id) REFERENCES academy_classes(id) ON DELETE CASCADE
);

CREATE INDEX idx_academy_class_requests_class_id ON academy_class_requests(class_id);
CREATE INDEX idx_academy_class_requests_user_email ON academy_class_requests(user_email);
CREATE INDEX idx_academy_class_requests_status ON academy_class_requests(status);
CREATE INDEX idx_academy_class_members_class_id ON academy_class_members(class_id);
CREATE INDEX idx_academy_class_members_user_email ON academy_class_members(user_email);
