
DROP INDEX idx_academy_videos_class;
DROP INDEX idx_academy_videos_module;
DROP TABLE academy_videos;
DROP INDEX idx_academy_modules_class;
DROP TABLE academy_modules;
