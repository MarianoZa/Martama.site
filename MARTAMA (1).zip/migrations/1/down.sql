
DROP INDEX idx_subscriptions_is_active;
DROP INDEX idx_subscriptions_order_id;
DROP INDEX idx_subscriptions_user_id;
DROP TABLE subscriptions;

DROP INDEX idx_withdrawal_requests_status;
DROP INDEX idx_withdrawal_requests_affiliate_id;
DROP TABLE withdrawal_requests;

DROP INDEX idx_commissions_status;
DROP INDEX idx_commissions_affiliate_id;
DROP INDEX idx_commissions_order_id;
DROP TABLE commissions;

DROP INDEX idx_orders_created_at;
DROP INDEX idx_orders_status;
DROP INDEX idx_orders_affiliate_id;
DROP INDEX idx_orders_customer_email;
DROP TABLE orders;

DROP INDEX idx_link_clicks_created_at;
DROP INDEX idx_link_clicks_product_id;
DROP INDEX idx_link_clicks_affiliate_id;
DROP TABLE link_clicks;

DROP INDEX idx_affiliates_status;
DROP INDEX idx_affiliates_promo_code;
DROP INDEX idx_affiliates_user_id;
DROP TABLE affiliates;

DROP INDEX idx_products_is_active;
DROP INDEX idx_products_category;
DROP TABLE products;

DROP INDEX idx_users_role;
DROP INDEX idx_users_email;
DROP TABLE users;
