
-- Add bnb887991@gmail.com as admin
INSERT INTO users (id, email, full_name, role, has_completed_onboarding)
SELECT 'bnb887991_temp_id', 'bnb887991@gmail.com', 'BnB', 'admin', 1
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'bnb887991@gmail.com');
