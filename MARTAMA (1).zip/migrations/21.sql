
-- Add column to track if affiliate received welcome bonus
ALTER TABLE affiliates ADD COLUMN received_welcome_bonus BOOLEAN DEFAULT 0;

-- Give 650F welcome bonus to all existing affiliates
UPDATE affiliates SET balance = balance + 650, received_welcome_bonus = 1 WHERE received_welcome_bonus = 0;
