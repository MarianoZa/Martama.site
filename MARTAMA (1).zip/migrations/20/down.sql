
ALTER TABLE affiliate_requests DROP COLUMN payment_phone_number;
ALTER TABLE affiliates DROP COLUMN payment_phone_number;
ALTER TABLE affiliates DROP COLUMN welcome_bonus_paid;
