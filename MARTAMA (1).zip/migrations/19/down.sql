
DROP INDEX IF EXISTS idx_app_secrets_name;
DROP TABLE IF EXISTS app_secrets;
