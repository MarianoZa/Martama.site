
DROP INDEX idx_customer_affiliate;
DROP INDEX idx_customer_email;
DROP TABLE customer_purchase_history;
