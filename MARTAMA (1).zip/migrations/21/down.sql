
-- Remove welcome bonus from affiliates who received it
UPDATE affiliates SET balance = balance - 650 WHERE received_welcome_bonus = 1;

-- Drop the column
ALTER TABLE affiliates DROP COLUMN received_welcome_bonus;
