-- Add links/resources field to formation videos
ALTER TABLE formation_videos ADD COLUMN resources TEXT;

-- Add links/resources field to academy videos
ALTER TABLE academy_videos ADD COLUMN resources TEXT;

-- Create academy video comments table
CREATE TABLE academy_video_comments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  video_id INTEGER NOT NULL,
  user_email TEXT NOT NULL,
  comment TEXT NOT NULL,
  parent_comment_id INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (video_id) REFERENCES academy_videos(id) ON DELETE CASCADE,
  FOREIGN KEY (parent_comment_id) REFERENCES academy_video_comments(id) ON DELETE CASCADE
);

CREATE INDEX idx_academy_video_comments_video_id ON academy_video_comments(video_id);
CREATE INDEX idx_academy_video_comments_user_email ON academy_video_comments(user_email);
CREATE INDEX idx_academy_video_comments_parent ON academy_video_comments(parent_comment_id);