
DROP INDEX idx_formation_videos_module;
DROP INDEX idx_formation_modules_product;
DROP TABLE formation_videos;
DROP TABLE formation_modules;
