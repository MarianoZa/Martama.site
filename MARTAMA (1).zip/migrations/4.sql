
ALTER TABLE products ADD COLUMN download_url TEXT;
