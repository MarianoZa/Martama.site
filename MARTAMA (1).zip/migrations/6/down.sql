
-- Remove usage_instructions field from products table
ALTER TABLE products DROP COLUMN usage_instructions;
