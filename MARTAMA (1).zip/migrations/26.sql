
CREATE TABLE lesson_resources (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  video_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  resource_type TEXT NOT NULL,
  resource_url TEXT NOT NULL,
  file_size INTEGER,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (video_id) REFERENCES formation_videos(id) ON DELETE CASCADE
);

CREATE TABLE lesson_progress (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_email TEXT NOT NULL,
  product_id INTEGER NOT NULL,
  video_id INTEGER NOT NULL,
  is_completed BOOLEAN DEFAULT 0,
  watch_time_seconds INTEGER DEFAULT 0,
  completed_at DATETIME,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (product_id) REFERENCES products(id),
  FOREIGN KEY (video_id) REFERENCES formation_videos(id) ON DELETE CASCADE
);

CREATE TABLE course_certificates (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_email TEXT NOT NULL,
  product_id INTEGER NOT NULL,
  certificate_code TEXT NOT NULL UNIQUE,
  issued_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (product_id) REFERENCES products(id)
);

CREATE INDEX idx_lesson_progress_user ON lesson_progress(user_email, product_id);
CREATE INDEX idx_lesson_resources_video ON lesson_resources(video_id);
CREATE INDEX idx_certificates_user ON course_certificates(user_email, product_id);
