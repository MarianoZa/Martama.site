
ALTER TABLE products DROP COLUMN download_url;
