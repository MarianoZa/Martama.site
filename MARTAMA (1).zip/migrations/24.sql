
ALTER TABLE products ADD COLUMN file_url TEXT;
ALTER TABLE products ADD COLUMN file_size INTEGER;
ALTER TABLE products ADD COLUMN file_type TEXT;
ALTER TABLE products ADD COLUMN auto_delivery BOOLEAN DEFAULT 1;
