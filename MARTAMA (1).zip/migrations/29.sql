
CREATE TABLE academy_modules (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  class_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  display_order INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_academy_modules_class ON academy_modules(class_id);

CREATE TABLE academy_videos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  module_id INTEGER NOT NULL,
  class_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  video_type TEXT NOT NULL,
  video_url TEXT NOT NULL,
  aspect_ratio TEXT DEFAULT '16:9',
  duration_minutes INTEGER,
  display_order INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_academy_videos_module ON academy_videos(module_id);
CREATE INDEX idx_academy_videos_class ON academy_videos(class_id);
