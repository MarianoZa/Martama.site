
DROP INDEX idx_order_notifications_unread;
DROP TABLE order_notifications;
