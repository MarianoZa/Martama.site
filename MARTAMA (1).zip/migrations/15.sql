
CREATE TABLE payment_gateways (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  gateway_name TEXT NOT NULL UNIQUE,
  is_enabled BOOLEAN DEFAULT 0,
  display_name TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO payment_gateways (gateway_name, display_name, is_enabled) VALUES
  ('fedapay', 'FedaPay Checkout', 1),
  ('moneroo', 'Moneroo Checkout', 0),
  ('lygos', 'Liens Lygos', 0);
