
CREATE TABLE testimonials (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_name TEXT,
  screenshot_url TEXT NOT NULL,
  is_featured INTEGER DEFAULT 1,
  display_order INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_testimonials_featured ON testimonials(is_featured, display_order);
