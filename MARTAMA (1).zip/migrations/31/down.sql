
DROP INDEX idx_admin_activity_created_at;
DROP INDEX idx_admin_activity_admin_id;
DROP TABLE admin_activity_logs;
ALTER TABLE users DROP COLUMN admin_role;
