
DROP INDEX idx_webhook_events_event_id;
DROP TABLE webhook_events;
