
-- Remove price_options column
ALTER TABLE products DROP COLUMN price_options;
