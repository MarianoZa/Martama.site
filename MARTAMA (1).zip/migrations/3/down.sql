
-- Remove bnb887991@gmail.com admin
DELETE FROM users WHERE email = 'bnb887991@gmail.com' AND id = 'bnb887991_temp_id';
