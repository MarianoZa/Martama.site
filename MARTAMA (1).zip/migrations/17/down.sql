
DROP INDEX idx_testimonials_featured;
DROP TABLE testimonials;
