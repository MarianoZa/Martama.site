
ALTER TABLE products DROP COLUMN auto_delivery;
ALTER TABLE products DROP COLUMN file_type;
ALTER TABLE products DROP COLUMN file_size;
ALTER TABLE products DROP COLUMN file_url;
