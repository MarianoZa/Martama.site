
-- Add admin_role column to users table
ALTER TABLE users ADD COLUMN admin_role TEXT DEFAULT NULL;

-- Update existing admins to super_admin
UPDATE users SET admin_role = 'super_admin' WHERE role = 'admin';

-- Create admin_activity_logs table to track admin actions
CREATE TABLE admin_activity_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  admin_id TEXT NOT NULL,
  admin_email TEXT NOT NULL,
  admin_role TEXT NOT NULL,
  action_type TEXT NOT NULL,
  action_details TEXT,
  target_user_id TEXT,
  ip_address TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_admin_activity_admin_id ON admin_activity_logs(admin_id);
CREATE INDEX idx_admin_activity_created_at ON admin_activity_logs(created_at);
