
-- Table pour les codes promotionnels exceptionnels des affiliés
CREATE TABLE exceptional_promo_codes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  affiliate_id INTEGER NOT NULL,
  code TEXT NOT NULL UNIQUE,
  discount_rate REAL NOT NULL,
  commission_rate REAL NOT NULL,
  applies_to TEXT NOT NULL,
  target_ids TEXT,
  start_date DATETIME,
  end_date DATETIME,
  is_active INTEGER DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (affiliate_id) REFERENCES affiliates(id)
);

CREATE INDEX idx_exceptional_codes_code ON exceptional_promo_codes(code);
CREATE INDEX idx_exceptional_codes_active ON exceptional_promo_codes(is_active);
