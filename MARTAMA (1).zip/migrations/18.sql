
-- Ajouter des colonnes pour tracer les détails des actions sur les commandes
ALTER TABLE orders ADD COLUMN transaction_details TEXT;
ALTER TABLE orders ADD COLUMN payment_gateway TEXT;
ALTER TABLE orders ADD COLUMN delivered_at DATETIME;
ALTER TABLE orders ADD COLUMN delivered_by TEXT;

-- Ajouter une table pour l'historique des actions sur les commandes
CREATE TABLE order_action_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id INTEGER NOT NULL,
  action_type TEXT NOT NULL,
  action_details TEXT,
  performed_by TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (order_id) REFERENCES orders(id)
);

CREATE INDEX idx_order_action_logs_order_id ON order_action_logs(order_id);
CREATE INDEX idx_order_action_logs_created_at ON order_action_logs(created_at);
