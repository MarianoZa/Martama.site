
DROP INDEX idx_user_formations_product;
DROP INDEX idx_user_formations_user;
DROP TABLE user_formations;
