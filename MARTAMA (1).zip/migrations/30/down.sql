DROP INDEX idx_academy_video_comments_parent;
DROP INDEX idx_academy_video_comments_user_email;
DROP INDEX idx_academy_video_comments_video_id;
DROP TABLE academy_video_comments;

ALTER TABLE academy_videos DROP COLUMN resources;
ALTER TABLE formation_videos DROP COLUMN resources;