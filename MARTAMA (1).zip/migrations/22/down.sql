
DROP INDEX idx_blog_posts_published;
DROP INDEX idx_blog_posts_slug;
DROP TABLE blog_posts;
