
ALTER TABLE formation_videos ADD COLUMN description TEXT;
ALTER TABLE products ADD COLUMN content_type TEXT;
ALTER TABLE products ADD COLUMN access_duration TEXT;
ALTER TABLE products ADD COLUMN drip_content BOOLEAN DEFAULT 0;
ALTER TABLE products ADD COLUMN drip_interval_days INTEGER;
