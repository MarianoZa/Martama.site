
CREATE TABLE user_formations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_email TEXT NOT NULL,
  product_id INTEGER NOT NULL,
  order_id INTEGER NOT NULL,
  access_granted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  last_accessed_at DATETIME,
  progress_data TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (product_id) REFERENCES products(id),
  FOREIGN KEY (order_id) REFERENCES orders(id)
);

CREATE INDEX idx_user_formations_user ON user_formations(user_email);
CREATE INDEX idx_user_formations_product ON user_formations(product_id);
