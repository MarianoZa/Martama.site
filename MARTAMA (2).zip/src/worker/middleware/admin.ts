import { Context, Next } from "hono";

export const adminMiddleware = async (c: Context, next: Next) => {
  const mochaUser = c.get("user");
  
  if (!mochaUser) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  // Check if user is admin in our database
  const userResult = await c.env.DB.prepare(
    "SELECT * FROM users WHERE id = ? AND role = 'admin'"
  ).bind(mochaUser.id).first();

  if (!userResult) {
    return c.json({ error: "Forbidden - Admin access required" }, 403);
  }

  await next();
};
