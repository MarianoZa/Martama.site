import { Hono } from "hono";
import { authMiddleware } from "@getmocha/users-service/backend";

const app = new Hono<{ Bindings: Env }>();

// Get active announcement bar
app.get("/api/announcement", async (c) => {
  const announcement = await c.env.DB.prepare(
    "SELECT * FROM announcement_bar WHERE is_active = 1 ORDER BY created_at DESC LIMIT 1"
  ).first();
  
  if (!announcement) {
    return c.json({ active: false });
  }
  
  return c.json({
    active: true,
    message: announcement.message,
    promo_code: announcement.promo_code,
    link_url: announcement.link_url,
  });
});

// Admin: Get all announcements
app.get("/api/admin/announcements", authMiddleware, async (c) => {
  const mochaUser = c.get("user");
  if (!mochaUser) return c.json({ error: "Unauthorized" }, 401);
  
  const user = await c.env.DB.prepare(
    "SELECT * FROM users WHERE id = ? AND role = 'admin'"
  ).bind(mochaUser.id).first();
  
  if (!user) return c.json({ error: "Forbidden" }, 403);
  
  const { results } = await c.env.DB.prepare(
    "SELECT * FROM announcement_bar ORDER BY created_at DESC"
  ).all();
  
  return c.json(results);
});

// Admin: Update announcement
app.put("/api/admin/announcement/:id", authMiddleware, async (c) => {
  const mochaUser = c.get("user");
  if (!mochaUser) return c.json({ error: "Unauthorized" }, 401);
  
  const user = await c.env.DB.prepare(
    "SELECT * FROM users WHERE id = ? AND role = 'admin'"
  ).bind(mochaUser.id).first();
  
  if (!user) return c.json({ error: "Forbidden" }, 403);
  
  const id = c.req.param("id");
  const body = await c.req.json();
  
  await c.env.DB.prepare(
    `UPDATE announcement_bar SET
     message = ?,
     promo_code = ?,
     link_url = ?,
     is_active = ?,
     updated_at = CURRENT_TIMESTAMP
     WHERE id = ?`
  ).bind(
    body.message,
    body.promo_code || null,
    body.link_url || null,
    body.is_active ? 1 : 0,
    id
  ).run();
  
  const updated = await c.env.DB.prepare(
    "SELECT * FROM announcement_bar WHERE id = ?"
  ).bind(id).first();
  
  return c.json(updated);
});

// Admin: Create announcement
app.post("/api/admin/announcement", authMiddleware, async (c) => {
  const mochaUser = c.get("user");
  if (!mochaUser) return c.json({ error: "Unauthorized" }, 401);
  
  const user = await c.env.DB.prepare(
    "SELECT * FROM users WHERE id = ? AND role = 'admin'"
  ).bind(mochaUser.id).first();
  
  if (!user) return c.json({ error: "Forbidden" }, 403);
  
  const body = await c.req.json();
  
  // Deactivate all existing announcements if this one is active
  if (body.is_active) {
    await c.env.DB.prepare(
      "UPDATE announcement_bar SET is_active = 0"
    ).run();
  }
  
  const result = await c.env.DB.prepare(
    `INSERT INTO announcement_bar (message, promo_code, link_url, is_active)
     VALUES (?, ?, ?, ?)`
  ).bind(
    body.message,
    body.promo_code || null,
    body.link_url || null,
    body.is_active ? 1 : 0
  ).run();
  
  const announcement = await c.env.DB.prepare(
    "SELECT * FROM announcement_bar WHERE id = ?"
  ).bind(result.meta.last_row_id).first();
  
  return c.json(announcement, 201);
});

export default app;
