import { Hono } from "hono";
import { authMiddleware } from "@getmocha/users-service/backend";

const app = new Hono<{ Bindings: Env }>();

// Public: Get featured testimonials
app.get("/api/testimonials", async (c) => {
  const { results } = await c.env.DB.prepare(
    "SELECT * FROM testimonials WHERE is_featured = 1 ORDER BY display_order ASC, created_at DESC"
  ).all();
  
  return c.json(results);
});

// Admin: Get all testimonials
app.get("/api/admin/testimonials", authMiddleware, async (c) => {
  const mochaUser = c.get("user");
  if (!mochaUser) return c.json({ error: "Unauthorized" }, 401);
  
  const user = await c.env.DB.prepare(
    "SELECT * FROM users WHERE id = ? AND role = 'admin'"
  ).bind(mochaUser.id).first();
  
  if (!user) return c.json({ error: "Forbidden" }, 403);
  
  const { results } = await c.env.DB.prepare(
    "SELECT * FROM testimonials ORDER BY display_order ASC, created_at DESC"
  ).all();
  
  return c.json(results);
});

// Admin: Create testimonial
app.post("/api/admin/testimonials", authMiddleware, async (c) => {
  const mochaUser = c.get("user");
  if (!mochaUser) return c.json({ error: "Unauthorized" }, 401);
  
  const user = await c.env.DB.prepare(
    "SELECT * FROM users WHERE id = ? AND role = 'admin'"
  ).bind(mochaUser.id).first();
  
  if (!user) return c.json({ error: "Forbidden" }, 403);
  
  const body = await c.req.json();
  
  // Get the max display_order and increment
  const maxOrder = await c.env.DB.prepare(
    "SELECT MAX(display_order) as max_order FROM testimonials"
  ).first();
  
  const newOrder = (maxOrder?.max_order as number || 0) + 1;
  
  const result = await c.env.DB.prepare(
    `INSERT INTO testimonials (customer_name, screenshot_url, is_featured, display_order)
     VALUES (?, ?, ?, ?)`
  ).bind(
    body.customer_name || null,
    body.screenshot_url,
    body.is_featured ? 1 : 0,
    newOrder
  ).run();
  
  const testimonial = await c.env.DB.prepare(
    "SELECT * FROM testimonials WHERE id = ?"
  ).bind(result.meta.last_row_id).first();
  
  return c.json(testimonial, 201);
});

// Admin: Update testimonial
app.put("/api/admin/testimonials/:id", authMiddleware, async (c) => {
  const mochaUser = c.get("user");
  if (!mochaUser) return c.json({ error: "Unauthorized" }, 401);
  
  const user = await c.env.DB.prepare(
    "SELECT * FROM users WHERE id = ? AND role = 'admin'"
  ).bind(mochaUser.id).first();
  
  if (!user) return c.json({ error: "Forbidden" }, 403);
  
  const id = c.req.param("id");
  const body = await c.req.json();
  
  await c.env.DB.prepare(
    `UPDATE testimonials SET
     is_featured = ?,
     updated_at = CURRENT_TIMESTAMP
     WHERE id = ?`
  ).bind(
    body.is_featured !== undefined ? (body.is_featured ? 1 : 0) : undefined,
    id
  ).run();
  
  const updated = await c.env.DB.prepare(
    "SELECT * FROM testimonials WHERE id = ?"
  ).bind(id).first();
  
  return c.json(updated);
});

// Admin: Reorder testimonial
app.put("/api/admin/testimonials/:id/reorder", authMiddleware, async (c) => {
  const mochaUser = c.get("user");
  if (!mochaUser) return c.json({ error: "Unauthorized" }, 401);
  
  const user = await c.env.DB.prepare(
    "SELECT * FROM users WHERE id = ? AND role = 'admin'"
  ).bind(mochaUser.id).first();
  
  if (!user) return c.json({ error: "Forbidden" }, 403);
  
  const id = c.req.param("id");
  const body = await c.req.json();
  const newOrder = body.new_order;
  
  // Get current testimonial
  const current = await c.env.DB.prepare(
    "SELECT * FROM testimonials WHERE id = ?"
  ).bind(id).first();
  
  if (!current) {
    return c.json({ error: "Testimonial not found" }, 404);
  }
  
  const currentOrder = current.display_order as number;
  
  // Swap orders
  if (newOrder < currentOrder) {
    // Moving up - increment all items between new and current
    await c.env.DB.prepare(
      "UPDATE testimonials SET display_order = display_order + 1 WHERE display_order >= ? AND display_order < ?"
    ).bind(newOrder, currentOrder).run();
  } else {
    // Moving down - decrement all items between current and new
    await c.env.DB.prepare(
      "UPDATE testimonials SET display_order = display_order - 1 WHERE display_order > ? AND display_order <= ?"
    ).bind(currentOrder, newOrder).run();
  }
  
  // Set new order for current item
  await c.env.DB.prepare(
    "UPDATE testimonials SET display_order = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?"
  ).bind(newOrder, id).run();
  
  const updated = await c.env.DB.prepare(
    "SELECT * FROM testimonials WHERE id = ?"
  ).bind(id).first();
  
  return c.json(updated);
});

// Admin: Delete testimonial
app.delete("/api/admin/testimonials/:id", authMiddleware, async (c) => {
  const mochaUser = c.get("user");
  if (!mochaUser) return c.json({ error: "Unauthorized" }, 401);
  
  const user = await c.env.DB.prepare(
    "SELECT * FROM users WHERE id = ? AND role = 'admin'"
  ).bind(mochaUser.id).first();
  
  if (!user) return c.json({ error: "Forbidden" }, 403);
  
  const id = c.req.param("id");
  
  // Get the display_order of the item being deleted
  const testimonial = await c.env.DB.prepare(
    "SELECT display_order FROM testimonials WHERE id = ?"
  ).bind(id).first();
  
  if (testimonial) {
    // Delete the testimonial
    await c.env.DB.prepare(
      "DELETE FROM testimonials WHERE id = ?"
    ).bind(id).run();
    
    // Decrement display_order for all items after the deleted one
    await c.env.DB.prepare(
      "UPDATE testimonials SET display_order = display_order - 1 WHERE display_order > ?"
    ).bind(testimonial.display_order).run();
  }
  
  return c.json({ success: true });
});

export default app;
