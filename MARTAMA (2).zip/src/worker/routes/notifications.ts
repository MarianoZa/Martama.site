import { Hono } from "hono";
import { authMiddleware } from "@getmocha/users-service/backend";

const app = new Hono<{ Bindings: Env }>();

// Admin: Get unread order notifications count
app.get("/api/admin/notifications/unread-count", authMiddleware, async (c) => {
  const mochaUser = c.get("user");
  if (!mochaUser) return c.json({ error: "Unauthorized" }, 401);
  
  const user = await c.env.DB.prepare(
    "SELECT * FROM users WHERE id = ? AND role = 'admin'"
  ).bind(mochaUser.id).first();
  
  if (!user) return c.json({ error: "Forbidden" }, 403);
  
  const result = await c.env.DB.prepare(
    "SELECT COUNT(*) as count FROM order_notifications WHERE is_read = 0"
  ).first();
  
  return c.json({ count: result?.count || 0 });
});

// Admin: Get recent unread notifications
app.get("/api/admin/notifications/recent", authMiddleware, async (c) => {
  const mochaUser = c.get("user");
  if (!mochaUser) return c.json({ error: "Unauthorized" }, 401);
  
  const user = await c.env.DB.prepare(
    "SELECT * FROM users WHERE id = ? AND role = 'admin'"
  ).bind(mochaUser.id).first();
  
  if (!user) return c.json({ error: "Forbidden" }, 403);
  
  const { results } = await c.env.DB.prepare(
    `SELECT n.*, o.customer_email, o.amount, o.status, p.name as product_name
     FROM order_notifications n
     JOIN orders o ON n.order_id = o.id
     JOIN products p ON o.product_id = p.id
     WHERE n.is_read = 0
     ORDER BY n.created_at DESC
     LIMIT 10`
  ).all();
  
  return c.json(results);
});

// Admin: Mark notification as read
app.put("/api/admin/notifications/:id/read", authMiddleware, async (c) => {
  const mochaUser = c.get("user");
  if (!mochaUser) return c.json({ error: "Unauthorized" }, 401);
  
  const user = await c.env.DB.prepare(
    "SELECT * FROM users WHERE id = ? AND role = 'admin'"
  ).bind(mochaUser.id).first();
  
  if (!user) return c.json({ error: "Forbidden" }, 403);
  
  const id = c.req.param("id");
  
  await c.env.DB.prepare(
    "UPDATE order_notifications SET is_read = 1 WHERE id = ?"
  ).bind(id).run();
  
  return c.json({ success: true });
});

// Admin: Mark all notifications as read
app.put("/api/admin/notifications/read-all", authMiddleware, async (c) => {
  const mochaUser = c.get("user");
  if (!mochaUser) return c.json({ error: "Unauthorized" }, 401);
  
  const user = await c.env.DB.prepare(
    "SELECT * FROM users WHERE id = ? AND role = 'admin'"
  ).bind(mochaUser.id).first();
  
  if (!user) return c.json({ error: "Forbidden" }, 403);
  
  await c.env.DB.prepare(
    "UPDATE order_notifications SET is_read = 1 WHERE is_read = 0"
  ).run();
  
  return c.json({ success: true });
});

export default app;
