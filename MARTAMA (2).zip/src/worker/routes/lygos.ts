import { Hono } from "hono";

const app = new Hono<{ Bindings: Env }>();

// Lygos webhook endpoint
app.post("/api/lygos/webhook", async (c) => {
  try {
    const rawBody = await c.req.text();
    let event;
    
    try {
      event = JSON.parse(rawBody);
    } catch (e) {
      console.error("Invalid JSON payload from Lygos:", e);
      return c.json({ error: "Invalid payload" }, 400);
    }
    
    // Log the received webhook for debugging
    console.log("Lygos webhook received:", event);
    
    // Extract key information from Lygos webhook
    // Note: Adjust these field names based on actual Lygos webhook structure
    const eventId = event.id || event.transaction_id || `lygos_${Date.now()}`;
    const transactionId = event.transaction_id || event.id;
    const status = event.status || event.payment_status;
    const amount = event.amount || 0;
    const orderId = event.order_id || event.metadata?.order_id || event.custom_data?.order_id;
    
    // Check for duplicate webhook
    const existingWebhook = await c.env.DB.prepare(
      "SELECT id FROM lygos_webhooks WHERE event_id = ?"
    ).bind(eventId).first();
    
    if (existingWebhook) {
      console.log("Duplicate Lygos webhook ignored:", eventId);
      return c.json({ received: true, message: "Duplicate event" }, 200);
    }
    
    // Store webhook event
    await c.env.DB.prepare(
      `INSERT INTO lygos_webhooks (event_id, order_id, transaction_id, status, amount, raw_payload)
       VALUES (?, ?, ?, ?, ?, ?)`
    ).bind(eventId, orderId || null, transactionId, status, amount, rawBody).run();
    
    // Process webhook asynchronously
    c.executionCtx.waitUntil(processLygosWebhook(event, c.env));
    
    return c.json({ received: true }, 200);
  } catch (error) {
    console.error("Lygos webhook error:", error);
    return c.json({ received: true }, 200);
  }
});

async function processLygosWebhook(event: any, env: Env) {
  try {
    // Extract order ID and status
    const orderId = event.order_id || event.metadata?.order_id || event.custom_data?.order_id;
    const status = event.status || event.payment_status;
    const transactionId = event.transaction_id || event.id;
    
    if (!orderId) {
      console.error("No order ID found in Lygos webhook");
      return;
    }
    
    // Get order from database
    const order = await env.DB.prepare(
      "SELECT * FROM orders WHERE id = ?"
    ).bind(orderId).first();
    
    if (!order) {
      console.error("Order not found for Lygos webhook:", orderId);
      return;
    }
    
    // Map Lygos status to our order status
    let orderStatus = 'pending';
    
    // Adjust these status mappings based on actual Lygos webhook statuses
    if (status === 'completed' || status === 'success' || status === 'paid') {
      orderStatus = 'paid';
    } else if (status === 'failed' || status === 'cancelled' || status === 'declined') {
      orderStatus = 'cancelled';
    }
    
    // Update order status
    await env.DB.prepare(
      `UPDATE orders SET 
       status = ?,
       payment_reference = ?,
       payment_method = 'Lygos',
       updated_at = CURRENT_TIMESTAMP
       WHERE id = ?`
    ).bind(orderStatus, transactionId, orderId).run();
    
    // If payment successful, create user account if needed
    if (orderStatus === 'paid' && order.customer_email) {
      const existingUser = await env.DB.prepare(
        "SELECT * FROM users WHERE email = ?"
      ).bind(order.customer_email).first();
      
      if (!existingUser) {
        const userId = `user_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        await env.DB.prepare(
          `INSERT INTO users (id, email, role, has_completed_onboarding, is_active)
           VALUES (?, ?, 'user', 0, 1)`
        ).bind(userId, order.customer_email).run();
      }
      
      // Handle affiliate commission if applicable
      if (order.affiliate_id && Number(order.affiliate_commission) > 0) {
        const existingCommission = await env.DB.prepare(
          "SELECT * FROM commissions WHERE order_id = ?"
        ).bind(orderId).first();
        
        if (!existingCommission) {
          const history = await env.DB.prepare(
            "SELECT total_purchases FROM customer_purchase_history WHERE customer_email = ? AND affiliate_id = ?"
          ).bind(order.customer_email, order.affiliate_id).first();
          
          const purchaseNumber = history ? Number(history.total_purchases) : 1;
          
          const product = await env.DB.prepare(
            "SELECT affiliate_commission_rate FROM products WHERE id = ?"
          ).bind(order.product_id).first();
          
          const baseCommissionRate = product ? Number(product.affiliate_commission_rate) : 0;
          
          let actualCommissionRate = 0;
          if (purchaseNumber === 1) {
            actualCommissionRate = baseCommissionRate;
          } else if (purchaseNumber === 2) {
            actualCommissionRate = baseCommissionRate / 2;
          } else {
            actualCommissionRate = 0.05;
          }
          
          await env.DB.prepare(
            "INSERT INTO commissions (order_id, affiliate_id, amount, status, purchase_number, commission_rate) VALUES (?, ?, ?, 'pending', ?, ?)"
          ).bind(orderId, order.affiliate_id, order.affiliate_commission, purchaseNumber, actualCommissionRate).run();
          
          await env.DB.prepare(
            `UPDATE affiliates SET 
             total_sales = total_sales + 1,
             total_commissions = total_commissions + ?,
             balance = balance + ?,
             updated_at = CURRENT_TIMESTAMP
             WHERE id = ?`
          ).bind(order.affiliate_commission, order.affiliate_commission, order.affiliate_id).run();
        }
      }
    }
    
    // Mark webhook as processed
    await env.DB.prepare(
      "UPDATE lygos_webhooks SET processed = 1, updated_at = CURRENT_TIMESTAMP WHERE event_id = ?"
    ).bind(event.id || event.transaction_id).run();
    
    console.log("Lygos webhook processed successfully for order:", orderId);
  } catch (error) {
    console.error("Error processing Lygos webhook:", error);
  }
}

export default app;
