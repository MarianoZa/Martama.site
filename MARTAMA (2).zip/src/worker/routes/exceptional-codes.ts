import { Hono } from "hono";
import { authMiddleware } from "@getmocha/users-service/backend";

const app = new Hono<{ Bindings: Env }>();

// Admin: Get all exceptional codes
app.get("/api/admin/exceptional-codes", authMiddleware, async (c) => {
  const mochaUser = c.get("user");
  if (!mochaUser) return c.json({ error: "Unauthorized" }, 401);
  
  const user = await c.env.DB.prepare(
    "SELECT * FROM users WHERE id = ? AND role = 'admin'"
  ).bind(mochaUser.id).first();
  
  if (!user) return c.json({ error: "Forbidden" }, 403);
  
  const { results } = await c.env.DB.prepare(
    `SELECT ec.*, a.promo_code as affiliate_promo_code, u.email as affiliate_email
     FROM exceptional_promo_codes ec
     JOIN affiliates a ON ec.affiliate_id = a.id
     JOIN users u ON a.user_id = u.id
     ORDER BY ec.created_at DESC`
  ).all();
  
  return c.json(results);
});

// Admin: Create exceptional code
app.post("/api/admin/exceptional-codes", authMiddleware, async (c) => {
  const mochaUser = c.get("user");
  if (!mochaUser) return c.json({ error: "Unauthorized" }, 401);
  
  const user = await c.env.DB.prepare(
    "SELECT * FROM users WHERE id = ? AND role = 'admin'"
  ).bind(mochaUser.id).first();
  
  if (!user) return c.json({ error: "Forbidden" }, 403);
  
  const body = await c.req.json();
  
  // Check if code already exists
  const existingCode = await c.env.DB.prepare(
    "SELECT * FROM exceptional_promo_codes WHERE code = ?"
  ).bind(body.code).first();
  
  if (existingCode) {
    return c.json({ error: "Ce code existe déjà" }, 400);
  }
  
  const result = await c.env.DB.prepare(
    `INSERT INTO exceptional_promo_codes (
      affiliate_id, code, discount_rate, commission_rate,
      applies_to, target_ids, start_date, end_date, is_active
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).bind(
    body.affiliate_id,
    body.code,
    body.discount_rate,
    body.commission_rate,
    body.applies_to, // 'all', 'category', or 'product'
    body.target_ids || null, // JSON string of IDs
    body.start_date || null,
    body.end_date || null,
    body.is_active ? 1 : 0
  ).run();
  
  const code = await c.env.DB.prepare(
    "SELECT * FROM exceptional_promo_codes WHERE id = ?"
  ).bind(result.meta.last_row_id).first();
  
  return c.json(code, 201);
});

// Admin: Update exceptional code
app.put("/api/admin/exceptional-codes/:id", authMiddleware, async (c) => {
  const mochaUser = c.get("user");
  if (!mochaUser) return c.json({ error: "Unauthorized" }, 401);
  
  const user = await c.env.DB.prepare(
    "SELECT * FROM users WHERE id = ? AND role = 'admin'"
  ).bind(mochaUser.id).first();
  
  if (!user) return c.json({ error: "Forbidden" }, 403);
  
  const id = c.req.param("id");
  const body = await c.req.json();
  
  await c.env.DB.prepare(
    `UPDATE exceptional_promo_codes SET
     discount_rate = ?,
     commission_rate = ?,
     applies_to = ?,
     target_ids = ?,
     start_date = ?,
     end_date = ?,
     is_active = ?,
     updated_at = CURRENT_TIMESTAMP
     WHERE id = ?`
  ).bind(
    body.discount_rate,
    body.commission_rate,
    body.applies_to,
    body.target_ids || null,
    body.start_date || null,
    body.end_date || null,
    body.is_active ? 1 : 0,
    id
  ).run();
  
  const updated = await c.env.DB.prepare(
    "SELECT * FROM exceptional_promo_codes WHERE id = ?"
  ).bind(id).first();
  
  return c.json(updated);
});

// Admin: Delete exceptional code
app.delete("/api/admin/exceptional-codes/:id", authMiddleware, async (c) => {
  const mochaUser = c.get("user");
  if (!mochaUser) return c.json({ error: "Unauthorized" }, 401);
  
  const user = await c.env.DB.prepare(
    "SELECT * FROM users WHERE id = ? AND role = 'admin'"
  ).bind(mochaUser.id).first();
  
  if (!user) return c.json({ error: "Forbidden" }, 403);
  
  const id = c.req.param("id");
  
  await c.env.DB.prepare(
    "DELETE FROM exceptional_promo_codes WHERE id = ?"
  ).bind(id).run();
  
  return c.json({ success: true });
});

// Admin: Get exceptional codes for an affiliate
app.get("/api/admin/affiliates/:affiliateId/exceptional-codes", authMiddleware, async (c) => {
  const mochaUser = c.get("user");
  if (!mochaUser) return c.json({ error: "Unauthorized" }, 401);
  
  const user = await c.env.DB.prepare(
    "SELECT * FROM users WHERE id = ? AND role = 'admin'"
  ).bind(mochaUser.id).first();
  
  if (!user) return c.json({ error: "Forbidden" }, 403);
  
  const affiliateId = c.req.param("affiliateId");
  
  const { results } = await c.env.DB.prepare(
    "SELECT * FROM exceptional_promo_codes WHERE affiliate_id = ? ORDER BY created_at DESC"
  ).bind(affiliateId).all();
  
  return c.json(results);
});

export default app;
