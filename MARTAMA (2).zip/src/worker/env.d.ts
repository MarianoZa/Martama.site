// Extend the Env interface with FedaPay secrets
interface Env {
  DB: D1Database;
  R2_BUCKET: R2Bucket;
  MOCHA_USERS_SERVICE_API_URL: string;
  MOCHA_USERS_SERVICE_API_KEY: string;
  FEDAPAY_PUBLIC_KEY: string;
  FEDAPAY_SECRET_KEY: string;
  FEDAPAY_WEBHOOK_SECRET: string;
}
