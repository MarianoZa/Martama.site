import z from "zod";

// User schemas
export const UserRoleSchema = z.enum(["user", "affiliate", "admin"]);
export const UserRoleTypeSchema = z.enum(["client", "affiliate", "moderator", "owner"]);
export const UserAffiliateStatusSchema = z.enum(["none", "pending", "approved", "rejected"]);
export const LoyaltyTierSchema = z.enum(["bronze", "silver", "gold", "platinum"]);

export const UserSchema = z.object({
  id: z.string(),
  email: z.string().email(),
  full_name: z.string().nullable(),
  phone_number: z.string().nullable(),
  role: UserRoleSchema,
  role_type: UserRoleTypeSchema.nullable(),
  country: z.string().nullable(),
  preferred_categories: z.string().nullable(),
  has_completed_onboarding: z.number().int(),
  affiliate_status: UserAffiliateStatusSchema.nullable(),
  affiliate_code: z.string().nullable(),
  affiliate_commission_rate: z.number().nullable(),
  payment_method: z.string().nullable(),
  payment_account_number: z.string().nullable(),
  payment_account_name: z.string().nullable(),
  is_active: z.number().int().nullable(),
  unique_identifier: z.string().nullable(),
  loyalty_points: z.number().int().nullable(),
  loyalty_tier: LoyaltyTierSchema.nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export type User = z.infer<typeof UserSchema>;
export type UserRole = z.infer<typeof UserRoleSchema>;
export type UserRoleType = z.infer<typeof UserRoleTypeSchema>;
export type UserAffiliateStatus = z.infer<typeof UserAffiliateStatusSchema>;
export type UserLoyaltyTier = z.infer<typeof LoyaltyTierSchema>;

// Product schemas
export const ProductCategorySchema = z.enum(["abonnement", "formation", "pack"]);

export const ProductSchema = z.object({
  id: z.number(),
  name: z.string(),
  description: z.string().nullable(),
  category: ProductCategorySchema,
  service: z.string().nullable(),
  price_1_months: z.number().nullable(),
  price_3_months: z.number().nullable(),
  price_6_months: z.number().nullable(),
  price_options: z.string().nullable(),
  client_discount_rate: z.number(),
  affiliate_commission_rate: z.number(),
  features: z.string().nullable(),
  image_url: z.string().nullable(),
  is_active: z.number().int(),
  stock: z.number().int().nullable(),
  total_sales: z.number().int(),
  created_at: z.string(),
  updated_at: z.string(),
});

export type Product = z.infer<typeof ProductSchema>;
export type ProductCategory = z.infer<typeof ProductCategorySchema>;

// Order schemas
export const OrderStatusSchema = z.enum([
  "pending",
  "paid",
  "delivered",
  "cancelled",
  "refunded",
]);

export const OrderSchema = z.object({
  id: z.number(),
  product_id: z.number(),
  customer_email: z.string().email(),
  duration_months: z.number().int().nullable(),
  amount: z.number(),
  original_amount: z.number().nullable(),
  discount_amount: z.number(),
  affiliate_code: z.string().nullable(),
  affiliate_id: z.number().nullable(),
  affiliate_commission: z.number(),
  status: OrderStatusSchema,
  payment_method: z.string().nullable(),
  payment_reference: z.string().nullable(),
  access_credentials: z.string().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export type Order = z.infer<typeof OrderSchema>;
export type OrderStatus = z.infer<typeof OrderStatusSchema>;

// Affiliate schemas
export const AffiliateStatusSchema = z.enum(["pending", "active", "rejected", "suspended"]);

export const AffiliateSchema = z.object({
  id: z.number(),
  user_id: z.string(),
  promo_code: z.string(),
  balance: z.number(),
  total_clicks: z.number().int(),
  total_sales: z.number().int(),
  total_commissions: z.number(),
  status: AffiliateStatusSchema,
  created_at: z.string(),
  updated_at: z.string(),
});

export type Affiliate = z.infer<typeof AffiliateSchema>;
export type AffiliateStatus = z.infer<typeof AffiliateStatusSchema>;

// Commission schemas
export const CommissionStatusSchema = z.enum(["pending", "approved", "paid"]);

export const CommissionSchema = z.object({
  id: z.number(),
  order_id: z.number(),
  affiliate_id: z.number(),
  amount: z.number(),
  status: CommissionStatusSchema,
  created_at: z.string(),
  updated_at: z.string(),
});

export type Commission = z.infer<typeof CommissionSchema>;
export type CommissionStatus = z.infer<typeof CommissionStatusSchema>;

// Subscription schemas
export const SubscriptionSchema = z.object({
  id: z.number(),
  order_id: z.number(),
  user_id: z.string().nullable(),
  product_id: z.number(),
  access_credentials: z.string().nullable(),
  expires_at: z.string().nullable(),
  is_active: z.number().int(),
  created_at: z.string(),
  updated_at: z.string(),
});

export type Subscription = z.infer<typeof SubscriptionSchema>;

// API request/response schemas
export const CreateOrderSchema = z.object({
  product_id: z.number(),
  customer_email: z.string().email(),
  duration_months: z.number().int().optional(),
  affiliate_code: z.string().optional(),
  payment_method: z.string(),
});

export const UpdateUserProfileSchema = z.object({
  full_name: z.string().optional(),
  phone_number: z.string().optional(),
  preferred_categories: z.string().optional(),
});

export const ApplyAffiliateSchema = z.object({
  promo_code: z.string().min(3).max(20),
});

export const CreateWithdrawalRequestSchema = z.object({
  amount: z.number().positive(),
  payment_method: z.string(),
  payment_details: z.string(),
});

// Inventory schemas
export const InventorySchema = z.object({
  id: z.number(),
  product_id: z.number(),
  access_credentials: z.string(),
  is_used: z.number().int(),
  order_id: z.number().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export type Inventory = z.infer<typeof InventorySchema>;

// Affiliate Request schemas
export const AffiliateRequestStatusSchema = z.enum(["pending", "approved", "rejected"]);

export const AffiliateRequestSchema = z.object({
  id: z.number(),
  user_id: z.string(),
  promo_code: z.string(),
  specialty: z.string().nullable(),
  audience_size: z.string().nullable(),
  social_links: z.string().nullable(),
  motivation: z.string().nullable(),
  payment_method: z.string().nullable(),
  status: AffiliateRequestStatusSchema,
  admin_notes: z.string().nullable(),
  reviewed_by: z.string().nullable(),
  reviewed_at: z.string().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export type AffiliateRequest = z.infer<typeof AffiliateRequestSchema>;
export type AffiliateRequestStatus = z.infer<typeof AffiliateRequestStatusSchema>;

// Withdrawal Request schemas
export const WithdrawalRequestStatusSchema = z.enum(["pending", "approved", "rejected", "completed"]);

export const WithdrawalRequestSchema = z.object({
  id: z.number(),
  affiliate_id: z.number(),
  amount: z.number(),
  payment_method: z.string(),
  payment_details: z.string().nullable(),
  status: WithdrawalRequestStatusSchema,
  processed_at: z.string().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export type WithdrawalRequest = z.infer<typeof WithdrawalRequestSchema>;
export type WithdrawalRequestStatus = z.infer<typeof WithdrawalRequestStatusSchema>;

// Admin API schemas
export const UpdateOrderStatusSchema = z.object({
  status: OrderStatusSchema,
  access_credentials: z.string().optional(),
});

export const ApproveAffiliateRequestSchema = z.object({
  admin_notes: z.string().optional(),
});

export const RejectAffiliateRequestSchema = z.object({
  admin_notes: z.string().optional(),
});

export const AddInventorySchema = z.object({
  product_id: z.number(),
  access_credentials: z.string(),
});
