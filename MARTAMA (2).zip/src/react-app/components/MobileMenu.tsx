import { useState } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "@getmocha/users-service/react";
import { useTheme } from "@/react-app/context/ThemeContext";
import { 
  Home, 
  Package, 
  LayoutDashboard, 
  User, 
  TrendingUp,
  LogOut,
  X,
  Menu as MenuIcon,
  Shield,
  Moon,
  Sun,
  LogIn,
  HelpCircle
} from "lucide-react";

interface MobileMenuProps {
  currentPath?: string;
}

export default function MobileMenu({ currentPath }: MobileMenuProps) {
  const navigate = useNavigate();
  const { user, redirectToLogin } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [isOpen, setIsOpen] = useState(false);

  const handleLogout = async () => {
    try {
      await fetch("/api/logout");
      window.location.href = "/";
    } catch (error) {
      console.error("Logout failed:", error);
    }
  };

  const menuItems = [
    { path: "/", label: "Accueil", icon: Home, show: true },
    { path: "/catalog", label: "Catalogue", icon: Package, show: true },
    { path: "/help", label: "Centre d'Aide", icon: HelpCircle, show: true },
    { path: "login", label: "Connexion", icon: User, show: !user }, // Login button for non-authenticated users
    { path: "/dashboard", label: "Mon Espace", icon: LayoutDashboard, show: !!user },
    { path: "/affiliate/dashboard", label: "Affiliation", icon: TrendingUp, show: !!user },
    { path: "/profile", label: "Profil", icon: User, show: !!user },
    { path: "/admin", label: "Administration", icon: Shield, show: user?.email && ['arsuzannou@gmail.com', 'bnb887991@gmail.com', 'thelucidshadow7@gmail.com'].includes(user.email) },
  ];

  return (
    <>
      {/* Mobile Menu Button - Fixed Top Right */}
      <button
        onClick={() => setIsOpen(true)}
        className="fixed top-6 right-6 w-12 h-12 rounded-xl flex items-center justify-center shadow-lg z-40 lg:hidden"
        style={{ background: 'linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%)' }}
      >
        <MenuIcon className="w-5 h-5 text-white" />
      </button>

      {/* Mobile Menu Overlay */}
      {isOpen && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 lg:hidden">
          <div 
            className="absolute inset-y-0 right-0 w-80 max-w-[85vw] shadow-2xl"
            style={{ backgroundColor: 'var(--bg-primary)' }}
          >
            {/* Header */}
            <div className="flex items-center justify-between p-6 border-b" style={{ borderColor: 'var(--border-color)' }}>
              <div>
                <h3 className="text-xl font-bold" style={{ color: 'var(--text-primary)' }}>Menu</h3>
                {user && (
                  <p className="text-sm mt-1" style={{ color: 'var(--text-secondary)' }}>
                    {user.email?.split('@')[0]}
                  </p>
                )}
              </div>
              <button
                onClick={() => setIsOpen(false)}
                className="p-2 rounded-xl hover:bg-gray-100 transition-colors"
              >
                <X className="w-6 h-6" style={{ color: 'var(--text-primary)' }} />
              </button>
            </div>

            {/* Menu Items */}
            <div className="p-4 space-y-2 overflow-y-auto" style={{ maxHeight: 'calc(100vh - 240px)' }}>
              {menuItems.filter(item => item.show).map((item) => {
                const Icon = item.path === "login" ? LogIn : item.icon;
                const isActive = currentPath === item.path;
                
                return (
                  <button
                    key={item.path}
                    onClick={() => {
                      if (item.path === "login") {
                        redirectToLogin();
                        setIsOpen(false);
                      } else {
                        navigate(item.path);
                        setIsOpen(false);
                      }
                    }}
                    className={`w-full flex items-center gap-4 p-4 rounded-xl transition-all ${
                      isActive ? 'shadow-md' : ''
                    }`}
                    style={{
                      backgroundColor: isActive ? 'var(--primary)' : 'var(--bg-secondary)',
                      color: isActive ? '#ffffff' : 'var(--text-primary)'
                    }}
                  >
                    <Icon className="w-5 h-5" />
                    <span className="font-semibold">{item.label}</span>
                  </button>
                );
              })}
            </div>

            {/* Footer */}
            <div className="absolute bottom-0 left-0 right-0 p-4 border-t space-y-2" style={{ borderColor: 'var(--border-color)', backgroundColor: 'var(--bg-primary)' }}>
              {/* Theme Toggle */}
              <button
                onClick={() => {
                  toggleTheme();
                  setIsOpen(false);
                }}
                className="w-full flex items-center justify-center gap-3 p-4 rounded-xl font-semibold transition-all border"
                style={{ backgroundColor: 'var(--gray-100)', color: 'var(--text-primary)', borderColor: 'var(--border-color)' }}
              >
                {theme === 'light' ? (
                  <>
                    <Moon className="w-5 h-5" />
                    Mode Sombre
                  </>
                ) : (
                  <>
                    <Sun className="w-5 h-5" />
                    Mode Clair
                  </>
                )}
              </button>
              
              {/* Logout */}
              {user && (
                <button
                  onClick={handleLogout}
                  className="w-full flex items-center justify-center gap-3 p-4 rounded-xl font-semibold transition-all"
                  style={{ backgroundColor: 'rgba(239, 68, 68, 0.1)', color: 'var(--error)' }}
                >
                  <LogOut className="w-5 h-5" />
                  Déconnexion
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
