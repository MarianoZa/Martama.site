import { useState, useEffect } from "react";
import { Gift, Copy, Check, X } from "lucide-react";

interface AnnouncementData {
  active: boolean;
  message?: string;
  promo_code?: string;
  link_url?: string;
}

export default function AnnouncementBar() {
  const [codeRevealed, setCodeRevealed] = useState(false);
  const [codeCopied, setCodeCopied] = useState(false);
  const [isVisible, setIsVisible] = useState(true);
  const [announcement, setAnnouncement] = useState<AnnouncementData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAnnouncement();
  }, []);

  const fetchAnnouncement = async () => {
    try {
      const response = await fetch("/api/announcement");
      const data = await response.json();
      setAnnouncement(data);
    } catch (error) {
      console.error("Failed to fetch announcement:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleRevealCode = () => {
    setCodeRevealed(true);
  };

  const handleCopyCode = async () => {
    if (!announcement?.promo_code) return;
    
    try {
      await navigator.clipboard.writeText(announcement.promo_code);
      setCodeCopied(true);
      setTimeout(() => setCodeCopied(false), 2000);
    } catch (error) {
      console.error("Failed to copy code:", error);
    }
  };

  const handleClose = () => {
    setIsVisible(false);
  };

  if (loading || !announcement?.active || !isVisible) return null;

  return (
    <div className="w-full px-4 py-3 border-b shadow-md" style={{ 
      background: 'linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%)',
      borderColor: 'rgba(255, 255, 255, 0.1)'
    }}>
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-2 flex-1">
          <Gift className="w-5 h-5 text-white animate-bounce flex-shrink-0" />
          <span className="text-white font-bold text-sm sm:text-base text-center sm:text-left">
            {announcement.message}
          </span>
        </div>
        
        <div className="flex items-center gap-2">
          {announcement.promo_code && !codeRevealed ? (
            <button
              onClick={handleRevealCode}
              className="px-5 py-2 rounded-xl font-bold text-sm transition-all duration-300 hover:scale-105 shadow-lg"
              style={{ backgroundColor: 'white', color: 'var(--primary)' }}
            >
              Révéler le code 🎁
            </button>
          ) : announcement.promo_code ? (
            <div className="flex items-center gap-2">
              <div className="px-4 py-2 rounded-xl border-2 border-white/30 bg-white/10 backdrop-blur-sm">
                <span className="text-white font-bold text-lg tracking-wider">{announcement.promo_code}</span>
              </div>
              <button
                onClick={handleCopyCode}
                className="p-2 rounded-xl transition-all duration-300 hover:scale-110"
                style={{ backgroundColor: 'white', color: 'var(--primary)' }}
                title="Copier le code"
              >
                {codeCopied ? (
                  <Check className="w-5 h-5" />
                ) : (
                  <Copy className="w-5 h-5" />
                )}
              </button>
            </div>
          ) : null}
          
          <button
            onClick={handleClose}
            className="p-2 rounded-xl transition-all duration-300 hover:scale-110 hover:bg-white/10"
            title="Fermer"
          >
            <X className="w-5 h-5 text-white" />
          </button>
        </div>
      </div>
    </div>
  );
}
