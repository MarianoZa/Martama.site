import { useEffect, useState, useRef } from "react";
import { useNavigate } from "react-router";
import { BookOpen, Package, Layers, Sparkles, ChevronLeft, ChevronRight } from "lucide-react";
import type { Product } from "@/shared/types";

interface ProductCarouselProps {
  products: Product[];
}

export default function ProductCarousel({ products }: ProductCarouselProps) {
  const navigate = useNavigate();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isHovered, setIsHovered] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "formation": return <BookOpen className="w-5 h-5" />;
      case "abonnement": return <Layers className="w-5 h-5" />;
      case "pack": return <Package className="w-5 h-5" />;
      default: return <Sparkles className="w-5 h-5" />;
    }
  };

  // Auto-scroll effect
  useEffect(() => {
    if (products.length === 0 || isHovered) return;

    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % products.length);
    }, 3000); // Change every 3 seconds

    return () => clearInterval(interval);
  }, [products.length, isHovered]);

  // Smooth scroll to current product
  useEffect(() => {
    if (scrollRef.current) {
      const cardWidth = scrollRef.current.offsetWidth / (window.innerWidth >= 768 ? 3 : 1);
      scrollRef.current.scrollTo({
        left: currentIndex * cardWidth,
        behavior: 'smooth'
      });
    }
  }, [currentIndex]);

  const handlePrevious = () => {
    setCurrentIndex((prev) => (prev - 1 + products.length) % products.length);
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % products.length);
  };

  if (products.length === 0) return null;

  return (
    <div 
      className="relative"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Navigation Buttons */}
      <button
        onClick={handlePrevious}
        className="absolute left-0 top-1/2 -translate-y-1/2 z-10 p-3 rounded-full shadow-xl transition-all duration-300 hover:scale-110"
        style={{ backgroundColor: 'var(--primary)', color: 'white', marginLeft: '-20px' }}
      >
        <ChevronLeft className="w-6 h-6" />
      </button>

      <button
        onClick={handleNext}
        className="absolute right-0 top-1/2 -translate-y-1/2 z-10 p-3 rounded-full shadow-xl transition-all duration-300 hover:scale-110"
        style={{ backgroundColor: 'var(--primary)', color: 'white', marginRight: '-20px' }}
      >
        <ChevronRight className="w-6 h-6" />
      </button>

      {/* Carousel Container */}
      <div 
        ref={scrollRef}
        className="flex gap-6 overflow-x-auto scrollbar-hide scroll-smooth"
        style={{ scrollSnapType: 'x mandatory' }}
      >
        {products.map((product, index) => (
          <div
            key={product.id}
            className="flex-shrink-0 w-full md:w-1/3 scroll-snap-align-start"
            style={{ scrollSnapAlign: 'start' }}
          >
            <div
              onClick={() => navigate(`/products/${product.id}`)}
              className="group rounded-3xl border overflow-hidden hover:shadow-2xl transition-all duration-500 hover:scale-105 cursor-pointer transform"
              style={{ 
                backgroundColor: 'var(--bg-secondary)', 
                borderColor: 'var(--border-color)',
                animation: `float ${3 + index * 0.5}s ease-in-out infinite`
              }}
            >
              {product.image_url && (
                <div className="aspect-video w-full overflow-hidden relative">
                  <div 
                    className="absolute inset-0 opacity-30"
                    style={{ 
                      background: 'linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%)',
                      animation: 'pulse 2s ease-in-out infinite'
                    }}
                  />
                  <img
                    src={product.image_url}
                    alt={product.name}
                    loading="lazy"
                    className="w-full h-full object-cover group-hover:scale-125 transition-transform duration-700 relative z-10"
                  />
                </div>
              )}
              <div className="p-6 relative">
                {/* Shine effect on hover */}
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent opacity-0 group-hover:opacity-100 group-hover:animate-shimmer" />
                
                <div className="flex items-center gap-2 mb-3 relative z-10">
                  <div 
                    className="w-8 h-8 rounded-lg flex items-center justify-center text-white transform group-hover:rotate-12 transition-transform duration-300" 
                    style={{ background: 'linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%)' }}
                  >
                    {getCategoryIcon(product.category)}
                  </div>
                  <span className="text-sm font-medium capitalize" style={{ color: 'var(--text-secondary)' }}>
                    {product.category}
                  </span>
                </div>
                
                <h3 className="text-xl font-bold mb-2 line-clamp-2 relative z-10" style={{ color: 'var(--text-primary)' }}>
                  {product.name}
                </h3>
                
                <p className="text-sm mb-4 line-clamp-2 whitespace-pre-line relative z-10" style={{ color: 'var(--text-secondary)' }}>
                  {product.description}
                </p>
                
                <div className="flex items-center justify-between relative z-10">
                  <div>
                    {product.price_1_months && (
                      <div className="text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>
                        {product.price_1_months.toLocaleString()} FCFA
                        <span className="text-sm font-normal ml-1" style={{ color: 'var(--text-muted)' }}>/mois</span>
                      </div>
                    )}
                  </div>
                  <div 
                    className="text-sm font-medium transition-all duration-300 group-hover:translate-x-2" 
                    style={{ color: 'var(--primary)' }}
                  >
                    Découvrir →
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Dots Indicator */}
      <div className="flex justify-center gap-2 mt-6">
        {products.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentIndex(index)}
            className="w-2 h-2 rounded-full transition-all duration-300"
            style={{
              backgroundColor: currentIndex === index ? 'var(--primary)' : 'var(--gray-500)',
              width: currentIndex === index ? '24px' : '8px',
            }}
          />
        ))}
      </div>

      <style>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-10px); }
        }
      `}</style>
    </div>
  );
}
