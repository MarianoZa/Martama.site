import { Star } from 'lucide-react';

interface TestimonialProps {
  customerName: string;
  rating: number;
  comment: string;
  avatar?: string;
}

export default function Testimonial({ customerName, rating, comment, avatar }: TestimonialProps) {
  return (
    <div className="rounded-2xl border p-6" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
      <div className="flex items-start gap-4 mb-4">
        <div className="w-12 h-12 rounded-full flex items-center justify-center text-white font-bold text-lg" style={{ background: 'linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%)' }}>
          {avatar ? (
            <img src={avatar} alt={customerName} className="w-full h-full rounded-full object-cover" />
          ) : (
            customerName.charAt(0).toUpperCase()
          )}
        </div>
        <div className="flex-1">
          <h4 className="font-bold mb-1" style={{ color: 'var(--text-primary)' }}>
            {customerName}
          </h4>
          <div className="flex items-center gap-1">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star
                key={i}
                className={`w-4 h-4 ${i < rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}`}
              />
            ))}
          </div>
        </div>
      </div>
      <p className="text-sm leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
        {comment}
      </p>
    </div>
  );
}
