import { useEffect } from 'react';

interface SEOHeadProps {
  title: string;
  description: string;
  image?: string;
  url?: string;
  type?: string;
}

export default function SEOHead({ title, description, image, url, type = 'website' }: SEOHeadProps) {
  useEffect(() => {
    // Update document title
    document.title = `${title} | Martama`;

    // Update meta tags
    const metaTags = [
      { property: 'og:title', content: title },
      { property: 'og:description', content: description },
      { property: 'og:type', content: type },
      { name: 'description', content: description },
      { name: 'twitter:title', content: title },
      { name: 'twitter:description', content: description },
    ];

    if (image) {
      metaTags.push(
        { property: 'og:image', content: image },
        { name: 'twitter:image', content: image }
      );
    }

    if (url) {
      metaTags.push({ property: 'og:url', content: url });
    }

    // Apply meta tags
    metaTags.forEach(({ property, name, content }) => {
      const selector = property ? `meta[property="${property}"]` : `meta[name="${name}"]`;
      let element = document.querySelector(selector);

      if (!element) {
        element = document.createElement('meta');
        if (property) element.setAttribute('property', property);
        if (name) element.setAttribute('name', name);
        document.head.appendChild(element);
      }

      element.setAttribute('content', content);
    });

    return () => {
      // Cleanup is optional since we're updating existing tags
    };
  }, [title, description, image, url, type]);

  return null; // This component doesn't render anything
}
