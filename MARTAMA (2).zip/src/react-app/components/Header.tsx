import { useNavigate } from "react-router";
import { useAuth } from "@getmocha/users-service/react";
import MobileMenu from "@/react-app/components/MobileMenu";
import { LogOut, User, LayoutDashboard } from "lucide-react";

interface HeaderProps {
  showBackButton?: boolean;
  onBack?: () => void;
}

export default function Header({ showBackButton, onBack }: HeaderProps) {
  const navigate = useNavigate();
  const { user, redirectToLogin } = useAuth();

  const handleLogout = async () => {
    try {
      await fetch("/api/logout");
      window.location.href = "/";
    } catch (error) {
      console.error("Logout failed:", error);
    }
  };

  return (
    <>
      <header className="px-4 sm:px-6 py-4 sm:py-6 flex justify-between items-center max-w-7xl mx-auto" style={{ backgroundColor: 'var(--bg-primary)' }}>
        <div className="flex items-center gap-3 sm:gap-4">
        {showBackButton && onBack && (
          <button
            onClick={onBack}
            className="p-2 rounded-xl transition-colors"
            style={{ backgroundColor: 'var(--gray-100)' }}
          >
            <svg className="w-6 h-6" style={{ color: 'var(--text-primary)' }} fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
        )}
        <div 
            className="flex items-center gap-2 sm:gap-3 cursor-pointer" 
            onClick={() => navigate("/")}
          >
            <img 
              src="https://mocha-cdn.com/019a9e15-2be5-75ee-95ff-4622e0e0fa46/20251126_134422.png"
              alt="Logo Martama"
              className="h-8 sm:h-10 w-auto object-contain"
            />
            <span className="text-2xl sm:text-3xl font-bold" style={{ color: 'var(--text-primary)' }}>
              Martama
            </span>
          </div>
        </div>

      <div className="hidden lg:flex items-center gap-3">
          {user ? (
            <>
              <button
                onClick={() => navigate("/dashboard")}
                className="flex items-center gap-2 px-4 py-2 rounded-xl transition-all duration-300 font-medium border"
                style={{
                  backgroundColor: 'var(--gray-100)',
                  color: 'var(--text-primary)',
                  borderColor: 'var(--border-color)'
                }}
              >
                <LayoutDashboard className="w-4 h-4" />
                <span className="hidden md:inline">Mon Espace</span>
              </button>
              <button
                onClick={() => navigate("/profile")}
                className="flex items-center gap-2 px-4 py-2 rounded-xl transition-all duration-300 font-medium border"
                style={{
                  backgroundColor: 'var(--gray-100)',
                  color: 'var(--text-primary)',
                  borderColor: 'var(--border-color)'
                }}
              >
                <User className="w-4 h-4" />
                <span className="hidden md:inline">Profil</span>
              </button>
              <button
                onClick={handleLogout}
                className="flex items-center gap-2 px-4 py-2 rounded-xl transition-all duration-300 font-medium border"
                style={{
                  backgroundColor: 'rgba(239, 68, 68, 0.1)',
                  color: 'var(--error)',
                  borderColor: 'rgba(239, 68, 68, 0.3)'
                }}
              >
                <LogOut className="w-4 h-4" />
                <span className="hidden md:inline">Déconnexion</span>
              </button>
            </>
          ) : (
            <button
              onClick={redirectToLogin}
              className="px-6 py-2.5 rounded-xl transition-all duration-300 font-medium text-white"
              style={{ backgroundColor: 'var(--primary)' }}
            >
              Connexion
            </button>
          )}
        </div>

        {/* Mobile menu button is now fixed in MobileMenu component */}
      </header>
      
      {/* Mobile Menu Component */}
      <MobileMenu currentPath={window.location.pathname} />
    </>
  );
}
