interface TestimonialScreenshotProps {
  screenshotUrl: string;
  customerName?: string;
}

export default function TestimonialScreenshot({ screenshotUrl, customerName }: TestimonialScreenshotProps) {
  return (
    <div 
      className="group rounded-3xl overflow-hidden border-4 hover:shadow-2xl transition-all duration-500 hover:scale-105 cursor-pointer transform"
      style={{ 
        borderColor: 'var(--primary)',
        animation: 'float 4s ease-in-out infinite'
      }}
    >
      <div className="relative overflow-hidden">
        {/* Glow effect */}
        <div 
          className="absolute inset-0 opacity-0 group-hover:opacity-20 transition-opacity duration-500"
          style={{
            background: 'radial-gradient(circle at center, var(--primary) 0%, transparent 70%)',
          }}
        />
        
        {/* Screenshot */}
        <img
          src={screenshotUrl}
          alt={customerName || "Témoignage client"}
          className="w-full h-auto object-cover transition-transform duration-700 group-hover:scale-105"
          loading="lazy"
        />
        
        {/* Overlay on hover */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500">
          <div className="absolute bottom-0 left-0 right-0 p-6">
            {customerName && (
              <p className="text-white font-bold text-lg mb-2">
                {customerName}
              </p>
            )}
            <p className="text-white/90 text-sm">
              ✅ Client Satisfait
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
