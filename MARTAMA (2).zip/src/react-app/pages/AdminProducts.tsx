import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { ArrowLeft, Plus, Edit, Trash2, Package, BookOpen, Layers, X } from "lucide-react";

interface Product {
  id: number;
  name: string;
  description: string;
  category: string;
  service: string | null;
  price_1_months: number | null;
  price_3_months: number | null;
  price_6_months: number | null;
  price_options: string | null;
  client_discount_rate: number;
  affiliate_commission_rate: number;
  features: string | null;
  image_url: string | null;
  download_url: string | null;
  is_active: number;
  stock: number | null;
  total_sales: number;
}

interface PriceOption {
  months: number;
  price: string;
  lygos_payment_link?: string;
}

export default function AdminProducts() {
  const navigate = useNavigate();
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [activeCategory, setActiveCategory] = useState("all");

  const [formData, setFormData] = useState({
    name: "",
    description: "",
    category: "abonnement",
    service: "",
    client_discount_rate: "10",
    affiliate_commission_rate: "15",
    features: "",
    image_url: "",
    download_url: "",
    usage_instructions: "",
    is_active: 1,
    stock: "",
    single_price: "",
  });

  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string>("");

  const [priceOptions, setPriceOptions] = useState<PriceOption[]>([
    { months: 1, price: "" }
  ]);

  useEffect(() => {
    const loadFont = () => {
      const link = document.createElement("link");
      link.href = "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap";
      link.rel = "stylesheet";
      document.head.appendChild(link);
    };
    loadFont();
  }, []);

  useEffect(() => {
    fetchProducts();
  }, [activeCategory]);

  const fetchProducts = async () => {
    try {
      setLoading(true);
      const url = activeCategory === "all" 
        ? "/api/admin/products" 
        : `/api/admin/products?category=${activeCategory}`;
      const response = await fetch(url);
      
      if (response.status === 403) {
        navigate("/");
        return;
      }
      
      const data = await response.json();
      setProducts(data);
    } catch (error) {
      console.error("Failed to fetch products:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleOpenModal = (product?: Product) => {
    if (product) {
      setEditingProduct(product);
      setFormData({
        name: product.name,
        description: product.description || "",
        category: product.category,
        service: product.service || "",
        client_discount_rate: (product.client_discount_rate * 100).toString(),
        affiliate_commission_rate: (product.affiliate_commission_rate * 100).toString(),
        features: product.features || "",
        image_url: product.image_url || "",
        download_url: product.download_url || "",
        usage_instructions: (product as any).usage_instructions || "",
        is_active: product.is_active,
        stock: product.stock?.toString() || "",
        single_price: product.price_1_months?.toString() || "",
      });

      setImagePreview(product.image_url || "");
      setSelectedImage(null);

      if (product.category === "abonnement") {
        // Try to load from price_options first, fallback to old fields
        if (product.price_options) {
          try {
            const options = JSON.parse(product.price_options);
            setPriceOptions(options);
          } catch (e) {
            console.error("Failed to parse price_options:", e);
            setPriceOptions([{ months: 1, price: "" }]);
          }
        } else {
          // Fallback to old system
          const options: PriceOption[] = [];
          if (product.price_1_months) options.push({ months: 1, price: product.price_1_months.toString() });
          if (product.price_3_months) options.push({ months: 3, price: product.price_3_months.toString() });
          if (product.price_6_months) options.push({ months: 6, price: product.price_6_months.toString() });
          setPriceOptions(options.length > 0 ? options : [{ months: 1, price: "" }]);
        }
      } else {
        setPriceOptions([{ months: 1, price: "" }]);
      }
    } else {
      setEditingProduct(null);
      setFormData({
        name: "",
        description: "",
        category: "abonnement",
        service: "",
        client_discount_rate: "10",
        affiliate_commission_rate: "15",
        features: "",
        image_url: "",
        download_url: "",
        usage_instructions: "",
        is_active: 1,
        stock: "",
        single_price: "",
      });
      setPriceOptions([{ months: 1, price: "" }]);
      setSelectedImage(null);
      setImagePreview("");
    }
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setEditingProduct(null);
    setSelectedImage(null);
    setImagePreview("");
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedImage(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const addPriceOption = () => {
    setPriceOptions([...priceOptions, { months: 1, price: "" }]);
  };

  const removePriceOption = (index: number) => {
    if (priceOptions.length > 1) {
      setPriceOptions(priceOptions.filter((_, i) => i !== index));
    }
  };

  const updatePriceOption = (index: number, field: 'months' | 'price' | 'lygos_payment_link', value: string) => {
    const newOptions = [...priceOptions];
    if (field === 'months') {
      newOptions[index].months = parseInt(value) || 1;
    } else if (field === 'price') {
      newOptions[index].price = value;
    } else if (field === 'lygos_payment_link') {
      newOptions[index].lygos_payment_link = value;
    }
    setPriceOptions(newOptions);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      let imageUrl = formData.image_url;
      if (selectedImage) {
        const imageFormData = new FormData();
        imageFormData.append("image", selectedImage);
        
        const uploadResponse = await fetch("/api/admin/upload-image", {
          method: "POST",
          body: imageFormData,
        });
        
        if (uploadResponse.ok) {
          const uploadData = await uploadResponse.json();
          imageUrl = uploadData.url;
        } else {
          console.error("Failed to upload image");
          return;
        }
      }
      
      let priceFields: any = {
        price_1_months: null,
        price_3_months: null,
        price_6_months: null,
        price_options: null,
      };

      if (formData.category === "abonnement") {
        // Store as JSON in price_options
        const validOptions = priceOptions.filter(opt => {
          const price = parseFloat(opt.price);
          return !isNaN(price) && price > 0 && opt.months > 0;
        });
        
        if (validOptions.length > 0) {
          priceFields.price_options = JSON.stringify(validOptions);
          
          // Also populate legacy fields for backward compatibility
          validOptions.forEach(option => {
            const price = parseFloat(option.price);
            if (option.months === 1) priceFields.price_1_months = price;
            else if (option.months === 3) priceFields.price_3_months = price;
            else if (option.months === 6) priceFields.price_6_months = price;
          });
        }
      } else {
        const singlePrice = parseFloat(formData.single_price);
        if (!isNaN(singlePrice) && singlePrice > 0) {
          priceFields.price_1_months = singlePrice;
          priceFields.price_options = JSON.stringify([{ months: 1, price: singlePrice.toString() }]);
        }
      }

      const payload = {
        name: formData.name,
        description: formData.description,
        category: formData.category,
        service: formData.service || null,
        ...priceFields,
        client_discount_rate: parseFloat(formData.client_discount_rate) / 100,
        affiliate_commission_rate: parseFloat(formData.affiliate_commission_rate) / 100,
        features: formData.features || null,
        image_url: imageUrl || null,
        download_url: formData.download_url || null,
        usage_instructions: formData.usage_instructions || null,
        is_active: formData.is_active,
        stock: formData.stock ? parseInt(formData.stock) : null,
      };

      const url = editingProduct 
        ? `/api/admin/products/${editingProduct.id}`
        : "/api/admin/products";
      
      const response = await fetch(url, {
        method: editingProduct ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (response.ok) {
        await fetchProducts();
        handleCloseModal();
      }
    } catch (error) {
      console.error("Failed to save product:", error);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Êtes-vous sûr de vouloir supprimer ce produit ?")) return;

    try {
      const response = await fetch(`/api/admin/products/${id}`, {
        method: "DELETE",
      });

      if (response.ok) {
        await fetchProducts();
      }
    } catch (error) {
      console.error("Failed to delete product:", error);
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "formation": return <BookOpen className="w-5 h-5" />;
      case "abonnement": return <Layers className="w-5 h-5" />;
      case "pack": return <Package className="w-5 h-5" />;
      default: return <Package className="w-5 h-5" />;
    }
  };

  const filteredProducts = activeCategory === "all" 
    ? products 
    : products.filter(p => p.category === activeCategory);

  const stats = {
    total: products.length,
    active: products.filter(p => p.is_active === 1).length,
    formations: products.filter(p => p.category === "formation").length,
  };

  return (
    <div className="min-h-screen" style={{ fontFamily: "'Outfit', sans-serif", backgroundColor: 'var(--bg-primary)' }}>
      <header className="px-6 py-6 max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate("/admin")}
              className="p-2 hover:opacity-80 rounded-xl transition-opacity"
              style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)' }}
            >
              <ArrowLeft className="w-6 h-6" style={{ color: 'var(--primary)' }} />
            </button>
            <div>
              <h1 className="text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>Gestion des Produits</h1>
              <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>Gérez vos abonnements, formations et ebooks</p>
            </div>
          </div>
          <button
            onClick={() => handleOpenModal()}
            className="flex items-center gap-2 px-6 py-3 rounded-xl font-semibold transition-all text-white"
            style={{ backgroundColor: 'var(--primary)' }}
          >
            <Plus className="w-5 h-5" />
            Nouveau Produit
          </button>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <div className="rounded-2xl p-6 border" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm" style={{ color: 'var(--text-muted)' }}>Total Produits</span>
              <Package className="w-8 h-8" style={{ color: 'var(--primary)' }} />
            </div>
            <div className="text-3xl font-bold" style={{ color: 'var(--text-primary)' }}>{stats.total}</div>
          </div>

          <div className="rounded-2xl p-6 border" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm" style={{ color: 'var(--text-muted)' }}>Produits Actifs</span>
              <Layers className="w-8 h-8" style={{ color: 'var(--success)' }} />
            </div>
            <div className="text-3xl font-bold" style={{ color: 'var(--text-primary)' }}>{stats.active}</div>
          </div>

          <div className="rounded-2xl p-6 border" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm" style={{ color: 'var(--text-muted)' }}>Formations</span>
              <BookOpen className="w-8 h-8" style={{ color: 'var(--warning)' }} />
            </div>
            <div className="text-3xl font-bold" style={{ color: 'var(--text-primary)' }}>{stats.formations}</div>
          </div>
        </div>

        {/* Filters */}
        <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide">
          {["all", "abonnement", "formation", "pack"].map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-6 py-3 rounded-xl font-semibold whitespace-nowrap transition-all ${
                activeCategory === cat ? "text-white shadow-lg" : ""
              }`}
              style={{
                backgroundColor: activeCategory === cat ? 'var(--primary)' : 'var(--bg-secondary)',
                color: activeCategory === cat ? '#ffffff' : 'var(--text-primary)',
                borderColor: 'var(--border-color)',
                border: activeCategory === cat ? 'none' : '1px solid'
              }}
            >
              {cat === "all" ? "Tous" : cat === "abonnement" ? "Abonnements" : cat === "formation" ? "Formations" : "Packs & Ebooks"}
            </button>
          ))}
        </div>
      </header>

      <main className="px-6 pb-12 max-w-7xl mx-auto">
        {loading ? (
          <div className="text-center py-20">
            <div className="inline-block w-12 h-12 border-4 rounded-full animate-spin" style={{ borderColor: 'var(--gray-200)', borderTopColor: 'var(--primary)' }}></div>
          </div>
        ) : filteredProducts.length === 0 ? (
          <div className="text-center py-20">
            <Package className="w-16 h-16 mx-auto mb-4" style={{ color: 'var(--text-muted)', opacity: 0.3 }} />
            <p className="text-xl" style={{ color: 'var(--text-muted)' }}>Aucun produit</p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 gap-6">
            {filteredProducts.map((product) => (
              <div
                key={product.id}
                className="rounded-2xl border overflow-hidden hover:opacity-90 transition-opacity"
                style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}
              >
                {product.image_url && (
                  <div className="aspect-video w-full overflow-hidden" style={{ background: 'linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%)' }}>
                    <img
                      src={product.image_url}
                      alt={product.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}
                
                <div className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <div style={{ color: 'var(--primary)' }}>
                          {getCategoryIcon(product.category)}
                        </div>
                        <span className="text-sm capitalize" style={{ color: 'var(--text-muted)' }}>{product.category}</span>
                        {product.is_active === 1 ? (
                          <span className="px-2 py-0.5 bg-green-500/20 text-green-600 text-xs font-medium rounded-full">
                            Actif
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 bg-red-500/20 text-red-600 text-xs font-medium rounded-full">
                            Inactif
                          </span>
                        )}
                      </div>
                      <h3 className="text-xl font-bold mb-1" style={{ color: 'var(--text-primary)' }}>{product.name}</h3>
                      <p className="text-sm line-clamp-2 whitespace-pre-line" style={{ color: 'var(--text-secondary)' }}>{product.description}</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
                    {product.price_1_months && (
                      <div>
                        <span style={{ color: 'var(--text-muted)' }}>
                          {product.category === "abonnement" ? "Prix (1 mois)" : "Prix"}
                        </span>
                        <div className="font-semibold" style={{ color: 'var(--text-primary)' }}>{product.price_1_months.toLocaleString()} F</div>
                      </div>
                    )}
                    <div>
                      <span style={{ color: 'var(--text-muted)' }}>Réduction code promo</span>
                      <div className="font-semibold" style={{ color: 'var(--text-primary)' }}>{(product.client_discount_rate * 100).toFixed(0)}%</div>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <button
                      onClick={() => handleOpenModal(product)}
                      className="flex-1 flex items-center justify-center gap-2 px-4 py-2 rounded-xl font-medium transition-colors text-white"
                      style={{ backgroundColor: 'var(--info)' }}
                    >
                      <Edit className="w-4 h-4" />
                      Modifier
                    </button>
                    <button
                      onClick={() => handleDelete(product.id)}
                      className="px-4 py-2 border rounded-xl transition-colors"
                      style={{ backgroundColor: 'rgba(239, 68, 68, 0.1)', color: 'var(--error)', borderColor: 'rgba(239, 68, 68, 0.3)' }}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      {/* Product Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-6 z-50 overflow-y-auto">
          <div className="rounded-3xl border p-8 max-w-3xl w-full my-8" style={{ backgroundColor: 'var(--bg-primary)', borderColor: 'var(--border-color)' }}>
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>
                {editingProduct ? "Modifier le produit" : "Nouveau produit"}
              </h3>
              <button
                onClick={handleCloseModal}
                className="p-2 hover:opacity-80 rounded-xl transition-opacity"
                style={{ backgroundColor: 'var(--bg-secondary)' }}
              >
                <X className="w-6 h-6" style={{ color: 'var(--text-primary)' }} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                    Nom du produit *
                  </label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    required
                    placeholder="Ex: ChatGPT Premium"
                    className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                    style={{ 
                      backgroundColor: 'var(--bg-secondary)', 
                      borderColor: 'var(--border-color)', 
                      color: 'var(--text-primary)',
                      '--tw-ring-color': 'var(--primary)'
                    } as any}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                    Type de produit *
                  </label>
                  <select
                    value={formData.category}
                    onChange={(e) => {
                      setFormData({ ...formData, category: e.target.value });
                      if (e.target.value !== "abonnement") {
                        setPriceOptions([{ months: 1, price: "" }]);
                      }
                    }}
                    className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                    style={{ 
                      backgroundColor: 'var(--bg-secondary)', 
                      borderColor: 'var(--border-color)', 
                      color: 'var(--text-primary)',
                      '--tw-ring-color': 'var(--primary)'
                    } as any}
                  >
                    <option value="abonnement">Abonnement</option>
                    <option value="formation">Formation</option>
                    <option value="pack">Pack / Ebook</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                  Description
                </label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  rows={3}
                  placeholder="Décrivez les fonctionnalités et avantages du produit"
                  className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                  style={{ 
                    backgroundColor: 'var(--bg-secondary)', 
                    borderColor: 'var(--border-color)', 
                    color: 'var(--text-primary)',
                    '--tw-ring-color': 'var(--primary)'
                  } as any}
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                  Image du produit
                </label>
                <div className="space-y-3">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageSelect}
                    className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                    style={{ 
                      backgroundColor: 'var(--bg-secondary)', 
                      borderColor: 'var(--border-color)', 
                      color: 'var(--text-primary)',
                      '--tw-ring-color': 'var(--primary)'
                    } as any}
                  />
                  {imagePreview && (
                    <div className="relative w-full aspect-video rounded-xl overflow-hidden border" style={{ borderColor: 'var(--border-color)' }}>
                      <img
                        src={imagePreview}
                        alt="Aperçu"
                        className="w-full h-full object-cover"
                      />
                    </div>
                  )}
                </div>
              </div>

              {formData.category === "abonnement" && (
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                    Nom du service
                  </label>
                  <input
                    type="text"
                    value={formData.service}
                    onChange={(e) => setFormData({ ...formData, service: e.target.value })}
                    placeholder="Ex: ChatGPT, Capcut Pro, Netflix, etc."
                    className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                    style={{ 
                      backgroundColor: 'var(--bg-secondary)', 
                      borderColor: 'var(--border-color)', 
                      color: 'var(--text-primary)',
                      '--tw-ring-color': 'var(--primary)'
                    } as any}
                  />
                </div>
              )}

              {formData.category === "abonnement" ? (
                <div className="border rounded-xl p-6" style={{ borderColor: 'var(--border-color)', backgroundColor: 'var(--bg-secondary)' }}>
                  <div className="flex items-center justify-between mb-4">
                    <h4 className="text-lg font-semibold" style={{ color: 'var(--text-primary)' }}>Options d'abonnement</h4>
                    <button
                      type="button"
                      onClick={addPriceOption}
                      className="flex items-center gap-2 px-4 py-2 rounded-xl font-medium transition-colors text-white"
                      style={{ backgroundColor: 'var(--success)' }}
                    >
                      <Plus className="w-4 h-4" />
                      Ajouter
                    </button>
                  </div>
                  
                  <div className="space-y-4">
                    {priceOptions.map((option, index) => (
                      <div key={index} className="border rounded-xl p-4" style={{ borderColor: 'var(--border-color)', backgroundColor: 'var(--bg-primary)' }}>
                        <div className="flex gap-3 items-start mb-3">
                          <div className="flex-1">
                            <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                              Nombre de mois
                            </label>
                            <input
                              type="number"
                              min="1"
                              value={option.months}
                              onChange={(e) => updatePriceOption(index, 'months', e.target.value)}
                              className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                              style={{ 
                                backgroundColor: 'var(--bg-secondary)', 
                                borderColor: 'var(--border-color)', 
                                color: 'var(--text-primary)',
                                '--tw-ring-color': 'var(--primary)'
                              } as any}
                            />
                          </div>
                          <div className="flex-1">
                            <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                              Prix (FCFA)
                            </label>
                            <input
                              type="number"
                              min="0"
                              step="1"
                              value={option.price}
                              onChange={(e) => updatePriceOption(index, 'price', e.target.value)}
                              className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                              style={{ 
                                backgroundColor: 'var(--bg-secondary)', 
                                borderColor: 'var(--border-color)', 
                                color: 'var(--text-primary)',
                                '--tw-ring-color': 'var(--primary)'
                              } as any}
                            />
                          </div>
                          {priceOptions.length > 1 && (
                            <button
                              type="button"
                              onClick={() => removePriceOption(index)}
                              className="mt-8 p-3 border rounded-xl transition-colors"
                              style={{ backgroundColor: 'rgba(239, 68, 68, 0.1)', color: 'var(--error)', borderColor: 'rgba(239, 68, 68, 0.3)' }}
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                        <div>
                          <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                            Lien de paiement Lygos (optionnel)
                          </label>
                          <input
                            type="url"
                            value={option.lygos_payment_link || ''}
                            onChange={(e) => updatePriceOption(index, 'lygos_payment_link', e.target.value)}
                            placeholder="https://lygos.co/pay/link..."
                            className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2 font-mono text-sm"
                            style={{ 
                              backgroundColor: 'var(--bg-secondary)', 
                              borderColor: 'var(--border-color)', 
                              color: 'var(--text-primary)',
                              '--tw-ring-color': 'var(--primary)'
                            } as any}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                      Prix (FCFA) *
                    </label>
                    <input
                      type="number"
                      min="0"
                      step="1"
                      value={formData.single_price}
                      onChange={(e) => setFormData({ ...formData, single_price: e.target.value })}
                      required
                      placeholder="Ex: 5000"
                      className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                      style={{ 
                        backgroundColor: 'var(--bg-secondary)', 
                        borderColor: 'var(--border-color)', 
                        color: 'var(--text-primary)',
                        '--tw-ring-color': 'var(--primary)'
                      } as any}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                      Lien de téléchargement
                    </label>
                    <input
                      type="url"
                      value={formData.download_url}
                      onChange={(e) => setFormData({ ...formData, download_url: e.target.value })}
                      placeholder="https://example.com/content"
                      className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                      style={{ 
                        backgroundColor: 'var(--bg-secondary)', 
                        borderColor: 'var(--border-color)', 
                        color: 'var(--text-primary)',
                        '--tw-ring-color': 'var(--primary)'
                      } as any}
                    />
                  </div>
                </div>
              )}

              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                  Instructions d'utilisation
                </label>
                <textarea
                  value={formData.usage_instructions}
                  onChange={(e) => setFormData({ ...formData, usage_instructions: e.target.value })}
                  rows={4}
                  placeholder="Ex: Pour activer votre abonnement..."
                  className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                  style={{ 
                    backgroundColor: 'var(--bg-secondary)', 
                    borderColor: 'var(--border-color)', 
                    color: 'var(--text-primary)',
                    '--tw-ring-color': 'var(--primary)'
                  } as any}
                />
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                    Taux de réduction avec code promo (%) *
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="100"
                    step="0.1"
                    value={formData.client_discount_rate}
                    onChange={(e) => setFormData({ ...formData, client_discount_rate: e.target.value })}
                    required
                    placeholder="Ex: 10"
                    className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                    style={{ 
                      backgroundColor: 'var(--bg-secondary)', 
                      borderColor: 'var(--border-color)', 
                      color: 'var(--text-primary)',
                      '--tw-ring-color': 'var(--primary)'
                    } as any}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                    Commission affilié (%) *
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="100"
                    step="0.1"
                    value={formData.affiliate_commission_rate}
                    onChange={(e) => setFormData({ ...formData, affiliate_commission_rate: e.target.value })}
                    required
                    placeholder="Ex: 15"
                    className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                    style={{ 
                      backgroundColor: 'var(--bg-secondary)', 
                      borderColor: 'var(--border-color)', 
                      color: 'var(--text-primary)',
                      '--tw-ring-color': 'var(--primary)'
                    } as any}
                  />
                </div>
              </div>

              <div className="flex items-center gap-3">
                <input
                  type="checkbox"
                  id="is_active"
                  checked={formData.is_active === 1}
                  onChange={(e) => setFormData({ ...formData, is_active: e.target.checked ? 1 : 0 })}
                  className="w-5 h-5 rounded"
                />
                <label htmlFor="is_active" className="font-medium" style={{ color: 'var(--text-primary)' }}>
                  Produit actif (visible dans le catalogue)
                </label>
              </div>

              <div className="flex gap-3 pt-4 border-t" style={{ borderColor: 'var(--border-color)' }}>
                <button
                  type="submit"
                  className="flex-1 px-6 py-3 rounded-xl font-semibold transition-colors text-white"
                  style={{ backgroundColor: 'var(--primary)' }}
                >
                  {editingProduct ? "Mettre à jour" : "Créer le produit"}
                </button>
                <button
                  type="button"
                  onClick={handleCloseModal}
                  className="px-6 py-3 rounded-xl font-semibold transition-colors"
                  style={{ backgroundColor: 'var(--bg-secondary)', color: 'var(--text-primary)' }}
                >
                  Annuler
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
