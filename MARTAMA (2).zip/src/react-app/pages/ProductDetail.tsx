import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router";
import { useAuth } from "@getmocha/users-service/react";
import Header from "@/react-app/components/Header";
import Footer from "@/react-app/components/Footer";
import Testimonial from "@/react-app/components/Testimonial";
import SEOHead from "@/react-app/components/SEOHead";
import AnnouncementBar from "@/react-app/components/AnnouncementBar";
import FedaPayCheckout from "@/react-app/components/FedaPayCheckout";
import { getAffiliateCookie } from "@/react-app/hooks/useAffiliateTracking";
import { useToast } from "@/react-app/hooks/useToast";
import ToastContainer from "@/react-app/components/ToastContainer";
import { Check, Tag, X, ChevronDown, MessageCircle } from "lucide-react";
import type { Product } from "@/shared/types";

interface OrderFormData {
  firstName: string;
  lastName: string;
  email: string;
  countryCode: string;
  phoneNumber: string;
  duration: number;
  promoCode: string;
}

interface PriceOption {
  months: number;
  price: string;
  lygos_payment_link?: string;
}

const countryCodes = [
  { code: "+221", country: "Sénégal", flag: "🇸🇳" },
  { code: "+225", country: "Côte d'Ivoire", flag: "🇨🇮" },
  { code: "+223", country: "Mali", flag: "🇲🇱" },
  { code: "+226", country: "Burkina Faso", flag: "🇧🇫" },
  { code: "+227", country: "Niger", flag: "🇳🇪" },
  { code: "+228", country: "Togo", flag: "🇹🇬" },
  { code: "+229", country: "Bénin", flag: "🇧🇯" },
  { code: "+237", country: "Cameroun", flag: "🇨🇲" },
  { code: "+212", country: "Maroc", flag: "🇲🇦" },
  { code: "+213", country: "Algérie", flag: "🇩🇿" },
  { code: "+216", country: "Tunisie", flag: "🇹🇳" },
];

// Declare FedaPay on window
declare global {
  interface Window {
    FedaPay: any;
  }
}

export default function ProductDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toasts, removeToast, success, error, info } = useToast();
  const [product, setProduct] = useState<Product | null>(null);
  const [priceOptions, setPriceOptions] = useState<PriceOption[]>([]);
  const [loading, setLoading] = useState(true);
  const [showOrderModal, setShowOrderModal] = useState(false);
  const [showCountryDropdown, setShowCountryDropdown] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [selectedDuration, setSelectedDuration] = useState(1);
  const [promoCode, setPromoCode] = useState("");
  const [promoValidation, setPromoValidation] = useState<{
    isValid: boolean | null;
    message: string;
    discountRate: number;
  }>({ isValid: null, message: "", discountRate: 0 });
  const [validatingPromo, setValidatingPromo] = useState(false);
  const [createdOrder, setCreatedOrder] = useState<any>(null);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [activeLygos, setActiveLygos] = useState(false);
  const [showFullDescription, setShowFullDescription] = useState(false);

  const [formData, setFormData] = useState<OrderFormData>({
    firstName: "",
    lastName: "",
    email: user?.email || "",
    countryCode: "+221",
    phoneNumber: "",
    duration: 1,
    promoCode: "",
  });

  useEffect(() => {
    const loadFont = () => {
      const link = document.createElement("link");
      link.href = "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap";
      link.rel = "stylesheet";
      document.head.appendChild(link);
    };
    loadFont();
  }, []);

  useEffect(() => {
    fetchProduct();
    fetchPaymentGateways();
  }, [id]);

  const fetchPaymentGateways = async () => {
    try {
      const response = await fetch("/api/payment-gateways");
      if (response.ok) {
        const data = await response.json();
        const lygos = data.find((g: any) => g.gateway_name === 'lygos');
        setActiveLygos(lygos?.is_enabled === 1);
      }
    } catch (error) {
      console.error("Failed to fetch payment gateways:", error);
    }
  };

  useEffect(() => {
    if (user?.email) {
      setFormData(prev => ({ ...prev, email: user.email || "" }));
    }
  }, [user]);

  // Check for saved affiliate cookie on mount
  useEffect(() => {
    const savedPromoCode = getAffiliateCookie();
    if (savedPromoCode && !promoCode) {
      setPromoCode(savedPromoCode);
      validatePromoCodeWithCode(savedPromoCode);
    }
  }, []);

  const fetchProduct = async () => {
    try {
      setLoading(true);
      const response = await fetch(`/api/products/${id}`);
      const data = await response.json();
      setProduct(data);
      
      // Parse price options from new system or fallback to old
      let options: PriceOption[] = [];
      
      if (data.price_options) {
        try {
          options = JSON.parse(data.price_options);
        } catch (e) {
          console.error("Failed to parse price_options:", e);
        }
      }
      
      // Fallback to old system if no price_options
      if (options.length === 0) {
        if (data.price_1_months) options.push({ months: 1, price: data.price_1_months.toString() });
        if (data.price_3_months) options.push({ months: 3, price: data.price_3_months.toString() });
        if (data.price_6_months) options.push({ months: 6, price: data.price_6_months.toString() });
      }
      
      setPriceOptions(options);
      
      // Set default duration to first available option
      if (options.length > 0) {
        setSelectedDuration(options[0].months);
      }
    } catch (error) {
      console.error("Failed to fetch product:", error);
    } finally {
      setLoading(false);
    }
  };

  const validatePromoCodeWithCode = async (code: string) => {
    if (!code.trim()) {
      setPromoValidation({ isValid: null, message: "", discountRate: 0 });
      return;
    }

    setValidatingPromo(true);

    try {
      const response = await fetch(`/api/affiliates/validate?code=${code}`);
      const data = await response.json();

      if (response.ok && data.valid) {
        // Determine the actual discount rate
        let actualDiscountRate = data.discountRate;
        
        // If not an exceptional code (discountRate is 0), use product's discount rate
        if (!data.isExceptional && product) {
          actualDiscountRate = Number(product.client_discount_rate || 0);
        }
        
        setPromoValidation({
          isValid: true,
          message: `Code promo valide ! Réduction de ${(actualDiscountRate * 100).toFixed(0)}% appliquée`,
          discountRate: actualDiscountRate,
        });
        info(`Code promo ${code} appliqué automatiquement`);
      } else {
        setPromoCode("");
        setPromoValidation({
          isValid: false,
          message: "Code promo invalide ou inactif - Tarif normal appliqué",
          discountRate: 0,
        });
      }
    } catch (err) {
      console.error("Failed to validate promo code:", err);
      setPromoCode("");
      setPromoValidation({
        isValid: false,
        message: "Erreur lors de la validation du code - Tarif normal appliqué",
        discountRate: 0,
      });
    } finally {
      setValidatingPromo(false);
    }
  };

  const validatePromoCode = async () => {
    await validatePromoCodeWithCode(promoCode);
  };

  const calculatePrice = () => {
    if (!product) return { original: 0, discount: 0, final: 0 };
    
    // Find the selected price option
    const selectedOption = priceOptions.find(opt => opt.months === selectedDuration);
    const originalPrice = selectedOption ? parseFloat(selectedOption.price) : 0;

    const discountRate = promoValidation.isValid ? promoValidation.discountRate : 0;
    const discountAmount = discountRate > 0 ? originalPrice * discountRate : 0;
    const finalPrice = originalPrice - discountAmount;

    return {
      original: originalPrice,
      discount: discountAmount,
      final: finalPrice,
    };
  };

  const calculateSavings = (months: number, price: number): number => {
    // Find 1-month price as baseline
    const oneMonthOption = priceOptions.find(opt => opt.months === 1);
    if (!oneMonthOption || months === 1) return 0;
    
    const oneMonthPrice = parseFloat(oneMonthOption.price);
    const expectedPrice = oneMonthPrice * months;
    const savings = ((expectedPrice - price) / expectedPrice) * 100;
    
    return Math.round(savings);
  };

  const handleOrderClick = async () => {
    // Validate promo code if entered
    if (promoCode.trim()) {
      setValidatingPromo(true);
      await validatePromoCode();
      setValidatingPromo(false);
      
      // Wait a moment for validation to complete
      setTimeout(() => {
        setFormData({ ...formData, duration: selectedDuration, promoCode: promoCode });
        
        // Check if we should use Lygos
        if (activeLygos) {
          handleLygosRedirect();
        } else {
          setShowOrderModal(true);
        }
      }, 500);
    } else {
      setFormData({ ...formData, duration: selectedDuration, promoCode: "" });
      
      // Check if we should use Lygos
      if (activeLygos) {
        handleLygosRedirect();
      } else {
        setShowOrderModal(true);
      }
    }
  };

  const handleLygosRedirect = async () => {
    if (!product) return;
    
    // Find the selected price option with Lygos link
    const selectedOption = priceOptions.find(opt => opt.months === selectedDuration);
    
    if (!selectedOption?.lygos_payment_link) {
      error("Lien de paiement Lygos non configuré pour cette option");
      return;
    }
    
    try {
      setSubmitting(true);
      
      // Create order first
      const priceInfo = calculatePrice();
      const response = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          product_id: product.id,
          customer_email: user?.email || formData.email,
          first_name: formData.firstName || user?.email?.split('@')[0] || '',
          last_name: formData.lastName || '',
          phone_number: formData.phoneNumber ? `${formData.countryCode}${formData.phoneNumber}` : '',
          duration_months: selectedDuration,
          affiliate_code: promoCode || undefined,
          amount: priceInfo.final,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        error(errorData.error || "Erreur lors de la création de la commande");
        setSubmitting(false);
        return;
      }

      const order = await response.json();
      
      // Redirect to Lygos payment link with order ID if possible
      let lygosLink = selectedOption.lygos_payment_link;
      
      // Try to append order_id to the link if it supports query parameters
      try {
        const url = new URL(lygosLink);
        url.searchParams.set('order_id', order.id.toString());
        url.searchParams.set('customer_email', user?.email || formData.email);
        lygosLink = url.toString();
      } catch (e) {
        // If URL parsing fails, just use the link as is
        console.warn("Could not append order_id to Lygos link:", e);
      }
      
      info("Redirection vers la page de paiement Lygos...");
      
      // Store order info in localStorage for post-payment redirect
      localStorage.setItem('recent_order', JSON.stringify({
        email: user?.email || formData.email,
        order_id: order.id,
        product_name: product.name,
      }));
      
      // Redirect to Lygos
      setTimeout(() => {
        window.location.href = lygosLink;
      }, 1000);
      
    } catch (err) {
      console.error("Failed to create order:", err);
      error("Erreur lors de la création de la commande");
      setSubmitting(false);
    }
  };

  const handleCloseModal = () => {
    setShowOrderModal(false);
  };

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!product) return;

    setSubmitting(true);

    try {
      const priceInfo = calculatePrice();
      
      const response = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          product_id: product.id,
          customer_email: formData.email,
          first_name: formData.firstName,
          last_name: formData.lastName,
          phone_number: `${formData.countryCode}${formData.phoneNumber}`,
          duration_months: selectedDuration,
          affiliate_code: promoCode || undefined,
          amount: priceInfo.final,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        error(errorData.error || "Erreur lors de la création de la commande");
        setSubmitting(false);
        return;
      }

      const order = await response.json();
      
      // Store order and show payment modal
      setCreatedOrder(order);
      setShowOrderModal(false);
      setShowPaymentModal(true);
      setSubmitting(false);
    } catch (err) {
      console.error("Failed to submit order:", err);
      error("Erreur lors de la création de la commande");
      setSubmitting(false);
    }
  };

  const handlePaymentSuccess = () => {
    setShowPaymentModal(false);
    
    // Store order info in localStorage for post-payment redirect
    if (createdOrder && product) {
      localStorage.setItem('recent_order', JSON.stringify({
        email: formData.email,
        order_id: createdOrder.id,
        product_name: product.name,
      }));
    }
    
    // Redirect to auth or dashboard based on user status
    if (!user) {
      success("Paiement réussi! Veuillez vous connecter pour accéder à vos achats.");
      setTimeout(() => {
        window.location.href = `/auth/post-purchase?email=${encodeURIComponent(formData.email)}`;
      }, 2000);
    } else {
      success("Paiement réussi! Vos accès seront bientôt disponibles.");
      setTimeout(() => {
        navigate("/dashboard");
      }, 2000);
    }
  };

  const handlePaymentCancel = () => {
    setShowPaymentModal(false);
    setCreatedOrder(null);
    setShowOrderModal(true);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: 'var(--bg-primary)' }}>
        <div className="w-12 h-12 border-4 rounded-full animate-spin" style={{ borderColor: 'var(--gray-200)', borderTopColor: 'var(--primary)' }}></div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: 'var(--bg-primary)' }}>
        <div className="text-center">
          <p className="text-xl mb-4" style={{ color: 'var(--text-primary)' }}>Produit introuvable</p>
          <button
            onClick={() => navigate("/catalog")}
            className="px-6 py-3 rounded-xl font-semibold text-white"
            style={{ backgroundColor: 'var(--primary)' }}
          >
            Retour au catalogue
          </button>
        </div>
      </div>
    );
  }

  const features = product.features ? JSON.parse(product.features) : [];

  // Mock testimonials - In production, fetch from API
  const testimonials = [
    {
      customerName: "Aminata Diallo",
      rating: 5,
      comment: "Formation excellente ! J'ai beaucoup appris et le contenu est très bien structuré. Je recommande vivement."
    },
    {
      customerName: "Ibrahim Sow",
      rating: 5,
      comment: "Très bon rapport qualité-prix. Le service client est réactif et les accès sont livrés rapidement."
    },
    {
      customerName: "Fatou Ndiaye",
      rating: 4,
      comment: "Contenu de qualité adapté au marché africain. Les paiements par Mobile Money facilitent beaucoup les choses."
    }
  ];

  return (
    <div className="min-h-screen" style={{ fontFamily: "'Outfit', sans-serif", backgroundColor: 'var(--bg-primary)' }}>
      <SEOHead
        title={product.name}
        description={product.description || `Découvrez ${product.name} - Formation premium sur Martama`}
        image={product.image_url || undefined}
        url={`https://martama.mocha.app/products/${product.id}`}
        type="product"
      />
      <ToastContainer toasts={toasts} onRemove={removeToast} />
      <AnnouncementBar />
      <Header showBackButton onBack={() => navigate("/catalog")} />

      <main className="px-4 sm:px-6 py-8 sm:py-12 max-w-4xl mx-auto pb-24">
        <div className="space-y-6 sm:space-y-8">
          {/* Product Image and Name */}
          <div>
            {product.image_url ? (
              <div className="aspect-video w-full rounded-3xl overflow-hidden shadow-2xl mb-6" style={{ background: 'linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%)' }}>
                <img
                  src={product.image_url}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
              </div>
            ) : (
              <div className="aspect-video w-full rounded-3xl shadow-2xl flex items-center justify-center mb-6" style={{ background: 'linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%)' }}>
                <Tag className="w-24 h-24 text-white opacity-30" />
              </div>
            )}
            
            <div className="inline-block px-3 sm:px-4 py-1.5 rounded-full mb-3 border" style={{ backgroundColor: 'var(--gray-100)', borderColor: 'var(--border-color)' }}>
              <span className="text-xs sm:text-sm font-medium capitalize" style={{ color: 'var(--text-primary)' }}>{product.category}</span>
            </div>
            
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold mb-3 sm:mb-4" style={{ color: 'var(--text-primary)' }}>{product.name}</h1>
            
            <div>
              <p className="text-base sm:text-lg leading-relaxed whitespace-pre-line" style={{ color: 'var(--text-secondary)' }}>
                {showFullDescription || !product.description || product.description.length <= 200
                  ? product.description
                  : `${product.description.substring(0, 200)}...`}
              </p>
              {product.description && product.description.length > 200 && (
                <button
                  onClick={() => setShowFullDescription(!showFullDescription)}
                  className="mt-2 text-sm font-semibold hover:underline"
                  style={{ color: 'var(--primary)' }}
                >
                  {showFullDescription ? '← Voir moins' : 'Voir plus →'}
                </button>
              )}
            </div>
          </div>

          {/* Features */}
          {features.length > 0 && (
            <div className="rounded-2xl p-6 border" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
              <h3 className="text-sm font-semibold mb-4 uppercase tracking-wide" style={{ color: 'var(--text-muted)' }}>
                Inclus
              </h3>
              <div className="grid md:grid-cols-2 gap-3">
                {features.map((feature: string, index: number) => (
                  <div key={index} className="flex items-start gap-3">
                    <div className="w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5" style={{ backgroundColor: 'var(--success)' }}>
                      <Check className="w-3 h-3 text-white" />
                    </div>
                    <span style={{ color: 'var(--text-secondary)' }}>{feature}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Choisir la durée */}
          {priceOptions.length > 0 && (
            <div className="rounded-2xl border p-6" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
              <h3 className="text-xl font-bold mb-4" style={{ color: 'var(--text-primary)' }}>
                Choisir la durée
              </h3>
              
              <div className="space-y-3">
                {priceOptions.map((option) => {
                  const price = parseFloat(option.price);
                  const savings = calculateSavings(option.months, price);
                  const pricePerMonth = Math.round(price / option.months);
                  
                  return (
                    <button
                      key={option.months}
                      onClick={() => setSelectedDuration(option.months)}
                      className="w-full p-4 rounded-xl border-2 transition-all"
                      style={{ 
                        backgroundColor: selectedDuration === option.months ? 'rgba(139, 92, 246, 0.05)' : 'var(--bg-primary)',
                        borderColor: selectedDuration === option.months ? 'var(--primary)' : 'var(--border-color)'
                      }}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="w-5 h-5 rounded-full border-2 flex items-center justify-center" style={{ borderColor: selectedDuration === option.months ? 'var(--primary)' : 'var(--border-color)' }}>
                            {selectedDuration === option.months && (
                              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: 'var(--primary)' }}></div>
                            )}
                          </div>
                          <div className="text-left">
                            <span className="font-bold" style={{ color: 'var(--text-primary)' }}>
                              {option.months} Mois
                            </span>
                            {savings > 0 && (
                              <div className="text-xs font-semibold" style={{ color: 'var(--success)' }}>
                                Économisez {savings}%
                              </div>
                            )}
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-xl font-bold" style={{ color: 'var(--primary)' }}>
                            {price.toLocaleString()} FCFA
                          </div>
                          <div className="text-xs" style={{ color: 'var(--text-muted)' }}>
                            {pricePerMonth.toLocaleString()} FCFA/mois
                          </div>
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Code Promo */}
          <div className="rounded-2xl border p-4 sm:p-6" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
            <label className="block text-sm font-semibold mb-3 uppercase tracking-wide" style={{ color: 'var(--text-muted)' }}>
              Code Promo (optionnel)
            </label>
            <div className="flex flex-col sm:flex-row gap-2">
              <input
                type="text"
                value={promoCode}
                onChange={(e) => {
                  setPromoCode(e.target.value.toUpperCase());
                  setPromoValidation({ isValid: null, message: "", discountRate: 0 });
                }}
                placeholder="Entrez votre code promo"
                className="flex-1 px-4 py-3 rounded-xl border-2 focus:outline-none transition-colors text-base"
                style={{ 
                  borderColor: 'var(--border-color)', 
                  backgroundColor: 'var(--bg-primary)', 
                  color: 'var(--text-primary)',
                  '--tw-ring-color': 'var(--primary)'
                } as any}
              />
              <button
                type="button"
                onClick={validatePromoCode}
                disabled={!promoCode.trim() || validatingPromo}
                className="px-6 py-3 rounded-xl font-semibold text-white transition-all disabled:opacity-50 whitespace-nowrap text-base"
                style={{ backgroundColor: 'var(--primary)' }}
              >
                {validatingPromo ? "..." : "Vérifier"}
              </button>
            </div>
            
            {promoValidation.message && (
              <div className={`mt-3 p-3 rounded-xl border ${
                promoValidation.isValid 
                  ? 'bg-green-500/10 border-green-500/30' 
                  : 'bg-red-500/10 border-red-500/30'
              }`}>
                <p className={`text-sm font-medium ${
                  promoValidation.isValid ? 'text-green-600' : 'text-red-600'
                }`}>
                  {promoValidation.message}
                </p>
              </div>
            )}
          </div>

          {/* Code Promo Status Banner */}
          {promoValidation.isValid && (
            <div className="rounded-2xl p-4 border-2 flex items-center gap-3 animate-pulse" style={{ backgroundColor: 'rgba(16, 185, 129, 0.1)', borderColor: 'var(--success)' }}>
              <div className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0" style={{ backgroundColor: 'var(--success)' }}>
                <Check className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1">
                <p className="font-bold" style={{ color: 'var(--success)' }}>Code promo "{promoCode}" appliqué !</p>
                <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
                  Vous économisez {calculatePrice().discount.toLocaleString()} FCFA ({(promoValidation.discountRate * 100).toFixed(0)}% de réduction)
                </p>
              </div>
            </div>
          )}

          {/* Total à payer */}
          <div className="rounded-2xl p-4 sm:p-6 border" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
            {promoValidation.isValid && (
              <div className="mb-4 pb-4 border-b" style={{ borderColor: 'var(--border-color)' }}>
                <div className="flex items-center justify-between text-sm mb-2">
                  <span style={{ color: 'var(--text-secondary)' }}>Prix original</span>
                  <span className="font-semibold line-through" style={{ color: 'var(--text-muted)' }}>
                    {calculatePrice().original.toLocaleString()} FCFA
                  </span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span style={{ color: 'var(--success)' }}>Réduction ({(promoValidation.discountRate * 100).toFixed(0)}%)</span>
                  <span className="font-semibold" style={{ color: 'var(--success)' }}>
                    -{calculatePrice().discount.toLocaleString()} FCFA
                  </span>
                </div>
              </div>
            )}
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
              <span className="text-lg sm:text-xl font-bold" style={{ color: 'var(--text-primary)' }}>
                Total à payer
              </span>
              <span className="text-2xl sm:text-3xl font-bold" style={{ color: 'var(--primary)' }}>
                {calculatePrice().final.toLocaleString()} FCFA
              </span>
            </div>
          </div>

          {/* WhatsApp Support */}
          <div className="rounded-2xl border p-4 flex items-center gap-3" style={{ 
            backgroundColor: 'rgba(37, 211, 102, 0.1)', 
            borderColor: 'rgba(37, 211, 102, 0.3)'
          }}>
            <MessageCircle className="w-6 h-6 flex-shrink-0" style={{ color: '#25D366' }} />
            <div className="flex-1">
              <p className="text-sm font-semibold mb-1" style={{ color: 'var(--text-primary)' }}>
                Une question avant de commander ?
              </p>
              <a
                href="https://wa.me/22951661357?text=Bonjour%2C%20j%27ai%20une%20question%20concernant%20ce%20produit"
                target="_blank"
                rel="noopener noreferrer"
                className="text-sm font-medium hover:underline"
                style={{ color: '#25D366' }}
              >
                Contactez-nous sur WhatsApp : +229 51 66 13 57
              </a>
            </div>
          </div>

          {/* Commander Button */}
          <button 
            onClick={handleOrderClick}
            disabled={validatingPromo || submitting}
            className="w-full py-4 rounded-2xl font-bold text-lg text-white hover:opacity-90 transition-all duration-300 shadow-lg hover:shadow-xl disabled:opacity-50" 
            style={{ backgroundColor: 'var(--primary)' }}
          >
            {validatingPromo ? "Vérification en cours..." : submitting ? "Redirection en cours..." : "Commander maintenant"}
          </button>
          
          {activeLygos && (
            <div className="text-center">
              <p className="text-sm" style={{ color: 'var(--text-muted)' }}>
                Paiement sécurisé via Lygos
              </p>
            </div>
          )}

          {/* Testimonials Section */}
          {testimonials.length > 0 && (
            <div className="mt-12">
              <h3 className="text-2xl font-bold mb-6" style={{ color: 'var(--text-primary)' }}>
                Avis de nos clients
              </h3>
              <div className="grid md:grid-cols-3 gap-4">
                {testimonials.map((testimonial, index) => (
                  <Testimonial
                    key={index}
                    customerName={testimonial.customerName}
                    rating={testimonial.rating}
                    comment={testimonial.comment}
                  />
                ))}
              </div>
            </div>
          )}
        </div>
      </main>

      <Footer />

      {/* Order Modal - Personal Information Only - Mobile Optimized */}
      {showOrderModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-2xl w-full my-8 max-h-[90vh] overflow-y-auto" style={{ backgroundColor: 'var(--bg-primary)' }}>
            <div className="p-6 md:p-8">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>
                  Informations personnelles
                </h2>
                <button
                  onClick={handleCloseModal}
                  className="p-2 hover:bg-gray-100 rounded-xl transition-colors"
                >
                  <X className="w-6 h-6" style={{ color: 'var(--text-primary)' }} />
                </button>
              </div>

              <form onSubmit={handleSubmitOrder} className="space-y-6">
                {/* First Name and Last Name */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-primary)' }}>
                      Prénom <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.firstName}
                      onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border-2 focus:outline-none transition-colors text-base"
                      style={{ 
                        borderColor: 'var(--border-color)', 
                        backgroundColor: 'var(--bg-secondary)', 
                        color: 'var(--text-primary)',
                        '--tw-ring-color': 'var(--primary)'
                      } as any}
                      autoComplete="given-name"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-primary)' }}>
                      Nom <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.lastName}
                      onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border-2 focus:outline-none transition-colors text-base"
                      style={{ 
                        borderColor: 'var(--border-color)', 
                        backgroundColor: 'var(--bg-secondary)', 
                        color: 'var(--text-primary)',
                        '--tw-ring-color': 'var(--primary)'
                      } as any}
                      autoComplete="family-name"
                    />
                  </div>
                </div>

                {/* Email */}
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-primary)' }}>
                    Adresse email <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl border-2 focus:outline-none transition-colors"
                    style={{ 
                      borderColor: 'var(--border-color)', 
                      backgroundColor: 'var(--bg-secondary)', 
                      color: 'var(--text-primary)',
                      '--tw-ring-color': 'var(--primary)'
                    } as any}
                  />
                </div>

                {/* Phone Number with Country Code */}
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-primary)' }}>
                    Numéro de téléphone <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <div className="flex gap-2">
                      <div className="relative">
                        <button
                          type="button"
                          onClick={() => setShowCountryDropdown(!showCountryDropdown)}
                          className="flex items-center gap-2 px-4 py-3 rounded-xl border-2 min-w-[120px] justify-between"
                          style={{ borderColor: 'var(--border-color)', backgroundColor: 'var(--bg-secondary)' }}
                        >
                          <span>{countryCodes.find(c => c.code === formData.countryCode)?.flag}</span>
                          <span className="font-medium" style={{ color: 'var(--text-primary)' }}>{formData.countryCode}</span>
                          <ChevronDown className="w-4 h-4" />
                        </button>
                        
                        {showCountryDropdown && (
                          <div className="absolute top-full left-0 mt-2 w-72 rounded-xl border-2 shadow-lg z-50 max-h-64 overflow-y-auto"
                               style={{ borderColor: 'var(--border-color)', backgroundColor: 'var(--bg-primary)' }}>
                            {countryCodes.map((country) => (
                              <button
                                key={country.code}
                                type="button"
                                onClick={() => {
                                  setFormData({ ...formData, countryCode: country.code });
                                  setShowCountryDropdown(false);
                                }}
                                className="w-full flex items-center gap-3 px-4 py-3 hover:bg-gray-100 transition-colors text-left"
                              >
                                <span className="text-xl">{country.flag}</span>
                                <span className="flex-1" style={{ color: 'var(--text-primary)' }}>{country.country}</span>
                                <span className="font-medium" style={{ color: 'var(--text-muted)' }}>{country.code}</span>
                              </button>
                            ))}
                          </div>
                        )}
                      </div>
                      
                      <input
                        type="tel"
                        required
                        value={formData.phoneNumber}
                        onChange={(e) => setFormData({ ...formData, phoneNumber: e.target.value })}
                        placeholder="XX XXX XX XX"
                        className="flex-1 px-4 py-3 rounded-xl border-2 focus:outline-none transition-colors text-base"
                        style={{ 
                          borderColor: 'var(--border-color)', 
                          backgroundColor: 'var(--bg-secondary)', 
                          color: 'var(--text-primary)',
                          '--tw-ring-color': 'var(--primary)'
                        } as any}
                        autoComplete="tel"
                        inputMode="tel"
                      />
                    </div>
                  </div>
                </div>

                {/* Submit Button */}
                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full py-4 rounded-2xl font-bold text-lg text-white transition-all disabled:opacity-50"
                  style={{ backgroundColor: 'var(--success)' }}
                >
                  {submitting ? "Traitement..." : "Passer au paiement"}
                </button>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Payment Modal with FedaPay Widget */}
      {showPaymentModal && createdOrder && product && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-3xl max-w-md w-full p-8" style={{ backgroundColor: 'var(--bg-primary)' }}>
            <div className="text-center mb-6">
              <h2 className="text-2xl font-bold mb-2" style={{ color: 'var(--text-primary)' }}>
                Finaliser le paiement
              </h2>
              <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
                {product.name} - {selectedDuration} mois
              </p>
              <p className="text-3xl font-bold mt-4" style={{ color: 'var(--primary)' }}>
                {calculatePrice().final.toLocaleString()} FCFA
              </p>
            </div>

            <FedaPayCheckout
              transactionDetails={{
                amount: calculatePrice().final,
                description: `${product.name} - ${selectedDuration} mois`,
                orderId: createdOrder.id,
                customerEmail: formData.email,
                firstName: formData.firstName,
                lastName: formData.lastName,
                phoneNumber: formData.phoneNumber,
                countryCode: formData.countryCode,
              }}
              onSuccess={handlePaymentSuccess}
              onCancel={handlePaymentCancel}
            />

            <button
              onClick={handlePaymentCancel}
              className="w-full mt-4 py-3 rounded-xl font-medium transition-colors"
              style={{ color: 'var(--text-muted)' }}
            >
              Annuler
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
