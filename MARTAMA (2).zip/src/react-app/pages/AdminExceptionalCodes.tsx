import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { ArrowLeft, Plus, Edit2, Trash2, Power, PowerOff } from "lucide-react";

interface ExceptionalCode {
  id: number;
  affiliate_id: number;
  affiliate_promo_code: string;
  affiliate_email: string;
  code: string;
  discount_rate: number;
  commission_rate: number;
  applies_to: string;
  target_ids: string | null;
  start_date: string | null;
  end_date: string | null;
  is_active: number;
  created_at: string;
}

interface Affiliate {
  id: number;
  promo_code: string;
  email: string;
}

export default function AdminExceptionalCodes() {
  const navigate = useNavigate();
  const [codes, setCodes] = useState<ExceptionalCode[]>([]);
  const [affiliates, setAffiliates] = useState<Affiliate[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    affiliate_id: 0,
    code: "",
    discount_rate: 0.42,
    commission_rate: 0.30,
    applies_to: "all",
    target_ids: "",
    start_date: "",
    end_date: "",
    is_active: true,
  });

  useEffect(() => {
    const loadFont = () => {
      const link = document.createElement("link");
      link.href = "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap";
      link.rel = "stylesheet";
      document.head.appendChild(link);
    };
    loadFont();
  }, []);

  useEffect(() => {
    fetchCodes();
    fetchAffiliates();
  }, []);

  const fetchCodes = async () => {
    try {
      setLoading(true);
      const response = await fetch("/api/admin/exceptional-codes");
      
      if (response.status === 403) {
        navigate("/");
        return;
      }
      
      const data = await response.json();
      setCodes(data);
    } catch (error) {
      console.error("Failed to fetch codes:", error);
    } finally {
      setLoading(false);
    }
  };

  const fetchAffiliates = async () => {
    try {
      const response = await fetch("/api/admin/affiliates");
      if (response.ok) {
        const data = await response.json();
        setAffiliates(data);
      }
    } catch (error) {
      console.error("Failed to fetch affiliates:", error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const url = editingId 
        ? `/api/admin/exceptional-codes/${editingId}`
        : "/api/admin/exceptional-codes";
      
      const method = editingId ? "PUT" : "POST";
      
      const response = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });
      
      if (response.ok) {
        await fetchCodes();
        setShowForm(false);
        setEditingId(null);
        resetForm();
      } else {
        const error = await response.json();
        alert(error.error || "Erreur lors de l'enregistrement");
      }
    } catch (error) {
      console.error("Failed to save code:", error);
    }
  };

  const resetForm = () => {
    setFormData({
      affiliate_id: 0,
      code: "",
      discount_rate: 0.42,
      commission_rate: 0.30,
      applies_to: "all",
      target_ids: "",
      start_date: "",
      end_date: "",
      is_active: true,
    });
  };

  const handleEdit = (code: ExceptionalCode) => {
    setEditingId(code.id);
    setFormData({
      affiliate_id: code.affiliate_id,
      code: code.code,
      discount_rate: code.discount_rate,
      commission_rate: code.commission_rate,
      applies_to: code.applies_to,
      target_ids: code.target_ids || "",
      start_date: code.start_date || "",
      end_date: code.end_date || "",
      is_active: code.is_active === 1,
    });
    setShowForm(true);
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Êtes-vous sûr de vouloir supprimer ce code ?")) return;
    
    try {
      await fetch(`/api/admin/exceptional-codes/${id}`, {
        method: "DELETE",
      });
      await fetchCodes();
    } catch (error) {
      console.error("Failed to delete code:", error);
    }
  };

  const handleToggleActive = async (id: number, currentStatus: number) => {
    try {
      const code = codes.find(c => c.id === id);
      if (!code) return;
      
      await fetch(`/api/admin/exceptional-codes/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...code,
          is_active: currentStatus === 1 ? 0 : 1,
        }),
      });
      
      await fetchCodes();
    } catch (error) {
      console.error("Failed to toggle code:", error);
    }
  };

  return (
    <div className="min-h-screen" style={{ fontFamily: "'Outfit', sans-serif", backgroundColor: 'var(--bg-primary)' }}>
      <header className="px-6 py-6 max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate("/admin/affiliates")}
              className="p-2 hover:opacity-80 rounded-xl transition-opacity"
              style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)' }}
            >
              <ArrowLeft className="w-6 h-6" style={{ color: 'var(--primary)' }} />
            </button>
            <div>
              <h1 className="text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>
                Codes Exceptionnels Affiliés
              </h1>
              <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
                Gérez les codes promotionnels spéciaux avec réductions et commissions personnalisées
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              setShowForm(true);
              setEditingId(null);
              resetForm();
            }}
            className="flex items-center gap-2 px-6 py-3 rounded-xl font-semibold transition-all text-white"
            style={{ backgroundColor: 'var(--primary)' }}
          >
            <Plus className="w-5 h-5" />
            Nouveau Code
          </button>
        </div>
      </header>

      <main className="px-6 pb-12 max-w-7xl mx-auto">
        {loading ? (
          <div className="text-center py-20">
            <div className="inline-block w-12 h-12 border-4 rounded-full animate-spin" style={{ borderColor: 'var(--gray-200)', borderTopColor: 'var(--primary)' }}></div>
          </div>
        ) : (
          <div className="space-y-4">
            {codes.map((code) => (
              <div
                key={code.id}
                className="rounded-2xl border p-6"
                style={{ 
                  backgroundColor: 'var(--bg-secondary)', 
                  borderColor: code.is_active ? 'var(--primary)' : 'var(--border-color)',
                  borderWidth: code.is_active ? '2px' : '1px'
                }}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <span className="text-2xl font-mono font-bold" style={{ color: 'var(--primary)' }}>
                        {code.code}
                      </span>
                      {code.is_active === 1 && (
                        <span className="px-3 py-1 rounded-full text-xs font-semibold bg-green-500/20 text-green-600">
                          Actif
                        </span>
                      )}
                    </div>
                    <div className="text-sm mb-3" style={{ color: 'var(--text-secondary)' }}>
                      Affilié: <span className="font-semibold">{code.affiliate_email}</span> ({code.affiliate_promo_code})
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div>
                        <span className="text-xs" style={{ color: 'var(--text-muted)' }}>Réduction Client</span>
                        <div className="font-bold text-lg" style={{ color: 'var(--success)' }}>
                          {(code.discount_rate * 100).toFixed(0)}%
                        </div>
                      </div>
                      <div>
                        <span className="text-xs" style={{ color: 'var(--text-muted)' }}>Commission Affilié</span>
                        <div className="font-bold text-lg" style={{ color: 'var(--primary)' }}>
                          {(code.commission_rate * 100).toFixed(0)}%
                        </div>
                      </div>
                      <div>
                        <span className="text-xs" style={{ color: 'var(--text-muted)' }}>Portée</span>
                        <div className="font-semibold capitalize" style={{ color: 'var(--text-primary)' }}>
                          {code.applies_to === 'all' ? 'Tous les produits' : code.applies_to}
                        </div>
                      </div>
                      <div>
                        <span className="text-xs" style={{ color: 'var(--text-muted)' }}>Période</span>
                        <div className="font-semibold text-sm" style={{ color: 'var(--text-primary)' }}>
                          {code.start_date || code.end_date ? 
                            `${code.start_date ? new Date(code.start_date).toLocaleDateString('fr-FR') : '∞'} - ${code.end_date ? new Date(code.end_date).toLocaleDateString('fr-FR') : '∞'}` 
                            : 'Permanent'}
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleToggleActive(code.id, code.is_active)}
                      className="p-2 rounded-xl transition-colors"
                      style={{ 
                        backgroundColor: code.is_active ? 'rgba(239, 68, 68, 0.1)' : 'rgba(16, 185, 129, 0.1)',
                        color: code.is_active ? 'var(--error)' : 'var(--success)'
                      }}
                      title={code.is_active ? "Désactiver" : "Activer"}
                    >
                      {code.is_active ? <PowerOff className="w-5 h-5" /> : <Power className="w-5 h-5" />}
                    </button>
                    <button
                      onClick={() => handleEdit(code)}
                      className="p-2 rounded-xl transition-colors"
                      style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)', color: 'var(--primary)' }}
                      title="Modifier"
                    >
                      <Edit2 className="w-5 h-5" />
                    </button>
                    <button
                      onClick={() => handleDelete(code.id)}
                      className="p-2 rounded-xl transition-colors"
                      style={{ backgroundColor: 'rgba(239, 68, 68, 0.1)', color: 'var(--error)' }}
                      title="Supprimer"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
            {codes.length === 0 && (
              <div className="text-center py-20">
                <p className="text-xl mb-4" style={{ color: 'var(--text-muted)' }}>Aucun code exceptionnel</p>
                <button
                  onClick={() => setShowForm(true)}
                  className="px-6 py-3 rounded-xl font-semibold text-white"
                  style={{ backgroundColor: 'var(--primary)' }}
                >
                  Créer le premier code
                </button>
              </div>
            )}
          </div>
        )}
      </main>

      {/* Form Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-6 z-50 overflow-y-auto">
          <div className="rounded-3xl border p-8 max-w-2xl w-full my-8" style={{ backgroundColor: 'var(--bg-primary)', borderColor: 'var(--border-color)' }}>
            <h3 className="text-2xl font-bold mb-6" style={{ color: 'var(--text-primary)' }}>
              {editingId ? "Modifier le code" : "Nouveau code exceptionnel"}
            </h3>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-primary)' }}>
                  Affilié <span className="text-red-500">*</span>
                </label>
                <select
                  required
                  value={formData.affiliate_id}
                  onChange={(e) => setFormData({ ...formData, affiliate_id: Number(e.target.value) })}
                  className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                  style={{ 
                    backgroundColor: 'var(--bg-secondary)', 
                    borderColor: 'var(--border-color)', 
                    color: 'var(--text-primary)',
                    '--tw-ring-color': 'var(--primary)'
                  } as any}
                >
                  <option value={0}>Sélectionnez un affilié</option>
                  {affiliates.map((affiliate) => (
                    <option key={affiliate.id} value={affiliate.id}>
                      {affiliate.email} ({affiliate.promo_code})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-primary)' }}>
                  Code Promo <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={formData.code}
                  onChange={(e) => setFormData({ ...formData, code: e.target.value.toUpperCase() })}
                  placeholder="SPECIAL2024"
                  className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2 font-mono font-bold text-lg"
                  style={{ 
                    backgroundColor: 'var(--bg-secondary)', 
                    borderColor: 'var(--border-color)', 
                    color: 'var(--text-primary)',
                    '--tw-ring-color': 'var(--primary)'
                  } as any}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-primary)' }}>
                    Réduction Client (%) <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="number"
                    required
                    min="0"
                    max="100"
                    step="0.01"
                    value={formData.discount_rate * 100}
                    onChange={(e) => setFormData({ ...formData, discount_rate: Number(e.target.value) / 100 })}
                    className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                    style={{ 
                      backgroundColor: 'var(--bg-secondary)', 
                      borderColor: 'var(--border-color)', 
                      color: 'var(--text-primary)',
                      '--tw-ring-color': 'var(--primary)'
                    } as any}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-primary)' }}>
                    Commission Affilié (%) <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="number"
                    required
                    min="0"
                    max="100"
                    step="0.01"
                    value={formData.commission_rate * 100}
                    onChange={(e) => setFormData({ ...formData, commission_rate: Number(e.target.value) / 100 })}
                    className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                    style={{ 
                      backgroundColor: 'var(--bg-secondary)', 
                      borderColor: 'var(--border-color)', 
                      color: 'var(--text-primary)',
                      '--tw-ring-color': 'var(--primary)'
                    } as any}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-primary)' }}>
                    Date de Début
                  </label>
                  <input
                    type="datetime-local"
                    value={formData.start_date}
                    onChange={(e) => setFormData({ ...formData, start_date: e.target.value })}
                    className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                    style={{ 
                      backgroundColor: 'var(--bg-secondary)', 
                      borderColor: 'var(--border-color)', 
                      color: 'var(--text-primary)',
                      '--tw-ring-color': 'var(--primary)'
                    } as any}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-primary)' }}>
                    Date de Fin
                  </label>
                  <input
                    type="datetime-local"
                    value={formData.end_date}
                    onChange={(e) => setFormData({ ...formData, end_date: e.target.value })}
                    className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                    style={{ 
                      backgroundColor: 'var(--bg-secondary)', 
                      borderColor: 'var(--border-color)', 
                      color: 'var(--text-primary)',
                      '--tw-ring-color': 'var(--primary)'
                    } as any}
                  />
                </div>
              </div>

              <div className="flex items-center gap-3">
                <input
                  type="checkbox"
                  id="is_active"
                  checked={formData.is_active}
                  onChange={(e) => setFormData({ ...formData, is_active: e.target.checked })}
                  className="w-5 h-5 rounded"
                  style={{ accentColor: 'var(--primary)' }}
                />
                <label htmlFor="is_active" className="text-sm font-medium" style={{ color: 'var(--text-primary)' }}>
                  Activer ce code immédiatement
                </label>
              </div>

              <div className="flex gap-3">
                <button
                  type="submit"
                  className="flex-1 px-6 py-3 rounded-xl font-semibold transition-all text-white"
                  style={{ backgroundColor: 'var(--primary)' }}
                >
                  {editingId ? "Enregistrer" : "Créer"}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowForm(false);
                    setEditingId(null);
                    resetForm();
                  }}
                  className="px-6 py-3 rounded-xl font-semibold transition-all"
                  style={{ backgroundColor: 'var(--bg-secondary)', color: 'var(--text-primary)' }}
                >
                  Annuler
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
