import { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import Header from "@/react-app/components/Header";
import Footer from "@/react-app/components/Footer";
import ProductCarousel from "@/react-app/components/ProductCarousel";
import TestimonialScreenshot from "@/react-app/components/TestimonialScreenshot";
import SEOHead from "@/react-app/components/SEOHead";
import AnnouncementBar from "@/react-app/components/AnnouncementBar";
import { useAffiliateTracking } from "@/react-app/hooks/useAffiliateTracking";
import { ArrowRight, Zap, Lock, MessageCircle, Users, Package, Award, ChevronRight, Star } from "lucide-react";
import type { Product } from "@/shared/types";

interface Testimonial {
  id: number;
  customer_name: string | null;
  screenshot_url: string;
  is_featured: number;
  display_order: number;
}

export default function Home() {
  const navigate = useNavigate();
  const [allProducts, setAllProducts] = useState<Product[]>([]);
  const [testimonials, setTestimonials] = useState<Testimonial[]>([]);
  const [loading, setLoading] = useState(true);

  // Track affiliate referral from URL
  useAffiliateTracking();

  useEffect(() => {
    const loadFont = () => {
      const link = document.createElement("link");
      link.href = "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap";
      link.rel = "stylesheet";
      document.head.appendChild(link);
    };
    loadFont();
  }, []);

  useEffect(() => {
    fetchAllProducts();
    fetchTestimonials();
  }, []);

  const fetchAllProducts = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/products');
      if (response.ok) {
        const data = await response.json();
        // Limit to first 6 products for carousel
        setAllProducts(data.slice(0, 6));
      }
    } catch (error) {
      console.error('Failed to fetch products:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchTestimonials = async () => {
    try {
      const response = await fetch('/api/testimonials');
      if (response.ok) {
        const data = await response.json();
        setTestimonials(data);
      }
    } catch (error) {
      console.error('Failed to fetch testimonials:', error);
    }
  };

  const handleGetStarted = () => {
    navigate("/catalog");
  };

  return (
    <div className="min-h-screen overflow-hidden" style={{ fontFamily: "'Outfit', sans-serif" }}>
      <SEOHead
        title="Accueil"
        description="Accédez aux meilleurs abonnements premium et formations professionnelles adaptés au marché africain. Netflix, CapCut Pro, ChatGPT et plus encore à prix réduits."
        url="https://martama.mocha.app"
      />
      <AnnouncementBar />
      <Header />

      {/* Hero Section with Animated Background */}
      <section className="relative px-6 py-16 md:py-24 overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0 -z-10">
          {/* Gradient Background with Zoom Animation */}
          <div 
            className="absolute inset-0"
            style={{
              background: 'radial-gradient(circle at 50% 50%, rgba(139, 92, 246, 0.1) 0%, transparent 70%)',
              animation: 'zoomPulse 20s ease-in-out infinite'
            }}
          />
          
          {/* Floating Orbs */}
          <div 
            className="absolute w-96 h-96 rounded-full opacity-20 blur-3xl"
            style={{
              background: 'linear-gradient(135deg, var(--primary) 0%, var(--accent) 100%)',
              top: '10%',
              left: '10%',
              animation: 'float 8s ease-in-out infinite'
            }}
          />
          <div 
            className="absolute w-96 h-96 rounded-full opacity-20 blur-3xl"
            style={{
              background: 'linear-gradient(135deg, var(--accent) 0%, var(--primary) 100%)',
              bottom: '10%',
              right: '10%',
              animation: 'float 10s ease-in-out infinite reverse'
            }}
          />
          
          {/* Grid Pattern */}
          <div 
            className="absolute inset-0 opacity-5"
            style={{
              backgroundImage: `linear-gradient(var(--border-color) 1px, transparent 1px), linear-gradient(90deg, var(--border-color) 1px, transparent 1px)`,
              backgroundSize: '50px 50px',
              animation: 'gridMove 20s linear infinite'
            }}
          />
        </div>

        <div className="max-w-7xl mx-auto relative z-10">
          <div className="text-center max-w-5xl mx-auto">
            {/* Badge with Pulse Animation */}
            <div 
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full mb-8 border animate-fade-in-up" 
              style={{ 
                backgroundColor: 'var(--gray-100)', 
                borderColor: 'var(--border-color)',
                boxShadow: '0 0 20px rgba(139, 92, 246, 0.3)'
              }}
            >
              <span className="w-2.5 h-2.5 rounded-full animate-pulse" style={{ backgroundColor: 'var(--success)' }}></span>
              <span className="text-sm font-semibold" style={{ color: 'var(--text-secondary)' }}>
                Économisez jusqu'à 70% sur vos abonnements premium
              </span>
            </div>
            
            {/* Main Heading with Gradient Animation */}
            <h1 
              className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6 leading-tight animate-fade-in-up" 
              style={{ color: 'var(--text-primary)', animationDelay: '0.1s' }}
            >
              Accédez aux Meilleurs
              <span 
                className="block mt-2 bg-clip-text text-transparent animate-gradient"
                style={{ 
                  background: 'linear-gradient(90deg, var(--primary) 0%, var(--accent) 50%, var(--primary) 100%)',
                  backgroundSize: '200% auto',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent'
                }}
              >
                Abonnements & Formations Premium
              </span>
            </h1>
            
            <p 
              className="text-lg md:text-xl lg:text-2xl mb-4 leading-relaxed font-medium animate-fade-in-up" 
              style={{ color: 'var(--text-secondary)', animationDelay: '0.2s' }}
            >
              Netflix, CapCut Pro, ChatGPT, Formations professionnelles et plus...
            </p>
            
            <p 
              className="text-base md:text-lg mb-10 font-semibold animate-fade-in-up" 
              style={{ color: 'var(--primary)', animationDelay: '0.3s' }}
            >
              Avec des tarifs adaptés au marché africain 🌍
            </p>
            
            {/* CTA Button with Multiple Animations */}
            <button
              onClick={handleGetStarted}
              className="group inline-flex items-center gap-3 px-10 py-5 rounded-2xl text-lg md:text-xl font-bold shadow-2xl hover:shadow-3xl transition-all duration-300 hover:scale-110 text-white relative overflow-hidden animate-fade-in-up"
              style={{ 
                backgroundColor: 'var(--primary)',
                animationDelay: '0.4s',
                animation: 'pulse 2s ease-in-out infinite, fadeInUp 0.8s ease-out forwards'
              }}
            >
              <span className="relative z-10">Découvrir le catalogue</span>
              <ArrowRight className="w-6 h-6 group-hover:translate-x-2 transition-transform relative z-10" />
              {/* Shimmer Effect */}
              <span className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000"></span>
              {/* Glow Effect */}
              <span className="absolute inset-0 rounded-2xl blur-xl opacity-50" style={{ backgroundColor: 'var(--primary)' }}></span>
            </button>
          </div>
        </div>
      </section>

      {/* Popular Services Carousel Section */}
      <section className="px-6 py-16 md:py-20 relative overflow-hidden" style={{ backgroundColor: 'var(--bg-secondary)' }}>
        {/* Decorative Elements */}
        <div 
          className="absolute top-0 right-0 w-64 h-64 rounded-full opacity-10 blur-3xl"
          style={{
            background: 'linear-gradient(135deg, var(--primary) 0%, var(--accent) 100%)',
            animation: 'float 6s ease-in-out infinite'
          }}
        />
        
        <div className="max-w-7xl mx-auto relative z-10">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 mb-4">
              <Star className="w-6 h-6 animate-spin-slow" style={{ color: 'var(--accent)' }} />
              <h2 
                className="text-3xl md:text-4xl lg:text-5xl font-bold animate-fade-in-up" 
                style={{ color: 'var(--text-primary)' }}
              >
                Nos Services Populaires
              </h2>
              <Star className="w-6 h-6 animate-spin-slow" style={{ color: 'var(--accent)' }} />
            </div>
            <p 
              className="text-lg md:text-xl animate-fade-in-up" 
              style={{ color: 'var(--text-secondary)', animationDelay: '0.1s' }}
            >
              🎮 Transformez votre expérience digitale en aventure premium
            </p>
          </div>

          {loading ? (
            <div className="text-center py-20">
              <div 
                className="inline-block w-12 h-12 border-4 rounded-full animate-spin" 
                style={{ borderColor: 'var(--gray-200)', borderTopColor: 'var(--primary)' }}
              ></div>
            </div>
          ) : allProducts.length > 0 ? (
            <>
              <ProductCarousel products={allProducts} />
              
              <div className="text-center mt-12 animate-fade-in-up" style={{ animationDelay: '0.4s' }}>
                <button
                  onClick={handleGetStarted}
                  className="group inline-flex items-center gap-2 px-8 py-4 rounded-2xl text-lg font-bold transition-all duration-300 hover:scale-105 border-2 relative overflow-hidden"
                  style={{ 
                    backgroundColor: 'transparent',
                    color: 'var(--primary)',
                    borderColor: 'var(--primary)'
                  }}
                >
                  <span className="relative z-10">Voir tous les services</span>
                  <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform relative z-10" />
                  {/* Hover Fill Effect */}
                  <span 
                    className="absolute inset-0 opacity-0 group-hover:opacity-10 transition-opacity duration-300"
                    style={{ backgroundColor: 'var(--primary)' }}
                  ></span>
                </button>
              </div>
            </>
          ) : (
            <div className="text-center py-12">
              <p className="text-lg" style={{ color: 'var(--text-secondary)' }}>
                Nos services arrivent bientôt... 🚀
              </p>
            </div>
          )}
        </div>
      </section>

      {/* Why Choose Martama Section */}
      <section className="px-6 py-16 md:py-20 relative" style={{ backgroundColor: 'var(--bg-primary)' }}>
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16 animate-fade-in-up">
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4" style={{ color: 'var(--text-primary)' }}>
              Pourquoi Choisir Martama?
            </h2>
            <p className="text-lg md:text-xl" style={{ color: 'var(--text-secondary)' }}>
              🌟 Nous rendons le premium accessible à tous les Africains
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Feature 1 */}
            <div 
              className="group p-8 md:p-10 rounded-3xl border transition-all duration-500 hover:scale-105 hover:shadow-2xl animate-fade-in-up relative overflow-hidden" 
              style={{ 
                backgroundColor: 'var(--bg-secondary)', 
                borderColor: 'var(--border-color)', 
                animationDelay: '0s' 
              }}
            >
              {/* Glow Effect on Hover */}
              <div 
                className="absolute inset-0 opacity-0 group-hover:opacity-20 transition-opacity duration-500 blur-2xl"
                style={{ background: 'linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%)' }}
              />
              
              <div 
                className="w-16 h-16 rounded-2xl flex items-center justify-center mb-6 shadow-lg text-white relative z-10 group-hover:scale-110 group-hover:rotate-12 transition-transform duration-500" 
                style={{ background: 'linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%)' }}
              >
                <Zap className="w-8 h-8" />
              </div>
              <h3 className="text-2xl font-bold mb-4 relative z-10" style={{ color: 'var(--text-primary)' }}>
                ⚡ Activation Immédiate
              </h3>
              <p className="text-base leading-relaxed relative z-10" style={{ color: 'var(--text-secondary)' }}>
                Recevez vos accès premium immédiatement après validation du paiement. Pas d'attente, profitez tout de suite.
              </p>
            </div>

            {/* Feature 2 */}
            <div 
              className="group p-8 md:p-10 rounded-3xl border transition-all duration-500 hover:scale-105 hover:shadow-2xl animate-fade-in-up relative overflow-hidden" 
              style={{ 
                backgroundColor: 'var(--bg-secondary)', 
                borderColor: 'var(--border-color)', 
                animationDelay: '0.1s' 
              }}
            >
              <div 
                className="absolute inset-0 opacity-0 group-hover:opacity-20 transition-opacity duration-500 blur-2xl"
                style={{ background: 'linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%)' }}
              />
              
              <div 
                className="w-16 h-16 rounded-2xl flex items-center justify-center mb-6 shadow-lg text-white relative z-10 group-hover:scale-110 group-hover:rotate-12 transition-transform duration-500" 
                style={{ background: 'linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%)' }}
              >
                <Lock className="w-8 h-8" />
              </div>
              <h3 className="text-2xl font-bold mb-4 relative z-10" style={{ color: 'var(--text-primary)' }}>
                🔒 Paiement Sécurisé
              </h3>
              <p className="text-base leading-relaxed relative z-10" style={{ color: 'var(--text-secondary)' }}>
                Transactions cryptées avec les méthodes de paiement les plus populaires en Afrique.
              </p>
            </div>

            {/* Feature 3 */}
            <div 
              className="group p-8 md:p-10 rounded-3xl border transition-all duration-500 hover:scale-105 hover:shadow-2xl animate-fade-in-up relative overflow-hidden" 
              style={{ 
                backgroundColor: 'var(--bg-secondary)', 
                borderColor: 'var(--border-color)', 
                animationDelay: '0.2s' 
              }}
            >
              <div 
                className="absolute inset-0 opacity-0 group-hover:opacity-20 transition-opacity duration-500 blur-2xl"
                style={{ background: 'linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%)' }}
              />
              
              <div 
                className="w-16 h-16 rounded-2xl flex items-center justify-center mb-6 shadow-lg text-white relative z-10 group-hover:scale-110 group-hover:rotate-12 transition-transform duration-500" 
                style={{ background: 'linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%)' }}
              >
                <MessageCircle className="w-8 h-8" />
              </div>
              <h3 className="text-2xl font-bold mb-4 relative z-10" style={{ color: 'var(--text-primary)' }}>
                💬 Support 24/7
              </h3>
              <p className="text-base leading-relaxed relative z-10" style={{ color: 'var(--text-secondary)' }}>
                Notre équipe de support est disponible 24h/24 et 7j/7 via WhatsApp pour répondre à toutes vos questions.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Community Stats Section */}
      <section className="px-6 py-16 md:py-20 max-w-7xl mx-auto relative" style={{ backgroundColor: 'var(--bg-secondary)' }}>
        <div className="text-center mb-12 animate-fade-in-up">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4" style={{ color: 'var(--text-primary)' }}>
            Rejoignez une Communauté Grandissante
          </h2>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          <div 
            className="text-center p-8 rounded-3xl border animate-fade-in-up transition-all duration-500 hover:scale-105 relative overflow-hidden group" 
            style={{ 
              backgroundColor: 'var(--bg-primary)', 
              borderColor: 'var(--border-color)', 
              animationDelay: '0s' 
            }}
          >
            <div 
              className="absolute inset-0 opacity-0 group-hover:opacity-10 transition-opacity duration-500"
              style={{ background: 'linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%)' }}
            />
            <div 
              className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 text-white relative z-10 group-hover:scale-110 transition-transform duration-500" 
              style={{ background: 'linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%)' }}
            >
              <Users className="w-8 h-8" />
            </div>
            <div className="text-4xl md:text-5xl font-bold mb-2 relative z-10" style={{ color: 'var(--text-primary)' }}>200+</div>
            <div className="text-lg font-medium relative z-10" style={{ color: 'var(--text-secondary)' }}>Clients Satisfaits</div>
          </div>
          
          <div 
            className="text-center p-8 rounded-3xl border animate-fade-in-up transition-all duration-500 hover:scale-105 relative overflow-hidden group" 
            style={{ 
              backgroundColor: 'var(--bg-primary)', 
              borderColor: 'var(--border-color)', 
              animationDelay: '0.1s' 
            }}
          >
            <div 
              className="absolute inset-0 opacity-0 group-hover:opacity-10 transition-opacity duration-500"
              style={{ background: 'linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%)' }}
            />
            <div 
              className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 text-white relative z-10 group-hover:scale-110 transition-transform duration-500" 
              style={{ background: 'linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%)' }}
            >
              <Package className="w-8 h-8" />
            </div>
            <div className="text-4xl md:text-5xl font-bold mb-2 relative z-10" style={{ color: 'var(--text-primary)' }}>50+</div>
            <div className="text-lg font-medium relative z-10" style={{ color: 'var(--text-secondary)' }}>Abonnements Disponibles</div>
          </div>
          
          <div 
            className="text-center p-8 rounded-3xl border animate-fade-in-up transition-all duration-500 hover:scale-105 relative overflow-hidden group" 
            style={{ 
              backgroundColor: 'var(--bg-primary)', 
              borderColor: 'var(--border-color)', 
              animationDelay: '0.2s' 
            }}
          >
            <div 
              className="absolute inset-0 opacity-0 group-hover:opacity-10 transition-opacity duration-500"
              style={{ background: 'linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%)' }}
            />
            <div 
              className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 text-white relative z-10 group-hover:scale-110 transition-transform duration-500" 
              style={{ background: 'linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%)' }}
            >
              <Award className="w-8 h-8" />
            </div>
            <div className="text-4xl md:text-5xl font-bold mb-2 relative z-10" style={{ color: 'var(--text-primary)' }}>100+</div>
            <div className="text-lg font-medium relative z-10" style={{ color: 'var(--text-secondary)' }}>Affiliés Actifs</div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      {testimonials.length > 0 && (
        <section className="px-6 py-16 md:py-20 relative overflow-hidden" style={{ backgroundColor: 'var(--bg-primary)' }}>
          {/* Background Decoration */}
          <div 
            className="absolute bottom-0 left-0 w-96 h-96 rounded-full opacity-10 blur-3xl"
            style={{
              background: 'linear-gradient(135deg, var(--accent) 0%, var(--primary) 100%)',
              animation: 'float 12s ease-in-out infinite'
            }}
          />
          
          <div className="max-w-7xl mx-auto relative z-10">
            <div className="text-center mb-12 animate-fade-in-up">
              <h2 
                className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4" 
                style={{ 
                  background: 'linear-gradient(90deg, var(--primary) 0%, var(--accent) 100%)',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent'
                }}
              >
                💬 Témoignages
              </h2>
              <p className="text-lg md:text-xl" style={{ color: 'var(--text-secondary)' }}>
                Découvrez ce que nos clients disent de nous
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {testimonials.map((testimonial, index) => (
                <div
                  key={testimonial.id}
                  className="animate-fade-in-up"
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  <TestimonialScreenshot
                    screenshotUrl={testimonial.screenshot_url}
                    customerName={testimonial.customer_name || undefined}
                  />
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      <Footer />

      {/* Global Animation Styles */}
      <style>{`
        @keyframes zoomPulse {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.1); }
        }

        @keyframes float {
          0%, 100% { transform: translateY(0px) translateX(0px); }
          33% { transform: translateY(-20px) translateX(10px); }
          66% { transform: translateY(-10px) translateX(-10px); }
        }

        @keyframes gridMove {
          0% { transform: translate(0, 0); }
          100% { transform: translate(50px, 50px); }
        }

        @keyframes gradient {
          0% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }

        .animate-gradient {
          animation: gradient 3s ease infinite;
        }

        .animate-spin-slow {
          animation: spin 3s linear infinite;
        }

        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
}
