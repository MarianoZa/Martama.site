import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "@getmocha/users-service/react";
import { useNotificationSound } from "@/react-app/hooks/useNotificationSound";
import { 
  ArrowLeft, 
  Package, 
  DollarSign, 
  Users, 
  TrendingUp,
  ShoppingCart,
  AlertCircle,
  Bell,
  BellOff,
  Volume2,
  VolumeX,
  CreditCard
} from "lucide-react";

interface DashboardStats {
  orders: {
    total: number;
    pending: number;
    paid: number;
  };
  revenue: {
    total: number;
  };
  affiliates: {
    total: number;
    pending_requests: number;
  };
}

export default function AdminDashboard() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { checkForNewOrders, isEnabled, toggleSound, unreadCount } = useNotificationSound();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [recentNotifications, setRecentNotifications] = useState<any[]>([]);

  useEffect(() => {
    const loadFont = () => {
      const link = document.createElement("link");
      link.href = "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap";
      link.rel = "stylesheet";
      document.head.appendChild(link);
    };
    loadFont();
  }, []);

  useEffect(() => {
    fetchStats();
    fetchRecentNotifications();
  }, []);

  useEffect(() => {
    // Poll for new orders every 30 seconds
    const interval = setInterval(() => {
      checkForNewOrders();
      fetchRecentNotifications();
    }, 30000);

    return () => clearInterval(interval);
  }, []);

  const fetchRecentNotifications = async () => {
    try {
      const response = await fetch("/api/admin/notifications/recent");
      if (response.ok) {
        const data = await response.json();
        setRecentNotifications(data);
      }
    } catch (error) {
      console.error("Failed to fetch notifications:", error);
    }
  };

  const markNotificationRead = async (id: number) => {
    try {
      await fetch(`/api/admin/notifications/${id}/read`, {
        method: "PUT",
      });
      await fetchRecentNotifications();
      await checkForNewOrders();
    } catch (error) {
      console.error("Failed to mark notification as read:", error);
    }
  };

  const markAllRead = async () => {
    try {
      await fetch("/api/admin/notifications/read-all", {
        method: "PUT",
      });
      await fetchRecentNotifications();
      await checkForNewOrders();
    } catch (error) {
      console.error("Failed to mark all as read:", error);
    }
  };

  const fetchStats = async () => {
    try {
      setLoading(true);
      const response = await fetch("/api/admin/stats");
      
      if (response.status === 403) {
        navigate("/");
        return;
      }
      
      const data = await response.json();
      setStats(data);
    } catch (error) {
      console.error("Failed to fetch stats:", error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: 'var(--bg-primary)' }}>
        <div className="w-12 h-12 border-4 rounded-full animate-spin" style={{ borderColor: 'var(--gray-200)', borderTopColor: 'var(--primary)' }}></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen" style={{ fontFamily: "'Outfit', sans-serif", backgroundColor: 'var(--bg-primary)' }}>
      {/* Header */}
      <header className="px-6 py-6 max-w-7xl mx-auto">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate("/")}
              className="p-2 rounded-xl transition-colors hover:shadow-md"
              style={{ backgroundColor: 'var(--bg-secondary)' }}
            >
              <ArrowLeft className="w-6 h-6" style={{ color: 'var(--text-primary)' }} />
            </button>
            <div>
              <h1 className="text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>Tableau de Bord Admin</h1>
              <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>Gérez votre plateforme Martama</p>
            </div>
          </div>
          {user && (
            <div className="flex items-center gap-4">
              <button
                onClick={toggleSound}
                className="p-2 rounded-xl transition-colors relative"
                style={{ backgroundColor: 'var(--bg-secondary)' }}
                title={isEnabled ? "Désactiver les sons" : "Activer les sons"}
              >
                {isEnabled ? (
                  <Volume2 className="w-5 h-5" style={{ color: 'var(--primary)' }} />
                ) : (
                  <VolumeX className="w-5 h-5" style={{ color: 'var(--text-muted)' }} />
                )}
              </button>
              
              <div className="relative">
                <button
                  className="p-2 rounded-xl transition-colors relative"
                  style={{ backgroundColor: 'var(--bg-secondary)' }}
                  title="Notifications"
                >
                  <Bell className="w-5 h-5" style={{ color: 'var(--primary)' }} />
                  {unreadCount > 0 && (
                    <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold text-white" style={{ backgroundColor: 'var(--error)' }}>
                      {unreadCount > 9 ? '9+' : unreadCount}
                    </span>
                  )}
                </button>
              </div>
              
              <div className="text-sm text-right">
                <span style={{ color: 'var(--text-muted)' }}>Admin</span>
                <div className="font-semibold" style={{ color: 'var(--text-primary)' }}>{user.email}</div>
              </div>
            </div>
          )}
        </div>
      </header>

      {/* Stats Grid */}
      <main className="px-6 py-8 max-w-7xl mx-auto">
        {/* Overview Section */}
        <div className="mb-8">
          <h2 className="text-lg font-semibold mb-1" style={{ color: 'var(--text-primary)' }}>Vue d'ensemble de votre plateforme</h2>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {/* CA Total */}
          <div className="rounded-3xl border p-6 hover:shadow-lg transition-all" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-sm mb-1" style={{ color: 'var(--text-muted)' }}>CA Total</p>
                <div className="text-3xl font-bold" style={{ color: 'var(--text-primary)' }}>
                  {stats?.revenue.total.toLocaleString() || 0} FCFA
                </div>
              </div>
              <div className="w-12 h-12 rounded-2xl flex items-center justify-center" style={{ backgroundColor: 'rgba(16, 185, 129, 0.1)' }}>
                <DollarSign className="w-6 h-6" style={{ color: 'var(--success)' }} />
              </div>
            </div>
            <div className="text-sm flex items-center gap-1" style={{ color: 'var(--success)' }}>
              <TrendingUp className="w-4 h-4" />
              <span>+10.2% depuis le mois dernier</span>
            </div>
          </div>

          {/* Total Commandes */}
          <div className="rounded-3xl border p-6 hover:shadow-lg transition-all" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-sm mb-1" style={{ color: 'var(--text-muted)' }}>Total Commandes</p>
                <div className="text-3xl font-bold" style={{ color: 'var(--text-primary)' }}>
                  {stats?.orders.total || 0}
                </div>
              </div>
              <div className="w-12 h-12 rounded-2xl flex items-center justify-center" style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)' }}>
                <ShoppingCart className="w-6 h-6" style={{ color: 'var(--primary)' }} />
              </div>
            </div>
            <div className="text-sm" style={{ color: 'var(--text-secondary)' }}>
              {stats?.orders.paid || 0} payées • {stats?.orders.pending || 0} en attente
            </div>
          </div>

          {/* Demandes d'Affiliation */}
          <div className="rounded-3xl border p-6 hover:shadow-lg transition-all" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-sm mb-1" style={{ color: 'var(--text-muted)' }}>Demandes d'Affiliation</p>
                <div className="text-3xl font-bold" style={{ color: 'var(--text-primary)' }}>
                  {stats?.affiliates.pending_requests || 0}
                </div>
              </div>
              <div className="w-12 h-12 rounded-2xl flex items-center justify-center" style={{ backgroundColor: 'rgba(59, 130, 246, 0.1)' }}>
                <Users className="w-6 h-6 text-blue-500" />
              </div>
            </div>
            <div className="text-sm" style={{ color: 'var(--text-secondary)' }}>
              En attente de validation
            </div>
          </div>

          {/* Affiliés Actifs */}
          <div className="rounded-3xl border p-6 hover:shadow-lg transition-all" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-sm mb-1" style={{ color: 'var(--text-muted)' }}>Affiliés Actifs</p>
                <div className="text-3xl font-bold" style={{ color: 'var(--text-primary)' }}>
                  {stats?.affiliates.total || 0}
                </div>
              </div>
              <div className="w-12 h-12 rounded-2xl flex items-center justify-center" style={{ backgroundColor: 'rgba(245, 158, 11, 0.1)' }}>
                <Users className="w-6 h-6" style={{ color: 'var(--warning)' }} />
              </div>
            </div>
            <div className="text-sm flex items-center gap-1" style={{ color: 'var(--success)' }}>
              <TrendingUp className="w-4 h-4" />
              <span>+2 depuis le mois dernier</span>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-6" style={{ color: 'var(--text-primary)' }}>Accès rapides</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-4">
            <button
              onClick={() => navigate("/admin/users")}
              className="p-6 rounded-2xl border hover:shadow-lg transition-all text-left group"
              style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}
            >
              <div className="w-12 h-12 rounded-2xl flex items-center justify-center mb-3" style={{ backgroundColor: 'rgba(59, 130, 246, 0.1)' }}>
                <Users className="w-6 h-6 text-blue-500 transition-colors" />
              </div>
              <h3 className="text-lg font-semibold mb-1" style={{ color: 'var(--text-primary)' }}>Gestion des Utilisateurs</h3>
              <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>Gérer les rôles et paramètres utilisateurs.</p>
            </button>

            <button
              onClick={() => navigate("/admin/payments")}
              className="p-6 rounded-2xl border hover:shadow-lg transition-all text-left group"
              style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}
            >
              <div className="w-12 h-12 rounded-2xl flex items-center justify-center mb-3" style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)' }}>
                <DollarSign className="w-6 h-6 transition-colors" style={{ color: 'var(--primary)' }} />
              </div>
              <h3 className="text-lg font-semibold mb-1" style={{ color: 'var(--text-primary)' }}>Gestion des Paiements</h3>
              <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>Approuver, rejeter et suivre les demandes de retrait.</p>
            </button>

            <button
              onClick={() => navigate("/admin/affiliates")}
              className="p-6 rounded-2xl border hover:shadow-lg transition-all text-left group"
              style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}
            >
              <div className="w-12 h-12 rounded-2xl flex items-center justify-center mb-3" style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)' }}>
                <Users className="w-6 h-6 transition-colors" style={{ color: 'var(--primary)' }} />
              </div>
              <h3 className="text-lg font-semibold mb-1" style={{ color: 'var(--text-primary)' }}>Gestion des Affiliés</h3>
              <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>Ajouter et gérer vos affiliés.</p>
            </button>

            <button
              onClick={() => navigate("/admin/products")}
              className="p-6 rounded-2xl border hover:shadow-lg transition-all text-left group"
              style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}
            >
              <div className="w-12 h-12 rounded-2xl flex items-center justify-center mb-3" style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)' }}>
                <Package className="w-6 h-6 transition-colors" style={{ color: 'var(--primary)' }} />
              </div>
              <h3 className="text-lg font-semibold mb-1" style={{ color: 'var(--text-primary)' }}>Gestion des Produits</h3>
              <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>Ajouter et modifier vos produits.</p>
            </button>

            <button
              onClick={() => navigate("/admin/orders")}
              className="p-6 rounded-2xl border hover:shadow-lg transition-all text-left group"
              style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}
            >
              <div className="w-12 h-12 rounded-2xl flex items-center justify-center mb-3" style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)' }}>
                <ShoppingCart className="w-6 h-6 transition-colors" style={{ color: 'var(--primary)' }} />
              </div>
              <h3 className="text-lg font-semibold mb-1" style={{ color: 'var(--text-primary)' }}>Voir les Commandes</h3>
              <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>Consulter toutes les commandes.</p>
            </button>

            <button
              onClick={() => navigate("/admin/announcement")}
              className="p-6 rounded-2xl border hover:shadow-lg transition-all text-left group"
              style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}
            >
              <div className="w-12 h-12 rounded-2xl flex items-center justify-center mb-3" style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)' }}>
                <svg className="w-6 h-6 transition-colors" style={{ color: 'var(--primary)' }} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-1.234 9.168-3v14c-1.543-1.766-5.067-3-9.168-3H7a3.988 3.988 0 01-1.564-.317z" />
                </svg>
              </div>
              <h3 className="text-lg font-semibold mb-1" style={{ color: 'var(--text-primary)' }}>Barre d'Annonces</h3>
              <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>Gérer les messages promotionnels.</p>
            </button>

            <button
              onClick={() => navigate("/admin/payment-gateways")}
              className="p-6 rounded-2xl border hover:shadow-lg transition-all text-left group"
              style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}
            >
              <div className="w-12 h-12 rounded-2xl flex items-center justify-center mb-3" style={{ backgroundColor: 'rgba(16, 185, 129, 0.1)' }}>
                <CreditCard className="w-6 h-6 transition-colors" style={{ color: 'var(--success)' }} />
              </div>
              <h3 className="text-lg font-semibold mb-1" style={{ color: 'var(--text-primary)' }}>Passerelles de Paiement</h3>
              <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>Configurer FedaPay, Moneroo, Lygos.</p>
            </button>

            <button
              onClick={() => navigate("/admin/testimonials")}
              className="p-6 rounded-2xl border hover:shadow-lg transition-all text-left group"
              style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}
            >
              <div className="w-12 h-12 rounded-2xl flex items-center justify-center mb-3" style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)' }}>
                <svg className="w-6 h-6 transition-colors" style={{ color: 'var(--primary)' }} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
                </svg>
              </div>
              <h3 className="text-lg font-semibold mb-1" style={{ color: 'var(--text-primary)' }}>Témoignages</h3>
              <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>Gérer les captures d'écran WhatsApp.</p>
            </button>
          </div>
        </div>

        {/* Recent Notifications */}
        {recentNotifications.length > 0 && (
          <div className="mb-8">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold flex items-center gap-2" style={{ color: 'var(--text-primary)' }}>
                <Bell className="w-6 h-6" />
                Nouvelles Commandes
              </h2>
              <button
                onClick={markAllRead}
                className="text-sm font-medium transition-colors"
                style={{ color: 'var(--primary)' }}
              >
                Tout marquer comme lu
              </button>
            </div>
            
            <div className="space-y-3">
              {recentNotifications.map((notification) => (
                <div
                  key={notification.id}
                  className="rounded-2xl border p-4 flex items-center justify-between hover:shadow-md transition-all"
                  style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--primary)', borderWidth: '2px' }}
                >
                  <div className="flex-1">
                    <h3 className="font-semibold mb-1" style={{ color: 'var(--text-primary)' }}>
                      Nouvelle commande - {notification.product_name}
                    </h3>
                    <p className="text-sm mb-1" style={{ color: 'var(--text-secondary)' }}>
                      Client : {notification.customer_email}
                    </p>
                    <p className="text-sm font-semibold" style={{ color: 'var(--success)' }}>
                      Montant : {notification.amount?.toLocaleString()} FCFA
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => navigate(`/admin/orders?highlight=${notification.order_id}`)}
                      className="px-4 py-2 rounded-xl font-semibold text-white transition-all"
                      style={{ backgroundColor: 'var(--primary)' }}
                    >
                      Voir
                    </button>
                    <button
                      onClick={() => markNotificationRead(notification.id)}
                      className="p-2 rounded-xl transition-colors"
                      style={{ backgroundColor: 'rgba(16, 185, 129, 0.1)', color: 'var(--success)' }}
                      title="Marquer comme lu"
                    >
                      <BellOff className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Alerts */}
        {stats && (stats.orders.pending > 0 || stats.affiliates.pending_requests > 0) && (
          <div className="space-y-4 mt-8">
            <h2 className="text-2xl font-bold mb-6" style={{ color: 'var(--text-primary)' }}>Alertes</h2>
            
            {stats.orders.pending > 0 && (
              <div className="p-4 rounded-2xl border flex items-start gap-3" style={{ backgroundColor: 'rgba(245, 158, 11, 0.1)', borderColor: 'rgba(245, 158, 11, 0.3)' }}>
                <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" style={{ color: 'var(--warning)' }} />
                <div>
                  <h4 className="font-semibold mb-1" style={{ color: 'var(--text-primary)' }}>Commandes en attente</h4>
                  <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
                    Vous avez {stats.orders.pending} commande{stats.orders.pending > 1 ? 's' : ''} en attente de traitement.
                  </p>
                  <button
                    onClick={() => navigate("/admin/orders?status=pending")}
                    className="mt-2 text-sm font-medium transition-colors"
                    style={{ color: 'var(--primary)' }}
                  >
                    Voir les commandes →
                  </button>
                </div>
              </div>
            )}

            {stats.affiliates.pending_requests > 0 && (
              <div className="p-4 rounded-2xl border flex items-start gap-3" style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)', borderColor: 'rgba(139, 92, 246, 0.3)' }}>
                <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" style={{ color: 'var(--primary)' }} />
                <div>
                  <h4 className="font-semibold mb-1" style={{ color: 'var(--text-primary)' }}>Demandes d'affiliation</h4>
                  <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
                    {stats.affiliates.pending_requests} demande{stats.affiliates.pending_requests > 1 ? 's' : ''} d'affiliation en attente.
                  </p>
                  <button
                    onClick={() => navigate("/admin/affiliates?tab=requests")}
                    className="mt-2 text-sm font-medium transition-colors"
                    style={{ color: 'var(--primary)' }}
                  >
                    Voir les demandes →
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
