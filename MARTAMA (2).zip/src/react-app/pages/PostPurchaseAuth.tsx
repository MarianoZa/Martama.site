import { useEffect, useState } from "react";
import { useNavigate, useSearchParams } from "react-router";
import { useAuth } from "@getmocha/users-service/react";
import { CheckCircle, ShoppingBag } from "lucide-react";

export default function PostPurchaseAuth() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { user, redirectToLogin } = useAuth();
  const [orderInfo, setOrderInfo] = useState<any>(null);

  useEffect(() => {
    const loadFont = () => {
      const link = document.createElement("link");
      link.href = "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap";
      link.rel = "stylesheet";
      document.head.appendChild(link);
    };
    loadFont();
  }, []);

  useEffect(() => {
    // Load order info from localStorage
    const storedOrder = localStorage.getItem('recent_order');
    if (storedOrder) {
      setOrderInfo(JSON.parse(storedOrder));
    }
  }, []);

  useEffect(() => {
    // If user is already logged in, redirect to dashboard
    if (user) {
      // Clear stored order info
      localStorage.removeItem('recent_order');
      navigate("/dashboard");
    }
  }, [user, navigate]);

  const handleLogin = () => {
    // Store redirect intent
    localStorage.setItem('post_auth_redirect', '/dashboard');
    redirectToLogin();
  };

  return (
    <div 
      className="min-h-screen flex items-center justify-center px-4"
      style={{ 
        fontFamily: "'Outfit', sans-serif",
        background: 'linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%)'
      }}
    >
      <div 
        className="max-w-md w-full rounded-3xl border p-8 text-center shadow-2xl"
        style={{ 
          backgroundColor: 'var(--bg-primary)',
          borderColor: 'var(--border-color)'
        }}
      >
        <div className="mb-6">
          <div 
            className="w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4"
            style={{ background: 'linear-gradient(135deg, var(--success) 0%, #059669 100%)' }}
          >
            <CheckCircle className="w-12 h-12 text-white" />
          </div>
          
          <h1 className="text-3xl font-bold mb-2" style={{ color: 'var(--text-primary)' }}>
            Paiement Réussi !
          </h1>
          
          {orderInfo && (
            <div 
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-4"
              style={{ backgroundColor: 'var(--gray-100)' }}
            >
              <ShoppingBag className="w-4 h-4" style={{ color: 'var(--text-secondary)' }} />
              <span className="text-sm font-medium" style={{ color: 'var(--text-secondary)' }}>
                {orderInfo.product_name}
              </span>
            </div>
          )}
        </div>

        <p className="text-lg mb-6" style={{ color: 'var(--text-secondary)' }}>
          Votre commande a été traitée avec succès. Pour accéder à vos achats, veuillez vous connecter avec l'adresse email utilisée lors de la commande.
        </p>

        {searchParams.get('email') && (
          <div 
            className="mb-6 p-4 rounded-xl border"
            style={{ 
              backgroundColor: 'var(--bg-secondary)',
              borderColor: 'var(--border-color)'
            }}
          >
            <p className="text-sm font-medium mb-1" style={{ color: 'var(--text-muted)' }}>
              Email de commande :
            </p>
            <p className="font-semibold" style={{ color: 'var(--text-primary)' }}>
              {searchParams.get('email')}
            </p>
          </div>
        )}

        <button
          onClick={handleLogin}
          className="w-full py-4 rounded-2xl font-bold text-lg text-white transition-all duration-300 hover:opacity-90 shadow-lg"
          style={{ background: 'linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%)' }}
        >
          Se connecter pour accéder
        </button>

        <p className="mt-4 text-sm" style={{ color: 'var(--text-muted)' }}>
          Un compte sera automatiquement créé si vous n'en avez pas encore.
        </p>

        <div className="mt-6 p-4 rounded-xl border" style={{ 
          backgroundColor: 'rgba(37, 211, 102, 0.1)', 
          borderColor: 'rgba(37, 211, 102, 0.3)'
        }}>
          <p className="text-sm text-center mb-2" style={{ color: 'var(--text-secondary)' }}>
            Besoin d'aide ?
          </p>
          <a
            href="https://wa.me/22951661357?text=Bonjour%2C%20j%27ai%20besoin%20d%27aide%20avec%20ma%20commande"
            target="_blank"
            rel="noopener noreferrer"
            className="text-sm font-semibold text-center block hover:underline"
            style={{ color: '#25D366' }}
          >
            Contactez-nous sur WhatsApp : +229 51 66 13 57
          </a>
        </div>
      </div>
    </div>
  );
}
