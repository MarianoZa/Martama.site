import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "@getmocha/users-service/react";
import Header from "@/react-app/components/Header";
import { 
  Package, 
  TrendingUp, 
  Users, 
  Calendar,
  ArrowRight,
  CheckCircle,
  Clock,
  BookOpen
} from "lucide-react";

interface UserData {
  role: string;
  has_completed_onboarding: number;
}

interface Subscription {
  id: number;
  product_name: string;
  product_category: string;
  status: string;
  access_credentials: string | null;
  created_at: string;
  expires_at: string | null;
}

interface AffiliateStats {
  total_clicks: number;
  total_sales: number;
  total_commissions: number;
  balance: number;
  promo_code: string;
}

interface AffiliateRequestStatus {
  has_request: boolean;
  status: string;
  promo_code: string | null;
}

export default function UserDashboard() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [userData, setUserData] = useState<UserData | null>(null);
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
  const [affiliateStats, setAffiliateStats] = useState<AffiliateStats | null>(null);
  const [affiliateRequest, setAffiliateRequest] = useState<AffiliateRequestStatus | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadFont = () => {
      const link = document.createElement("link");
      link.href = "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap";
      link.rel = "stylesheet";
      document.head.appendChild(link);
    };
    loadFont();
  }, []);

  useEffect(() => {
    if (user) {
      fetchUserData();
      fetchSubscriptions();
      checkAffiliateStatus();
      checkAffiliateRequest();
    }
  }, [user]);

  const fetchUserData = async () => {
    try {
      const response = await fetch("/api/users/me");
      const data = await response.json();
      setUserData(data);
    } catch (error) {
      console.error("Failed to fetch user data:", error);
    }
  };

  const fetchSubscriptions = async () => {
    try {
      const response = await fetch("/api/subscriptions/my");
      if (response.ok) {
        const data = await response.json();
        setSubscriptions(data);
      }
    } catch (error) {
      console.error("Failed to fetch subscriptions:", error);
    } finally {
      setLoading(false);
    }
  };

  const checkAffiliateStatus = async () => {
    try {
      const response = await fetch("/api/affiliate/stats");
      if (response.ok) {
        const data = await response.json();
        setAffiliateStats(data);
      } else if (response.status === 404) {
        // User is not an affiliate - set explicitly to null
        setAffiliateStats(null);
      }
    } catch (error) {
      // User is not an affiliate
      setAffiliateStats(null);
    }
  };

  const checkAffiliateRequest = async () => {
    try {
      const response = await fetch("/api/affiliate-requests/my-status");
      if (response.ok) {
        const data = await response.json();
        setAffiliateRequest(data);
      }
    } catch (error) {
      setAffiliateRequest(null);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "delivered": return "bg-green-500/20 text-green-300 border-green-500/30";
      case "paid": return "bg-blue-500/20 text-blue-300 border-blue-500/30";
      case "pending": return "bg-orange-500/20 text-orange-300 border-orange-500/30";
      default: return "bg-purple-500/20 text-purple-300 border-purple-500/30";
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: 'var(--bg-primary)' }}>
        <div className="text-center">
          <p className="text-xl mb-4" style={{ color: 'var(--text-primary)' }}>Veuillez vous connecter</p>
          <button
            onClick={() => navigate("/")}
            className="px-6 py-3 rounded-xl font-semibold text-white"
            style={{ backgroundColor: 'var(--primary)' }}
          >
            Retour à l'accueil
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen" style={{ fontFamily: "'Outfit', sans-serif", backgroundColor: 'var(--bg-primary)' }}>
      <Header showBackButton onBack={() => navigate("/")} />

      <main className="px-6 py-8 max-w-7xl mx-auto">
        {/* Welcome Section */}
        <div className="mb-12">
          <h1 className="text-4xl font-bold mb-2" style={{ color: 'var(--text-primary)' }}>
            Bienvenue, {user.email?.split('@')[0]}
          </h1>
          <p className="text-lg" style={{ color: 'var(--text-secondary)' }}>Gérez vos abonnements et accédez à vos contenus</p>
        </div>

        {/* Quick Stats */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          <div className="rounded-3xl border p-6 hover:shadow-lg transition-all" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-white" style={{ background: 'linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%)' }}>
                <Package className="w-6 h-6" />
              </div>
            </div>
            <div className="text-3xl font-bold mb-1" style={{ color: 'var(--text-primary)' }}>
              {subscriptions.length}
            </div>
            <div className="text-sm" style={{ color: 'var(--text-secondary)' }}>Abonnements Actifs</div>
          </div>

          {affiliateStats && (
            <>
              <div className="rounded-3xl border p-6 hover:shadow-lg transition-all" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 rounded-2xl flex items-center justify-center" style={{ backgroundColor: 'rgba(16, 185, 129, 0.1)' }}>
                    <TrendingUp className="w-6 h-6" style={{ color: 'var(--success)' }} />
                  </div>
                </div>
                <div className="text-3xl font-bold mb-1" style={{ color: 'var(--text-primary)' }}>
                  {affiliateStats.total_sales}
                </div>
                <div className="text-sm" style={{ color: 'var(--text-secondary)' }}>Ventes Affiliées</div>
              </div>

              <div className="rounded-3xl border p-6 hover:shadow-lg transition-all" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 rounded-2xl flex items-center justify-center" style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)' }}>
                    <Users className="w-6 h-6" style={{ color: 'var(--primary)' }} />
                  </div>
                </div>
                <div className="text-3xl font-bold mb-1" style={{ color: 'var(--text-primary)' }}>
                  {affiliateStats.balance.toLocaleString()} F
                </div>
                <div className="text-sm" style={{ color: 'var(--text-secondary)' }}>Solde Disponible</div>
              </div>
            </>
          )}
        </div>

        {/* Quick Actions */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold mb-6" style={{ color: 'var(--text-primary)' }}>Actions Rapides</h2>
          <div className="grid md:grid-cols-3 gap-4">
            <button
              onClick={() => navigate("/catalog")}
              className="p-6 rounded-2xl border hover:shadow-lg transition-all text-left group"
              style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}
            >
              <Package className="w-8 h-8 mb-3 transition-colors" style={{ color: 'var(--primary)' }} />
              <h3 className="text-lg font-semibold mb-1" style={{ color: 'var(--text-primary)' }}>Découvrir le Catalogue</h3>
              <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>Parcourir tous nos produits</p>
            </button>

            {affiliateStats === null && !affiliateRequest?.has_request && (
              <button
                onClick={() => navigate("/become-affiliate")}
                className="p-6 rounded-2xl border hover:shadow-lg transition-all text-left group"
                style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--primary)' }}
              >
                <TrendingUp className="w-8 h-8 mb-3 transition-colors" style={{ color: 'var(--primary)' }} />
                <h3 className="text-lg font-semibold mb-1" style={{ color: 'var(--text-primary)' }}>Devenir Affilié</h3>
                <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>Gagnez des commissions</p>
              </button>
            )}

            {affiliateStats === null && affiliateRequest?.has_request && (
              <div className="p-6 rounded-2xl border" style={{ backgroundColor: 'rgba(251, 191, 36, 0.1)', borderColor: 'rgba(251, 191, 36, 0.3)' }}>
                <Clock className="w-8 h-8 mb-3" style={{ color: 'var(--warning)' }} />
                <h3 className="text-lg font-semibold mb-1" style={{ color: 'var(--text-primary)' }}>Demande en Cours</h3>
                <p className="text-sm mb-2" style={{ color: 'var(--text-secondary)' }}>
                  Votre demande d'affiliation est {affiliateRequest.status === 'pending' ? 'en cours de traitement' : affiliateRequest.status}
                </p>
                {affiliateRequest.promo_code && (
                  <p className="text-xs font-mono" style={{ color: 'var(--warning)' }}>Code: {affiliateRequest.promo_code}</p>
                )}
              </div>
            )}

            {affiliateStats && (
              <button
                onClick={() => navigate("/affiliate/dashboard")}
                className="p-6 rounded-2xl border hover:shadow-lg transition-all text-left group"
                style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--primary)' }}
              >
                <TrendingUp className="w-8 h-8 mb-3 transition-colors" style={{ color: 'var(--primary)' }} />
                <h3 className="text-lg font-semibold mb-1" style={{ color: 'var(--text-primary)' }}>Tableau de Bord Affilié</h3>
                <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>Voir vos statistiques</p>
              </button>
            )}

            {userData?.role === 'admin' && (
              <button
                onClick={() => navigate("/admin")}
                className="p-6 rounded-2xl border hover:shadow-lg transition-all text-left group"
                style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--warning)' }}
              >
                <svg className="w-8 h-8 mb-3 transition-colors" style={{ color: 'var(--warning)' }} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" />
                </svg>
                <h3 className="text-lg font-semibold mb-1" style={{ color: 'var(--text-primary)' }}>Administration</h3>
                <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>Gérer la plateforme</p>
              </button>
            )}
          </div>
        </div>

        {/* My Subscriptions */}
        <div>
          <h2 className="text-2xl font-bold mb-6" style={{ color: 'var(--text-primary)' }}>Mes Abonnements</h2>
          {loading ? (
            <div className="text-center py-20">
              <div className="inline-block w-12 h-12 border-4 rounded-full animate-spin" style={{ borderColor: 'var(--gray-200)', borderTopColor: 'var(--primary)' }}></div>
            </div>
          ) : subscriptions.length === 0 ? (
            <div className="rounded-3xl border p-12 text-center" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
              <BookOpen className="w-16 h-16 mx-auto mb-4" style={{ color: 'var(--text-muted)' }} />
              <p className="text-xl mb-4" style={{ color: 'var(--text-secondary)' }}>Aucun abonnement actif</p>
              <button
                onClick={() => navigate("/catalog")}
                className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-semibold text-white transition-all"
                style={{ backgroundColor: 'var(--primary)' }}
              >
                Découvrir nos offres
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {subscriptions.map((sub) => (
                <div
                  key={sub.id}
                  className="rounded-2xl border p-6 hover:shadow-lg transition-all"
                  style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}
                >
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="text-xl font-bold text-white mb-1">{sub.product_name}</h3>
                      <p className="text-purple-200 text-sm capitalize">{sub.product_category}</p>
                    </div>
                    <div className={`px-3 py-1.5 rounded-full border flex items-center gap-2 ${getStatusColor(sub.status)}`}>
                      {sub.status === 'delivered' ? <CheckCircle className="w-4 h-4" /> : <Clock className="w-4 h-4" />}
                      <span className="text-sm font-medium capitalize">{sub.status}</span>
                    </div>
                  </div>

                  {sub.access_credentials && (
                    <div className="mb-4 p-4 bg-green-500/10 rounded-xl border border-green-500/20">
                      <p className="text-green-300 text-sm font-semibold mb-2">Identifiants d'accès :</p>
                      <p className="text-green-200 text-sm font-mono whitespace-pre-wrap">
                        {sub.access_credentials}
                      </p>
                    </div>
                  )}

                  <div className="flex items-center gap-4 text-sm text-purple-200">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4" />
                      <span>Souscrit le {new Date(sub.created_at).toLocaleDateString('fr-FR')}</span>
                    </div>
                    {sub.expires_at && (
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4" />
                        <span>Expire le {new Date(sub.expires_at).toLocaleDateString('fr-FR')}</span>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
