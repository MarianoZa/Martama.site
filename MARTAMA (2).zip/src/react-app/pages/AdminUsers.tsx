import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { ArrowLeft, Users, Edit, X, Save, UserPlus, Trash2 } from "lucide-react";

interface User {
  id: string;
  email: string;
  full_name: string | null;
  phone_number: string | null;
  role: string;
  role_type: string | null;
  country: string | null;
  affiliate_status: string | null;
  affiliate_code: string | null;
  affiliate_commission_rate: number | null;
  payment_method: string | null;
  payment_account_number: string | null;
  payment_account_name: string | null;
  is_active: number | null;
  unique_identifier: string | null;
  loyalty_points: number | null;
  loyalty_tier: string | null;
  created_at: string;
}

export default function AdminUsers() {
  const navigate = useNavigate();
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [deletingUser, setDeletingUser] = useState<User | null>(null);
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(false);

  const [formData, setFormData] = useState({
    role: "user",
    role_type: "client",
    country: "",
    affiliate_status: "none",
    affiliate_code: "",
    affiliate_commission_rate: "30",
    payment_method: "",
    payment_account_number: "",
    payment_account_name: "",
    is_active: 1,
    loyalty_tier: "",
  });

  useEffect(() => {
    const loadFont = () => {
      const link = document.createElement("link");
      link.href = "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap";
      link.rel = "stylesheet";
      document.head.appendChild(link);
    };
    loadFont();
  }, []);

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      setLoading(true);
      const response = await fetch("/api/admin/users");
      
      if (response.status === 403) {
        navigate("/");
        return;
      }
      
      const data = await response.json();
      setUsers(data);
    } catch (error) {
      console.error("Failed to fetch users:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleOpenModal = (user: User) => {
    setEditingUser(user);
    setFormData({
      role: user.role,
      role_type: user.role_type || "client",
      country: user.country || "",
      affiliate_status: user.affiliate_status || "none",
      affiliate_code: user.affiliate_code || "",
      affiliate_commission_rate: user.affiliate_commission_rate?.toString() || "30",
      payment_method: user.payment_method || "",
      payment_account_number: user.payment_account_number || "",
      payment_account_name: user.payment_account_name || "",
      is_active: user.is_active !== null ? user.is_active : 1,
      loyalty_tier: user.loyalty_tier || "",
    });
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setEditingUser(null);
  };

  const handleOpenDeleteModal = (user: User) => {
    setDeletingUser(user);
    setShowDeleteModal(true);
  };

  const handleCloseDeleteModal = () => {
    setShowDeleteModal(false);
    setDeletingUser(null);
  };

  const handleDelete = async () => {
    if (!deletingUser) return;

    setDeleting(true);

    try {
      const response = await fetch(`/api/admin/users/${deletingUser.id}`, {
        method: "DELETE",
      });

      if (response.ok) {
        await fetchUsers();
        handleCloseDeleteModal();
      } else {
        const error = await response.json();
        console.error("Failed to delete user:", error);
        alert(error.error || "Échec de la suppression");
      }
    } catch (error) {
      console.error("Failed to delete user:", error);
      alert("Erreur lors de la suppression");
    } finally {
      setDeleting(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!editingUser) return;

    setSaving(true);

    try {
      const response = await fetch(`/api/admin/users/${editingUser.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          role: formData.role,
          role_type: formData.role_type,
          country: formData.country || null,
          affiliate_status: formData.affiliate_status,
          affiliate_code: formData.affiliate_code || null,
          affiliate_commission_rate: formData.affiliate_commission_rate ? parseInt(formData.affiliate_commission_rate) : null,
          payment_method: formData.payment_method || null,
          payment_account_number: formData.payment_account_number || null,
          payment_account_name: formData.payment_account_name || null,
          is_active: formData.is_active,
          loyalty_tier: formData.loyalty_tier || null,
        }),
      });

      if (response.ok) {
        await fetchUsers();
        handleCloseModal();
      }
    } catch (error) {
      console.error("Failed to update user:", error);
    } finally {
      setSaving(false);
    }
  };

  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case "admin": return "bg-red-500/20 text-red-300 border-red-500/30";
      case "affiliate": return "bg-purple-500/20 text-purple-300 border-purple-500/30";
      default: return "bg-blue-500/20 text-blue-300 border-blue-500/30";
    }
  };

  return (
    <div className="min-h-screen" style={{ fontFamily: "'Outfit', sans-serif", backgroundColor: 'var(--bg-primary)' }}>
      <header className="px-6 py-6 max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate("/admin")}
              className="p-2 hover:opacity-80 rounded-xl transition-opacity"
              style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)' }}
            >
              <ArrowLeft className="w-6 h-6" style={{ color: 'var(--primary)' }} />
            </button>
            <div>
              <h1 className="text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>Gestion des Utilisateurs</h1>
              <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>Gérer les rôles et les paramètres des utilisateurs</p>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <div className="rounded-2xl border p-6" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm" style={{ color: 'var(--text-muted)' }}>Total Utilisateurs</span>
              <Users className="w-8 h-8" style={{ color: 'var(--primary)' }} />
            </div>
            <div className="text-3xl font-bold" style={{ color: 'var(--text-primary)' }}>{users.length}</div>
          </div>

          <div className="rounded-2xl border p-6" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm" style={{ color: 'var(--text-muted)' }}>Administrateurs</span>
              <UserPlus className="w-8 h-8" style={{ color: 'var(--error)' }} />
            </div>
            <div className="text-3xl font-bold" style={{ color: 'var(--text-primary)' }}>
              {users.filter(u => u.role === 'admin').length}
            </div>
          </div>

          <div className="rounded-2xl border p-6" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm" style={{ color: 'var(--text-muted)' }}>Affiliés</span>
              <Users className="w-8 h-8" style={{ color: 'var(--primary)' }} />
            </div>
            <div className="text-3xl font-bold" style={{ color: 'var(--text-primary)' }}>
              {users.filter(u => u.affiliate_status === 'approved').length}
            </div>
          </div>

          <div className="rounded-2xl border p-6" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm" style={{ color: 'var(--text-muted)' }}>Utilisateurs Actifs</span>
              <Users className="w-8 h-8" style={{ color: 'var(--success)' }} />
            </div>
            <div className="text-3xl font-bold" style={{ color: 'var(--text-primary)' }}>
              {users.filter(u => u.is_active === 1).length}
            </div>
          </div>
        </div>
      </header>

      <main className="px-6 pb-12 max-w-7xl mx-auto">
        {loading ? (
          <div className="text-center py-20">
            <div className="inline-block w-12 h-12 border-4 rounded-full animate-spin" style={{ borderColor: 'var(--gray-200)', borderTopColor: 'var(--primary)' }}></div>
          </div>
        ) : (
          <div className="rounded-3xl border overflow-hidden" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b" style={{ borderColor: 'var(--border-color)' }}>
                    <th className="px-6 py-4 text-left text-sm font-semibold" style={{ color: 'var(--text-muted)' }}>Email</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold" style={{ color: 'var(--text-muted)' }}>Nom</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold" style={{ color: 'var(--text-muted)' }}>Rôle</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold" style={{ color: 'var(--text-muted)' }}>Type</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold" style={{ color: 'var(--text-muted)' }}>Statut Affilié</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold" style={{ color: 'var(--text-muted)' }}>Points Fidélité</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold" style={{ color: 'var(--text-muted)' }}>Actif</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold" style={{ color: 'var(--text-muted)' }}>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {users.map((user) => (
                    <tr key={user.id} className="border-b hover:opacity-90 transition-opacity" style={{ borderColor: 'var(--border-color)' }}>
                      <td className="px-6 py-4 text-sm" style={{ color: 'var(--text-primary)' }}>{user.email}</td>
                      <td className="px-6 py-4 text-sm" style={{ color: 'var(--text-primary)' }}>{user.full_name || '-'}</td>
                      <td className="px-6 py-4">
                        <span className={`px-3 py-1 rounded-full text-xs font-medium border ${getRoleBadgeColor(user.role)}`}>
                          {user.role}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-sm capitalize" style={{ color: 'var(--text-secondary)' }}>{user.role_type || '-'}</td>
                      <td className="px-6 py-4 text-sm capitalize" style={{ color: 'var(--text-secondary)' }}>{user.affiliate_status || 'none'}</td>
                      <td className="px-6 py-4 text-sm" style={{ color: 'var(--text-primary)' }}>{user.loyalty_points || 0}</td>
                      <td className="px-6 py-4">
                        {user.is_active === 1 ? (
                          <span className="px-3 py-1 bg-green-500/20 text-green-300 text-xs font-medium rounded-full border border-green-500/30">
                            Actif
                          </span>
                        ) : (
                          <span className="px-3 py-1 bg-red-500/20 text-red-300 text-xs font-medium rounded-full border border-red-500/30">
                            Inactif
                          </span>
                        )}
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => handleOpenModal(user)}
                            className="p-2 hover:opacity-80 rounded-lg transition-opacity"
                            style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)' }}
                            title="Modifier"
                          >
                            <Edit className="w-4 h-4" style={{ color: 'var(--primary)' }} />
                          </button>
                          <button
                            onClick={() => handleOpenDeleteModal(user)}
                            className="p-2 hover:opacity-80 rounded-lg transition-opacity"
                            style={{ backgroundColor: 'rgba(239, 68, 68, 0.1)' }}
                            title="Supprimer"
                          >
                            <Trash2 className="w-4 h-4" style={{ color: 'var(--error)' }} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </main>

      {/* Edit User Modal */}
      {showModal && editingUser && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-6 z-50 overflow-y-auto">
          <div className="rounded-3xl border p-8 max-w-4xl w-full my-8" style={{ backgroundColor: 'var(--bg-primary)', borderColor: 'var(--border-color)' }}>
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>Modifier l'utilisateur</h3>
              <button
                onClick={handleCloseModal}
                className="p-2 hover:opacity-80 rounded-xl transition-opacity"
                style={{ backgroundColor: 'var(--bg-secondary)' }}
              >
                <X className="w-6 h-6" style={{ color: 'var(--text-primary)' }} />
              </button>
            </div>

            <div className="mb-6 p-4 rounded-xl border" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
              <p className="text-sm mb-1" style={{ color: 'var(--text-muted)' }}>Email</p>
              <p className="font-medium" style={{ color: 'var(--text-primary)' }}>{editingUser.email}</p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                    Rôle *
                  </label>
                  <select
                    value={formData.role}
                    onChange={(e) => setFormData({ ...formData, role: e.target.value })}
                    className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                    style={{ 
                      backgroundColor: 'var(--bg-secondary)', 
                      borderColor: 'var(--border-color)', 
                      color: 'var(--text-primary)',
                      '--tw-ring-color': 'var(--primary)'
                    } as any}
                  >
                    <option value="user">user</option>
                    <option value="admin">admin</option>
                  </select>
                  <p className="text-xs mt-1" style={{ color: 'var(--text-muted)' }}>Le rôle de l'utilisateur dans l'application</p>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                    Type de rôle
                  </label>
                  <select
                    value={formData.role_type}
                    onChange={(e) => setFormData({ ...formData, role_type: e.target.value })}
                    className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                    style={{ 
                      backgroundColor: 'var(--bg-secondary)', 
                      borderColor: 'var(--border-color)', 
                      color: 'var(--text-primary)',
                      '--tw-ring-color': 'var(--primary)'
                    } as any}
                  >
                    <option value="client">client</option>
                    <option value="affiliate">affiliate</option>
                    <option value="moderator">moderator</option>
                    <option value="owner">owner</option>
                  </select>
                  <p className="text-xs mt-1" style={{ color: 'var(--text-muted)' }}>Type de rôle utilisateur</p>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                  Pays de résidence
                </label>
                <input
                  type="text"
                  value={formData.country}
                  onChange={(e) => setFormData({ ...formData, country: e.target.value })}
                  placeholder="Sénégal"
                  className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                  style={{ 
                    backgroundColor: 'var(--bg-secondary)', 
                    borderColor: 'var(--border-color)', 
                    color: 'var(--text-primary)',
                    '--tw-ring-color': 'var(--primary)'
                  } as any}
                />
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                    Statut de la demande d'affiliation
                  </label>
                  <select
                    value={formData.affiliate_status}
                    onChange={(e) => setFormData({ ...formData, affiliate_status: e.target.value })}
                    className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                    style={{ 
                      backgroundColor: 'var(--bg-secondary)', 
                      borderColor: 'var(--border-color)', 
                      color: 'var(--text-primary)',
                      '--tw-ring-color': 'var(--primary)'
                    } as any}
                  >
                    <option value="none">none</option>
                    <option value="pending">pending</option>
                    <option value="approved">approved</option>
                    <option value="rejected">rejected</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                    Code promo unique de l'affilié
                  </label>
                  <input
                    type="text"
                    value={formData.affiliate_code}
                    onChange={(e) => setFormData({ ...formData, affiliate_code: e.target.value.toUpperCase() })}
                    placeholder="MARTAMA2025"
                    className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2 uppercase"
                    style={{ 
                      backgroundColor: 'var(--bg-secondary)', 
                      borderColor: 'var(--border-color)', 
                      color: 'var(--text-primary)',
                      '--tw-ring-color': 'var(--primary)'
                    } as any}
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                  Taux de commission de l'affilié en %
                </label>
                <input
                  type="number"
                  value={formData.affiliate_commission_rate}
                  onChange={(e) => setFormData({ ...formData, affiliate_commission_rate: e.target.value })}
                  placeholder="30"
                  className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                  style={{ 
                    backgroundColor: 'var(--bg-secondary)', 
                    borderColor: 'var(--border-color)', 
                    color: 'var(--text-primary)',
                    '--tw-ring-color': 'var(--primary)'
                  } as any}
                />
                <p className="text-xs mt-1" style={{ color: 'var(--text-muted)' }}>Défaut: 30</p>
              </div>

              <div className="grid md:grid-cols-3 gap-6">
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                    Méthode de paiement préférée
                  </label>
                  <select
                    value={formData.payment_method}
                    onChange={(e) => setFormData({ ...formData, payment_method: e.target.value })}
                    className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                    style={{ 
                      backgroundColor: 'var(--bg-secondary)', 
                      borderColor: 'var(--border-color)', 
                      color: 'var(--text-primary)',
                      '--tw-ring-color': 'var(--primary)'
                    } as any}
                  >
                    <option value="">Sélectionner</option>
                    <option value="Wave">Wave</option>
                    <option value="Orange Money">Orange Money</option>
                    <option value="MTN Mobile Money">MTN Mobile Money</option>
                    <option value="Moov Money">Moov Money</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                    Numéro de compte Mobile Money
                  </label>
                  <input
                    type="text"
                    value={formData.payment_account_number}
                    onChange={(e) => setFormData({ ...formData, payment_account_number: e.target.value })}
                    placeholder="+221 XX XXX XX XX"
                    className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                    style={{ 
                      backgroundColor: 'var(--bg-secondary)', 
                      borderColor: 'var(--border-color)', 
                      color: 'var(--text-primary)',
                      '--tw-ring-color': 'var(--primary)'
                    } as any}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                    Nom sur le compte
                  </label>
                  <input
                    type="text"
                    value={formData.payment_account_name}
                    onChange={(e) => setFormData({ ...formData, payment_account_name: e.target.value })}
                    placeholder="Nom complet"
                    className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                    style={{ 
                      backgroundColor: 'var(--bg-secondary)', 
                      borderColor: 'var(--border-color)', 
                      color: 'var(--text-primary)',
                      '--tw-ring-color': 'var(--primary)'
                    } as any}
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-muted)' }}>
                  Niveau de fidélité
                </label>
                <select
                  value={formData.loyalty_tier}
                  onChange={(e) => setFormData({ ...formData, loyalty_tier: e.target.value })}
                  className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                  style={{ 
                    backgroundColor: 'var(--bg-secondary)', 
                    borderColor: 'var(--border-color)', 
                    color: 'var(--text-primary)',
                    '--tw-ring-color': 'var(--primary)'
                  } as any}
                >
                  <option value="">Aucun</option>
                  <option value="bronze">bronze</option>
                  <option value="silver">silver</option>
                  <option value="gold">gold</option>
                  <option value="platinum">platinum</option>
                </select>
              </div>

              <div className="flex items-center gap-3">
                <input
                  type="checkbox"
                  id="is_active"
                  checked={formData.is_active === 1}
                  onChange={(e) => setFormData({ ...formData, is_active: e.target.checked ? 1 : 0 })}
                  className="w-5 h-5 rounded"
                />
                <label htmlFor="is_active" className="font-medium" style={{ color: 'var(--text-primary)' }}>
                  Compte actif
                </label>
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="submit"
                  disabled={saving}
                  className="flex-1 flex items-center justify-center gap-2 px-6 py-3 rounded-xl font-semibold transition-colors text-white disabled:opacity-50"
                  style={{ backgroundColor: 'var(--primary)' }}
                >
                  <Save className="w-5 h-5" />
                  {saving ? "Enregistrement..." : "Enregistrer"}
                </button>
                <button
                  type="button"
                  onClick={handleCloseModal}
                  className="px-6 py-3 rounded-xl font-semibold transition-colors"
                  style={{ backgroundColor: 'var(--bg-secondary)', color: 'var(--text-primary)' }}
                >
                  Annuler
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete User Modal */}
      {showDeleteModal && deletingUser && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-6 z-50">
          <div className="rounded-3xl border p-8 max-w-md w-full" style={{ backgroundColor: 'var(--bg-primary)', borderColor: 'var(--border-color)' }}>
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>Supprimer l'utilisateur</h3>
              <button
                onClick={handleCloseDeleteModal}
                className="p-2 hover:opacity-80 rounded-xl transition-opacity"
                style={{ backgroundColor: 'var(--bg-secondary)' }}
              >
                <X className="w-6 h-6" style={{ color: 'var(--text-primary)' }} />
              </button>
            </div>

            <div className="mb-6">
              <p className="mb-4" style={{ color: 'var(--text-primary)' }}>
                Êtes-vous sûr de vouloir supprimer cet utilisateur ?
              </p>
              <div className="p-4 rounded-xl border" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
                <p className="text-sm mb-1" style={{ color: 'var(--text-muted)' }}>Email</p>
                <p className="font-medium" style={{ color: 'var(--text-primary)' }}>{deletingUser.email}</p>
                {deletingUser.full_name && (
                  <>
                    <p className="text-sm mb-1 mt-3" style={{ color: 'var(--text-muted)' }}>Nom</p>
                    <p className="font-medium" style={{ color: 'var(--text-primary)' }}>{deletingUser.full_name}</p>
                  </>
                )}
              </div>
              {deletingUser.affiliate_status === 'approved' && (
                <div className="mt-4 p-4 rounded-xl" style={{ backgroundColor: 'rgba(251, 191, 36, 0.1)', borderLeft: '4px solid var(--warning)' }}>
                  <p className="text-sm font-medium" style={{ color: 'var(--warning)' }}>
                    ⚠️ Cet utilisateur est un affilié. La suppression supprimera également toutes ses données d'affiliation (commissions, retraits, codes exceptionnels, etc.).
                  </p>
                </div>
              )}
            </div>

            <div className="flex gap-3">
              <button
                onClick={handleDelete}
                disabled={deleting}
                className="flex-1 flex items-center justify-center gap-2 px-6 py-3 rounded-xl font-semibold transition-colors text-white disabled:opacity-50"
                style={{ backgroundColor: 'var(--error)' }}
              >
                <Trash2 className="w-5 h-5" />
                {deleting ? "Suppression..." : "Supprimer"}
              </button>
              <button
                onClick={handleCloseDeleteModal}
                disabled={deleting}
                className="px-6 py-3 rounded-xl font-semibold transition-colors disabled:opacity-50"
                style={{ backgroundColor: 'var(--bg-secondary)', color: 'var(--text-primary)' }}
              >
                Annuler
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
