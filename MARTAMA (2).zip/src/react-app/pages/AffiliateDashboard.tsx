import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "@getmocha/users-service/react";
import Header from "@/react-app/components/Header";
import { 
  TrendingUp, 
  Users, 
  MousePointerClick, 
  Target,
  Copy,
  Edit,
  DollarSign,
  CheckCircle,
  ArrowRight,
  ExternalLink
} from "lucide-react";

interface AffiliateStats {
  id: number;
  promo_code: string;
  balance: number;
  total_clicks: number;
  total_sales: number;
  total_commissions: number;
  status: string;
}

export default function AffiliateDashboard() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [stats, setStats] = useState<AffiliateStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [showPromoEdit, setShowPromoEdit] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const loadFont = () => {
      const link = document.createElement("link");
      link.href = "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap";
      link.rel = "stylesheet";
      document.head.appendChild(link);
    };
    loadFont();
  }, []);

  useEffect(() => {
    if (user) {
      fetchAffiliateStats();
    }
  }, [user]);

  const fetchAffiliateStats = async () => {
    try {
      setLoading(true);
      const response = await fetch("/api/affiliate/stats");
      
      if (response.status === 404) {
        navigate("/become-affiliate");
        return;
      }
      
      const data = await response.json();
      setStats(data);
    } catch (error) {
      console.error("Failed to fetch affiliate stats:", error);
      navigate("/become-affiliate");
    } finally {
      setLoading(false);
    }
  };

  const copyPromoCode = () => {
    if (stats?.promo_code) {
      navigator.clipboard.writeText(stats.promo_code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const copyAffiliateLink = () => {
    if (stats?.promo_code) {
      const link = `${window.location.origin}/?ref=${stats.promo_code}`;
      navigator.clipboard.writeText(link);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleWithdrawalRequest = () => {
    navigate("/affiliate/withdrawal");
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: 'var(--bg-primary)' }}>
        <div className="text-center">
          <p className="text-xl mb-4" style={{ color: 'var(--text-primary)' }}>Veuillez vous connecter</p>
          <button
            onClick={() => navigate("/")}
            className="px-6 py-3 rounded-xl font-semibold"
            style={{ backgroundColor: 'var(--primary)', color: '#ffffff' }}
          >
            Retour à l'accueil
          </button>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: 'var(--bg-primary)' }}>
        <div className="w-12 h-12 border-4 rounded-full animate-spin" style={{ borderColor: 'var(--gray-200)', borderTopColor: 'var(--primary)' }}></div>
      </div>
    );
  }

  if (!stats) {
    return null;
  }

  const monthlyGoal = 10; // Example goal
  const goalProgress = (stats.total_sales / monthlyGoal) * 100;

  return (
    <div className="min-h-screen" style={{ fontFamily: "'Outfit', sans-serif", backgroundColor: 'var(--bg-primary)' }}>
      <Header showBackButton onBack={() => navigate("/dashboard")} />

      <main className="px-4 sm:px-6 py-6 sm:py-8 max-w-4xl mx-auto pb-24">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl sm:text-4xl font-bold mb-2" style={{ color: 'var(--text-primary)' }}>
            Bienvenue, {user.email?.split('@')[0]} !
          </h1>
          <p className="text-base sm:text-lg" style={{ color: 'var(--text-secondary)' }}>
            Prêt à booster vos commissions ?
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-3 sm:gap-4 mb-6">
          <div className="rounded-2xl p-4 sm:p-6 border" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs sm:text-sm font-medium" style={{ color: 'var(--text-muted)' }}>Commission totale</span>
              <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl flex items-center justify-center" style={{ backgroundColor: 'rgba(34, 197, 94, 0.1)' }}>
                <DollarSign className="w-4 h-4 sm:w-5 sm:h-5 text-green-500" />
              </div>
            </div>
            <div className="text-2xl sm:text-3xl font-bold mb-1" style={{ color: 'var(--text-primary)' }}>
              {stats.total_commissions.toLocaleString()} F
            </div>
            <div className="text-xs" style={{ color: 'var(--success)' }}>+5.1% depuis le mois dernier</div>
          </div>

          <div className="rounded-2xl p-4 sm:p-6 border" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs sm:text-sm font-medium" style={{ color: 'var(--text-muted)' }}>Ventes (ce mois)</span>
              <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl flex items-center justify-center" style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)' }}>
                <TrendingUp className="w-4 h-4 sm:w-5 sm:h-5" style={{ color: 'var(--primary)' }} />
              </div>
            </div>
            <div className="text-2xl sm:text-3xl font-bold mb-1" style={{ color: 'var(--text-primary)' }}>
              {stats.total_sales}
            </div>
            <div className="text-xs" style={{ color: 'var(--success)' }}>+10 depuis le mois dernier</div>
          </div>

          <div className="rounded-2xl p-4 sm:p-6 border" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs sm:text-sm font-medium" style={{ color: 'var(--text-muted)' }}>Clics sur le lien</span>
              <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl flex items-center justify-center" style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)' }}>
                <MousePointerClick className="w-4 h-4 sm:w-5 sm:h-5" style={{ color: 'var(--primary)' }} />
              </div>
            </div>
            <div className="text-2xl sm:text-3xl font-bold mb-1" style={{ color: 'var(--text-primary)' }}>
              {stats.total_clicks}
            </div>
            <div className="text-xs" style={{ color: 'var(--success)' }}>+150 depuis le mois dernier</div>
          </div>

          <div className="rounded-2xl p-4 sm:p-6 border" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs sm:text-sm font-medium" style={{ color: 'var(--text-muted)' }}>Objectif Mensuel</span>
              <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl flex items-center justify-center" style={{ backgroundColor: 'rgba(251, 191, 36, 0.1)' }}>
                <Target className="w-4 h-4 sm:w-5 sm:h-5 text-amber-500" />
              </div>
            </div>
            <div className="text-2xl sm:text-3xl font-bold mb-1" style={{ color: 'var(--text-primary)' }}>
              {Math.min(goalProgress, 100).toFixed(0)}%
            </div>
            <div className="text-xs" style={{ color: 'var(--text-muted)' }}>{stats.total_sales}/{monthlyGoal} ventes</div>
          </div>
        </div>

        {/* Promo Code Section */}
        <div className="rounded-2xl p-5 sm:p-6 mb-6 border" style={{ background: 'linear-gradient(135deg, rgba(139, 92, 246, 0.1) 0%, rgba(236, 72, 153, 0.1) 100%)', borderColor: 'rgba(139, 92, 246, 0.3)' }}>
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-base sm:text-lg font-bold mb-1" style={{ color: 'var(--text-primary)' }}>Votre Code Promo</h3>
              <p className="text-xs sm:text-sm" style={{ color: 'var(--text-secondary)' }}>
                Commission: 20% • Réduction client: 10%
              </p>
            </div>
            <button
              onClick={() => setShowPromoEdit(!showPromoEdit)}
              className="p-2 sm:p-2.5 rounded-xl hover:bg-white/50 transition-colors"
              style={{ backgroundColor: 'rgba(255, 255, 255, 0.2)' }}
            >
              <Edit className="w-4 h-4 sm:w-5 sm:h-5" style={{ color: 'var(--primary)' }} />
            </button>
          </div>

          <div className="flex items-center gap-3 p-4 sm:p-5 rounded-xl" style={{ backgroundColor: 'rgba(255, 255, 255, 0.5)' }}>
            <div className="flex-1">
              <div className="text-2xl sm:text-3xl font-bold tracking-wider font-mono" style={{ color: 'var(--primary)' }}>
                {stats.promo_code}
              </div>
              <div className="text-xs mt-1" style={{ color: 'var(--text-muted)' }}>Réduction de 10% pour vos clients</div>
            </div>
            <button
              onClick={copyPromoCode}
              className="px-4 py-2.5 sm:px-5 sm:py-3 rounded-xl font-semibold text-white transition-all flex items-center gap-2 text-sm sm:text-base"
              style={{ backgroundColor: 'var(--primary)' }}
            >
              {copied ? <CheckCircle className="w-4 h-4 sm:w-5 sm:h-5" /> : <Copy className="w-4 h-4 sm:w-5 sm:h-5" />}
              <span className="hidden sm:inline">{copied ? "Copié" : "Copier"}</span>
            </button>
          </div>
        </div>

        {/* Affiliate Link */}
        <div className="rounded-2xl p-5 sm:p-6 mb-6 border" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
          <h3 className="text-base sm:text-lg font-bold mb-3" style={{ color: 'var(--text-primary)' }}>
            Votre lien d'affiliation :
          </h3>
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 p-4 rounded-xl" style={{ backgroundColor: 'var(--gray-100)' }}>
            <div className="flex-1 overflow-x-auto">
              <code className="text-xs sm:text-sm font-mono break-all" style={{ color: 'var(--text-primary)' }}>
                {window.location.origin}/?ref={stats.promo_code}
              </code>
            </div>
            <button
              onClick={copyAffiliateLink}
              className="px-4 py-2.5 sm:px-5 sm:py-3 rounded-xl font-semibold transition-all flex items-center justify-center gap-2 whitespace-nowrap text-sm sm:text-base"
              style={{ backgroundColor: 'var(--primary)', color: '#ffffff' }}
            >
              {copied ? <CheckCircle className="w-4 h-4 sm:w-5 sm:h-5" /> : <Copy className="w-4 h-4 sm:w-5 sm:h-5" />}
              {copied ? "Copié !" : "Copier"}
            </button>
          </div>
        </div>

        {/* How It Works */}
        <div className="rounded-2xl p-5 sm:p-6 mb-6 border" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
          <h3 className="text-lg sm:text-xl font-bold mb-4" style={{ color: 'var(--text-primary)' }}>
            Comment ça marche ?
          </h3>
          <div className="space-y-4">
            <div className="flex items-start gap-3 sm:gap-4">
              <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-full flex items-center justify-center flex-shrink-0" style={{ backgroundColor: 'var(--primary)', color: '#ffffff' }}>
                <span className="font-bold text-sm sm:text-base">1</span>
              </div>
              <div className="flex-1">
                <h4 className="font-bold mb-1 text-sm sm:text-base" style={{ color: 'var(--text-primary)' }}>Partagez votre code</h4>
                <p className="text-xs sm:text-sm" style={{ color: 'var(--text-secondary)' }}>
                  Diffusez votre code promo unique sur vos réseaux sociaux, blog ou site web
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 sm:gap-4">
              <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-full flex items-center justify-center flex-shrink-0" style={{ backgroundColor: 'var(--primary)', color: '#ffffff' }}>
                <span className="font-bold text-sm sm:text-base">2</span>
              </div>
              <div className="flex-1">
                <h4 className="font-bold mb-1 text-sm sm:text-base" style={{ color: 'var(--text-primary)' }}>Vos clients économisent</h4>
                <p className="text-xs sm:text-sm" style={{ color: 'var(--text-secondary)' }}>
                  Ils bénéficient de 10% de réduction sur leur abonnement
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 sm:gap-4">
              <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-full flex items-center justify-center flex-shrink-0" style={{ backgroundColor: 'var(--primary)', color: '#ffffff' }}>
                <span className="font-bold text-sm sm:text-base">3</span>
              </div>
              <div className="flex-1">
                <h4 className="font-bold mb-1 text-sm sm:text-base" style={{ color: 'var(--text-primary)' }}>Vous gagnez des commissions</h4>
                <p className="text-xs sm:text-sm" style={{ color: 'var(--text-secondary)' }}>
                  Recevez 20% de commission sur chaque vente réalisée
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Available Balance */}
        <div className="rounded-2xl p-5 sm:p-6 mb-6 border" style={{ background: 'linear-gradient(135deg, rgba(139, 92, 246, 0.9) 0%, rgba(236, 72, 153, 0.9) 100%)', borderColor: 'transparent' }}>
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm font-semibold text-white/80">Solde Disponible</span>
            <DollarSign className="w-6 h-6 text-white/80" />
          </div>
          <div className="text-3xl sm:text-4xl font-bold text-white mb-1">
            {stats.balance.toLocaleString()} F
          </div>
          <div className="text-sm text-white/80 mb-5">
            Prêt à être retiré.
          </div>
          <button
            onClick={handleWithdrawalRequest}
            disabled={stats.balance < 2000}
            className="w-full px-6 py-3 sm:py-4 rounded-xl font-bold text-base sm:text-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            style={{ backgroundColor: 'rgba(255, 255, 255, 0.9)', color: 'var(--primary)' }}
          >
            Demander un paiement
            <ArrowRight className="w-5 h-5" />
          </button>
          {stats.balance < 2000 && (
            <p className="text-xs text-white/70 mt-2 text-center">
              Minimum 2,000 F requis pour un retrait
            </p>
          )}
        </div>

        {/* Financial Stats */}
        {(stats.total_commissions > 0 || stats.total_sales > 0) && (
          <div className="rounded-2xl p-5 sm:p-6 border" style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
            <h3 className="text-lg sm:text-xl font-bold mb-4" style={{ color: 'var(--text-primary)' }}>
              Historique des Gains
            </h3>
            
            <div className="space-y-3">
              <div className="flex items-center justify-between p-4 rounded-xl border" style={{ backgroundColor: 'rgba(139, 92, 246, 0.05)', borderColor: 'rgba(139, 92, 246, 0.2)' }}>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)' }}>
                    <TrendingUp className="w-5 h-5" style={{ color: 'var(--primary)' }} />
                  </div>
                  <div>
                    <div className="text-xs font-medium" style={{ color: 'var(--text-muted)' }}>Total gagné</div>
                    <div className="text-sm font-semibold" style={{ color: 'var(--text-secondary)' }}>Depuis le début</div>
                  </div>
                </div>
                <div className="text-xl font-bold" style={{ color: 'var(--text-primary)' }}>{stats.total_commissions.toLocaleString()} F</div>
              </div>
            </div>
          </div>
        )}
        
        {stats.total_commissions === 0 && stats.total_sales === 0 && (
          <div className="rounded-2xl p-8 border text-center" style={{ backgroundColor: 'rgba(139, 92, 246, 0.05)', borderColor: 'rgba(139, 92, 246, 0.2)' }}>
            <div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4" style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)' }}>
              <TrendingUp className="w-8 h-8" style={{ color: 'var(--primary)' }} />
            </div>
            <h3 className="text-lg font-bold mb-2" style={{ color: 'var(--text-primary)' }}>Prêt à générer vos premières commissions ?</h3>
            <p className="text-sm mb-4" style={{ color: 'var(--text-secondary)' }}>
              Partagez votre code promo et commencez à gagner de l'argent dès maintenant !
            </p>
            <button
              onClick={() => {
                if (stats.promo_code) {
                  navigator.clipboard.writeText(`${window.location.origin}/?ref=${stats.promo_code}`);
                }
              }}
              className="px-6 py-3 rounded-xl font-semibold text-white transition-all"
              style={{ backgroundColor: 'var(--primary)' }}
            >
              Copier mon lien d'affiliation
            </button>
          </div>
        )}

        {/* Quick Actions */}
        <div className="mt-6 space-y-3">
          <button
            onClick={() => navigate("/catalog")}
            className="w-full flex items-center justify-between p-4 rounded-xl border hover:border-opacity-50 transition-all"
            style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ backgroundColor: 'var(--gray-100)' }}>
                <ExternalLink className="w-5 h-5" style={{ color: 'var(--primary)' }} />
              </div>
              <span className="font-semibold text-sm sm:text-base" style={{ color: 'var(--text-primary)' }}>Voir le catalogue</span>
            </div>
            <ArrowRight className="w-5 h-5" style={{ color: 'var(--text-muted)' }} />
          </button>

          <button
            onClick={() => navigate("/profile")}
            className="w-full flex items-center justify-between p-4 rounded-xl border hover:border-opacity-50 transition-all"
            style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ backgroundColor: 'var(--gray-100)' }}>
                <Users className="w-5 h-5" style={{ color: 'var(--primary)' }} />
              </div>
              <span className="font-semibold text-sm sm:text-base" style={{ color: 'var(--text-primary)' }}>Mon profil</span>
            </div>
            <ArrowRight className="w-5 h-5" style={{ color: 'var(--text-muted)' }} />
          </button>
        </div>
      </main>
    </div>
  );
}
