import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { ArrowLeft, Plus, Upload, Trash2, Eye, EyeOff, MoveUp, MoveDown } from "lucide-react";

interface Testimonial {
  id: number;
  customer_name: string | null;
  screenshot_url: string;
  is_featured: number;
  display_order: number;
  created_at: string;
  updated_at: string;
}

export default function AdminTestimonials() {
  const navigate = useNavigate();
  const [testimonials, setTestimonials] = useState<Testimonial[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [formData, setFormData] = useState({
    customer_name: "",
    screenshot_url: "",
    is_featured: true,
  });

  useEffect(() => {
    const loadFont = () => {
      const link = document.createElement("link");
      link.href = "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap";
      link.rel = "stylesheet";
      document.head.appendChild(link);
    };
    loadFont();
  }, []);

  useEffect(() => {
    fetchTestimonials();
  }, []);

  const fetchTestimonials = async () => {
    try {
      setLoading(true);
      const response = await fetch("/api/admin/testimonials");
      
      if (response.status === 403) {
        navigate("/");
        return;
      }
      
      const data = await response.json();
      setTestimonials(data);
    } catch (error) {
      console.error("Failed to fetch testimonials:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setUploading(true);
      const formData = new FormData();
      formData.append("image", file);

      const response = await fetch("/api/admin/upload-image", {
        method: "POST",
        body: formData,
      });

      if (response.ok) {
        const data = await response.json();
        setFormData(prev => ({ ...prev, screenshot_url: data.url }));
      }
    } catch (error) {
      console.error("Upload failed:", error);
      alert("Échec du téléchargement de l'image");
    } finally {
      setUploading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.screenshot_url) {
      alert("Veuillez télécharger une capture d'écran");
      return;
    }

    try {
      const response = await fetch("/api/admin/testimonials", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });
      
      if (response.ok) {
        await fetchTestimonials();
        setShowForm(false);
        setFormData({
          customer_name: "",
          screenshot_url: "",
          is_featured: true,
        });
      }
    } catch (error) {
      console.error("Failed to save testimonial:", error);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Êtes-vous sûr de vouloir supprimer ce témoignage ?")) return;

    try {
      await fetch(`/api/admin/testimonials/${id}`, {
        method: "DELETE",
      });
      
      await fetchTestimonials();
    } catch (error) {
      console.error("Failed to delete testimonial:", error);
    }
  };

  const handleToggleFeatured = async (id: number, currentStatus: number) => {
    try {
      await fetch(`/api/admin/testimonials/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ is_featured: currentStatus === 1 ? 0 : 1 }),
      });
      
      await fetchTestimonials();
    } catch (error) {
      console.error("Failed to toggle testimonial:", error);
    }
  };

  const handleReorder = async (id: number, direction: 'up' | 'down') => {
    const index = testimonials.findIndex(t => t.id === id);
    if (index === -1) return;
    
    const newOrder = direction === 'up' ? index - 1 : index + 1;
    if (newOrder < 0 || newOrder >= testimonials.length) return;

    try {
      await fetch(`/api/admin/testimonials/${id}/reorder`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ new_order: newOrder }),
      });
      
      await fetchTestimonials();
    } catch (error) {
      console.error("Failed to reorder testimonial:", error);
    }
  };

  return (
    <div className="min-h-screen" style={{ fontFamily: "'Outfit', sans-serif", backgroundColor: 'var(--bg-primary)' }}>
      <header className="px-6 py-6 max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate("/admin")}
              className="p-2 hover:opacity-80 rounded-xl transition-opacity"
              style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)' }}
            >
              <ArrowLeft className="w-6 h-6" style={{ color: 'var(--primary)' }} />
            </button>
            <div>
              <h1 className="text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>
                Gestion des Témoignages
              </h1>
              <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
                Ajoutez et gérez les captures d'écran de témoignages clients
              </p>
            </div>
          </div>
          <button
            onClick={() => setShowForm(true)}
            className="flex items-center gap-2 px-6 py-3 rounded-xl font-semibold transition-all text-white"
            style={{ backgroundColor: 'var(--primary)' }}
          >
            <Plus className="w-5 h-5" />
            Ajouter un Témoignage
          </button>
        </div>
      </header>

      <main className="px-6 pb-12 max-w-7xl mx-auto">
        {loading ? (
          <div className="text-center py-20">
            <div className="inline-block w-12 h-12 border-4 rounded-full animate-spin" style={{ borderColor: 'var(--gray-200)', borderTopColor: 'var(--primary)' }}></div>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {testimonials.map((testimonial, index) => (
              <div
                key={testimonial.id}
                className="rounded-2xl border p-4 relative group"
                style={{ 
                  backgroundColor: 'var(--bg-secondary)', 
                  borderColor: testimonial.is_featured ? 'var(--primary)' : 'var(--border-color)',
                  borderWidth: testimonial.is_featured ? '2px' : '1px'
                }}
              >
                {/* Screenshot Preview */}
                <div className="rounded-xl overflow-hidden mb-4 border-2" style={{ borderColor: 'var(--border-color)' }}>
                  <img
                    src={testimonial.screenshot_url}
                    alt={testimonial.customer_name || "Témoignage"}
                    className="w-full h-auto object-cover"
                  />
                </div>

                {/* Customer Name */}
                {testimonial.customer_name && (
                  <p className="font-semibold mb-2" style={{ color: 'var(--text-primary)' }}>
                    {testimonial.customer_name}
                  </p>
                )}

                {/* Status Badge */}
                {testimonial.is_featured === 1 && (
                  <span className="inline-block px-3 py-1 rounded-full text-xs font-semibold bg-green-500/20 text-green-600 mb-3">
                    Affiché
                  </span>
                )}

                {/* Action Buttons */}
                <div className="flex gap-2">
                  <button
                    onClick={() => handleToggleFeatured(testimonial.id, testimonial.is_featured)}
                    className="flex-1 p-2 rounded-xl transition-colors"
                    style={{ 
                      backgroundColor: testimonial.is_featured ? 'rgba(239, 68, 68, 0.1)' : 'rgba(16, 185, 129, 0.1)',
                      color: testimonial.is_featured ? 'var(--error)' : 'var(--success)'
                    }}
                    title={testimonial.is_featured ? "Masquer" : "Afficher"}
                  >
                    {testimonial.is_featured ? <EyeOff className="w-5 h-5 mx-auto" /> : <Eye className="w-5 h-5 mx-auto" />}
                  </button>
                  
                  <button
                    onClick={() => handleReorder(testimonial.id, 'up')}
                    disabled={index === 0}
                    className="p-2 rounded-xl transition-colors disabled:opacity-30"
                    style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)', color: 'var(--primary)' }}
                    title="Monter"
                  >
                    <MoveUp className="w-5 h-5" />
                  </button>
                  
                  <button
                    onClick={() => handleReorder(testimonial.id, 'down')}
                    disabled={index === testimonials.length - 1}
                    className="p-2 rounded-xl transition-colors disabled:opacity-30"
                    style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)', color: 'var(--primary)' }}
                    title="Descendre"
                  >
                    <MoveDown className="w-5 h-5" />
                  </button>
                  
                  <button
                    onClick={() => handleDelete(testimonial.id)}
                    className="p-2 rounded-xl transition-colors"
                    style={{ backgroundColor: 'rgba(239, 68, 68, 0.1)', color: 'var(--error)' }}
                    title="Supprimer"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>

                <div className="text-xs mt-3" style={{ color: 'var(--text-muted)' }}>
                  Ajouté le {new Date(testimonial.created_at).toLocaleDateString('fr-FR')}
                </div>
              </div>
            ))}
            
            {testimonials.length === 0 && (
              <div className="col-span-full text-center py-20">
                <p className="text-xl mb-4" style={{ color: 'var(--text-muted)' }}>Aucun témoignage</p>
                <button
                  onClick={() => setShowForm(true)}
                  className="px-6 py-3 rounded-xl font-semibold text-white"
                  style={{ backgroundColor: 'var(--primary)' }}
                >
                  Ajouter le premier témoignage
                </button>
              </div>
            )}
          </div>
        )}
      </main>

      {/* Form Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-6 z-50">
          <div className="rounded-3xl border p-8 max-w-2xl w-full max-h-[90vh] overflow-y-auto" style={{ backgroundColor: 'var(--bg-primary)', borderColor: 'var(--border-color)' }}>
            <h3 className="text-2xl font-bold mb-6" style={{ color: 'var(--text-primary)' }}>
              Ajouter un Témoignage
            </h3>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-primary)' }}>
                  Nom du Client (optionnel)
                </label>
                <input
                  type="text"
                  value={formData.customer_name}
                  onChange={(e) => setFormData({ ...formData, customer_name: e.target.value })}
                  placeholder="Ex: Jean Dupont"
                  className="w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2"
                  style={{ 
                    backgroundColor: 'var(--bg-secondary)', 
                    borderColor: 'var(--border-color)', 
                    color: 'var(--text-primary)',
                    '--tw-ring-color': 'var(--primary)'
                  } as any}
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-primary)' }}>
                  Capture d'écran WhatsApp <span className="text-red-500">*</span>
                </label>
                <div className="border-2 border-dashed rounded-xl p-6 text-center" style={{ borderColor: 'var(--border-color)' }}>
                  {formData.screenshot_url ? (
                    <div className="space-y-4">
                      <img
                        src={formData.screenshot_url}
                        alt="Preview"
                        className="max-w-full h-auto mx-auto rounded-lg"
                        style={{ maxHeight: '300px' }}
                      />
                      <button
                        type="button"
                        onClick={() => setFormData({ ...formData, screenshot_url: "" })}
                        className="text-sm font-medium"
                        style={{ color: 'var(--error)' }}
                      >
                        Supprimer et choisir une autre image
                      </button>
                    </div>
                  ) : (
                    <div>
                      <Upload className="w-12 h-12 mx-auto mb-4" style={{ color: 'var(--text-muted)' }} />
                      <p className="mb-2" style={{ color: 'var(--text-primary)' }}>
                        {uploading ? "Téléchargement..." : "Cliquez pour télécharger"}
                      </p>
                      <p className="text-sm mb-4" style={{ color: 'var(--text-muted)' }}>
                        PNG, JPG jusqu'à 10MB
                      </p>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleFileUpload}
                        disabled={uploading}
                        className="hidden"
                        id="screenshot-upload"
                      />
                      <label
                        htmlFor="screenshot-upload"
                        className="inline-block px-6 py-3 rounded-xl font-semibold cursor-pointer text-white"
                        style={{ backgroundColor: 'var(--primary)' }}
                      >
                        Choisir une image
                      </label>
                    </div>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-3">
                <input
                  type="checkbox"
                  id="is_featured"
                  checked={formData.is_featured}
                  onChange={(e) => setFormData({ ...formData, is_featured: e.target.checked })}
                  className="w-5 h-5 rounded"
                  style={{ accentColor: 'var(--primary)' }}
                />
                <label htmlFor="is_featured" className="text-sm font-medium" style={{ color: 'var(--text-primary)' }}>
                  Afficher ce témoignage sur la page d'accueil
                </label>
              </div>

              <div className="flex gap-3">
                <button
                  type="submit"
                  disabled={!formData.screenshot_url || uploading}
                  className="flex-1 px-6 py-3 rounded-xl font-semibold transition-all text-white disabled:opacity-50"
                  style={{ backgroundColor: 'var(--primary)' }}
                >
                  Ajouter
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowForm(false);
                    setFormData({
                      customer_name: "",
                      screenshot_url: "",
                      is_featured: true,
                    });
                  }}
                  className="px-6 py-3 rounded-xl font-semibold transition-all"
                  style={{ backgroundColor: 'var(--bg-secondary)', color: 'var(--text-primary)' }}
                >
                  Annuler
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
