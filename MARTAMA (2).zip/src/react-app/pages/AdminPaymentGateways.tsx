import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { ArrowLeft, CheckCircle, XCircle } from "lucide-react";

interface PaymentGateway {
  id: number;
  gateway_name: string;
  display_name: string;
  is_enabled: number;
}

export default function AdminPaymentGateways() {
  const navigate = useNavigate();
  const [gateways, setGateways] = useState<PaymentGateway[]>([]);
  const [loading, setLoading] = useState(true);
  const [updating, setUpdating] = useState<number | null>(null);

  useEffect(() => {
    const loadFont = () => {
      const link = document.createElement("link");
      link.href = "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap";
      link.rel = "stylesheet";
      document.head.appendChild(link);
    };
    loadFont();
  }, []);

  useEffect(() => {
    fetchGateways();
  }, []);

  const fetchGateways = async () => {
    try {
      setLoading(true);
      const response = await fetch("/api/payment-gateways");
      
      if (response.status === 403) {
        navigate("/");
        return;
      }
      
      const data = await response.json();
      setGateways(data);
    } catch (error) {
      console.error("Failed to fetch payment gateways:", error);
    } finally {
      setLoading(false);
    }
  };

  const toggleGateway = async (id: number, currentStatus: number) => {
    try {
      setUpdating(id);
      const response = await fetch(`/api/admin/payment-gateways/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ is_enabled: currentStatus === 1 ? 0 : 1 }),
      });
      
      if (response.ok) {
        await fetchGateways();
      }
    } catch (error) {
      console.error("Failed to update gateway:", error);
    } finally {
      setUpdating(null);
    }
  };

  return (
    <div className="min-h-screen" style={{ fontFamily: "'Outfit', sans-serif", backgroundColor: 'var(--bg-primary)' }}>
      <header className="px-6 py-6 max-w-7xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <button
            onClick={() => navigate("/admin")}
            className="p-2 hover:opacity-80 rounded-xl transition-opacity"
            style={{ backgroundColor: 'rgba(139, 92, 246, 0.1)' }}
          >
            <ArrowLeft className="w-6 h-6" style={{ color: 'var(--primary)' }} />
          </button>
          <div>
            <h1 className="text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>
              Configuration des Passerelles de Paiement
            </h1>
            <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
              Activer ou désactiver les méthodes de paiement
            </p>
          </div>
        </div>
      </header>

      <main className="px-6 pb-12 max-w-7xl mx-auto">
        {loading ? (
          <div className="text-center py-20">
            <div className="inline-block w-12 h-12 border-4 rounded-full animate-spin" 
                 style={{ borderColor: 'var(--gray-200)', borderTopColor: 'var(--primary)' }}></div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="p-4 rounded-xl border" 
                 style={{ backgroundColor: 'rgba(59, 130, 246, 0.1)', borderColor: 'rgba(59, 130, 246, 0.2)' }}>
              <p className="text-sm" style={{ color: 'var(--info)' }}>
                💡 <strong>Important :</strong> Lorsque vous activez Lygos, n'oubliez pas d'ajouter les liens de paiement 
                pour chaque option de prix dans la configuration des produits.
              </p>
            </div>

            {gateways.map((gateway) => (
              <div
                key={gateway.id}
                className="rounded-2xl border p-6 flex items-center justify-between"
                style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}
              >
                <div className="flex items-center gap-4">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                    gateway.is_enabled === 1 ? 'bg-green-500/20' : 'bg-gray-500/20'
                  }`}>
                    {gateway.is_enabled === 1 ? (
                      <CheckCircle className="w-6 h-6 text-green-500" />
                    ) : (
                      <XCircle className="w-6 h-6" style={{ color: 'var(--text-muted)' }} />
                    )}
                  </div>
                  <div>
                    <h3 className="text-lg font-bold" style={{ color: 'var(--text-primary)' }}>
                      {gateway.display_name}
                    </h3>
                    <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
                      {gateway.is_enabled === 1 ? 'Activé' : 'Désactivé'}
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => toggleGateway(gateway.id, gateway.is_enabled)}
                  disabled={updating === gateway.id}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors disabled:opacity-50 ${
                    gateway.is_enabled === 1 ? 'bg-green-500' : 'bg-gray-300'
                  }`}
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                      gateway.is_enabled === 1 ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>
            ))}

            <div className="mt-8 p-6 rounded-2xl border" 
                 style={{ backgroundColor: 'var(--bg-secondary)', borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-bold mb-4" style={{ color: 'var(--text-primary)' }}>
                URL du Webhook Lygos
              </h3>
              <div className="flex items-center gap-3">
                <input
                  type="text"
                  value="https://martama.site/api/lygos/webhook"
                  readOnly
                  className="flex-1 px-4 py-3 rounded-xl border font-mono text-sm"
                  style={{ 
                    backgroundColor: 'var(--bg-primary)', 
                    borderColor: 'var(--border-color)',
                    color: 'var(--text-primary)'
                  }}
                />
                <button
                  onClick={() => {
                    navigator.clipboard.writeText("https://martama.site/api/lygos/webhook");
                    alert("URL copiée !");
                  }}
                  className="px-4 py-3 rounded-xl font-medium text-white"
                  style={{ backgroundColor: 'var(--primary)' }}
                >
                  Copier
                </button>
              </div>
              <p className="text-sm mt-3" style={{ color: 'var(--text-muted)' }}>
                Utilisez cette URL dans la configuration de votre compte Lygos pour recevoir les notifications de paiement.
              </p>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
