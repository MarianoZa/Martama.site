import { useEffect } from 'react';

const AFFILIATE_COOKIE_NAME = 'martama_ref';
const COOKIE_DURATION_DAYS = 30;

export function useAffiliateTracking() {
  useEffect(() => {
    // Check URL for affiliate code on mount
    const urlParams = new URLSearchParams(window.location.search);
    const refCode = urlParams.get('ref');
    
    if (refCode) {
      // Store affiliate code in cookie
      setAffiliateCookie(refCode);
      
      // Track click in backend
      trackAffiliateClick(refCode);
      
      // Clean URL without reloading page
      const newUrl = window.location.pathname;
      window.history.replaceState({}, '', newUrl);
    }
  }, []);
}

export function setAffiliateCookie(code: string) {
  const expires = new Date();
  expires.setDate(expires.getDate() + COOKIE_DURATION_DAYS);
  
  document.cookie = `${AFFILIATE_COOKIE_NAME}=${code}; expires=${expires.toUTCString()}; path=/; SameSite=Lax`;
}

export function getAffiliateCookie(): string | null {
  const cookies = document.cookie.split(';');
  
  for (const cookie of cookies) {
    const [name, value] = cookie.trim().split('=');
    if (name === AFFILIATE_COOKIE_NAME) {
      return value;
    }
  }
  
  return null;
}

export function clearAffiliateCookie() {
  document.cookie = `${AFFILIATE_COOKIE_NAME}=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;`;
}

async function trackAffiliateClick(code: string) {
  try {
    await fetch(`/api/affiliates/track-click?code=${code}`, {
      method: 'POST',
    });
  } catch (error) {
    console.error('Failed to track affiliate click:', error);
  }
}
