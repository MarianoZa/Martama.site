import { useEffect, useRef, useState } from 'react';

export function useNotificationSound() {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [lastCount, setLastCount] = useState(0);
  const [isEnabled, setIsEnabled] = useState(() => {
    const saved = localStorage.getItem('notifications_sound_enabled');
    return saved !== 'false'; // Enabled by default
  });

  useEffect(() => {
    // Create audio element for notification sound
    // Using a simple tone - in production you might want a better sound file
    audioRef.current = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBSuBzvLZiTcIGWi77eefTRAMUKfj8LZjHAY4ktfyy3ksBSR3x/DdkEAKFF606+uoVRQKRp/g8r5sIQUrgs/y2Yk3CBlou+3nn00QDFC');
    
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
    };
  }, []);

  const playNotificationSound = () => {
    if (isEnabled && audioRef.current) {
      audioRef.current.currentTime = 0;
      audioRef.current.play().catch(err => {
        console.error('Failed to play notification sound:', err);
      });
    }
  };

  const checkForNewOrders = async () => {
    try {
      const response = await fetch('/api/admin/notifications/unread-count');
      if (response.ok) {
        const data = await response.json();
        const currentCount = data.count || 0;
        
        // Play sound if there are new notifications
        if (currentCount > lastCount && lastCount !== 0) {
          playNotificationSound();
        }
        
        setLastCount(currentCount);
        return currentCount;
      }
    } catch (error) {
      console.error('Failed to check notifications:', error);
    }
    return 0;
  };

  const toggleSound = () => {
    const newValue = !isEnabled;
    setIsEnabled(newValue);
    localStorage.setItem('notifications_sound_enabled', String(newValue));
  };

  return {
    checkForNewOrders,
    playNotificationSound,
    isEnabled,
    toggleSound,
    unreadCount: lastCount,
  };
}
