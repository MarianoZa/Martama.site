import { BrowserRouter as Router, Routes, Route } from "react-router";
import { AuthProvider } from "@getmocha/users-service/react";
import { ThemeProvider } from "@/react-app/context/ThemeContext";
import { useToast } from "@/react-app/hooks/useToast";
import ToastContainer from "@/react-app/components/ToastContainer";
import WhatsAppButton from "@/react-app/components/WhatsAppButton";
import HomePage from "@/react-app/pages/Home";
import AuthCallbackPage from "@/react-app/pages/AuthCallback";
import CatalogPage from "@/react-app/pages/Catalog";
import ProductDetailPage from "@/react-app/pages/ProductDetail";
import UserDashboard from "@/react-app/pages/UserDashboard";
import UserProfile from "@/react-app/pages/UserProfile";
import AdminDashboard from "@/react-app/pages/AdminDashboard";
import AdminOrders from "@/react-app/pages/AdminOrders";
import AdminProducts from "@/react-app/pages/AdminProducts";
import AdminAffiliates from "@/react-app/pages/AdminAffiliates";
import AdminUsers from "@/react-app/pages/AdminUsers";
import AdminPayments from "@/react-app/pages/AdminPayments";
import AdminAddAffiliate from "@/react-app/pages/AdminAddAffiliate";
import AdminAnnouncement from "@/react-app/pages/AdminAnnouncement";
import AdminExceptionalCodes from "@/react-app/pages/AdminExceptionalCodes";
import AdminPaymentGateways from "@/react-app/pages/AdminPaymentGateways";
import AdminTestimonials from "@/react-app/pages/AdminTestimonials";
import BecomeAffiliate from "@/react-app/pages/BecomeAffiliate";
import AffiliateDashboard from "@/react-app/pages/AffiliateDashboard";
import PostPurchaseAuth from "@/react-app/pages/PostPurchaseAuth";
import HelpCenter from "@/react-app/pages/HelpCenter";

function AppContent() {
  const { toasts, removeToast } = useToast();

  return (
    <>
      <Router>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/auth/callback" element={<AuthCallbackPage />} />
          <Route path="/auth/post-purchase" element={<PostPurchaseAuth />} />
          <Route path="/catalog" element={<CatalogPage />} />
          <Route path="/products/:id" element={<ProductDetailPage />} />
          <Route path="/dashboard" element={<UserDashboard />} />
          <Route path="/profile" element={<UserProfile />} />
          <Route path="/admin" element={<AdminDashboard />} />
          <Route path="/admin/orders" element={<AdminOrders />} />
          <Route path="/admin/products" element={<AdminProducts />} />
          <Route path="/admin/affiliates" element={<AdminAffiliates />} />
          <Route path="/admin/affiliates/add" element={<AdminAddAffiliate />} />
          <Route path="/admin/users" element={<AdminUsers />} />
          <Route path="/admin/payments" element={<AdminPayments />} />
          <Route path="/admin/announcement" element={<AdminAnnouncement />} />
          <Route path="/admin/exceptional-codes" element={<AdminExceptionalCodes />} />
          <Route path="/admin/payment-gateways" element={<AdminPaymentGateways />} />
          <Route path="/admin/testimonials" element={<AdminTestimonials />} />
          <Route path="/become-affiliate" element={<BecomeAffiliate />} />
          <Route path="/affiliate/dashboard" element={<AffiliateDashboard />} />
          <Route path="/help" element={<HelpCenter />} />
        </Routes>
      </Router>
      <ToastContainer toasts={toasts} onRemove={removeToast} />
      <WhatsAppButton />
    </>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </ThemeProvider>
  );
}
