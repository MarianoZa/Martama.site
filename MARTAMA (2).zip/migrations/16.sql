
CREATE TABLE lygos_webhooks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  event_id TEXT NOT NULL UNIQUE,
  order_id INTEGER,
  transaction_id TEXT,
  status TEXT,
  amount REAL,
  raw_payload TEXT,
  processed BOOLEAN DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
