
DROP INDEX idx_affiliate_requests_status;
DROP TABLE affiliate_requests;
DROP INDEX idx_inventory_product_used;
DROP TABLE inventory;
