
DROP TABLE lygos_webhooks;
