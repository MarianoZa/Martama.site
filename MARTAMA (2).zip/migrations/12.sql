
-- Table pour la barre d'annonces éditable
CREATE TABLE announcement_bar (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  message TEXT NOT NULL,
  promo_code TEXT,
  link_url TEXT,
  is_active INTEGER DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Insérer la barre d'annonces actuelle par défaut
INSERT INTO announcement_bar (message, promo_code, is_active) 
VALUES ('🎉 Ne soyez pas celui qui a raté les 40%', 'MRLATO', 1);
