
ALTER TABLE commissions DROP COLUMN commission_rate;
ALTER TABLE commissions DROP COLUMN purchase_number;
