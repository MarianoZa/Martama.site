
-- Add price_options column to store flexible pricing as JSON
ALTER TABLE products ADD COLUMN price_options TEXT;
