
-- Add usage_instructions field to products table
ALTER TABLE products ADD COLUMN usage_instructions TEXT;
