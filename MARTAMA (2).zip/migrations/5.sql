
-- Add new user management fields to support the enhanced user system
ALTER TABLE users ADD COLUMN role_type TEXT DEFAULT 'client';
ALTER TABLE users ADD COLUMN affiliate_status TEXT DEFAULT 'none';
ALTER TABLE users ADD COLUMN affiliate_code TEXT;
ALTER TABLE users ADD COLUMN affiliate_commission_rate INTEGER DEFAULT 30;
ALTER TABLE users ADD COLUMN payment_method TEXT;
ALTER TABLE users ADD COLUMN payment_account_number TEXT;
ALTER TABLE users ADD COLUMN payment_account_name TEXT;
ALTER TABLE users ADD COLUMN loyalty_points INTEGER DEFAULT 0;
ALTER TABLE users ADD COLUMN loyalty_tier TEXT;
ALTER TABLE users ADD COLUMN country TEXT;
ALTER TABLE users ADD COLUMN is_active BOOLEAN DEFAULT 1;
ALTER TABLE users ADD COLUMN unique_identifier TEXT;

-- Update existing admin emails to have correct role
UPDATE users SET role = 'admin' 
WHERE email IN ('bnb887991@gmail.com', 'arsuzannou@gmail.com', 'thelucidshadow7@gmail.com');
