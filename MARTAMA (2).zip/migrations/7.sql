
CREATE TABLE customer_purchase_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_email TEXT NOT NULL,
  affiliate_id INTEGER,
  first_purchase_date DATETIME,
  total_purchases INTEGER DEFAULT 1,
  used_promo_previously BOOLEAN DEFAULT 0,
  previous_discount_rate REAL,
  current_commission_tier INTEGER DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (affiliate_id) REFERENCES affiliates(id)
);

CREATE INDEX idx_customer_email ON customer_purchase_history(customer_email);
CREATE INDEX idx_customer_affiliate ON customer_purchase_history(customer_email, affiliate_id);
