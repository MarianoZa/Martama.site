
CREATE TABLE inventory (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  product_id INTEGER NOT NULL,
  access_credentials TEXT NOT NULL,
  is_used INTEGER DEFAULT 0,
  order_id INTEGER,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (product_id) REFERENCES products(id),
  FOREIGN KEY (order_id) REFERENCES orders(id)
);

CREATE INDEX idx_inventory_product_used ON inventory(product_id, is_used);

CREATE TABLE affiliate_requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  promo_code TEXT NOT NULL,
  specialty TEXT,
  audience_size TEXT,
  social_links TEXT,
  motivation TEXT,
  payment_method TEXT,
  status TEXT DEFAULT 'pending',
  admin_notes TEXT,
  reviewed_by TEXT,
  reviewed_at DATETIME,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE INDEX idx_affiliate_requests_status ON affiliate_requests(status);
