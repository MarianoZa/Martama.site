
DROP INDEX idx_exceptional_codes_active;
DROP INDEX idx_exceptional_codes_code;
DROP TABLE exceptional_promo_codes;
