
ALTER TABLE commissions ADD COLUMN purchase_number INTEGER DEFAULT 1;
ALTER TABLE commissions ADD COLUMN commission_rate REAL;
