
DROP TABLE announcement_bar;
