
DROP TABLE payment_gateways;
