
-- Revert admin status for the specified emails
UPDATE users SET role = 'user' 
WHERE email IN ('bnb887991@gmail.com', 'arsuzannou@gmail.com', 'thelucidshadow7@gmail.com');

-- Remove added columns in reverse order
ALTER TABLE users DROP COLUMN unique_identifier;
ALTER TABLE users DROP COLUMN is_active;
ALTER TABLE users DROP COLUMN country;
ALTER TABLE users DROP COLUMN loyalty_tier;
ALTER TABLE users DROP COLUMN loyalty_points;
ALTER TABLE users DROP COLUMN payment_account_name;
ALTER TABLE users DROP COLUMN payment_account_number;
ALTER TABLE users DROP COLUMN payment_method;
ALTER TABLE users DROP COLUMN affiliate_commission_rate;
ALTER TABLE users DROP COLUMN affiliate_code;
ALTER TABLE users DROP COLUMN affiliate_status;
ALTER TABLE users DROP COLUMN role_type;
